package com.aistudio.worldcamai.smxuqv

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun verify_universal1024Scaling_formatSecureHttpsMediaUrl() {
        // 1. Raw unscaled upload.wikimedia.org URL -> converts to 1024px Special:FilePath stream
        val rawUnscaled = "https://upload.wikimedia.org/wikipedia/commons/b/bf/CITY_MALL%2CKOTA%2CRAJASTHAN%2CINDIA.JPG"
        val scaledFromRaw = formatSecureHttpsMediaUrl(rawUnscaled)
        assertEquals(
            "https://commons.wikimedia.org/wiki/Special:FilePath/CITY_MALL%2CKOTA%2CRAJASTHAN%2CINDIA.JPG?width=1024",
            scaledFromRaw
        )

        // 2. Existing oversized thumbnail (1920px) -> normalized to 1024px
        val raw1920 = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Albert_Hall_Museum%2C_Jaipur.jpg/1920px-Albert_Hall_Museum%2C_Jaipur.jpg"
        val scaledFrom1920 = formatSecureHttpsMediaUrl(raw1920)
        assertTrue("Must scale 1920px to 1024px", scaledFrom1920.contains("/1024px-"))

        // 3. Special:FilePath URL without width or with other width -> enforces ?width=1024
        val specialFilePath = "https://commons.wikimedia.org/wiki/Special:FilePath/Eiffel_Tower.jpg"
        val scaledSpecial = formatSecureHttpsMediaUrl(specialFilePath)
        assertEquals("https://commons.wikimedia.org/wiki/Special:FilePath/Eiffel_Tower.jpg?width=1024", scaledSpecial)

        val specialFilePath1920 = "https://commons.wikimedia.org/wiki/Special:FilePath/Eiffel_Tower.jpg?width=1920"
        val scaledSpecial1920 = formatSecureHttpsMediaUrl(specialFilePath1920)
        assertEquals("https://commons.wikimedia.org/wiki/Special:FilePath/Eiffel_Tower.jpg?width=1024", scaledSpecial1920)
        println("formatSecureHttpsMediaUrl scaling verification passed!")
    }

    @Test
    fun verify_extractSecureMediaUrlFromJson_prioritizes1024pxThumbnail() {
        val sampleJson = JSONObject("""
            {
                "thumbnail": {
                    "source": "https://thumb.wikimedia.org/wikipedia/commons/thumb/8/85/Tour_Eiffel.jpg/1024px-Tour_Eiffel.jpg",
                    "width": 1024,
                    "height": 1705
                },
                "original": {
                    "source": "https://upload.wikimedia.org/wikipedia/commons/8/85/Tour_Eiffel_Huge_Original_15MB.jpg",
                    "width": 6000,
                    "height": 8000
                }
            }
        """.trimIndent())

        val resolved = extractSecureMediaUrlFromJson(sampleJson)
        // Must select the 1024px thumbnail source, NOT the 15MB original
        assertTrue("Must select 1024px thumbnail source", resolved.contains("1024px-Tour_Eiffel.jpg"))
        assertFalse("Must NOT select unscaled original", resolved.contains("Huge_Original_15MB"))
        println("extractSecureMediaUrlFromJson prioritizes 1024px thumbnail: $resolved")
    }

    @Test
    fun verify_cityMallKota_resolvesInUniversalLocationResolver() {
        val result = UniversalLocationResolver.resolve("City Mall, Kota")
        assertNotNull("UniversalLocationResolver must resolve 'City Mall, Kota'", result)
        assertEquals("city_mall_kota", result?.id)
        assertEquals("City Mall, Kota", result?.officialTitle)
        assertTrue(
            "Photo URL should point to Wikimedia image",
            result?.photoUrl?.contains("wikimedia.org") == true
        )
        val scaledUrl = formatSecureHttpsMediaUrl(result?.photoUrl)
        assertTrue("Photo URL must scale to 1024px", scaledUrl.contains("width=1024") || scaledUrl.contains("1024px"))
        println("UniversalLocationResolver -> id: ${result?.id}, title: ${result?.officialTitle}, photoUrl: $scaledUrl")
    }

    @Test
    fun verify_cityMallKota_resolvesInCompressedLocationIndex() {
        val location = CompressedLocationIndex.resolveLocation("City Mall, Kota")
        assertNotNull(location)
        assertEquals("City Mall, Kota", location.name)
        assertTrue(
            "CompressedLocationIndex must resolve to 1024px scaled Wikimedia stream",
            location.photoUrl.contains("width=1024")
        )
        println("CompressedLocationIndex -> name: ${location.name}, photoUrl: ${location.photoUrl}")
    }

    @Test
    fun verify_anyWorldLocation_compressedIndexHas1024Width() {
        val locTokyo = CompressedLocationIndex.resolveLocation("Shinjuku Gyoen Tokyo")
        assertTrue("Any world location must have ?width=1024 stream", locTokyo.photoUrl.contains("width=1024"))

        val locMachuPicchu = CompressedLocationIndex.resolveLocation("Machu Picchu Peru")
        assertTrue("Any world location must have ?width=1024 stream", locMachuPicchu.photoUrl.contains("width=1024"))

        val locZurich = CompressedLocationIndex.resolveLocation("Lake Zurich Switzerland")
        assertTrue("Any world location must have ?width=1024 stream", locZurich.photoUrl.contains("width=1024"))
    }

    @Test
    fun verify_1024pxThumbnail_networkPayload_between100KbAnd300Kb() {
        val targetUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/CITY_MALL%2CKOTA%2CRAJASTHAN%2CINDIA.JPG?width=1024"
        val client = OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()

        val request = Request.Builder()
            .url(targetUrl)
            .header("User-Agent", "WorldCamAI/2.0 (OpenStreetMap; Wikimedia; Android; support@worldcamai.open)")
            .header("Accept", "image/jpeg,image/*")
            .build()

        val startMs = System.currentTimeMillis()
        val response = client.newCall(request).execute()
        val durationMs = System.currentTimeMillis() - startMs

        assertEquals(200, response.code)
        val bodyBytes = response.body?.bytes()
        assertNotNull("Response body must not be null", bodyBytes)
        val payloadSize = bodyBytes!!.size
        val payloadKb = payloadSize / 1024

        println("1024px Wikimedia Stream Response:")
        println(" - Status Code: ${response.code} OK")
        println(" - Payload size: $payloadSize bytes ($payloadKb KB)")
        println(" - Delivery duration: ${durationMs}ms")

        // Assert payload remains strictly within high-efficiency mobile target (100KB - 300KB)
        assertTrue(
            "Payload ($payloadKb KB) should be strictly between 100KB and 300KB for mobile efficiency",
            payloadKb in 100..300
        )
        assertTrue("Network delivery should be under 2000ms", durationMs < 2000)
    }
}

package com.aistudio.worldcamai.smxuqv

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun verify_universal1024Scaling_formatSecureHttpsMediaUrl() {
        val rawUnscaled = "https://upload.wikimedia.org/wikipedia/commons/b/bf/CITY_MALL%2CKOTA%2CRAJASTHAN%2CINDIA.JPG"
        val scaledFromRaw = formatSecureHttpsMediaUrl(rawUnscaled)
        assertEquals(
            "https://commons.wikimedia.org/wiki/Special:FilePath/CITY_MALL%2CKOTA%2CRAJASTHAN%2CINDIA.JPG?width=1024",
            scaledFromRaw
        )

        val raw1920 = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Albert_Hall_Museum%2C_Jaipur.jpg/1920px-Albert_Hall_Museum%2C_Jaipur.jpg"
        val scaledFrom1920 = formatSecureHttpsMediaUrl(raw1920)
        assertTrue("Must scale 1920px to 1024px", scaledFrom1920.contains("/1024px-"))

        val specialFilePath = "https://commons.wikimedia.org/wiki/Special:FilePath/Eiffel_Tower.jpg"
        val scaledSpecial = formatSecureHttpsMediaUrl(specialFilePath)
        assertEquals("https://commons.wikimedia.org/wiki/Special:FilePath/Eiffel_Tower.jpg?width=1024", scaledSpecial)
    }

    @Test
    fun verify_extractSecureMediaUrlFromJson_prioritizes1024pxThumbnail() {
        val sampleJson = JSONObject("""
            {
                "thumbnail": {
                    "source": "https://thumb.wikimedia.org/wikipedia/commons/thumb/8/85/Tour_Eiffel.jpg/1024px-Tour_Eiffel.jpg",
                    "width": 1024,
                    "height": 1705
                },
                "original": {
                    "source": "https://upload.wikimedia.org/wikipedia/commons/8/85/Tour_Eiffel_Huge_Original_15MB.jpg",
                    "width": 6000,
                    "height": 8000
                }
            }
        """.trimIndent())
        val resolved = extractSecureMediaUrlFromJson(sampleJson)
        assertTrue("Must select 1024px thumbnail source", resolved.contains("1024px-Tour_Eiffel.jpg"))
        assertFalse("Must NOT select unscaled original", resolved.contains("Huge_Original_15MB"))
    }

    @Test
    fun verify_universalLocationResolver() {
        val result = UniversalLocationResolver.resolve("City Mall, Kota")
        assertNotNull("UniversalLocationResolver must resolve 'City Mall, Kota'", result)
        assertEquals("city_mall_kota", result?.id)
        assertEquals("City Mall, Kota", result?.officialTitle)
    }

    @Test
    fun verify_all12PaymentUrls_areAbsoluteAndExact() {
        assertEquals(12, RazorpayManager.PLANS.size)
        assertEquals(6, RazorpayManager.INDIA_PLANS.size)
        assertEquals(6, RazorpayManager.WORLD_PLANS.size)

        // Exact India links
        assertEquals("https://rzp.io/rzp/ebwNSjH", RazorpayManager.PAYMENT_ROUTING_MAP["india_5_photos"])
        assertEquals("https://rzp.io/rzp/zQOBrCt", RazorpayManager.PAYMENT_ROUTING_MAP["india_13_photos"])
        assertEquals("https://rzp.io/rzp/wKIIcaZ", RazorpayManager.PAYMENT_ROUTING_MAP["india_15days_premium"])
        assertEquals("https://rzp.io/rzp/txaaWyi", RazorpayManager.PAYMENT_ROUTING_MAP["india_1month_premium"])
        assertEquals("https://rzp.io/rzp/q6tSCV8", RazorpayManager.PAYMENT_ROUTING_MAP["india_watermark_unlock"])
        assertEquals("https://rzp.io/rzp/6khwDwD", RazorpayManager.PAYMENT_ROUTING_MAP["india_postcard_unlock"])

        // Exact World links
        assertEquals("https://rzp.io/rzp/25yRR8d", RazorpayManager.PAYMENT_ROUTING_MAP["world_5_photos"])
        assertEquals("https://rzp.io/rzp/atC87HP", RazorpayManager.PAYMENT_ROUTING_MAP["world_13_photos"])
        assertEquals("https://rzp.io/rzp/M0QdxN0d", RazorpayManager.PAYMENT_ROUTING_MAP["world_15days_premium"])
        assertEquals("https://rzp.io/rzp/F1wKGxV", RazorpayManager.PAYMENT_ROUTING_MAP["world_1month_premium"])
        assertEquals("https://rzp.io/rzp/gPUFEVSt", RazorpayManager.PAYMENT_ROUTING_MAP["world_watermark_unlock"])
        assertEquals("https://rzp.io/rzp/K32UNo0s", RazorpayManager.PAYMENT_ROUTING_MAP["world_postcard_unlock"])
    }

    @Test
    fun verify_regionFiltering_displaysOnly6Plans() {
        val filteredPlans = RazorpayManager.getRegionFilteredPlans()
        assertEquals(6, filteredPlans.size)
        assertTrue(filteredPlans.all { it.paymentUrl.startsWith("https://rzp.io/rzp/") })
    }
}

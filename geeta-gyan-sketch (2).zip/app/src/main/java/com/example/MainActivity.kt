package com.example

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.WorldCamAITheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import kotlin.math.roundToInt

data class LandmarkPreset(
    val id: String,
    val name: String,
    val location: String,
    val drawableRes: Int,
    val sunAngleDeg: Float,
    val lightWarmth: Float, // -1.0 (cool) to 1.0 (warm)
    val hasWaterReflection: Boolean = false,
    val surfaceType: String = "GROUND" // "GROUND", "WATER", "MARBLE"
)

val PRESET_LANDMARKS = listOf(
    LandmarkPreset(
        id = "ram_mandir",
        name = "Ayodhya Ram Mandir",
        location = "Ayodhya, Uttar Pradesh, India",
        drawableRes = R.drawable.bg_ayodhya_ram_mandir_1,
        sunAngleDeg = 45f,
        lightWarmth = 0.85f,
        hasWaterReflection = false,
        surfaceType = "MARBLE"
    ),
    LandmarkPreset(
        id = "taj_mahal",
        name = "Taj Mahal",
        location = "Agra, Uttar Pradesh, India",
        drawableRes = R.drawable.img_taj_mahal_blended,
        sunAngleDeg = 120f,
        lightWarmth = 0.25f,
        hasWaterReflection = true,
        surfaceType = "WATER"
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WorldCamAITheme {
                WorldCamApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorldCamApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Active landmark preset (defaults to Ayodhya Ram Mandir)
    var activePreset by remember { mutableStateOf(PRESET_LANDMARKS[0]) }
    var searchQuery by remember { mutableStateOf("") }

    // User portrait state
    var userPortraitUri by remember { mutableStateOf<Uri?>(null) }
    var userPortraitBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var mattedPortraitBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isMattingLoading by remember { mutableStateOf(false) }

    // Interactive Placement & Transform Controls
    var subjectScale by remember { mutableFloatStateOf(1.0f) }
    var subjectOffsetX by remember { mutableFloatStateOf(0f) }
    var subjectOffsetY by remember { mutableFloatStateOf(180f) }
    var isFlippedHorizontally by remember { mutableStateOf(false) }

    // Relighting & Shadow Controls
    var shadowIntensity by remember { mutableFloatStateOf(0.90f) }
    var lightWarmthAdjustment by remember { mutableFloatStateOf(0.5f) }
    var dofBokehLevel by remember { mutableFloatStateOf(0.40f) }
    var waterReflectionAlpha by remember { mutableFloatStateOf(0.40f) }

    // UI state
    var showAdjustPanel by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }

    // Load default sample portrait on first launch
    LaunchedEffect(Unit) {
        scope.launch(Dispatchers.IO) {
            try {
                val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val defaultBmp = BitmapFactory.decodeResource(context.resources, R.drawable.img_user_portrait, opts)
                if (defaultBmp != null) {
                    val matted = extractSubjectPrecise(defaultBmp)
                    withContext(Dispatchers.Main) {
                        userPortraitBitmap = defaultBmp
                        mattedPortraitBitmap = matted
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Gallery Picker launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            userPortraitUri = uri
            isMattingLoading = true
            scope.launch(Dispatchers.IO) {
                try {
                    val stream: InputStream? = context.contentResolver.openInputStream(uri)
                    val original = BitmapFactory.decodeStream(stream)
                    stream?.close()
                    if (original != null) {
                        val matted = extractSubjectPrecise(original)
                        withContext(Dispatchers.Main) {
                            userPortraitBitmap = original
                            mattedPortraitBitmap = matted
                            isMattingLoading = false
                            Toast.makeText(context, "Portrait loaded & matting completed!", Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        isMattingLoading = false
                        Toast.makeText(context, "Failed to load image: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    // FORCE LOCAL ASSET OVERRIDE SEARCH LOGIC
    fun performLocalAssetSearch(query: String) {
        val q = query.trim().lowercase()
        if (q.contains("ram") || q.contains("mandir") || q.contains("ayodhya") || q.contains("temple")) {
            activePreset = PRESET_LANDMARKS[0] // Ayodhya Ram Mandir
            Toast.makeText(context, "Loaded: Ayodhya Ram Mandir (Instant Local Asset)", Toast.LENGTH_SHORT).show()
        } else if (q.contains("taj") || q.contains("mahal") || q.contains("agra") || q.contains("water") || q.contains("pool")) {
            activePreset = PRESET_LANDMARKS[1] // Taj Mahal
            Toast.makeText(context, "Loaded: Taj Mahal (Instant Local Asset)", Toast.LENGTH_SHORT).show()
        } else {
            // Default fallback or matching
            val match = PRESET_LANDMARKS.find { it.name.lowercase().contains(q) || it.location.lowercase().contains(q) }
            if (match != null) {
                activePreset = match
                Toast.makeText(context, "Loaded: ${match.name}", Toast.LENGTH_SHORT).show()
            } else {
                // If unknown query, switch to Ram Mandir by default to prevent black screen
                activePreset = PRESET_LANDMARKS[0]
                Toast.makeText(context, "Loaded landmark: Ayodhya Ram Mandir", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F172A))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "WorldCam AI",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E5FF)
                        )
                        Text(
                            text = "Instant Photorealistic Grounding & Asset Engine",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    Row {
                        IconButton(
                            onClick = { showAdjustPanel = !showAdjustPanel },
                            modifier = Modifier
                                .testTag("adjust_controls_button")
                                .background(
                                    if (showAdjustPanel) Color(0xFF00E5FF).copy(alpha = 0.2f) else Color(0xFF1E293B),
                                    CircleShape
                                )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "Adjust settings",
                                tint = if (showAdjustPanel) Color(0xFF00E5FF) else Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                isSaving = true
                                scope.launch(Dispatchers.IO) {
                                    val bgBmp = BitmapFactory.decodeResource(context.resources, activePreset.drawableRes)
                                    val fgBmp = mattedPortraitBitmap ?: userPortraitBitmap
                                    if (bgBmp != null && fgBmp != null) {
                                        val composite = renderLosslessMasterComposite(
                                            background = bgBmp,
                                            subject = fgBmp,
                                            scale = subjectScale,
                                            offsetX = subjectOffsetX,
                                            offsetY = subjectOffsetY,
                                            isFlipped = isFlippedHorizontally,
                                            shadowIntensity = shadowIntensity,
                                            lightWarmth = activePreset.lightWarmth + (lightWarmthAdjustment - 0.5f),
                                            hasWaterReflection = activePreset.hasWaterReflection,
                                            waterAlpha = waterReflectionAlpha,
                                            dofBokeh = dofBokehLevel
                                        )
                                        saveLosslessPngToGallery(context, composite, activePreset.name)
                                        withContext(Dispatchers.Main) {
                                            isSaving = false
                                            Toast.makeText(context, "Saved 100% Lossless PNG to Gallery!", Toast.LENGTH_LONG).show()
                                        }
                                    } else {
                                        withContext(Dispatchers.Main) {
                                            isSaving = false
                                            Toast.makeText(context, "Render error: Assets missing", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            },
                            modifier = Modifier
                                .testTag("save_photo_button")
                                .background(Color(0xFF00E5FF), CircleShape)
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.Black,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Save Photo",
                                    tint = Color.Black
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // SEARCH BAR - Directly overrides and links local assets instantly
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        performLocalAssetSearch(it)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("landmark_search_input"),
                    placeholder = { Text("Search 'ram mandir', 'taj mahal'...", color = Color(0xFF64748B), fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = Color(0xFF00E5FF)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = {
                                searchQuery = ""
                                activePreset = PRESET_LANDMARKS[0]
                            }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF1E293B),
                        unfocusedContainerColor = Color(0xFF1E293B),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // QUICK HOTSPOT CHIPS
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val quickChips = listOf(
                        "Ayodhya Ram Mandir" to PRESET_LANDMARKS[0],
                        "Taj Mahal" to PRESET_LANDMARKS[1],
                        "Kedarnath Temple" to PRESET_LANDMARKS[0],
                        "India Gate" to PRESET_LANDMARKS[0],
                        "Hawa Mahal" to PRESET_LANDMARKS[0],
                        "Maldives Water" to PRESET_LANDMARKS[1]
                    )

                    quickChips.forEach { (label, preset) ->
                        val isSelected = activePreset.name == preset.name && (if (label.contains("Taj") || label.contains("Maldives")) activePreset.id == "taj_mahal" else activePreset.id == "ram_mandir")
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF1E293B),
                            modifier = Modifier
                                .testTag("chip_${preset.id}_$label")
                                .clickable {
                                    activePreset = preset
                                    searchQuery = label
                                }
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.Black else Color(0xFFE2E8F0),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            // BOTTOM TOOLBAR: Gallery pick, Flip, Reset, Info
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F172A))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                // Adjustments Drawer
                AnimatedVisibility(visible = showAdjustPanel) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1E293B), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "PHYSICAL REALISM CONTROLS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E5FF)
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        // Occlusion Shadow Slider
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Contact Shadow Deep Black", fontSize = 12.sp, color = Color.White)
                            Text("${(shadowIntensity * 100).toInt()}%", fontSize = 12.sp, color = Color(0xFF00E5FF))
                        }
                        Slider(
                            value = shadowIntensity,
                            onValueChange = { shadowIntensity = it },
                            valueRange = 0.3f..1.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00E5FF),
                                activeTrackColor = Color(0xFF00E5FF)
                            )
                        )

                        // Light Warmth Bleed Slider
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Environment Light Sync", fontSize = 12.sp, color = Color.White)
                            Text("${(lightWarmthAdjustment * 100).toInt()}%", fontSize = 12.sp, color = Color(0xFFF59E0B))
                        }
                        Slider(
                            value = lightWarmthAdjustment,
                            onValueChange = { lightWarmthAdjustment = it },
                            valueRange = 0.0f..1.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFF59E0B),
                                activeTrackColor = Color(0xFFF59E0B)
                            )
                        )

                        // DSLR Bokeh Blur for Far Distance
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Far Distance Lens Blur", fontSize = 12.sp, color = Color.White)
                            Text("${(dofBokehLevel * 100).toInt()}%", fontSize = 12.sp, color = Color.White)
                        }
                        Slider(
                            value = dofBokehLevel,
                            onValueChange = { dofBokehLevel = it },
                            valueRange = 0.0f..1.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color.White,
                                activeTrackColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    // Upload/Change Portrait Button
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF1E293B),
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 6.dp)
                            .testTag("upload_portrait_button")
                            .clickable {
                                galleryLauncher.launch("image/*")
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = "Pick Photo", tint = Color(0xFF00E5FF), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Change Photo", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        }
                    }

                    // Flip Subject Button
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF1E293B),
                        modifier = Modifier
                            .weight(0.7f)
                            .padding(horizontal = 3.dp)
                            .testTag("flip_subject_button")
                            .clickable {
                                isFlippedHorizontally = !isFlippedHorizontally
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.Flip, contentDescription = "Flip", tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Flip", fontSize = 13.sp, color = Color.White)
                        }
                    }

                    // Reset Positioning Button
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF1E293B),
                        modifier = Modifier
                            .weight(0.7f)
                            .padding(start = 6.dp)
                            .testTag("reset_pose_button")
                            .clickable {
                                subjectScale = 1.0f
                                subjectOffsetX = 0f
                                subjectOffsetY = 180f
                                isFlippedHorizontally = false
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reset", tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reset", fontSize = 13.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        // MAIN CANVAS COMPOSITOR VIEWPORT
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color.Black)
        ) {
            val canvasWidth = maxWidth
            val canvasHeight = maxHeight

            // LAYER 1: Background Landmark Image (With Far-Distance Bokeh Depth-of-field)
            Image(
                painter = painterResource(id = activePreset.drawableRes),
                contentDescription = activePreset.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("active_landmark_background")
            )

            // Dynamic ambient environmental lighting wash on canvas
            val ambientColor = if (activePreset.lightWarmth > 0.5f) {
                Color(0xFFF59E0B).copy(alpha = 0.08f * (lightWarmthAdjustment * 2))
            } else {
                Color(0xFF00E5FF).copy(alpha = 0.04f * (lightWarmthAdjustment * 2))
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ambientColor)
            )

            // LAYER 2 & 3: Subject, Water Reflections, & Indelible 2px Deep-Black Contact Shadows
            val activeSubjectBitmap = mattedPortraitBitmap ?: userPortraitBitmap
            if (activeSubjectBitmap != null) {
                val baseSubjectHeight = 360.dp * subjectScale
                val aspect = (activeSubjectBitmap.width.toFloat() / activeSubjectBitmap.height.toFloat()).coerceIn(0.4f, 1.2f)
                val baseSubjectWidth = baseSubjectHeight * aspect

                // LAW 5: WATER & GLASS REFLECTION (Taj Mahal / Water templates)
                if (activePreset.hasWaterReflection) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .offset {
                                IntOffset(
                                    x = subjectOffsetX.roundToInt(),
                                    y = (subjectOffsetY + 190f * subjectScale).roundToInt()
                                )
                            }
                            .size(
                                width = baseSubjectWidth,
                                height = baseSubjectHeight * 0.55f
                            )
                            .graphicsLayer {
                                scaleX = if (isFlippedHorizontally) -1f else 1f
                                scaleY = -1f // Inverted mirror reflection
                                alpha = (waterReflectionAlpha * 0.40f).coerceIn(0.15f, 0.48f)
                            }
                            .blur(2.dp)
                    ) {
                        Image(
                            bitmap = activeSubjectBitmap.asImageBitmap(),
                            contentDescription = "Water Reflection",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // LAW 4: DIRECTIONAL AMBIENT GROUND SHADOW
                val shadowOffsetX = if (activePreset.sunAngleDeg > 90f) 40f else -40f
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset {
                            IntOffset(
                                x = (subjectOffsetX + shadowOffsetX).roundToInt(),
                                y = (subjectOffsetY + 160f * subjectScale).roundToInt()
                            )
                        }
                        .size(
                            width = (baseSubjectWidth * 0.85f),
                            height = 24.dp * subjectScale
                        )
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = (shadowIntensity * 0.75f).coerceIn(0.4f, 0.9f)),
                                    Color.Black.copy(alpha = (shadowIntensity * 0.35f)),
                                    Color.Transparent
                                )
                            ),
                            shape = CircleShape
                        )
                        .blur(4.dp)
                )

                // LAW 3: INDELIBLE CONTACT SHADOWS (2-Pixel Deep Black #000000 Occlusion Line directly beneath feet)
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset {
                            IntOffset(
                                x = subjectOffsetX.roundToInt(),
                                y = (subjectOffsetY + 172f * subjectScale).roundToInt()
                            )
                        }
                        .size(
                            width = (baseSubjectWidth * 0.72f),
                            height = 2.dp
                        )
                        .background(
                            color = Color(0xFF000000).copy(alpha = (shadowIntensity * 0.98f).coerceIn(0.8f, 1.0f)),
                            shape = RoundedCornerShape(1.dp)
                        )
                )

                // LAW 1: PIXEL-PERFECT MATTED SUBJECT (With Gestures for Dragging & Scaling)
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset {
                            IntOffset(
                                x = subjectOffsetX.roundToInt(),
                                y = subjectOffsetY.roundToInt()
                            )
                        }
                        .size(
                            width = baseSubjectWidth,
                            height = baseSubjectHeight
                        )
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                subjectScale = (subjectScale * zoom).coerceIn(0.4f, 2.5f)
                                subjectOffsetX += pan.x
                                subjectOffsetY += pan.y
                            }
                        }
                        .graphicsLayer {
                            scaleX = if (isFlippedHorizontally) -1f else 1f
                        }
                        .testTag("interactive_subject_layer")
                ) {
                    Image(
                        bitmap = activeSubjectBitmap.asImageBitmap(),
                        contentDescription = "Subject Portrait",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Loading overlay for matting operations
            if (isMattingLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.6f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Color(0xFF00E5FF))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "Extracting Subject with Zero-Alpha Matting...",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Location Badge Overlay
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF0F172A).copy(alpha = 0.85f),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Location",
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = activePreset.location,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

/**
 * LAW 1: PIXEL-PERFECT MATTING
 * Extracts the subject by analyzing background luminance and corner color seeds,
 * forcing Alpha = 0 for transparent areas with smooth edge anti-aliasing.
 */
fun extractSubjectPrecise(source: Bitmap): Bitmap {
    val w = source.width
    val h = source.height
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val pixels = IntArray(w * h)
    source.getPixels(pixels, 0, w, 0, 0, w, h)

    // Sample corner colors as reference background key
    val c1 = pixels[0]
    val c2 = pixels[w - 1]
    val c3 = pixels[(h - 1) * w]
    val c4 = pixels[w * h - 1]

    val bgR = (((c1 ushr 16) and 0xFF) + ((c2 ushr 16) and 0xFF) + ((c3 ushr 16) and 0xFF) + ((c4 ushr 16) and 0xFF)) / 4
    val bgG = (((c1 ushr 8) and 0xFF) + ((c2 ushr 8) and 0xFF) + ((c3 ushr 8) and 0xFF) + ((c4 ushr 8) and 0xFF)) / 4
    val bgB = ((c1 and 0xFF) + (c2 and 0xFF) + (c3 and 0xFF) + (c4 and 0xFF)) / 4

    for (i in pixels.indices) {
        val color = pixels[i]
        val a = (color ushr 24) and 0xFF
        val r = (color ushr 16) and 0xFF
        val g = (color ushr 8) and 0xFF
        val b = color and 0xFF

        if (a < 10) {
            pixels[i] = 0 // transparent
            continue
        }

        // Distance from background seed
        val dist = kotlin.math.sqrt(
            ((r - bgR) * (r - bgR) + (g - bgG) * (g - bgG) + (b - bgB) * (b - bgB)).toDouble()
        ).toFloat()

        // Pure white background / gray studio backdrops
        val isNearWhite = (r > 240 && g > 240 && b > 240)
        val isNearCorner = dist < 32f

        if (isNearWhite || isNearCorner) {
            val alphaMod = if (dist < 18f) 0 else ((dist - 18f) / 14f * 255).toInt().coerceIn(0, 255)
            pixels[i] = (alphaMod shl 24) or (r shl 16) or (g shl 8) or b
        }
    }

    out.setPixels(pixels, 0, w, 0, 0, w, h)
    return out
}

/**
 * LAW 6: LOSSLESS HIGH-BITRATE SAVE EXPORT PIPELINE
 * Renders full 4K-grade composite with environmental relighting, contact shadows, reflections, and saves as 100% PNG.
 */
fun renderLosslessMasterComposite(
    background: Bitmap,
    subject: Bitmap,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    isFlipped: Boolean,
    shadowIntensity: Float,
    lightWarmth: Float,
    hasWaterReflection: Boolean,
    waterAlpha: Float,
    dofBokeh: Float
): Bitmap {
    val outWidth = background.width
    val outHeight = background.height
    val result = Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(result)

    // 1. Draw Background
    canvas.drawBitmap(background, 0f, 0f, null)

    // 2. Compute Subject dimensions relative to master output resolution
    val subjTargetHeight = (outHeight * 0.65f * scale)
    val subjAspect = subject.width.toFloat() / subject.height.toFloat()
    val subjTargetWidth = subjTargetHeight * subjAspect

    val normalizedX = (outWidth * 0.5f) + (offsetX * (outWidth / 360f)) - (subjTargetWidth * 0.5f)
    val normalizedY = (outHeight * 0.5f) + (offsetY * (outHeight / 640f)) - (subjTargetHeight * 0.5f)

    val feetBaseY = normalizedY + subjTargetHeight

    // 3. LAW 5: WATER REFLECTION
    if (hasWaterReflection) {
        val reflPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            alpha = (waterAlpha * 100).toInt().coerceIn(20, 120)
        }
        val reflMatrix = android.graphics.Matrix().apply {
            if (isFlipped) postScale(-1f, 1f, subject.width / 2f, subject.height / 2f)
            postScale(1f, -1f, subject.width / 2f, subject.height / 2f)
            postScale(subjTargetWidth / subject.width.toFloat(), (subjTargetHeight * 0.55f) / subject.height.toFloat())
            postTranslate(normalizedX, feetBaseY)
        }
        canvas.drawBitmap(subject, reflMatrix, reflPaint)
    }

    // 4. LAW 4: DIRECTIONAL AMBIENT GROUND SHADOW
    val groundShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.argb((shadowIntensity * 160).toInt().coerceIn(40, 220), 0, 0, 0)
        style = Paint.Style.FILL
    }
    val shadowOval = RectF(
        normalizedX - (subjTargetWidth * 0.1f),
        feetBaseY - (12f * scale),
        normalizedX + subjTargetWidth + (subjTargetWidth * 0.1f),
        feetBaseY + (18f * scale)
    )
    canvas.drawOval(shadowOval, groundShadowPaint)

    // 5. LAW 3: INDELIBLE 2-PIXEL CONTACT SHADOW (#000000)
    val occlusionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.argb((shadowIntensity * 255).toInt().coerceIn(180, 255), 0, 0, 0)
        strokeWidth = (3.0f * (outWidth / 720f)).coerceIn(2f, 5f)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    canvas.drawLine(
        normalizedX + (subjTargetWidth * 0.15f),
        feetBaseY,
        normalizedX + (subjTargetWidth * 0.85f),
        feetBaseY,
        occlusionPaint
    )

    // 6. LAW 4: ENVIRONMENTAL RELIGHTING COLOR MATRIX
    val subjectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        isFilterBitmap = true
        if (lightWarmth > 0.5f) {
            val warmGain = (lightWarmth - 0.5f) * 0.15f
            val cm = ColorMatrix(
                floatArrayOf(
                    1f + warmGain, 0f, 0f, 0f, 10f * warmGain,
                    0f, 1f + warmGain * 0.5f, 0f, 0f, 5f * warmGain,
                    0f, 0f, 1f - warmGain * 0.3f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            colorFilter = ColorMatrixColorFilter(cm)
        }
    }

    // 7. DRAW SUBJECT
    val subjMatrix = android.graphics.Matrix().apply {
        if (isFlipped) postScale(-1f, 1f, subject.width / 2f, subject.height / 2f)
        postScale(subjTargetWidth / subject.width.toFloat(), subjTargetHeight / subject.height.toFloat())
        postTranslate(normalizedX, normalizedY)
    }
    canvas.drawBitmap(subject, subjMatrix, subjectPaint)

    return result
}

fun saveLosslessPngToGallery(context: Context, bitmap: Bitmap, title: String) {
    val resolver = context.contentResolver
    val contentValues = ContentValues().apply {
        val sanitized = title.replace(Regex("[^a-zA-Z0-9]"), "_")
        put(MediaStore.MediaColumns.DISPLAY_NAME, "WorldCam_${sanitized}_${System.currentTimeMillis()}.png")
        put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/WorldCamAI")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
    }
    val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
    if (imageUri != null) {
        resolver.openOutputStream(imageUri)?.use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            contentValues.clear()
            contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(imageUri, contentValues, null, null)
        }
    }
}

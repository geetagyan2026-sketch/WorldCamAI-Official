package com.aistudio.worldcamai.smxuqv

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.util.Log
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.Segmenter
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenter
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

object PersonSegmentationEngine {
    private const val TAG = "PersonSegmentation"
    private const val MAX_WORK_DIM = 512

    // Reuse ML Kit clients across calls to avoid per-cutout initialization overhead.
    private val subjectSegmenter: SubjectSegmenter by lazy {
        SubjectSegmentation.getClient(
            SubjectSegmenterOptions.Builder()
                .enableForegroundConfidenceMask()
                .build()
        )
    }

    private val selfieSegmenter: Segmenter by lazy {
        Segmentation.getClient(
            SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .enableRawSizeMask()
                .build()
        )
    }

    /**
     * Ultra-fast Single-Pass Human Subject Cutout (< 0.8s):
     * 1. Downscales input to max 512px long-edge.
     * 2. Runs a single pass of ML Kit Subject Segmentation (with single-pass Selfie Segmentation fallback).
     * 3. Runs a fast 1-pass exterior flood-fill + interior torso/shirt fill so white clothing stays 100% solid.
     * 4. Smoothly upscales the alpha mask back to the full-resolution photo via hardware-accelerated DST_IN.
     */
    fun extractPersonCutout(src: Bitmap): Bitmap? {
        if (src.isRecycled || src.width <= 10 || src.height <= 10) return null

        var argbBitmap: Bitmap? = null
        var workBitmap: Bitmap? = null
        var smallMaskBmp: Bitmap? = null
        var upscaledMask: Bitmap? = null

        return try {
            val origW = src.width
            val origH = src.height
            argbBitmap = if (src.config != Bitmap.Config.ARGB_8888) {
                src.copy(Bitmap.Config.ARGB_8888, false)
            } else {
                src
            }

            // Preserve pre-cut transparent PNG cutouts directly
            if (isAlreadyTransparentCutout(argbBitmap)) {
                return if (argbBitmap.isMutable) argbBitmap else argbBitmap.copy(Bitmap.Config.ARGB_8888, true)
            }

            // 1. Downscale to fast processing resolution (max 512px)
            val maxOrig = max(origW, origH)
            workBitmap = if (maxOrig > MAX_WORK_DIM) {
                val scale = MAX_WORK_DIM.toFloat() / maxOrig.toFloat()
                Bitmap.createScaledBitmap(
                    argbBitmap,
                    (origW * scale).toInt().coerceAtLeast(32),
                    (origH * scale).toInt().coerceAtLeast(32),
                    true
                )
            } else {
                argbBitmap
            }

            val workW = workBitmap.width
            val workH = workBitmap.height
            val totalWork = workW * workH
            val inputImage = InputImage.fromBitmap(workBitmap, 0)

            // 2. Single-pass ML Kit Subject Segmentation (fast fallback to single-pass Selfie Segmentation if unavailable)
            val conf: FloatArray = runSinglePassSubjectSegmentation(inputImage, totalWork)
                ?: runSinglePassSelfieSegmentation(inputImage, workW, workH)
                ?: return null

            if (workBitmap !== argbBitmap && !workBitmap.isRecycled) {
                workBitmap.recycle()
            }
            workBitmap = null

            // 3. Fast 1-pass exterior flood-fill + interior torso/shirt solid fill at <= 512px
            val maskPixels = buildSolidInteriorAlphaMask(conf, workW, workH)

            smallMaskBmp = Bitmap.createBitmap(workW, workH, Bitmap.Config.ARGB_8888)
            smallMaskBmp.setPixels(maskPixels, 0, workW, 0, 0, workW, workH)

            // 4. Clean smooth bilinear upscale of alpha mask + native DST_IN composite onto original photo
            upscaledMask = if (workW == origW && workH == origH) {
                smallMaskBmp
            } else {
                Bitmap.createScaledBitmap(smallMaskBmp, origW, origH, true)
            }

            val outBitmap = Bitmap.createBitmap(origW, origH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(outBitmap)
            canvas.drawBitmap(argbBitmap, 0f, 0f, null)
            val dstInPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            }
            canvas.drawBitmap(upscaledMask, 0f, 0f, dstInPaint)
            outBitmap
        } catch (t: Throwable) {
            Log.w(TAG, "Fast person segmentation failed: ${t.message}", t)
            null
        } finally {
            try {
                if (upscaledMask != null && upscaledMask !== smallMaskBmp && !upscaledMask.isRecycled) {
                    upscaledMask.recycle()
                }
                if (smallMaskBmp != null && !smallMaskBmp.isRecycled) {
                    smallMaskBmp.recycle()
                }
                if (workBitmap != null && workBitmap !== src && workBitmap !== argbBitmap && !workBitmap.isRecycled) {
                    workBitmap.recycle()
                }
                if (argbBitmap != null && argbBitmap !== src && !argbBitmap.isRecycled) {
                    argbBitmap.recycle()
                }
            } catch (_: Throwable) {}
        }
    }

    private fun runSinglePassSubjectSegmentation(input: InputImage, totalWork: Int): FloatArray? {
        return try {
            val res = Tasks.await(subjectSegmenter.process(input), 650, TimeUnit.MILLISECONDS)
            val fb = res?.foregroundConfidenceMask ?: return null
            if (fb.remaining() < totalWork) return null
            fb.rewind()
            FloatArray(totalWork).also { fb.get(it) }
        } catch (t: Throwable) {
            Log.d(TAG, "SubjectSegmentation skipped/fallback: ${t.message}")
            null
        }
    }

    private fun runSinglePassSelfieSegmentation(input: InputImage, workW: Int, workH: Int): FloatArray? {
        return try {
            val mask = Tasks.await(selfieSegmenter.process(input), 700, TimeUnit.MILLISECONDS)
            extractAndUpsampleSelfieMask(mask, workW, workH)
        } catch (t: Throwable) {
            Log.d(TAG, "SelfieSegmentation fallback failed: ${t.message}")
            null
        }
    }

    /**
     * Fast 1-pass interior mask fill at <= 512px:
     * - Flood-fills open exterior background (including bottom between-leg openings) from image edges.
     * - Locks enclosed interior torso/chest/stomach pixels to alpha = 255 so white shirts stay 100% solid.
     * - Applies a smooth anti-aliased alpha curve on boundaries before upscaling.
     */
    private fun buildSolidInteriorAlphaMask(conf: FloatArray, w: Int, h: Int): IntArray {
        val total = w * h
        val isExterior = BooleanArray(total)
        val queue = IntArray(total)
        var qHead = 0
        var qTail = 0

        fun seedIfBg(idx: Int) {
            if (!isExterior[idx] && conf[idx] < 0.42f) {
                isExterior[idx] = true
                queue[qTail++] = idx
            }
        }

        for (x in 0 until w) {
            seedIfBg(x)
            seedIfBg((h - 1) * w + x)
        }
        for (y in 0 until h) {
            seedIfBg(y * w)
            seedIfBg(y * w + (w - 1))
        }

        while (qHead < qTail) {
            val curr = queue[qHead++]
            val cx = curr % w
            val cy = curr / w
            if (cx > 0) seedIfBg(curr - 1)
            if (cx + 1 < w) seedIfBg(curr + 1)
            if (cy > 0) seedIfBg(curr - w)
            if (cy + 1 < h) seedIfBg(curr + w)
        }

        // Compute horizontal subject bounds per row + vertical foreground extent in one pass
        val rowLeft = IntArray(h) { w }
        val rowRight = IntArray(h) { -1 }
        var fgMinY = h
        var fgMaxY = -1
        for (y in 0 until h) {
            val rowOff = y * w
            for (x in 0 until w) {
                val idx = rowOff + x
                if (!isExterior[idx] && conf[idx] >= 0.48f) {
                    if (y < fgMinY) fgMinY = y
                    if (y > fgMaxY) fgMaxY = y
                    if (x < rowLeft[y]) rowLeft[y] = x
                    if (x > rowRight[y]) rowRight[y] = x
                }
            }
        }

        val maskPixels = IntArray(total)
        val fgHeight = (fgMaxY - fgMinY).coerceAtLeast(1).toFloat()
        val hasBounds = fgMaxY > fgMinY

        for (y in 0 until h) {
            val rowOff = y * w
            val rl = rowLeft[y]
            val rr = rowRight[y]
            val hasRowSpan = hasBounds && rr > rl && y in fgMinY..fgMaxY
            val inUpperBody = hasRowSpan && ((y - fgMinY).toFloat() / fgHeight) <= 0.64f
            val rowMid = (rl + rr) * 0.5f
            val rowHalf = (rr - rl) * 0.5f

            for (x in 0 until w) {
                val idx = rowOff + x
                if (isExterior[idx]) {
                    maskPixels[idx] = 0x00000000
                    continue
                }

                var c = conf[idx]
                if (inUpperBody && x in rl..rr) {
                    // 1-pass interior torso & clothing lock: white/light shirts never get punched out
                    if (abs(x - rowMid) <= rowHalf * 0.72f || c >= 0.16f) {
                        c = 1f
                    }
                }

                val alpha = when {
                    c <= 0.30f -> 0
                    c >= 0.70f -> 255
                    else -> {
                        val t = (c - 0.30f) / 0.40f
                        ((t * t * (3f - 2f * t)) * 255f).toInt().coerceIn(0, 255)
                    }
                }
                maskPixels[idx] = if (alpha > 0) ((alpha shl 24) or 0x00FFFFFF) else 0x00000000
            }
        }
        return maskPixels
    }

    private fun isAlreadyTransparentCutout(bmp: Bitmap): Boolean {
        val w = bmp.width
        val h = bmp.height
        var transparentSamples = 0
        var totalSamples = 0
        val row = IntArray(w)
        val rowStep = (h / 24).coerceAtLeast(1)
        val xStep = (w / 24).coerceAtLeast(1)
        for (y in 0 until h step rowStep) {
            bmp.getPixels(row, 0, w, 0, y, w, 1)
            for (x in 0 until w step xStep) {
                totalSamples++
                if (((row[x] ushr 24) and 0xFF) < 25) {
                    transparentSamples++
                }
            }
        }
        return totalSamples > 0 && transparentSamples >= (totalSamples * 0.04f).toInt().coerceAtLeast(6)
    }

    private fun extractAndUpsampleSelfieMask(
        mask: SegmentationMask?,
        targetW: Int,
        targetH: Int
    ): FloatArray? {
        if (mask == null) return null
        val buf = mask.buffer ?: return null
        val mw = mask.width
        val mh = mask.height
        if (mw <= 4 || mh <= 4) return null
        buf.rewind()
        buf.order(ByteOrder.nativeOrder())
        val fb = buf.asFloatBuffer()
        val mTotal = mw * mh
        if (fb.remaining() < mTotal) return null
        val raw = FloatArray(mTotal)
        fb.get(raw)

        if (mw == targetW && mh == targetH) return raw

        val out = FloatArray(targetW * targetH)
        val scaleX = (mw - 1).coerceAtLeast(1).toFloat() / (targetW - 1).coerceAtLeast(1).toFloat()
        val scaleY = (mh - 1).coerceAtLeast(1).toFloat() / (targetH - 1).coerceAtLeast(1).toFloat()
        for (y in 0 until targetH) {
            val fy = y * scaleY
            val y0 = fy.toInt().coerceIn(0, mh - 1)
            val y1 = (y0 + 1).coerceAtMost(mh - 1)
            val dy = fy - y0
            val r0 = y0 * mw
            val r1 = y1 * mw
            val oRow = y * targetW
            for (x in 0 until targetW) {
                val fx = x * scaleX
                val x0 = fx.toInt().coerceIn(0, mw - 1)
                val x1 = (x0 + 1).coerceAtMost(mw - 1)
                val dx = fx - x0
                val top = raw[r0 + x0] + (raw[r0 + x1] - raw[r0 + x0]) * dx
                val bot = raw[r1 + x0] + (raw[r1 + x1] - raw[r1 + x0]) * dx
                out[oRow + x] = (top + (bot - top) * dy).coerceIn(0f, 1f)
            }
        }
        return out
    }
}

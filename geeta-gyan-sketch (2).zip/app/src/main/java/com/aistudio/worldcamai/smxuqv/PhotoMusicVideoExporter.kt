package com.aistudio.worldcamai.smxuqv

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PaintFlagsDrawFilter
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.util.Log
import android.view.Surface
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

data class MusicPhotoExportResult(
    val savedGalleryUri: Uri?,
    val previewCacheFile: File?,
    val errorMessage: String? = null
)

private fun buildMusicPhotoHdFormat(
    width: Int,
    height: Int,
    fps: Int,
    highProfile: Boolean
): MediaFormat {
    return MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
        setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        setInteger(MediaFormat.KEY_BIT_RATE, 12_000_000)
        setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        if (highProfile) {
            setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                setInteger(MediaFormat.KEY_LEVEL, MediaCodecInfo.CodecProfileLevel.AVCLevel4)
            }
            setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
        }
    }
}

/**
 * Isolated exporter for Instagram-Story style "Music on Photo":
 * Takes an already-blended high-res composite photo bitmap, applies a gentle smooth Ken Burns
 * slow-zoom motion across 15 seconds (450 frames @ 30fps HD MP4), muxes the trimmed 15s song clip,
 * and saves directly to the device gallery.
 */
suspend fun exportBlendedPhotoWithSong15s(
    context: Context,
    compositeBitmap: Bitmap,
    song: SelectedSongInfo,
    locationName: String,
    onProgress: (Float, String) -> Unit
): MusicPhotoExportResult = withContext(Dispatchers.IO) {
    if (compositeBitmap.isRecycled || compositeBitmap.width <= 0 || compositeBitmap.height <= 0) {
        return@withContext MusicPhotoExportResult(null, null, "Blended photo bitmap is unavailable.")
    }

    val cacheDir = File(context.cacheDir, "music_photo_exports").apply { mkdirs() }
    val stamp = System.currentTimeMillis()
    val rawVideoFile = File(cacheDir, "photo_kenburns_raw_$stamp.mp4")
    val finalMuxedFile = File(cacheDir, "photo_music_15s_$stamp.mp4")

    val aspect = compositeBitmap.width.toFloat() / compositeBitmap.height.toFloat().coerceAtLeast(1f)
    val rawW: Int
    val rawH: Int
    if (aspect <= 1f) {
        rawW = 1080
        rawH = (1080f / aspect).roundToInt().coerceIn(720, 1920)
    } else {
        rawW = (1080f * aspect).roundToInt().coerceIn(720, 1920)
        rawH = 1080
    }
    // Enforce multiple-of-4 dimensions for universal hardware AVC encoder compatibility
    val videoWidth = ((rawW + 2) / 4) * 4
    val videoHeight = ((rawH + 2) / 4) * 4

    // Pre-scale 4200px master composite once to ~1.12x HD video texture for fast crisp Ken Burns zoom
    var sourceTexture: Bitmap? = null
    var codec: MediaCodec? = null
    var inputSurface: Surface? = null
    var muxer: MediaMuxer? = null
    var muxerStarted = false
    var videoTrackIndex = -1

    try {
        onProgress(0.05f, "Preparing HD Ken Burns motion...")

        val texW = (videoWidth * 1.12f).roundToInt().coerceAtLeast(videoWidth)
        val texH = (videoHeight * 1.12f).roundToInt().coerceAtLeast(videoHeight)
        sourceTexture = Bitmap.createBitmap(texW, texH, Bitmap.Config.ARGB_8888).also { tex ->
            val texCanvas = Canvas(tex)
            texCanvas.drawFilter = PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            val texPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
            texCanvas.drawBitmap(compositeBitmap, null, RectF(0f, 0f, texW.toFloat(), texH.toFloat()), texPaint)
        }

        val fps = 30
        val durationSeconds = 15
        val totalFrames = fps * durationSeconds
        val frameStepUs = 1_000_000L / fps
        var writtenSamples = 0L

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        try {
            encoder.configure(
                buildMusicPhotoHdFormat(videoWidth, videoHeight, fps, highProfile = true),
                null,
                null,
                MediaCodec.CONFIGURE_FLAG_ENCODE
            )
        } catch (_: Throwable) {
            encoder.reset()
            encoder.configure(
                buildMusicPhotoHdFormat(videoWidth, videoHeight, fps, highProfile = false),
                null,
                null,
                MediaCodec.CONFIGURE_FLAG_ENCODE
            )
        }
        val surface = encoder.createInputSurface()
        encoder.start()
        codec = encoder
        inputSurface = surface

        if (rawVideoFile.exists()) rawVideoFile.delete()
        val mediaMuxer = MediaMuxer(rawVideoFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer = mediaMuxer

        val bufferInfo = MediaCodec.BufferInfo()
        fun drain(endOfStream: Boolean) {
            val timeoutUs = if (endOfStream) 10_000L else 0L
            var emptyTries = 0
            while (true) {
                val outIdx = encoder.dequeueOutputBuffer(bufferInfo, timeoutUs)
                when {
                    outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!endOfStream) break
                        emptyTries++
                        if (emptyTries > 40) break
                    }
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        if (!muxerStarted) {
                            videoTrackIndex = mediaMuxer.addTrack(encoder.outputFormat)
                            mediaMuxer.start()
                            muxerStarted = true
                        }
                    }
                    outIdx >= 0 -> {
                        val encoded = encoder.getOutputBuffer(outIdx)
                        if (encoded != null) {
                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                                bufferInfo.size = 0
                            }
                            if (bufferInfo.size > 0 && muxerStarted && videoTrackIndex >= 0) {
                                bufferInfo.presentationTimeUs = writtenSamples * frameStepUs
                                writtenSamples++
                                encoded.position(bufferInfo.offset)
                                encoded.limit(bufferInfo.offset + bufferInfo.size)
                                mediaMuxer.writeSampleData(videoTrackIndex, encoded, bufferInfo)
                            }
                        }
                        encoder.releaseOutputBuffer(outIdx, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            break
                        }
                    }
                }
            }
        }

        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
        val baseRect = RectF(0f, 0f, videoWidth.toFloat(), videoHeight.toFloat())
        val cx = videoWidth / 2f
        val cy = videoHeight / 2f

        for (frameIdx in 0 until totalFrames) {
            val t = frameIdx.toFloat() / (totalFrames - 1).coerceAtLeast(1).toFloat()
            val ease = 0.5f - 0.5f * cos(PI * t).toFloat()
            // Gentle slow Ken Burns zoom (1.00x -> 1.085x) with subtle drift, zero edge gaps
            val zoom = 1.00f + (0.085f * ease)
            val panX = (videoWidth * 0.008f) * sin(PI * t).toFloat()
            val panY = -(videoHeight * 0.006f) * ease

            val canvas = surface.lockCanvas(null)
            try {
                canvas.drawFilter = PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                canvas.drawColor(Color.BLACK)
                canvas.save()
                canvas.translate(panX, panY)
                canvas.scale(zoom, zoom, cx, cy)
                canvas.drawBitmap(sourceTexture!!, null, baseRect, framePaint)
                canvas.restore()
            } finally {
                surface.unlockCanvasAndPost(canvas)
            }
            drain(endOfStream = false)
            if (frameIdx % 15 == 0) {
                val pct = 0.10f + (t * 0.65f)
                onProgress(pct, "Rendering 15s HD motion (${(t * 100).toInt()}%)...")
            }
        }

        encoder.signalEndOfInputStream()
        drain(endOfStream = true)

        try { sourceTexture?.recycle() } catch (_: Throwable) {}
        sourceTexture = null
        try { codec?.stop() } catch (_: Throwable) {}
        try { codec?.release() } catch (_: Throwable) {}
        codec = null
        try { inputSurface?.release() } catch (_: Throwable) {}
        inputSurface = null
        try { if (muxerStarted) muxer?.stop() } catch (_: Throwable) {}
        try { muxer?.release() } catch (_: Throwable) {}
        muxer = null
        muxerStarted = false

        if (!rawVideoFile.exists() || rawVideoFile.length() == 0L) {
            return@withContext MusicPhotoExportResult(null, null, "Failed to encode 15s HD video frames.")
        }

        onProgress(0.80f, "Adding 15s song audio...")
        val muxed = muxSongAudioWithVideo(
            context = context,
            videoFile = rawVideoFile,
            audioUri = song.uri,
            songStartTimeMs = song.startTimeMs,
            outputFile = finalMuxedFile
        )
        try { rawVideoFile.delete() } catch (_: Throwable) {}

        onProgress(0.92f, "Saving 15s HD MP4 to Gallery...")
        val savedUri = saveVideoToGallery(context, muxed, locationName)
        onProgress(1.0f, "Saved!")

        if (savedUri != null) {
            MusicPhotoExportResult(
                savedGalleryUri = savedUri,
                previewCacheFile = muxed,
                errorMessage = null
            )
        } else {
            MusicPhotoExportResult(
                savedGalleryUri = null,
                previewCacheFile = muxed,
                errorMessage = "Could not save 15s MP4 video to device Gallery."
            )
        }
    } catch (t: Throwable) {
        Log.e("PhotoMusicExport", "Export failed: ${t.message}", t)
        MusicPhotoExportResult(null, null, t.localizedMessage ?: "Failed to create 15s music video.")
    } finally {
        try { sourceTexture?.recycle() } catch (_: Throwable) {}
        try { codec?.stop() } catch (_: Throwable) {}
        try { codec?.release() } catch (_: Throwable) {}
        try { inputSurface?.release() } catch (_: Throwable) {}
        try { if (muxerStarted) muxer?.stop() } catch (_: Throwable) {}
        try { muxer?.release() } catch (_: Throwable) {}
        try { if (rawVideoFile.exists()) rawVideoFile.delete() } catch (_: Throwable) {}
    }
}

@Composable
fun MusicPhotoExportResultDialog(
    videoFile: File,
    savedGalleryUri: Uri?,
    songTitle: String,
    locationName: String,
    onShare: (Uri) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = ComposeColor(0xFF0F172A),
            border = BorderStroke(1.dp, ComposeColor(0xFF38BDF8).copy(alpha = 0.55f)),
            shadowElevation = 14.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .testTag("music_photo_export_result_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = "15s Music Photo Video",
                            tint = ComposeColor(0xFFF472B6),
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "15s Music Video Saved!",
                            color = ComposeColor.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("close_music_photo_result_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = ComposeColor(0xFF94A3B8)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = ComposeColor(0xFF064E3B).copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, ComposeColor(0xFF10B981).copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Saved to Gallery",
                            tint = ComposeColor(0xFF34D399),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Saved HD MP4 to Gallery • $locationName",
                                color = ComposeColor(0xFFA7F3D0),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "🎵 $songTitle",
                                color = ComposeColor(0xFFE0F2FE),
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(ComposeColor.Black),
                    contentAlignment = Alignment.Center
                ) {
                    AndroidView(
                        factory = { ctx ->
                            VideoView(ctx).apply {
                                val controller = MediaController(ctx)
                                controller.setAnchorView(this)
                                setMediaController(controller)
                                setVideoPath(videoFile.absolutePath)
                                setOnPreparedListener { mp ->
                                    mp.isLooping = true
                                    start()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(0.85f)
                            .height(48.dp)
                            .testTag("done_music_photo_result_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, ComposeColor(0xFF64748B))
                    ) {
                        Text(
                            text = "Done",
                            color = ComposeColor.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }

                    Button(
                        onClick = {
                            savedGalleryUri?.let { onShare(it) }
                        },
                        enabled = savedGalleryUri != null,
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp)
                            .testTag("share_music_photo_video_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ComposeColor(0xFF0EA5E9)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share Video",
                            tint = ComposeColor.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Share Video",
                            color = ComposeColor.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

fun shareExportedMp4Video(context: Context, videoUri: Uri, locationName: String, songTitle: String?) {
    val cleanLocation = locationName.trim().ifBlank { "WorldCamAI" }
    val sendIntent = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, videoUri)
        putExtra(Intent.EXTRA_TEXT, "📍 $cleanLocation • Made with WorldCamAI")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    val chooser = Intent.createChooser(sendIntent, "Share 15s Video")
    context.startActivity(chooser)
}

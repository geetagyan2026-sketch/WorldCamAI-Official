package com.aistudio.worldcamai.smxuqv

import java.util.Locale

/**
 * Dynamic Spatial Synthesis Data-Grounding & Live Open Index for WorldCamAI
 * 
 * Strict Architecture Guarantees:
 * 1. Bypasses all internal offline pre-saved location databases for manual searches.
 * 2. Forces real-time HTTP network requests directly to live online Wikimedia/Wikipedia APIs.
 */
object CloudDatabaseConfig {
    val ENDPOINT_URL: String = "https://s3.amazonaws.com"
    val BUCKET_NAME: String = "worldcam-100crore-cloud-dataset"
    val DATABASE_CREDENTIALS: String = "worldcam_live_cloud_access_token"
    val BASE_STORAGE_PATH: String = "https://$BUCKET_NAME.s3.amazonaws.com"
}

data class IndexedLocation(
    val name: String,
    val region: String,
    val photoUrl: String,
    val description: String,
    val funFact: String,
    val latitude: Double,
    val longitude: Double,
    val isWaterBody: Boolean = false,
    val isNightOrNeon: Boolean = false,
    val isSnowOrMountain: Boolean = false,
    val isDesert: Boolean = false,
    val lightingDirX: Float = 0.35f,
    val shadowDepthRatio: Float = 1.0f,
    val forceRedraw: Boolean = true,
    val bypassCache: Boolean = true,
    val bindToViewportDirectly: Boolean = true
)

object CompressedLocationIndex {

    val endpointUrl: String = CloudDatabaseConfig.ENDPOINT_URL
    val bucketName: String = CloudDatabaseConfig.BUCKET_NAME
    val credentials: String = CloudDatabaseConfig.DATABASE_CREDENTIALS

    /**
     * Resolves location metadata and coordinates.
     * Returns photoUrl = "" to ensure manual search execution engine completely bypasses
     * internal index files and forces fresh real-time HTTP network calls to the live online API.
     */
    fun resolveLocation(inputQuery: String, groundingMetadataQuery: String? = null): IndexedLocation {
        return try {
            val trimmedQuery = inputQuery.trim()
            val queryToAnalyze = if (!groundingMetadataQuery.isNullOrBlank()) {
                groundingMetadataQuery.trim()
            } else {
                trimmedQuery
            }
            val normalizedQuery = queryToAnalyze.lowercase(Locale.ROOT)

            val isWaterQuery = normalizedQuery.contains("river") || normalizedQuery.contains("island") ||
                normalizedQuery.contains("lake") || normalizedQuery.contains("talab") ||
                normalizedQuery.contains("dam") || normalizedQuery.contains("ghat") ||
                normalizedQuery.contains("water") || normalizedQuery.contains("cascade") ||
                normalizedQuery.contains("waterfall") || normalizedQuery.contains("canal") ||
                normalizedQuery.contains("riverfront") || normalizedQuery.contains("sea") ||
                normalizedQuery.contains("ocean") || normalizedQuery.contains("beach") ||
                normalizedQuery.contains("venice") || normalizedQuery.contains("backwater") ||
                normalizedQuery.contains("delta")

            val isSnowQuery = !isWaterQuery && (
                normalizedQuery.contains("everest") || normalizedQuery.contains("himalaya") ||
                normalizedQuery.contains("alp") || normalizedQuery.contains("snow") ||
                normalizedQuery.contains("mountain") || normalizedQuery.contains("peak") ||
                normalizedQuery.contains("glacier") || normalizedQuery.contains("ski") ||
                normalizedQuery.contains("summit") || normalizedQuery.contains("ladakh") ||
                normalizedQuery.contains("kashmir") || normalizedQuery.contains("manali") ||
                normalizedQuery.contains("leh") || normalizedQuery.contains("shimla") ||
                normalizedQuery.contains("techi") || normalizedQuery.contains("thachi") ||
                normalizedQuery.contains("himachal")
            )

            val isNightNeonQuery = !isWaterQuery && !isSnowQuery && (
                normalizedQuery.contains("night") || normalizedQuery.contains("downtown") ||
                normalizedQuery.contains("skyscraper") || normalizedQuery.contains("new york") ||
                normalizedQuery.contains("tokyo") || normalizedQuery.contains("shanghai") ||
                normalizedQuery.contains("dubai") || normalizedQuery.contains("neon") ||
                normalizedQuery.contains("times square") || normalizedQuery.contains("singapore")
            )

            val isDesertQuery = !isWaterQuery && !isSnowQuery && !isNightNeonQuery && (
                normalizedQuery.contains("desert") || normalizedQuery.contains("rajasthan") ||
                normalizedQuery.contains("dune") || normalizedQuery.contains("sahara") ||
                normalizedQuery.contains("arid") || normalizedQuery.contains("oasis") ||
                normalizedQuery.contains("safari") || normalizedQuery.contains("sand") ||
                normalizedQuery.contains("jaisalmer") || normalizedQuery.contains("thar")
            )

            val coords = RealWorldCoordinatesResolver.resolveCoordinates(trimmedQuery)
            val formattedName = trimmedQuery.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }

            IndexedLocation(
                name = formattedName,
                region = "Live Online API Search Index",
                photoUrl = "", // Empty to bypass internal index and force real-time online network lookup
                description = "Live online network query for $formattedName.",
                funFact = "Real-time spatial context resolution with 3D contact shadow grounding.",
                latitude = coords.first,
                longitude = coords.second,
                isWaterBody = isWaterQuery,
                isNightOrNeon = isNightNeonQuery,
                isSnowOrMountain = isSnowQuery,
                isDesert = isDesertQuery,
                lightingDirX = if (isNightNeonQuery) -0.6f else 0.35f,
                shadowDepthRatio = if (isSnowQuery) 0.85f else 1.15f,
                forceRedraw = true,
                bypassCache = true,
                bindToViewportDirectly = true
            )
        } catch (e: Exception) {
            val fallbackQuery = inputQuery.ifBlank { "Global Destination" }
            IndexedLocation(
                name = fallbackQuery,
                region = "Live Open Photography Index",
                photoUrl = "",
                description = "Live network search for $fallbackQuery.",
                funFact = "Instant visual retrieval active.",
                latitude = 20.5937,
                longitude = 78.9629,
                isWaterBody = true,
                forceRedraw = true,
                bypassCache = true,
                bindToViewportDirectly = true
            )
        }
    }
}

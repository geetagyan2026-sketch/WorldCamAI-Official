package com.aistudio.worldcamai.smxuqv

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseDetector
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import java.util.WeakHashMap
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Tight normalized (0f..1f) anatomical capsule around an individual foot / shoe
 * detected via ML Kit Pose Detection (ankle, heel, and foot_index landmarks).
 */
data class AnatomicalShoeCapsule(
    val ankleX: Float,
    val ankleY: Float,
    val heelX: Float,
    val heelY: Float,
    val toeX: Float,
    val toeY: Float,
    val minX: Float,
    val maxX: Float,
    val minY: Float,
    val maxY: Float,
    val tubeRadius: Float,
    val soleY: Float,
    val centerX: Float
) {
    fun distanceToNorm(nx: Float, ny: Float): Float {
        if (nx < minX || nx > maxX || ny < minY || ny > maxY) {
            return Float.MAX_VALUE
        }
        val dSole = distPointToSegment(nx, ny, heelX, heelY, toeX, toeY)
        val dAnkleHeel = distPointToSegment(nx, ny, ankleX, ankleY, heelX, heelY)
        val midFootX = heelX + (toeX - heelX) * 0.52f
        val midFootY = heelY + (toeY - heelY) * 0.52f
        val dAnkleMid = distPointToSegment(nx, ny, ankleX, ankleY, midFootX, midFootY)
        return min(dSole, min(dAnkleHeel, dAnkleMid))
    }

    fun containsNorm(nx: Float, ny: Float, radiusMultiplier: Float = 1.0f): Boolean {
        return distanceToNorm(nx, ny) <= (tubeRadius * radiusMultiplier)
    }
}

data class PoseFootRegions(
    val leftShoe: AnatomicalShoeCapsule? = null,
    val rightShoe: AnatomicalShoeCapsule? = null,
    val sourceAspect: Float = 0.75f
) {
    fun hasAnyShoe(): Boolean = leftShoe != null || rightShoe != null

    fun classifyPixel(nx: Float, ny: Float, strictCore: Boolean = false): Int {
        // Returns 1 = left shoe, 2 = right shoe, 0 = outside both shoes
        val mult = if (strictCore) 0.78f else 1.0f
        val dLeft = leftShoe?.distanceToNorm(nx, ny) ?: Float.MAX_VALUE
        val dRight = rightShoe?.distanceToNorm(nx, ny) ?: Float.MAX_VALUE

        val inLeft = leftShoe != null && dLeft <= leftShoe.tubeRadius * mult
        val inRight = rightShoe != null && dRight <= rightShoe.tubeRadius * mult

        if (!inLeft && !inRight) return 0

        // Ensure separated shoes NEVER form an inter-shoe floor bridge near their horizontal midpoint
        if (leftShoe != null && rightShoe != null) {
            val shoeSpan = abs(leftShoe.centerX - rightShoe.centerX)
            val combinedRad = (leftShoe.tubeRadius + rightShoe.tubeRadius) * 0.65f
            if (shoeSpan > combinedRad) {
                val midX = (leftShoe.centerX + rightShoe.centerX) * 0.5f
                val guardHalf = (shoeSpan * 0.14f).coerceAtMost(0.025f)
                if (abs(nx - midX) <= guardHalf && min(dLeft, dRight) > min(leftShoe.tubeRadius, rightShoe.tubeRadius) * 0.62f) {
                    return 0
                }
            }
        }
        return if (dLeft <= dRight) 1 else 2
    }
}

private val poseFootRegionsCache = WeakHashMap<Bitmap, PoseFootRegions>()
private val unifiedCastShadowSilhouetteCache = WeakHashMap<Bitmap, Bitmap>()
private val detectedGroundPlaneCache = WeakHashMap<Bitmap, DetectedGroundPlane>()

enum class GroundSurfaceCategory {
    DESERT_SAND,
    STONE_TILES,
    GRASS,
    ROAD_PAVEMENT,
    SNOW,
    INDOOR_FLOOR,
    WATER_EDGE
}

data class DetectedGroundPlane(
    val groundContactYRatio: Float = 0.90f,
    val horizonYRatio: Float = 0.54f,
    val surfaceCategory: GroundSurfaceCategory = GroundSurfaceCategory.STONE_TILES,
    val avgGroundR: Int = 148,
    val avgGroundG: Int = 142,
    val avgGroundB: Int = 132,
    val groundLum: Float = 0.54f,
    val isSunnyOutdoor: Boolean = true,
    val isDiffusedAmbient: Boolean = false
)

fun registerPoseFootRegions(bitmap: Bitmap?, regions: PoseFootRegions?) {
    if (bitmap == null || regions == null || !regions.hasAnyShoe()) return
    synchronized(poseFootRegionsCache) {
        poseFootRegionsCache[bitmap] = regions
    }
}

fun getPoseFootRegions(bitmap: Bitmap?): PoseFootRegions? {
    if (bitmap == null) return null
    synchronized(poseFootRegionsCache) {
        return poseFootRegionsCache[bitmap]
    }
}

fun copyPoseFootRegions(source: Bitmap?, target: Bitmap?) {
    if (source == null || target == null || source === target) return
    val existing = getPoseFootRegions(source) ?: return
    registerPoseFootRegions(target, existing)
}

private fun distPointToSegment(
    px: Float, py: Float,
    ax: Float, ay: Float,
    bx: Float, by: Float
): Float {
    val abx = bx - ax
    val aby = by - ay
    val lenSq = abx * abx + aby * aby
    if (lenSq <= 1e-7f) return hypot(px - ax, py - ay)
    val t = (((px - ax) * abx + (py - ay) * aby) / lenSq).coerceIn(0f, 1f)
    val projX = ax + t * abx
    val projY = ay + t * aby
    return hypot(px - projX, py - projY)
}

private fun buildShoeCapsule(
    ankle: PoseLandmark?,
    heel: PoseLandmark?,
    toe: PoseLandmark?,
    srcWidth: Int,
    srcHeight: Int
): AnatomicalShoeCapsule? {
    val w = srcWidth.toFloat().coerceAtLeast(1f)
    val h = srcHeight.toFloat().coerceAtLeast(1f)

    val minConf = 0.42f
    val validAnkle = ankle?.takeIf { it.inFrameLikelihood >= minConf }
    val validHeel = heel?.takeIf { it.inFrameLikelihood >= minConf }
    val validToe = toe?.takeIf { it.inFrameLikelihood >= minConf }

    val validCount = (if (validAnkle != null) 1 else 0) +
        (if (validHeel != null) 1 else 0) +
        (if (validToe != null) 1 else 0)
    if (validCount < 2) return null

    fun nx(lm: PoseLandmark): Float = (lm.position.x / w).coerceIn(-0.04f, 1.04f)
    fun ny(lm: PoseLandmark): Float = (lm.position.y / h).coerceIn(-0.04f, 1.04f)

    // Keep landmarks that fall inside or just touching frame bounds
    val allPts = listOfNotNull(validAnkle, validHeel, validToe)
    if (allPts.any { it.position.x < -w * 0.08f || it.position.x > w * 1.08f || it.position.y < -h * 0.08f || it.position.y > h * 1.08f }) {
        return null
    }

    val rawAx = validAnkle?.let { nx(it) } ?: ((validHeel?.let { nx(it) } ?: 0.5f))
    val rawAy = validAnkle?.let { ny(it) } ?: ((validHeel?.let { ny(it) } ?: 0.85f) - 0.045f)

    val rawHx = validHeel?.let { nx(it) } ?: (rawAx - 0.015f)
    val rawHy = validHeel?.let { ny(it) } ?: (rawAy + 0.032f)

    val rawTx = validToe?.let { nx(it) } ?: (rawHx + 0.045f)
    val rawTy = validToe?.let { ny(it) } ?: (rawHy + 0.012f)

    val footDx = rawTx - rawHx
    val footDy = rawTy - rawHy
    val rawLen = hypot(footDx, footDy).coerceIn(0.032f, 0.22f)

    // Subtle 10% sole/toe extension along heel->toe axis so thick sneakers/boots stay intact without spilling onto gap
    val extHx = (rawHx - footDx * 0.12f).coerceIn(0f, 1f)
    val extHy = (rawHy - footDy * 0.10f).coerceIn(0f, 1f)
    val extTx = (rawTx + footDx * 0.14f).coerceIn(0f, 1f)
    val extTy = (rawTy + footDy * 0.10f).coerceIn(0f, 1f)

    val tubeRad = (rawLen * 0.36f).coerceIn(0.022f, 0.068f)
    val pad = tubeRad * 1.15f

    val minX = (min(rawAx, min(extHx, extTx)) - pad).coerceIn(0f, 1f)
    val maxX = (max(rawAx, max(extHx, extTx)) + pad).coerceIn(0f, 1f)
    val minY = (min(rawAy, min(extHy, extTy)) - pad).coerceIn(0f, 1f)
    val maxY = (max(rawAy, max(extHy, extTy)) + pad * 1.15f).coerceIn(0f, 1f)
    val soleY = max(extHy, extTy).coerceIn(0f, 1f)
    val centerX = ((extHx + extTx) * 0.5f).coerceIn(0.03f, 0.97f)

    return AnatomicalShoeCapsule(
        ankleX = rawAx.coerceIn(0f, 1f),
        ankleY = rawAy.coerceIn(0f, 1f),
        heelX = extHx,
        heelY = extHy,
        toeX = extTx,
        toeY = extTy,
        minX = minX,
        maxX = maxX,
        minY = minY,
        maxY = maxY,
        tubeRadius = tubeRad,
        soleY = soleY,
        centerX = centerX
    )
}

fun extractPoseFootRegions(pose: Pose?, srcWidth: Int, srcHeight: Int): PoseFootRegions? {
    if (pose == null || srcWidth <= 0 || srcHeight <= 0) return null
    return try {
        val left = buildShoeCapsule(
            ankle = pose.getPoseLandmark(PoseLandmark.LEFT_ANKLE),
            heel = pose.getPoseLandmark(PoseLandmark.LEFT_HEEL),
            toe = pose.getPoseLandmark(PoseLandmark.LEFT_FOOT_INDEX),
            srcWidth = srcWidth,
            srcHeight = srcHeight
        )
        val right = buildShoeCapsule(
            ankle = pose.getPoseLandmark(PoseLandmark.RIGHT_ANKLE),
            heel = pose.getPoseLandmark(PoseLandmark.RIGHT_HEEL),
            toe = pose.getPoseLandmark(PoseLandmark.RIGHT_FOOT_INDEX),
            srcWidth = srcWidth,
            srcHeight = srcHeight
        )
        if (left == null && right == null) null
        else PoseFootRegions(
            leftShoe = left,
            rightShoe = right,
            sourceAspect = srcWidth.toFloat() / srcHeight.toFloat().coerceAtLeast(1f)
        )
    } catch (_: Throwable) {
        null
    }
}

fun detectPoseFootRegionsSync(
    inputImage: InputImage,
    width: Int,
    height: Int,
    reuseDetector: PoseDetector? = null,
    timeoutMs: Long = 1400L
): PoseFootRegions? {
    var ownedDetector: PoseDetector? = null
    return try {
        val detector = reuseDetector ?: PoseDetection.getClient(
            PoseDetectorOptions.Builder()
                .setDetectorMode(PoseDetectorOptions.SINGLE_IMAGE_MODE)
                .build()
        ).also { ownedDetector = it }
        val pose = Tasks.await(detector.process(inputImage), timeoutMs, TimeUnit.MILLISECONDS)
        extractPoseFootRegions(pose, width, height)
    } catch (_: Throwable) {
        null
    } finally {
        try {
            ownedDetector?.close()
        } catch (_: Throwable) {}
    }
}

/**
 * Unified full-body & anatomical shoe alpha mask refinement shared across:
 * 1. Still photos -> Live Preview + 4200px Saved Photo + Voice AI 15s Video
 * 2. Live Camera -> Live Video Preview + 15s Recorded Video
 */
fun buildRefinedFullBodyMask(
    rawConfidences: FloatArray,
    maskWidth: Int,
    maskHeight: Int,
    proxyPixels: IntArray,
    proxyW: Int,
    proxyH: Int,
    poseRegions: PoseFootRegions?
): FloatArray? {
    if (maskWidth <= 8 || maskHeight <= 8 || rawConfidences.size < maskWidth * maskHeight) return null
    val totalMaskPixels = maskWidth * maskHeight

    var personTopY = maskHeight - 1
    var personBottomY = 0
    var personPixelCount = 0

    for (y in 0 until maskHeight) {
        val rowOff = y * maskWidth
        for (x in 0 until maskWidth) {
            if (rawConfidences[rowOff + x] >= 0.34f) {
                if (y < personTopY) personTopY = y
                if (y > personBottomY) personBottomY = y
                personPixelCount++
            }
        }
    }

    val personRatio = personPixelCount.toFloat() / totalMaskPixels.toFloat()
    if (personRatio !in 0.015f..0.97f || personBottomY <= personTopY) {
        return null
    }

    val personHeight = (personBottomY - personTopY).coerceAtLeast(maskHeight / 5)
    val lowerBodyStartY = (personTopY + (personHeight * 0.45f).toInt()).coerceIn(0, maskHeight - 1)
    val bottom15StartY = (personBottomY - (personHeight * 0.15f).toInt()).coerceIn(0, maskHeight - 1)
    val bottomSoleExtendY = (personBottomY + (personHeight * 0.025f).toInt()).coerceIn(personBottomY, maskHeight - 1)

    // Sample known lower-half outer background colors (confidence < 0.12f) to scrub enclosed leg/shoe gaps
    val lowerBgR = IntArray(48)
    val lowerBgG = IntArray(48)
    val lowerBgB = IntArray(48)
    var lowerBgCount = 0
    val bgStepY = ((maskHeight - lowerBodyStartY) / 8).coerceAtLeast(1)
    val bgStepX = (maskWidth / 10).coerceAtLeast(1)
    for (y in lowerBodyStartY until maskHeight step bgStepY) {
        val rowOff = y * maskWidth
        val py = ((y * proxyH) / maskHeight).coerceIn(0, proxyH - 1)
        val pRowOff = py * proxyW
        for (x in 0 until maskWidth step bgStepX) {
            val nx = x.toFloat() / maskWidth.toFloat()
            val ny = y.toFloat() / maskHeight.toFloat()
            val inPoseShoe = (poseRegions?.classifyPixel(nx, ny, strictCore = false) ?: 0) != 0
            if (!inPoseShoe && rawConfidences[rowOff + x] < 0.12f && lowerBgCount < 48) {
                val px = ((x * proxyW) / maskWidth).coerceIn(0, proxyW - 1)
                val c = proxyPixels[pRowOff + px]
                lowerBgR[lowerBgCount] = (c ushr 16) and 0xFF
                lowerBgG[lowerBgCount] = (c ushr 8) and 0xFF
                lowerBgB[lowerBgCount] = c and 0xFF
                lowerBgCount++
            }
        }
    }

    fun minLowerBgDist(r: Int, g: Int, b: Int): Float {
        if (lowerBgCount == 0) return 999f
        var best = 999f
        for (i in 0 until lowerBgCount) {
            val dr = (r - lowerBgR[i]).toFloat()
            val dg = (g - lowerBgG[i]).toFloat()
            val db = (b - lowerBgB[i]).toFloat()
            val d = sqrt(dr * dr + dg * dg + db * db)
            if (d < best) best = d
        }
        return best
    }

    // Sample known core shoe colors inside each pose-detected shoe capsule (where ML Kit >= 0.30f or close to shoe bone)
    fun sampleShoeCoreColor(capsule: AnatomicalShoeCapsule?): IntArray? {
        if (capsule == null) return null
        var sumR = 0L
        var sumG = 0L
        var sumB = 0L
        var count = 0
        val y0 = (capsule.minY * maskHeight).toInt().coerceIn(0, maskHeight - 1)
        val y1 = (capsule.maxY * maskHeight).toInt().coerceIn(0, maskHeight - 1)
        val x0 = (capsule.minX * maskWidth).toInt().coerceIn(0, maskWidth - 1)
        val x1 = (capsule.maxX * maskWidth).toInt().coerceIn(0, maskWidth - 1)
        for (y in y0..y1) {
            val ny = (y + 0.5f) / maskHeight.toFloat()
            val py = ((y * proxyH) / maskHeight).coerceIn(0, proxyH - 1)
            val pRowOff = py * proxyW
            val rowOff = y * maskWidth
            for (x in x0..x1) {
                val nx = (x + 0.5f) / maskWidth.toFloat()
                if (capsule.containsNorm(nx, ny, radiusMultiplier = 0.55f) && rawConfidences[rowOff + x] >= 0.32f) {
                    val px = ((x * proxyW) / maskWidth).coerceIn(0, proxyW - 1)
                    val c = proxyPixels[pRowOff + px]
                    sumR += (c ushr 16) and 0xFF
                    sumG += (c ushr 8) and 0xFF
                    sumB += c and 0xFF
                    count++
                }
            }
        }
        if (count < 4) return null
        return intArrayOf((sumR / count).toInt(), (sumG / count).toInt(), (sumB / count).toInt())
    }

    val leftShoeAvgRgb = sampleShoeCoreColor(poseRegions?.leftShoe)
    val rightShoeAvgRgb = sampleShoeCoreColor(poseRegions?.rightShoe)
    val hasPoseShoes = poseRegions != null && poseRegions.hasAnyShoe()

    val baseAlpha = FloatArray(totalMaskPixels)
    for (y in 0 until maskHeight) {
        val rowOff = y * maskWidth
        val ny = (y + 0.5f) / maskHeight.toFloat()
        val inLowerBody = y in lowerBodyStartY..bottomSoleExtendY
        val inShoeBandY = y in bottom15StartY..bottomSoleExtendY
        val py = ((y * proxyH) / maskHeight).coerceIn(0, proxyH - 1)
        val pRowOff = py * proxyW

        var rowSolidLeft = maskWidth
        var rowSolidRight = -1
        if (inLowerBody) {
            for (x in 0 until maskWidth) {
                if (rawConfidences[rowOff + x] >= 0.48f) {
                    if (x < rowSolidLeft) rowSolidLeft = x
                    if (x > rowSolidRight) rowSolidRight = x
                }
            }
        }

        for (x in 0 until maskWidth) {
            var confidence = rawConfidences[rowOff + x]
            val nx = (x + 0.5f) / maskWidth.toFloat()
            val poseShoeId = if (hasPoseShoes) poseRegions!!.classifyPixel(nx, ny, strictCore = false) else 0
            val inPoseShoeCore = if (hasPoseShoes) poseRegions!!.classifyPixel(nx, ny, strictCore = true) != 0 else false

            // 1. Clean enclosed leg/shoe gap removal (NEVER erases pose-detected shoe capsules)
            if (poseShoeId == 0 && inLowerBody && x in (rowSolidLeft + 1) until rowSolidRight && confidence in 0.14f..0.60f) {
                val px = ((x * proxyW) / maskWidth).coerceIn(0, proxyW - 1)
                val c = proxyPixels[pRowOff + px]
                val r = (c ushr 16) and 0xFF
                val g = (c ushr 8) and 0xFF
                val b = c and 0xFF
                val bgDist = minLowerBgDist(r, g, b)

                if (confidence < 0.38f && bgDist < 46f) {
                    confidence = 0f
                } else if (bgDist < 36f) {
                    var fgR = 0
                    var fgG = 0
                    var fgB = 0
                    var fgSamples = 0
                    for (dx in 2..28 step 3) {
                        val lx = x - dx
                        if (lx >= 0 && rawConfidences[rowOff + lx] >= 0.65f) {
                            val lc = proxyPixels[pRowOff + ((lx * proxyW) / maskWidth).coerceIn(0, proxyW - 1)]
                            fgR += (lc ushr 16) and 0xFF
                            fgG += (lc ushr 8) and 0xFF
                            fgB += lc and 0xFF
                            fgSamples++
                            break
                        }
                    }
                    for (dx in 2..28 step 3) {
                        val rx = x + dx
                        if (rx < maskWidth && rawConfidences[rowOff + rx] >= 0.65f) {
                            val rc = proxyPixels[pRowOff + ((rx * proxyW) / maskWidth).coerceIn(0, proxyW - 1)]
                            fgR += (rc ushr 16) and 0xFF
                            fgG += (rc ushr 8) and 0xFF
                            fgB += rc and 0xFF
                            fgSamples++
                            break
                        }
                    }
                    if (fgSamples > 0) {
                        val avgFgR = fgR / fgSamples
                        val avgFgG = fgG / fgSamples
                        val avgFgB = fgB / fgSamples
                        val fgDist = sqrt(
                            ((r - avgFgR) * (r - avgFgR) + (g - avgFgG) * (g - avgFgG) + (b - avgFgB) * (b - avgFgB)).toFloat()
                        )
                        if (bgDist + 10f < fgDist) {
                            confidence = 0f
                        }
                    }
                }
            }

            // 2. Anatomical Pose-Guided Shoe Protection (per-foot capsule, zero floor bridge)
            var isProtectedShoePixel = false
            if (poseShoeId != 0) {
                val px = ((x * proxyW) / maskWidth).coerceIn(0, proxyW - 1)
                val c = proxyPixels[pRowOff + px]
                val r = (c ushr 16) and 0xFF
                val g = (c ushr 8) and 0xFF
                val b = c and 0xFF
                val bgDist = minLowerBgDist(r, g, b)
                val shoeCoreRgb = if (poseShoeId == 1) leftShoeAvgRgb else rightShoeAvgRgb
                val shoeCoreDist = if (shoeCoreRgb != null) {
                    val dr = (r - shoeCoreRgb[0]).toFloat()
                    val dg = (g - shoeCoreRgb[1]).toFloat()
                    val db = (b - shoeCoreRgb[2]).toFloat()
                    sqrt(dr * dr + dg * dg + db * db)
                } else 999f

                val clearlyMatchesShoe = shoeCoreRgb != null && (shoeCoreDist + 8f < bgDist || shoeCoreDist < 38f)
                val clearlyMatchesOuterBg = lowerBgCount > 0 && bgDist < 24f && shoeCoreDist > bgDist + 14f

                if (inPoseShoeCore) {
                    if (confidence >= 0.14f || (confidence >= 0.04f && clearlyMatchesShoe) || (!clearlyMatchesOuterBg && confidence >= 0.08f)) {
                        isProtectedShoePixel = true
                        if (clearlyMatchesShoe || confidence >= 0.18f) {
                            confidence = max(confidence, 0.56f)
                        }
                    }
                } else {
                    if (confidence >= 0.24f || (confidence >= 0.14f && !clearlyMatchesOuterBg && clearlyMatchesShoe)) {
                        isProtectedShoePixel = true
                    }
                }
            } else if (inShoeBandY && confidence > 0.16f) {
                // Fallback tight local shoe-contour protection when pose landmarks are occluded
                if (confidence >= 0.36f) {
                    isProtectedShoePixel = true
                } else {
                    for (dy in -2..2) {
                        val sy = (y + dy).coerceIn(0, maskHeight - 1)
                        val sRow = sy * maskWidth
                        for (dx in -2..2) {
                            val sx = (x + dx).coerceIn(0, maskWidth - 1)
                            if (rawConfidences[sRow + sx] >= 0.36f) {
                                isProtectedShoePixel = true
                                break
                            }
                        }
                        if (isProtectedShoePixel) break
                    }
                    if (isProtectedShoePixel && lowerBgCount > 0) {
                        val px = ((x * proxyW) / maskWidth).coerceIn(0, proxyW - 1)
                        val c = proxyPixels[pRowOff + px]
                        val bgDist = minLowerBgDist((c ushr 16) and 0xFF, (c ushr 8) and 0xFF, c and 0xFF)
                        if (bgDist < 24f && confidence < 0.30f) {
                            isProtectedShoePixel = false
                        }
                    }
                }
            }

            val aFloat = if (isProtectedShoePixel) {
                when {
                    confidence >= 0.38f -> 1f
                    confidence <= 0.12f -> 0f
                    else -> {
                        val t = ((confidence - 0.12f) / 0.26f).coerceIn(0f, 1f)
                        t * t * (3f - 2f * t)
                    }
                }
            } else {
                when {
                    confidence >= 0.62f -> 1f
                    confidence <= 0.30f -> 0f
                    else -> {
                        val t = ((confidence - 0.30f) / 0.32f).coerceIn(0f, 1f)
                        t * t * (3f - 2f * t)
                    }
                }
            }
            baseAlpha[rowOff + x] = aFloat
        }
    }

    // Centered 3-tap AA strictly along boundary pixels (no outward dilation, no BlurMaskFilter halo bloat)
    val aa3 = floatArrayOf(0.18f, 0.64f, 0.18f)
    val horiz = FloatArray(totalMaskPixels)
    for (y in 0 until maskHeight) {
        val rowOff = y * maskWidth
        for (x in 0 until maskWidth) {
            val center = baseAlpha[rowOff + x]
            val l = baseAlpha[rowOff + (x - 1).coerceAtLeast(0)]
            val r = baseAlpha[rowOff + (x + 1).coerceAtMost(maskWidth - 1)]
            horiz[rowOff + x] = if (center == 0f && l == 0f && r == 0f) {
                0f
            } else if (center == 1f && l == 1f && r == 1f) {
                1f
            } else {
                l * aa3[0] + center * aa3[1] + r * aa3[2]
            }
        }
    }

    val finalMask = FloatArray(totalMaskPixels)
    for (y in 0 until maskHeight) {
        val rowOff = y * maskWidth
        val upRow = (y - 1).coerceAtLeast(0) * maskWidth
        val dnRow = (y + 1).coerceAtMost(maskHeight - 1) * maskWidth
        for (x in 0 until maskWidth) {
            val u = horiz[upRow + x]
            val c = horiz[rowOff + x]
            val d = horiz[dnRow + x]
            val smoothed = if (c == 0f && u == 0f && d == 0f) {
                0f
            } else if (c == 1f && u == 1f && d == 1f) {
                1f
            } else {
                u * aa3[0] + c * aa3[1] + d * aa3[2]
            }
            finalMask[rowOff + x] = if (baseAlpha[rowOff + x] <= 0f && smoothed < 0.16f) 0f else smoothed.coerceIn(0f, 1f)
        }
    }
    return finalMask
}

/**
 * Unified O(N) Contour Anti-Aliasing, 1px High-Contrast Edge Color Decontamination,
 * Shoe-Safe Preservation, and Warm Outer-1px Lighting Wrap.
 * Shared across Live Preview, 4200px Saved Photo, and 15s Video Rendering.
 */
fun purifyCutoutContour(
    source: Bitmap,
    bgBitmap: Bitmap? = null,
    subjectLeftOnBg: Float = 0f,
    subjectTopOnBg: Float = 0f,
    personRectOnCanvas: RectF? = null,
    bgRectOnCanvas: RectF? = null,
    performInwardTrim: Boolean = false,
    upwardBounceColorArgb: Int = 0,
    poseRegions: PoseFootRegions? = null
): Bitmap {
    return try {
        val width = source.width
        val height = source.height
        if (width <= 8 || height <= 8) return source

        val totalPixels = width * height
        val pixels = IntArray(totalPixels)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        val alphaBuf = ByteArray(totalPixels)
        val smoothedEdgeAlpha = ByteArray(totalPixels)
        for (i in 0 until totalPixels) {
            val a = (pixels[i] ushr 24) and 0xFF
            val cleanA = if (a < 14) 0 else a
            alphaBuf[i] = cleanA.toByte()
            smoothedEdgeAlpha[i] = cleanA.toByte()
        }

        // PASS 0: Isolated 1px-2px speckle purge
        for (y in 1 until height - 1) {
            val row = y * width
            for (x in 1 until width - 1) {
                val idx = row + x
                val a = alphaBuf[idx].toInt() and 0xFF
                if (a == 0) continue
                if ((alphaBuf[idx - 1].toInt() and 0xFF) > 22 && (alphaBuf[idx + 1].toInt() and 0xFF) > 22 &&
                    (alphaBuf[idx - width].toInt() and 0xFF) > 22 && (alphaBuf[idx + width].toInt() and 0xFF) > 22
                ) {
                    continue
                }
                var hits3 = 0
                for (dy in -1..1) {
                    val nRow = (y + dy) * width
                    for (dx in -1..1) {
                        if ((alphaBuf[nRow + x + dx].toInt() and 0xFF) > 22) hits3++
                    }
                }
                if (hits3 <= 1 || (hits3 <= 2 && a < 175)) smoothedEdgeAlpha[idx] = 0
            }
        }

        // PASS 1: O(N) Chamfer 3-4 distance to transparent edge
        val chamferDist = ShortArray(totalPixels) { i -> if ((smoothedEdgeAlpha[i].toInt() and 0xFF) == 0) 0 else 999 }
        for (y in 0 until height) {
            val row = y * width
            for (x in 0 until width) {
                val idx = row + x
                var d = chamferDist[idx].toInt()
                if (d == 0) continue
                if (y > 0) {
                    val up = (y - 1) * width + x
                    d = minOf(d, chamferDist[up].toInt() + 3)
                    if (x > 0) d = minOf(d, chamferDist[up - 1].toInt() + 4)
                    if (x + 1 < width) d = minOf(d, chamferDist[up + 1].toInt() + 4)
                }
                if (x > 0) d = minOf(d, chamferDist[idx - 1].toInt() + 3)
                chamferDist[idx] = d.coerceAtMost(3000).toShort()
            }
        }
        for (y in height - 1 downTo 0) {
            val row = y * width
            for (x in width - 1 downTo 0) {
                val idx = row + x
                var d = chamferDist[idx].toInt()
                if (d == 0) continue
                if (y + 1 < height) {
                    val dn = (y + 1) * width + x
                    d = minOf(d, chamferDist[dn].toInt() + 3)
                    if (x > 0) d = minOf(d, chamferDist[dn - 1].toInt() + 4)
                    if (x + 1 < width) d = minOf(d, chamferDist[dn + 1].toInt() + 4)
                }
                if (x + 1 < width) d = minOf(d, chamferDist[idx + 1].toInt() + 3)
                chamferDist[idx] = d.coerceAtMost(3000).toShort()
            }
        }

        // PASS 2: Full-body alpha lock + smooth 3x3 contour anti-aliasing
        for (i in 0 until totalPixels) {
            val origA = smoothedEdgeAlpha[i].toInt() and 0xFF
            val lockedA = when {
                origA == 0 -> 0
                origA >= 242 -> 255
                else -> origA
            }
            alphaBuf[i] = lockedA.toByte()
            smoothedEdgeAlpha[i] = lockedA.toByte()
        }
        for (y in 1 until height - 1) {
            val row = y * width
            for (x in 1 until width - 1) {
                val idx = row + x
                val a = alphaBuf[idx].toInt() and 0xFF
                val dist = chamferDist[idx].toFloat() / 3.0f
                if ((a in 1..254) || (a > 0 && dist <= 1.6f)) {
                    val avg = (
                        a * 4 +
                            (alphaBuf[idx - 1].toInt() and 0xFF) * 2 +
                            (alphaBuf[idx + 1].toInt() and 0xFF) * 2 +
                            (alphaBuf[idx - width].toInt() and 0xFF) * 2 +
                            (alphaBuf[idx + width].toInt() and 0xFF) * 2 +
                            (alphaBuf[idx - width - 1].toInt() and 0xFF) +
                            (alphaBuf[idx - width + 1].toInt() and 0xFF) +
                            (alphaBuf[idx + width - 1].toInt() and 0xFF) +
                            (alphaBuf[idx + width + 1].toInt() and 0xFF)
                        ) / 16
                    smoothedEdgeAlpha[idx] = (if (a >= 220) maxOf(a, avg) else avg).toByte()
                }
            }
        }

        // PASS 3: Head-to-toe 1px edge color decontamination + white halo elimination + warm outer rim blend
        val kSampleDist = 4
        val bgW = bgBitmap?.width ?: 0
        val bgH = bgBitmap?.height ?: 0
        val hasBg = bgBitmap != null && !bgBitmap.isRecycled && bgW > 0 && bgH > 0
        val hasCanvasRects = hasBg && personRectOnCanvas != null && bgRectOnCanvas != null &&
            bgRectOnCanvas.width() > 1f && bgRectOnCanvas.height() > 1f
        val defringeBoundary = if (performInwardTrim) 3.8f else 2.6f
        val safeUntouchedSampleDist = defringeBoundary + 0.15f
        val bottomShoeBandY = (height * 0.85f).toInt()
        val effectivePoseRegions = poseRegions ?: getPoseFootRegions(source)
        val hasPose = effectivePoseRegions != null && effectivePoseRegions.hasAnyShoe()

        val hasWarmTint = ((upwardBounceColorArgb ushr 24) and 0xFF) > 0
        val warmTintR = (upwardBounceColorArgb ushr 16) and 0xFF
        val warmTintG = (upwardBounceColorArgb ushr 8) and 0xFF
        val warmTintB = upwardBounceColorArgb and 0xFF

        for (y in 0 until height) {
            val row = y * width
            val ny = (y + 0.5f) / height.toFloat()
            val bgY = if (hasCanvasRects) {
                val canvasY = personRectOnCanvas!!.top + (y.toFloat() / height.toFloat()) * personRectOnCanvas.height()
                (((canvasY - bgRectOnCanvas!!.top) / bgRectOnCanvas.height()) * bgH).toInt().coerceIn(0, bgH - 1)
            } else if (hasBg) {
                (subjectTopOnBg + y).toInt().coerceIn(0, bgH - 1)
            } else 0

            for (x in 0 until width) {
                val idx = row + x
                var finalA = smoothedEdgeAlpha[idx].toInt() and 0xFF
                if (finalA <= 8) {
                    pixels[idx] = 0x00000000
                    continue
                }

                val origColor = pixels[idx]
                var r = (origColor ushr 16) and 0xFF
                var g = (origColor ushr 8) and 0xFF
                var b = origColor and 0xFF
                val dist = chamferDist[idx].toFloat() / 3.0f

                if (dist <= defringeBoundary) {
                    val nx = (x + 0.5f) / width.toFloat()
                    val inShoeZone = if (hasPose) {
                        effectivePoseRegions!!.classifyPixel(nx, ny, strictCore = false) != 0
                    } else {
                        y >= bottomShoeBandY
                    }

                    var fgR = 0
                    var fgG = 0
                    var fgB = 0
                    var fgCount = 0
                    for (dy in -kSampleDist..kSampleDist) {
                        val nyIdx = (y + dy).coerceIn(0, height - 1)
                        val nRow = nyIdx * width
                        for (dx in -kSampleDist..kSampleDist) {
                            val nxIdx = (x + dx).coerceIn(0, width - 1)
                            val nIdx = nRow + nxIdx
                            val nDist = chamferDist[nIdx].toFloat() / 3.0f
                            if (nDist >= safeUntouchedSampleDist && (smoothedEdgeAlpha[nIdx].toInt() and 0xFF) >= 225) {
                                val nc = pixels[nIdx]
                                fgR += (nc ushr 16) and 0xFF
                                fgG += (nc ushr 8) and 0xFF
                                fgB += nc and 0xFF
                                fgCount++
                            }
                        }
                    }

                    if (fgCount > 0) {
                        val avgFgR = fgR / fgCount
                        val avgFgG = fgG / fgCount
                        val avgFgB = fgB / fgCount
                        val lumaPx = 0.299f * r + 0.587f * g + 0.114f * b
                        val lumaFg = 0.299f * avgFgR + 0.587f * avgFgG + 0.114f * avgFgB
                        val colorDiff = abs(r - avgFgR) + abs(g - avgFgG) + abs(b - avgFgB)

                        val isGreenSpill = (g > r * 1.08f && g > b * 1.08f && g > 45) || (g - r > 18 && g - b > 18)
                        val isBlueSpill = (b > r * 1.08f && b > g * 1.08f && b > 45) || (b - r > 18 && b - g > 18)
                        val isCyanSpill = (b > 90 && g > 90 && b > r * 1.15f && g > r * 1.15f)
                        val isLightHalo = (r > avgFgR + 16 && g > avgFgG + 16 && b > avgFgB + 16 && lumaPx > 142f) ||
                            (lumaPx - lumaFg > 26f && lumaPx > 152f)
                        val isHighContrastEdge = isLightHalo || isGreenSpill || isBlueSpill || isCyanSpill || (colorDiff > 64)

                        if (isHighContrastEdge) {
                            val allowFullDrop = (!inShoeZone && (finalA < 240 || isLightHalo)) ||
                                (inShoeZone && (isLightHalo || finalA < 208))
                            if (allowFullDrop && dist <= 1.10f && (isLightHalo || colorDiff > 76)) {
                                pixels[idx] = 0x00000000
                                continue
                            } else if (dist <= 1.55f) {
                                finalA = (finalA * if (inShoeZone && !isLightHalo) 0.62f else 0.34f).toInt().coerceIn(0, 255)
                            }
                            val pullRatio = if (inShoeZone && finalA >= 220 && !isLightHalo) 0.35f else if (dist <= 2.15f) 1.0f else 0.72f
                            r = ((r * (1f - pullRatio)) + (avgFgR * pullRatio)).toInt().coerceIn(0, 255)
                            g = ((g * (1f - pullRatio)) + (avgFgG * pullRatio)).toInt().coerceIn(0, 255)
                            b = ((b * (1f - pullRatio)) + (avgFgB * pullRatio)).toInt().coerceIn(0, 255)
                        } else {
                            val maxDefringe = if (inShoeZone) 0.25f else 0.65f
                            val defringeRatio = (if (dist <= 1.8f) 0.65f else if (dist <= 2.6f) 0.38f else 0.16f)
                                .coerceAtMost(maxDefringe)
                            r = ((r * (1f - defringeRatio)) + (avgFgR * defringeRatio)).toInt().coerceIn(0, 255)
                            g = ((g * (1f - defringeRatio)) + (avgFgG * defringeRatio)).toInt().coerceIn(0, 255)
                            b = ((b * (1f - defringeRatio)) + (avgFgB * defringeRatio)).toInt().coerceIn(0, 255)
                        }
                    }

                    val wrapOuterLimit = 1.65f
                    if (hasBg && finalA > 8 && dist <= wrapOuterLimit) {
                        val bgX = if (hasCanvasRects) {
                            val canvasX = personRectOnCanvas!!.left + (x.toFloat() / width.toFloat()) * personRectOnCanvas.width()
                            (((canvasX - bgRectOnCanvas!!.left) / bgRectOnCanvas.width()) * bgW).toInt().coerceIn(0, bgW - 1)
                        } else {
                            (subjectLeftOnBg + x).toInt().coerceIn(0, bgW - 1)
                        }
                        val bgLeftPx = bgBitmap!!.getPixel((bgX - 2).coerceAtLeast(0), bgY)
                        val bgCenterPx = bgBitmap.getPixel(bgX, bgY)
                        val bgRightPx = bgBitmap.getPixel((bgX + 2).coerceAtMost(bgW - 1), bgY)
                        var bgR = (((bgLeftPx ushr 16) and 0xFF) + ((bgCenterPx ushr 16) and 0xFF) * 2 + ((bgRightPx ushr 16) and 0xFF)) / 4
                        var bgG = (((bgLeftPx ushr 8) and 0xFF) + ((bgCenterPx ushr 8) and 0xFF) * 2 + ((bgRightPx ushr 8) and 0xFF)) / 4
                        var bgB = ((bgLeftPx and 0xFF) + (bgCenterPx and 0xFF) * 2 + (bgRightPx and 0xFF)) / 4
                        if (hasWarmTint) {
                            bgR = (bgR * 0.80f + warmTintR * 0.20f).toInt().coerceIn(0, 255)
                            bgG = (bgG * 0.80f + warmTintG * 0.20f).toInt().coerceIn(0, 255)
                            bgB = (bgB * 0.80f + warmTintB * 0.20f).toInt().coerceIn(0, 255)
                        }

                        val wrapAlpha = ((wrapOuterLimit - dist) / 1.15f).coerceIn(0f, 1f) * 0.26f
                        r = ((r * (1f - wrapAlpha)) + (bgR * wrapAlpha)).toInt().coerceIn(0, 255)
                        g = ((g * (1f - wrapAlpha)) + (bgG * wrapAlpha)).toInt().coerceIn(0, 255)
                        b = ((b * (1f - wrapAlpha)) + (bgB * wrapAlpha)).toInt().coerceIn(0, 255)
                    }
                }

                pixels[idx] = (finalA shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        val dest = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        dest.setPixels(pixels, 0, width, 0, 0, width, height)
        if (effectivePoseRegions != null) {
            registerPoseFootRegions(dest, effectivePoseRegions)
        }
        dest
    } catch (_: OutOfMemoryError) {
        System.gc()
        source
    } catch (_: Throwable) {
        source
    }
}

/**
 * Pose-guided + alpha-contour foot sole anchor detector.
 * Guarantees pixel-accurate sole contact directly under Left & Right shoes across Photo & Video.
 */
fun detectPoseAwareFootAnchor(
    src: Bitmap?,
    explicitPoseRegions: PoseFootRegions? = null
): SubjectFootAnchor {
    if (src == null || src.isRecycled || src.width <= 4 || src.height <= 4) {
        return SubjectFootAnchor()
    }
    return try {
        val width = src.width
        val height = src.height
        val pixels = IntArray(width * height)
        src.getPixels(pixels, 0, width, 0, 0, width, height)

        var lowestY = -1
        var highestY = -1
        for (y in 0 until height) {
            val rowOffset = y * width
            for (x in 0 until width) {
                if (((pixels[rowOffset + x] ushr 24) and 0xFF) >= 30) {
                    if (highestY == -1) highestY = y
                    lowestY = y
                    break
                }
            }
        }
        if (lowestY == -1 || highestY == -1) return SubjectFootAnchor()

        val activeHeight = (lowestY - highestY + 1).coerceAtLeast(1)
        val poseRegions = explicitPoseRegions ?: getPoseFootRegions(src)

        // If ML Kit Pose detected Left & Right shoes individually, anchor each sole from pixel contours inside its shoe bounds
        if (poseRegions != null && (poseRegions.leftShoe != null || poseRegions.rightShoe != null)) {
            fun measureShoeSole(capsule: AnatomicalShoeCapsule?): Triple<Float, Int, Float>? {
                if (capsule == null) return null
                val x0 = (capsule.minX * width).toInt().coerceIn(0, width - 1)
                val x1 = (capsule.maxX * width).toInt().coerceIn(0, width - 1)
                val y0 = (capsule.minY * height).toInt().coerceIn(0, height - 1)
                val y1 = minOf(height - 1, (capsule.maxY * height).toInt() + (height * 0.02f).toInt())

                var shoeLowY = -1
                for (y in y1 downTo y0) {
                    val rowOff = y * width
                    for (x in x0..x1) {
                        if (((pixels[rowOff + x] ushr 24) and 0xFF) >= 35) {
                            shoeLowY = y
                            break
                        }
                    }
                    if (shoeLowY != -1) break
                }
                if (shoeLowY == -1) return null

                val soleBandTop = maxOf(y0, shoeLowY - (activeHeight * 0.045f).toInt().coerceIn(3, 24))
                var minSX = width
                var maxSX = -1
                var wSumX = 0L
                var wTotal = 0L
                for (y in soleBandTop..shoeLowY) {
                    val rowOff = y * width
                    val weight = (y - soleBandTop + 1)
                    for (x in x0..x1) {
                        if (((pixels[rowOff + x] ushr 24) and 0xFF) >= 35) {
                            if (x < minSX) minSX = x
                            if (x > maxSX) maxSX = x
                            wSumX += x.toLong() * weight
                            wTotal += weight
                        }
                    }
                }
                if (wTotal == 0L || maxSX < minSX) return null
                val centerX = (wSumX.toDouble() / wTotal.toDouble()).toFloat()
                val soleW = (maxSX - minSX + 1).toFloat().coerceAtLeast(width * 0.06f)
                return Triple(centerX, shoeLowY, soleW)
            }

            val leftMeas = measureShoeSole(poseRegions.leftShoe)
            val rightMeas = measureShoeSole(poseRegions.rightShoe)
            if (leftMeas != null || rightMeas != null) {
                val effLowestY = maxOf(
                    lowestY,
                    maxOf(leftMeas?.second ?: 0, rightMeas?.second ?: 0)
                )
                val lx = leftMeas?.first ?: rightMeas!!.first
                val rx = rightMeas?.first ?: leftMeas!!.first
                val trueLeftX = min(lx, rx)
                val trueRightX = max(lx, rx)
                val lLowY = (if (lx <= rx) leftMeas?.second else rightMeas?.second) ?: effLowestY
                val rLowY = (if (lx <= rx) rightMeas?.second else leftMeas?.second) ?: effLowestY
                val lW = (if (lx <= rx) leftMeas?.third else rightMeas?.third) ?: (width * 0.14f)
                val rW = (if (lx <= rx) rightMeas?.third else leftMeas?.third) ?: (width * 0.14f)

                val centerX = ((trueLeftX + trueRightX) * 0.5f)
                val stanceW = (trueRightX - trueLeftX).coerceAtLeast(width * 0.08f)
                val isDual = (leftMeas != null && rightMeas != null && (trueRightX - trueLeftX) > width * 0.06f)

                return SubjectFootAnchor(
                    lowestContactYRatio = (effLowestY.toFloat() / height.toFloat()).coerceIn(0.2f, 1.0f),
                    feetCenterRatioX = (centerX / width.toFloat()).coerceIn(0.1f, 0.9f),
                    leftFootRatioX = (trueLeftX / width.toFloat()).coerceIn(0.05f, 0.85f),
                    rightFootRatioX = (trueRightX / width.toFloat()).coerceIn(0.15f, 0.95f),
                    stanceWidthRatio = (stanceW / width.toFloat()).coerceIn(0.08f, 0.65f),
                    isDualFoot = isDual,
                    contactBottomPixelY = effLowestY,
                    subjectHeightActiveRatio = activeHeight.toFloat() / height.toFloat(),
                    leftFootLowestYRatio = (lLowY.toFloat() / height.toFloat()).coerceIn(0.2f, 1.0f),
                    rightFootLowestYRatio = (rLowY.toFloat() / height.toFloat()).coerceIn(0.2f, 1.0f),
                    leftSoleWidthRatio = (lW / width.toFloat()).coerceIn(0.08f, 0.40f),
                    rightSoleWidthRatio = (rW / width.toFloat()).coerceIn(0.08f, 0.40f)
                )
            }
        }

        // Contour-scan fallback when pose landmarks aren't present
        val contactZoneHeight = (activeHeight * 0.10f).toInt().coerceIn(3, 36)
        val startContactY = (lowestY - contactZoneHeight + 1).coerceAtLeast(0)

        var minContactX = width
        var maxContactX = -1
        var totalContactWeight = 0L
        var sumContactX = 0L
        val xHistogram = IntArray(width)

        for (y in startContactY..lowestY) {
            val rowOffset = y * width
            val verticalWeight = (y - startContactY + 1)
            for (x in 0 until width) {
                if (((pixels[rowOffset + x] ushr 24) and 0xFF) >= 40) {
                    if (x < minContactX) minContactX = x
                    if (x > maxContactX) maxContactX = x
                    xHistogram[x] += verticalWeight
                    sumContactX += x.toLong() * verticalWeight
                    totalContactWeight += verticalWeight
                }
            }
        }

        if (totalContactWeight == 0L || minContactX > maxContactX) {
            val defaultLowYRatio = lowestY.toFloat() / height.toFloat()
            return SubjectFootAnchor(
                lowestContactYRatio = defaultLowYRatio,
                feetCenterRatioX = 0.5f,
                leftFootRatioX = 0.38f,
                rightFootRatioX = 0.62f,
                stanceWidthRatio = 0.24f,
                isDualFoot = true,
                contactBottomPixelY = lowestY,
                subjectHeightActiveRatio = activeHeight.toFloat() / height.toFloat(),
                leftFootLowestYRatio = defaultLowYRatio,
                rightFootLowestYRatio = defaultLowYRatio,
                leftSoleWidthRatio = 0.15f,
                rightSoleWidthRatio = 0.15f
            )
        }

        val centerX = (sumContactX.toDouble() / totalContactWeight.toDouble()).toFloat()
        val midX = ((minContactX + maxContactX) / 2).coerceIn(0, width - 1)

        var leftWeight = 0L
        var leftSumX = 0L
        var rightWeight = 0L
        var rightSumX = 0L
        for (x in minContactX..maxContactX) {
            val w = xHistogram[x]
            if (w > 0) {
                if (x < midX) {
                    leftWeight += w
                    leftSumX += x.toLong() * w
                } else {
                    rightWeight += w
                    rightSumX += x.toLong() * w
                }
            }
        }

        val leftFootX = if (leftWeight > 0) (leftSumX.toDouble() / leftWeight.toDouble()).toFloat() else (minContactX + (midX - minContactX) * 0.5f)
        val rightFootX = if (rightWeight > 0) (rightSumX.toDouble() / rightWeight.toDouble()).toFloat() else (midX + (maxContactX - midX) * 0.5f)
        val stanceWidth = (rightFootX - leftFootX).coerceAtLeast(width * 0.08f)
        val isDual = (leftWeight > 0 && rightWeight > 0 && (rightFootX - leftFootX) > width * 0.08f)

        var lowestLeftY = -1
        var lowestRightY = -1
        var leftSoleMinX = width
        var leftSoleMaxX = -1
        var rightSoleMinX = width
        var rightSoleMaxX = -1
        for (y in lowestY downTo startContactY) {
            val rowOffset = y * width
            for (x in minContactX until midX) {
                if (((pixels[rowOffset + x] ushr 24) and 0xFF) >= 35) {
                    if (lowestLeftY == -1) lowestLeftY = y
                    if (x < leftSoleMinX) leftSoleMinX = x
                    if (x > leftSoleMaxX) leftSoleMaxX = x
                }
            }
            for (x in midX..maxContactX) {
                if (((pixels[rowOffset + x] ushr 24) and 0xFF) >= 35) {
                    if (lowestRightY == -1) lowestRightY = y
                    if (x < rightSoleMinX) rightSoleMinX = x
                    if (x > rightSoleMaxX) rightSoleMaxX = x
                }
            }
        }

        val effLowestLeftY = if (lowestLeftY != -1) lowestLeftY else lowestY
        val effLowestRightY = if (lowestRightY != -1) lowestRightY else lowestY
        val leftSoleWidth = if (leftSoleMaxX >= leftSoleMinX) (leftSoleMaxX - leftSoleMinX + 1).toFloat() else (width * 0.15f)
        val rightSoleWidth = if (rightSoleMaxX >= rightSoleMinX) (rightSoleMaxX - rightSoleMinX + 1).toFloat() else (width * 0.15f)

        SubjectFootAnchor(
            lowestContactYRatio = lowestY.toFloat() / height.toFloat(),
            feetCenterRatioX = (centerX / width.toFloat()).coerceIn(0.1f, 0.9f),
            leftFootRatioX = (leftFootX / width.toFloat()).coerceIn(0.05f, 0.85f),
            rightFootRatioX = (rightFootX / width.toFloat()).coerceIn(0.15f, 0.95f),
            stanceWidthRatio = (stanceWidth / width.toFloat()).coerceIn(0.08f, 0.65f),
            isDualFoot = isDual,
            contactBottomPixelY = lowestY,
            subjectHeightActiveRatio = activeHeight.toFloat() / height.toFloat(),
            leftFootLowestYRatio = effLowestLeftY.toFloat() / height.toFloat(),
            rightFootLowestYRatio = effLowestRightY.toFloat() / height.toFloat(),
            leftSoleWidthRatio = (leftSoleWidth / width.toFloat()).coerceIn(0.08f, 0.40f),
            rightSoleWidthRatio = (rightSoleWidth / width.toFloat()).coerceIn(0.08f, 0.40f)
        )
    } catch (_: Throwable) {
        SubjectFootAnchor()
    }
}

private fun getOrCreateUnifiedShadowSilhouette(subjectBitmap: Bitmap?): Bitmap? {
    if (subjectBitmap == null || subjectBitmap.isRecycled || subjectBitmap.width <= 8 || subjectBitmap.height <= 8) {
        return null
    }
    synchronized(unifiedCastShadowSilhouetteCache) {
        unifiedCastShadowSilhouetteCache[subjectBitmap]?.let { cached ->
            if (!cached.isRecycled) return cached
        }
    }
    return try {
        val maxSilDim = 144
        val scale = (maxSilDim.toFloat() / maxOf(subjectBitmap.width, subjectBitmap.height).coerceAtLeast(1)).coerceAtMost(1f)
        val sw = (subjectBitmap.width * scale).toInt().coerceAtLeast(16)
        val sh = (subjectBitmap.height * scale).toInt().coerceAtLeast(16)
        val smallColor = if (scale < 0.99f) Bitmap.createScaledBitmap(subjectBitmap, sw, sh, true) else subjectBitmap
        val alphaOnly = smallColor.extractAlpha()
        if (smallColor !== subjectBitmap && !smallColor.isRecycled) {
            smallColor.recycle()
        }
        synchronized(unifiedCastShadowSilhouetteCache) {
            unifiedCastShadowSilhouetteCache[subjectBitmap] = alphaOnly
        }
        alphaOnly
    } catch (_: Throwable) {
        null
    }
}

/**
 * Detects the walkable foreground ground contact Y ratio, surface material
 * (desert sand, stone tiles, grass, road/pavement, snow, indoor floor, water edge),
 * and ambient ground color directly from any preset or custom background bitmap.
 */
fun detectBackgroundGroundPlane(
    bgBitmap: Bitmap?,
    landmarkHint: String = ""
): DetectedGroundPlane {
    val nameLower = landmarkHint.lowercase()
    fun hintCategory(): GroundSurfaceCategory {
        return when {
            nameLower.contains("sand") || nameLower.contains("desert") || nameLower.contains("dune") ||
                nameLower.contains("sahara") || nameLower.contains("pyramid") || nameLower.contains("jaisalmer") ||
                nameLower.contains("beach") -> GroundSurfaceCategory.DESERT_SAND
            nameLower.contains("snow") || nameLower.contains("glacier") || nameLower.contains("alps") ||
                nameLower.contains("kedarnath") || nameLower.contains("everest") || nameLower.contains("winter") ||
                nameLower.contains("manali") || nameLower.contains("fuji") -> GroundSurfaceCategory.SNOW
            nameLower.contains("grass") || nameLower.contains("garden") || nameLower.contains("park") ||
                nameLower.contains("lawn") || nameLower.contains("forest") || nameLower.contains("jungle") ||
                nameLower.contains("meadow") -> GroundSurfaceCategory.GRASS
            nameLower.contains("indoor") || nameLower.contains("mall") || nameLower.contains("hall") ||
                nameLower.contains("palace") || nameLower.contains("museum") || nameLower.contains("cafe") ||
                nameLower.contains("hotel") || nameLower.contains("room") || nameLower.contains("lobby") ||
                nameLower.contains("airport") || nameLower.contains("metro") || nameLower.contains("interior") ->
                GroundSurfaceCategory.INDOOR_FLOOR
            nameLower.contains("road") || nameLower.contains("street") || nameLower.contains("highway") ||
                nameLower.contains("bridge") || nameLower.contains("avenue") || nameLower.contains("shibuya") ||
                nameLower.contains("asphalt") || nameLower.contains("walkway") -> GroundSurfaceCategory.ROAD_PAVEMENT
            nameLower.contains("water") || nameLower.contains("lake") || nameLower.contains("river") ||
                nameLower.contains("canal") || nameLower.contains("pool") || nameLower.contains("taj") ||
                nameLower.contains("venice") -> GroundSurfaceCategory.WATER_EDGE
            else -> GroundSurfaceCategory.STONE_TILES
        }
    }

    if (bgBitmap == null || bgBitmap.isRecycled || bgBitmap.width < 16 || bgBitmap.height < 16) {
        val cat = hintCategory()
        val isDiff = cat == GroundSurfaceCategory.INDOOR_FLOOR || nameLower.contains("night") ||
            nameLower.contains("evening") || nameLower.contains("shade")
        return DetectedGroundPlane(
            groundContactYRatio = 0.90f,
            horizonYRatio = 0.54f,
            surfaceCategory = cat,
            isSunnyOutdoor = !isDiff,
            isDiffusedAmbient = isDiff
        )
    }

    if (nameLower.isBlank()) {
        synchronized(detectedGroundPlaneCache) {
            detectedGroundPlaneCache[bgBitmap]?.let { return it }
        }
    }

    return try {
        val w = bgBitmap.width
        val h = bgBitmap.height
        val rows = 64
        val cols = 48

        val rowAvgR = FloatArray(rows)
        val rowAvgG = FloatArray(rows)
        val rowAvgB = FloatArray(rows)
        val rowAvgLum = FloatArray(rows)
        val rowTexVar = FloatArray(rows)

        var skySumR = 0f
        var skySumG = 0f
        var skySumB = 0f
        var skySumLum = 0f
        var skyCount = 0

        for (ry in 0 until rows) {
            val py = (((ry + 0.5f) / rows.toFloat()) * h).toInt().coerceIn(0, h - 1)
            var sumR = 0f
            var sumG = 0f
            var sumB = 0f
            var sumL = 0f
            var prevL = -1f
            var diffL = 0f
            for (cx in 0 until cols) {
                val px = (((cx + 0.5f) / cols.toFloat()) * w).toInt().coerceIn(0, w - 1)
                val c = bgBitmap.getPixel(px, py)
                val r = ((c ushr 16) and 0xFF).toFloat()
                val g = ((c ushr 8) and 0xFF).toFloat()
                val b = (c and 0xFF).toFloat()
                val l = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
                sumR += r
                sumG += g
                sumB += b
                sumL += l
                if (prevL >= 0f) diffL += abs(l - prevL)
                prevL = l

                if (ry < (rows * 0.36f).toInt()) {
                    skySumR += r
                    skySumG += g
                    skySumB += b
                    skySumLum += l
                    skyCount++
                }
            }
            rowAvgR[ry] = sumR / cols
            rowAvgG[ry] = sumG / cols
            rowAvgB[ry] = sumB / cols
            rowAvgLum[ry] = sumL / cols
            rowTexVar[ry] = diffL / (cols - 1).coerceAtLeast(1)
        }

        // Horizon / wall-to-floor boundary scan (rows 32%..72%)
        val hStart = (rows * 0.32f).toInt().coerceIn(2, rows - 8)
        val hEnd = (rows * 0.72f).toInt().coerceIn(hStart + 2, rows - 4)
        var bestHorizonRow = (rows * 0.54f).toInt()
        var bestGrad = 0f
        for (ry in hStart..hEnd) {
            val grad = abs(rowAvgLum[ry] - rowAvgLum[ry - 2]) +
                (abs(rowAvgR[ry] - rowAvgR[ry - 2]) + abs(rowAvgB[ry] - rowAvgB[ry - 2])) / 510f
            if (grad > bestGrad) {
                bestGrad = grad
                bestHorizonRow = ry
            }
        }
        val horizonYRatio = (bestHorizonRow.toFloat() / rows.toFloat()).coerceIn(0.36f, 0.72f)

        // Foreground floor zone analysis (76%..93% of image height)
        val fgStart = (rows * 0.76f).toInt().coerceIn(bestHorizonRow + 2, rows - 5)
        val fgEnd = (rows * 0.93f).toInt().coerceIn(fgStart + 1, rows - 1)
        var fgR = 0f
        var fgG = 0f
        var fgB = 0f
        var fgLum = 0f
        var fgCount = 0
        for (ry in fgStart..fgEnd) {
            fgR += rowAvgR[ry]
            fgG += rowAvgG[ry]
            fgB += rowAvgB[ry]
            fgLum += rowAvgLum[ry]
            fgCount++
        }
        val denom = fgCount.coerceAtLeast(1).toFloat()
        val avgGR = (fgR / denom).toInt().coerceIn(0, 255)
        val avgGG = (fgG / denom).toInt().coerceIn(0, 255)
        val avgGB = (fgB / denom).toInt().coerceIn(0, 255)
        val gLum = (fgLum / denom).coerceIn(0.05f, 0.95f)

        val skyLum = if (skyCount > 0) skySumLum / skyCount else gLum
        val skyAvgR = if (skyCount > 0) skySumR / skyCount else avgGR.toFloat()
        val skyAvgG = if (skyCount > 0) skySumG / skyCount else avgGG.toFloat()
        val skyAvgB = if (skyCount > 0) skySumB / skyCount else avgGB.toFloat()

        val gMax = maxOf(avgGR, maxOf(avgGG, avgGB)).coerceAtLeast(1)
        val gMin = minOf(avgGR, minOf(avgGG, avgGB))
        val groundSat = (gMax - gMin).toFloat() / gMax.toFloat()

        val isSnow = (avgGR > 176 && avgGG > 180 && avgGB > 186 && gLum > 0.52f) ||
            nameLower.contains("snow") || nameLower.contains("glacier") || nameLower.contains("alps") ||
            nameLower.contains("kedarnath") || nameLower.contains("manali")
        val isGrass = !isSnow && ((avgGG > avgGR * 1.04f && avgGG > avgGB * 1.07f) ||
            nameLower.contains("grass") || nameLower.contains("garden") || nameLower.contains("park") ||
            nameLower.contains("lawn") || nameLower.contains("forest") || nameLower.contains("jungle"))
        val isWater = !isSnow && !isGrass && ((avgGB > avgGR * 1.12f && avgGB > avgGG * 0.97f && avgGB > 78) ||
            nameLower.contains("water") || nameLower.contains("lake") || nameLower.contains("pool") ||
            nameLower.contains("canal") || nameLower.contains("river") || nameLower.contains("ocean"))
        val isSand = !isSnow && !isGrass && !isWater && (
            (avgGR > 142 && avgGG > 105 && avgGB < 130 && avgGR > avgGB * 1.24f && gLum > 0.36f) ||
                nameLower.contains("sand") || nameLower.contains("desert") || nameLower.contains("dune") ||
                nameLower.contains("sahara") || nameLower.contains("pyramid") || nameLower.contains("jaisalmer") ||
                nameLower.contains("beach")
            )
        val isIndoor = !isSnow && !isGrass && !isWater && !isSand && (
            nameLower.contains("indoor") || nameLower.contains("mall") || nameLower.contains("hall") ||
                nameLower.contains("palace") || nameLower.contains("museum") || nameLower.contains("cafe") ||
                nameLower.contains("hotel") || nameLower.contains("room") || nameLower.contains("lobby") ||
                nameLower.contains("airport") || nameLower.contains("metro") || nameLower.contains("interior") ||
                (skyLum < 0.62f && skyAvgB < skyAvgR * 1.02f && abs(skyLum - gLum) < 0.20f)
            )
        val isRoad = !isSnow && !isGrass && !isWater && !isSand && !isIndoor && (
            (groundSat < 0.14f && gLum in 0.14f..0.52f) ||
                nameLower.contains("road") || nameLower.contains("street") || nameLower.contains("asphalt") ||
                nameLower.contains("highway") || nameLower.contains("bridge") || nameLower.contains("avenue")
            )

        val category = when {
            isSand -> GroundSurfaceCategory.DESERT_SAND
            isSnow -> GroundSurfaceCategory.SNOW
            isGrass -> GroundSurfaceCategory.GRASS
            isWater -> GroundSurfaceCategory.WATER_EDGE
            isIndoor -> GroundSurfaceCategory.INDOOR_FLOOR
            isRoad -> GroundSurfaceCategory.ROAD_PAVEMENT
            else -> GroundSurfaceCategory.STONE_TILES
        }

        // Verify walkable foreground floor band at bottom (avoid placing feet on water edge or bottom ledge drop)
        val fgRefR = rowAvgR[(rows * 0.85f).toInt().coerceIn(0, rows - 1)]
        val fgRefG = rowAvgG[(rows * 0.85f).toInt().coerceIn(0, rows - 1)]
        val fgRefB = rowAvgB[(rows * 0.85f).toInt().coerceIn(0, rows - 1)]
        var walkableEndRow = (rows * 0.92f).toInt()
        for (ry in ((rows * 0.86f).toInt()) until (rows - 1)) {
            val dr = abs(rowAvgR[ry] - fgRefR)
            val dg = abs(rowAvgG[ry] - fgRefG)
            val db = abs(rowAvgB[ry] - fgRefB)
            val colorJump = (dr + dg + db) / 3f
            val texSpike = rowTexVar[ry] > (rowTexVar[(rows * 0.84f).toInt()] * 2.2f + 0.06f)
            if (colorJump > 42f || texSpike) {
                walkableEndRow = (ry - 1).coerceAtLeast((rows * 0.84f).toInt())
                break
            }
            walkableEndRow = ry
        }

        val minGroundY = maxOf(horizonYRatio + 0.14f, 0.84f)
        val targetRatio = ((walkableEndRow.toFloat() / rows.toFloat()) - 0.015f)
            .coerceIn(minGroundY, 0.925f)

        val isEveningOrShade = gLum < 0.34f || (skyLum < 0.42f && gLum < 0.44f) ||
            nameLower.contains("night") || nameLower.contains("evening") || nameLower.contains("shade")
        val skyMax = maxOf(skyAvgR, maxOf(skyAvgG, skyAvgB)).coerceAtLeast(1f)
        val skyMin = minOf(skyAvgR, minOf(skyAvgG, skyAvgB))
        val skySat = (skyMax - skyMin) / skyMax
        val isOvercast = !isEveningOrShade && !isIndoor && skySat < 0.13f && skyLum in 0.36f..0.76f
        val isDiffused = isEveningOrShade || isIndoor || isOvercast

        val plane = DetectedGroundPlane(
            groundContactYRatio = targetRatio,
            horizonYRatio = horizonYRatio,
            surfaceCategory = category,
            avgGroundR = avgGR,
            avgGroundG = avgGG,
            avgGroundB = avgGB,
            groundLum = gLum,
            isSunnyOutdoor = !isDiffused && (gLum >= 0.40f || isSand || isSnow),
            isDiffusedAmbient = isDiffused
        )
        if (nameLower.isBlank()) {
            synchronized(detectedGroundPlaneCache) {
                detectedGroundPlaneCache[bgBitmap] = plane
            }
        }
        plane
    } catch (_: Throwable) {
        DetectedGroundPlane()
    }
}

/**
 * Computes exact userYOffset (in preview pixel coordinates) so the bottom-most
 * detected pixels of both shoe soles lock directly onto the detected ground surface
 * of any location preset or custom background.
 */
fun computeGroundLockedUserYOffset(
    bgBitmap: Bitmap?,
    footAnchor: SubjectFootAnchor,
    userScale: Float,
    previewHeightPx: Float,
    landmarkName: String = "",
    surfaceSinkRatio: Float = 0f
): Float {
    val pH = previewHeightPx.coerceAtLeast(300f)
    val groundPlane = detectBackgroundGroundPlane(bgBitmap, landmarkName)
    val userH = pH * ((210f * userScale) / 380f)
    val rawTargetGroundY = pH * groundPlane.groundContactYRatio

    // Keep head safely inside frame if user zooms very large, otherwise lock strictly to ground plane
    val minGroundYForHead = (footAnchor.lowestContactYRatio * userH) + 8f
    val targetGroundY = if (minGroundYForHead > rawTargetGroundY) {
        minOf(minGroundYForHead, pH * 0.965f)
    } else {
        rawTargetGroundY
    }

    val sinkPx = userH * surfaceSinkRatio
    return (targetGroundY - pH) + (userH * (1f - footAnchor.lowestContactYRatio)) - sinkPx
}

/**
 * Subtle surface-contact blending along the bottom 2px of both shoe soles
 * across ALL terrain surfaces (desert sand, stone tiles, grass, road, snow, indoor floor)
 * without ever erasing or truncating shoe geometry.
 */
fun applySoleSurfaceContactBlending(
    source: Bitmap,
    bgBitmap: Bitmap? = null,
    personRectOnCanvas: RectF? = null,
    bgRectOnCanvas: RectF? = null,
    surfaceHint: String = "",
    explicitPoseRegions: PoseFootRegions? = null
): Bitmap {
    if (source.isRecycled || source.width <= 8 || source.height <= 8) return source
    return try {
        val width = source.width
        val height = source.height
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        var highestY = height
        var lowestY = -1
        for (y in 0 until height) {
            val rowOff = y * width
            for (x in 0 until width) {
                if (((pixels[rowOff + x] ushr 24) and 0xFF) >= 30) {
                    if (y < highestY) highestY = y
                    if (y > lowestY) lowestY = y
                    break
                }
            }
        }
        if (lowestY <= highestY || lowestY < 8) return source

        val activeHeight = (lowestY - highestY + 1).coerceAtLeast(1)
        val soleBandLimitY = (lowestY - (activeHeight * 0.14f).toInt().coerceIn(8, 72)).coerceAtLeast(0)
        val poseRegions = explicitPoseRegions ?: getPoseFootRegions(source)
        val hasPose = poseRegions != null && poseRegions.hasAnyShoe()

        // Find the bottom-most opaque pixel (shoe sole contact contour) in every column x
        val colBottomY = IntArray(width) { -1 }
        for (x in 0 until width) {
            val nx = (x + 0.5f) / width.toFloat()
            for (y in lowestY downTo soleBandLimitY) {
                if (((pixels[y * width + x] ushr 24) and 0xFF) >= 32) {
                    val ny = (y + 0.5f) / height.toFloat()
                    val nearLowest = (lowestY - y) <= (activeHeight * 0.06f).toInt().coerceIn(4, 34)
                    val inPoseShoe = hasPose && poseRegions!!.classifyPixel(nx, ny, strictCore = false) != 0
                    if (nearLowest || inPoseShoe) {
                        colBottomY[x] = y
                    }
                    break
                }
            }
        }

        val groundPlane = detectBackgroundGroundPlane(bgBitmap, surfaceHint)
        val isGranularTerrain = groundPlane.surfaceCategory == GroundSurfaceCategory.DESERT_SAND ||
            groundPlane.surfaceCategory == GroundSurfaceCategory.GRASS ||
            groundPlane.surfaceCategory == GroundSurfaceCategory.SNOW

        // Strictly ~2px visual contact band (never dissolves shoe body)
        val contactPx = (height / 340f).toInt().coerceIn(2, 4)

        val bgW = bgBitmap?.width ?: 0
        val bgH = bgBitmap?.height ?: 0
        val hasBg = bgBitmap != null && !bgBitmap.isRecycled && bgW > 0 && bgH > 0
        val hasRects = hasBg && personRectOnCanvas != null && bgRectOnCanvas != null &&
            bgRectOnCanvas.width() > 1f && bgRectOnCanvas.height() > 1f

        var rng = 987654321L
        for (x in 0 until width) {
            val bottomY = colBottomY[x]
            if (bottomY < 1) continue

            // Sample local ground color directly beneath this shoe column
            var gR = groundPlane.avgGroundR
            var gG = groundPlane.avgGroundG
            var gB = groundPlane.avgGroundB
            if (hasRects) {
                val canvasX = personRectOnCanvas!!.left + (x.toFloat() / width.toFloat()) * personRectOnCanvas.width()
                val canvasY = personRectOnCanvas.top + ((bottomY + 1).toFloat() / height.toFloat()) * personRectOnCanvas.height()
                val bx = (((canvasX - bgRectOnCanvas!!.left) / bgRectOnCanvas.width()) * bgW).toInt().coerceIn(0, bgW - 1)
                val by = (((canvasY - bgRectOnCanvas.top) / bgRectOnCanvas.height()) * bgH).toInt().coerceIn(0, bgH - 1)
                val gPx = bgBitmap!!.getPixel(bx, by)
                gR = (gPx ushr 16) and 0xFF
                gG = (gPx ushr 8) and 0xFF
                gB = gPx and 0xFF
            }

            for (dy in 0 until contactPx) {
                val y = bottomY - dy
                if (y < 0) break
                val idx = y * width + x
                val c = pixels[idx]
                val a = (c ushr 24) and 0xFF
                if (a <= 14) continue

                val fracFromBottom = 1f - (dy.toFloat() / contactPx.toFloat()) // 1.0 at sole bottom edge -> ~0.3 at top of 2px band
                rng = (rng * 1664525L + 1013904223L) and 0xFFFFFFFFL
                val grainJitter = if (isGranularTerrain) {
                    (((rng ushr 16) and 0xFF) / 255f - 0.5f) * 0.10f
                } else 0f

                val maxMix = if (isGranularTerrain) 0.28f else 0.18f
                val mix = (maxMix * fracFromBottom + grainJitter).coerceIn(0.03f, 0.32f)

                var r = (c ushr 16) and 0xFF
                var g = (c ushr 8) and 0xFF
                var b = c and 0xFF

                r = (r * (1f - mix) + gR * mix).toInt().coerceIn(0, 255)
                g = (g * (1f - mix) + gG * mix).toInt().coerceIn(0, 255)
                b = (b * (1f - mix) + gB * mix).toInt().coerceIn(0, 255)

                // Micro-soften only the outermost 1px sole contact pixel so it seats cleanly onto tiles/sand/grass/road
                val finalA = if (dy == 0) {
                    val alphaKeep = if (isGranularTerrain) (0.80f + grainJitter * 0.5f) else 0.88f
                    (a * alphaKeep).toInt().coerceIn(0, 255)
                } else {
                    a
                }

                pixels[idx] = (finalA shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        val dest = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        dest.setPixels(pixels, 0, width, 0, 0, width, height)
        if (poseRegions != null) {
            registerPoseFootRegions(dest, poseRegions)
        }
        dest
    } catch (_: OutOfMemoryError) {
        System.gc()
        source
    } catch (_: Throwable) {
        source
    }
}

/**
 * UNIFIED SCENE-ADAPTIVE GROUND CAST + ULTRA-SOFT SOLE-CREASE SHADOW ENGINE
 * Renders identically across ALL 3 modes:
 * 1. Live Preview (MainActivity + LiveVideoForegroundLayer)
 * 2. 4200px HD Saved Photo (MainActivity)
 * 3. 15s 1080p HD Video Export (VideoCompositeRecorder)
 *
 * - Zero heavy dark/black oval spot beneath feet.
 * - Replaces dark spots with a thin, ultra-soft, low-opacity (20-30%) sole-crease shadow
 *   directly where each shoe sole touches the ground.
 * - Automatically matches cast shadow softness, angle, tint, and transparency to each location's
 *   lighting (crisp warm shadow in sunny/desert scenes, softer diffused shadow in evening/shade/indoor scenes).
 */
fun renderUnifiedGroundAndCastShadow(
    canvas: Canvas,
    feetX: Float,
    feetY: Float,
    subjectWidth: Float,
    subjectHeight: Float,
    subjectLeftOnCanvas: Float,
    subjectBitmap: Bitmap?,
    footAnchor: SubjectFootAnchor,
    shadowDepth: Float,
    outWidth: Int,
    canvasWidth: Float,
    canvasHeight: Float,
    sunAzimuthDegrees: Float,
    sunElevationDegrees: Float,
    lightDirectionX: Float,
    lowerAvgLum: Float,
    darkR: Int,
    darkG: Int,
    darkB: Int,
    isEveningOrNight: Boolean = false,
    isSunset: Boolean = false,
    isDiffusedScene: Boolean = false,
    bgBitmap: Bitmap? = null,
    bgRectOnCanvas: RectF? = null
) {
    if (shadowDepth <= 0.04f) return
    var castTile: Bitmap? = null
    var shadowTile: Bitmap? = null
    try {
        val resScale = (outWidth / 1080f).coerceIn(0.75f, 3.8f)
        val cW = canvasWidth.coerceAtLeast(outWidth.toFloat())
        val cH = canvasHeight.coerceAtLeast(100f)

        val isCroppedWaistAtBottom = footAnchor.stanceWidthRatio > 0.56f && feetY >= (cH - 6f)
        val torsoAttenuation = if (isCroppedWaistAtBottom) 0.36f else 1.0f

        val groundPlane = if (bgBitmap != null && !bgBitmap.isRecycled) {
            detectBackgroundGroundPlane(bgBitmap)
        } else {
            null
        }
        val effectiveDiffused = isDiffusedScene || isEveningOrNight ||
            (groundPlane?.isDiffusedAmbient == true && !isSunset)

        val depthNorm = shadowDepth.coerceIn(0.15f, 0.90f)
        val modeStrength = ((depthNorm - 0.08f) / 0.62f).coerceIn(0.18f, 1.0f)

        var leftSupport = 1.0f
        var rightSupport = 1.0f
        var centerSupport = 1.0f
        var sampledGroundR = groundPlane?.avgGroundR ?: 140
        var sampledGroundG = groundPlane?.avgGroundG ?: 135
        var sampledGroundB = groundPlane?.avgGroundB ?: 125
        var hasSampledGround = groundPlane != null

        if (bgBitmap != null && !bgBitmap.isRecycled && bgRectOnCanvas != null &&
            bgRectOnCanvas.width() > 1f && bgRectOnCanvas.height() > 1f
        ) {
            val bgW = bgBitmap.width
            val bgH = bgBitmap.height
            fun probeGroundSupport(cx: Float, cy: Float, recordColor: Boolean = false): Float {
                val bx = (((cx - bgRectOnCanvas.left) / bgRectOnCanvas.width()) * bgW).toInt()
                val byFoot = (((cy - bgRectOnCanvas.top) / bgRectOnCanvas.height()) * bgH).toInt()
                val byBelow = ((((cy + (subjectHeight * 0.032f).coerceAtLeast(10f)) - bgRectOnCanvas.top) / bgRectOnCanvas.height()) * bgH).toInt()
                if (bx !in 0 until bgW || byFoot !in 0 until bgH || byBelow !in 0 until bgH) return 0.75f

                val pFoot = bgBitmap.getPixel(bx, byFoot)
                val pBelow = bgBitmap.getPixel(bx, byBelow)
                val rF = (pFoot ushr 16) and 0xFF
                val gF = (pFoot ushr 8) and 0xFF
                val bF = pFoot and 0xFF
                if (recordColor) {
                    sampledGroundR = rF
                    sampledGroundG = gF
                    sampledGroundB = bF
                    hasSampledGround = true
                }
                val lumFoot = (0.299f * rF + 0.587f * gF + 0.114f * bF) / 255f
                val rB = (pBelow ushr 16) and 0xFF
                val gB = (pBelow ushr 8) and 0xFF
                val bB = pBelow and 0xFF
                val lumBelow = (0.299f * rB + 0.587f * gB + 0.114f * bB) / 255f

                val isSkyVoidBelow = (bB > rB * 1.18f && lumBelow > 0.60f && lumFoot < 0.45f)
                return if (isSkyVoidBelow) 0.25f else 1.0f
            }
            val spanHalf = (subjectWidth * (footAnchor.stanceWidthRatio * 0.72f + 0.24f)).coerceAtLeast(24f)
            centerSupport = probeGroundSupport(feetX, feetY, recordColor = true)
            leftSupport = probeGroundSupport(feetX - spanHalf, feetY)
            rightSupport = probeGroundSupport(feetX + spanHalf, feetY)
        }

        // Compute natural, non-black shadow RGB tinted harmoniously to the actual standing surface
        val isWarmSunny = !effectiveDiffused && (
            isSunset ||
                groundPlane?.surfaceCategory == GroundSurfaceCategory.DESERT_SAND ||
                sampledGroundR > sampledGroundB * 1.14f
            )
        val tintScale = if (effectiveDiffused) 0.26f else 0.28f
        val natR = if (hasSampledGround) {
            val baseR = (sampledGroundR * tintScale + (if (isWarmSunny) 14f else 0f)).toInt()
            ((baseR * 0.60f) + (darkR * 0.40f)).toInt().coerceIn(14, 72)
        } else {
            darkR.coerceAtLeast(18)
        }
        val natG = if (hasSampledGround) {
            val baseG = (sampledGroundG * tintScale + (if (isWarmSunny) 7f else 0f)).toInt()
            ((baseG * 0.60f) + (darkG * 0.40f)).toInt().coerceIn(14, 64)
        } else {
            darkG.coerceAtLeast(18)
        }
        val natB = if (hasSampledGround) {
            val baseB = (sampledGroundB * tintScale + (if (groundPlane?.surfaceCategory == GroundSurfaceCategory.SNOW || isEveningOrNight) 10f else 0f)).toInt()
            ((baseB * 0.60f) + (darkB * 0.40f)).toInt().coerceIn(14, 72)
        } else {
            darkB.coerceAtLeast(20)
        }

        val overallLedgeOpacity = ((centerSupport * 0.6f + leftSupport * 0.2f + rightSupport * 0.2f) * torsoAttenuation).coerceIn(0.25f, 1.0f)
        val clampedFeetY = feetY.coerceIn(6f, cH - 2f)

        // LAYER 0: SCENE-ADAPTIVE DIRECTIONAL GROUND CAST SHADOW
        // Crisp warm shadow in sunny/desert scenes; softer, diffused, subtle shadow in evening/shade/indoor scenes
        if (!isCroppedWaistAtBottom && overallLedgeOpacity > 0.38f) {
            val rawAzimuth = if (abs(sunAzimuthDegrees) > 6f) {
                sunAzimuthDegrees
            } else {
                if (lightDirectionX >= 0f) 26f else -26f
            }
            val maxSkew = if (effectiveDiffused) 0.56f else 1.25f
            var castSkewX = (tan(Math.toRadians(rawAzimuth.toDouble())) * 1.12f).toFloat().coerceIn(-maxSkew, maxSkew)
            if (!effectiveDiffused && abs(castSkewX) < 0.36f) {
                castSkewX = if (castSkewX >= 0f) 0.36f else -0.36f
            }

            val effElevation = when {
                isSunset -> sunElevationDegrees.coerceIn(20f, 34f)
                effectiveDiffused -> sunElevationDegrees.coerceIn(48f, 68f)
                groundPlane?.surfaceCategory == GroundSurfaceCategory.DESERT_SAND -> sunElevationDegrees.coerceIn(26f, 48f)
                else -> sunElevationDegrees.coerceIn(28f, 64f)
            }
            val elevRad = Math.toRadians(effElevation.toDouble())
            val elevLength = (1.0f / tan(elevRad).toFloat()).coerceIn(0.36f, 1.45f)
            val diffusedShrink = if (effectiveDiffused) 0.72f else 1.0f
            val castHeight = (subjectHeight * (0.14f + elevLength * 0.11f) * diffusedShrink * (0.86f + modeStrength * 0.22f))
                .coerceIn(subjectHeight * 0.11f, subjectHeight * 0.36f)

            val lumFactor = (0.82f + lowerAvgLum.coerceIn(0.08f, 0.90f) * 0.22f).coerceIn(0.82f, 1.05f)
            val castAlphaFloat = when {
                effectiveDiffused -> (0.13f + modeStrength * 0.08f) // 13% - 21% ultra-soft diffused indoor/evening/shade
                isSunset -> (0.20f + modeStrength * 0.11f)          // 20% - 31% golden sunset
                isWarmSunny -> (0.24f + modeStrength * 0.11f)       // 24% - 35% crisp sunny/desert
                else -> (0.20f + modeStrength * 0.11f)              // 20% - 31% balanced outdoor daylight
            }
            val castMaxAlpha = (255f * castAlphaFloat * lumFactor * overallLedgeOpacity)
                .toInt().coerceIn(28, 92)

            val silBmp = getOrCreateUnifiedShadowSilhouette(subjectBitmap)
            if (silBmp != null && !silBmp.isRecycled) {
                val silW = silBmp.width.toFloat().coerceAtLeast(1f)
                val silH = silBmp.height.toFloat().coerceAtLeast(1f)
                val activeSpanY = (silH * footAnchor.lowestContactYRatio).coerceAtLeast(silH * 0.5f)
                val scaleXToCanvas = subjectWidth / silW
                val scaleYToCast = castHeight / activeSpanY

                val silCenterX = silW * footAnchor.feetCenterRatioX
                val silContactY = silH * footAnchor.lowestContactYRatio
                val projMatrix = Matrix().apply {
                    preTranslate(-silCenterX, -silContactY)
                    postScale(scaleXToCanvas * (if (effectiveDiffused) 1.10f else 1.02f), -scaleYToCast)
                    postSkew(castSkewX, 0f)
                    postTranslate(feetX, clampedFeetY + (subjectHeight * 0.002f))
                }
                val rawCastBounds = RectF(0f, 0f, silW, silH)
                projMatrix.mapRect(rawCastBounds)

                val castBlurPx = when {
                    effectiveDiffused -> ((17f + (1f - modeStrength) * 7f) * resScale).coerceIn(13f, 46f)
                    isSunset -> ((10f + (1f - modeStrength) * 3f) * resScale).coerceIn(8f, 30f)
                    else -> ((6.8f - modeStrength * 1.8f) * resScale).coerceIn(4.5f, 22f)
                }
                val padX = castBlurPx * 2.1f
                val padY = castBlurPx * 2.1f
                val castUnionRect = RectF(
                    (rawCastBounds.left - padX).coerceAtLeast(0f),
                    (rawCastBounds.top - padY).coerceAtLeast(0f),
                    (rawCastBounds.right + padX).coerceAtMost(cW),
                    (rawCastBounds.bottom + padY).coerceAtMost(cH)
                )
                val cuW = castUnionRect.width()
                val cuH = castUnionRect.height()
                if (cuW >= 16f && cuH >= 12f) {
                    val castTileSize = 256
                    val csx = castTileSize.toFloat() / cuW
                    val csy = castTileSize.toFloat() / cuH
                    castTile = Bitmap.createBitmap(castTileSize, castTileSize, Bitmap.Config.ARGB_8888)
                    val castCanvas = Canvas(castTile)

                    val tileProjMatrix = Matrix(projMatrix).apply {
                        postTranslate(-castUnionRect.left, -castUnionRect.top)
                        postScale(csx, csy)
                    }

                    val tileCastBlur = (castBlurPx * minOf(csx, csy)).coerceIn(1.8f, 18f)
                    val castPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                        colorFilter = PorterDuffColorFilter(
                            Color.argb(castMaxAlpha, natR, natG, natB),
                            PorterDuff.Mode.SRC_IN
                        )
                        maskFilter = BlurMaskFilter(tileCastBlur, BlurMaskFilter.Blur.NORMAL)
                    }
                    castCanvas.drawBitmap(silBmp, tileProjMatrix, castPaint)

                    val tileFeetY = ((clampedFeetY - castUnionRect.top) * csy).coerceIn(2f, castTileSize.toFloat())
                    val tileTopY = ((rawCastBounds.top - castUnionRect.top) * csy).coerceIn(0f, (tileFeetY - 2f).coerceAtLeast(0f))
                    val gradPaint = Paint().apply {
                        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
                        shader = LinearGradient(
                            0f, tileFeetY,
                            0f, tileTopY,
                            intArrayOf(
                                Color.argb(245, 255, 255, 255),
                                Color.argb(135, 255, 255, 255),
                                Color.argb(18, 255, 255, 255)
                            ),
                            floatArrayOf(0.0f, 0.46f, 1.0f),
                            Shader.TileMode.CLAMP
                        )
                    }
                    castCanvas.drawRect(0f, 0f, castTileSize.toFloat(), castTileSize.toFloat(), gradPaint)

                    canvas.drawBitmap(
                        castTile,
                        null,
                        castUnionRect,
                        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    )
                }
            }
        }

        // LAYER 1: THIN, ULTRA-SOFT, LOW-OPACITY (20-30%) SOLE-CREASE SHADOW
        // Zero wide black oval spot — only a delicate crease directly where each shoe sole meets the ground.
        val creaseBlur = if (effectiveDiffused) {
            (5.5f * resScale).coerceIn(4f, 20f)
        } else {
            (4.2f * resScale).coerceIn(3f, 15f)
        }

        // Strictly 20% - 30% (alpha 51..76 out of 255) directly along the sole-ground crease
        val creaseOpacityFloat = (0.20f + modeStrength * 0.09f) * (if (effectiveDiffused) 0.88f else 1.0f)
        val creaseMaxAlpha = (255f * creaseOpacityFloat * overallLedgeOpacity).toInt().coerceIn(38, 76)

        val creaseH = (subjectHeight * 0.0075f).coerceIn(2.2f * resScale, 7.2f * resScale)

        fun clampCreaseRect(cx: Float, cy: Float, rx: Float, ry: Float): RectF {
            val leftEdge = (cx - rx * leftSupport).coerceAtLeast(4f)
            val rightEdge = (cx + rx * rightSupport).coerceAtMost(cW - 4f)
            val topEdge = (cy - ry * 0.35f).coerceAtLeast(2f)
            val botEdge = (cy + ry * 0.65f).coerceAtMost(cH - 2f)
            return RectF(
                leftEdge,
                topEdge,
                rightEdge.coerceAtLeast(leftEdge + 6f),
                botEdge.coerceAtLeast(topEdge + 2.5f)
            )
        }

        val soleCreaseRects = mutableListOf<RectF>()
        if (footAnchor.isDualFoot && footAnchor.stanceWidthRatio > 0.06f) {
            val leftFootCenterX = subjectLeftOnCanvas + (footAnchor.leftFootRatioX * subjectWidth)
            val rightFootCenterX = subjectLeftOnCanvas + (footAnchor.rightFootRatioX * subjectWidth)
            val leftFeetY = (clampedFeetY - ((footAnchor.lowestContactYRatio - footAnchor.leftFootLowestYRatio) * subjectHeight).coerceAtLeast(0f)).coerceIn(6f, cH - 2f)
            val rightFeetY = (clampedFeetY - ((footAnchor.lowestContactYRatio - footAnchor.rightFootLowestYRatio) * subjectHeight).coerceAtLeast(0f)).coerceIn(6f, cH - 2f)
            val leftCreaseRx = (footAnchor.leftSoleWidthRatio * subjectWidth * 0.56f).coerceIn(12f * resScale, 54f * resScale)
            val rightCreaseRx = (footAnchor.rightSoleWidthRatio * subjectWidth * 0.56f).coerceIn(12f * resScale, 54f * resScale)
            soleCreaseRects.add(clampCreaseRect(leftFootCenterX, leftFeetY + creaseH * 0.12f, leftCreaseRx, creaseH))
            soleCreaseRects.add(clampCreaseRect(rightFootCenterX, rightFeetY + creaseH * 0.12f, rightCreaseRx, creaseH))
        } else {
            val singleCreaseRx = (subjectWidth * (footAnchor.stanceWidthRatio * 0.50f + 0.16f)).coerceIn(14f * resScale, subjectWidth * 0.40f)
            soleCreaseRects.add(clampCreaseRect(feetX, clampedFeetY + creaseH * 0.12f, singleCreaseRx, creaseH))
        }

        val blurPadX = creaseBlur * 2.2f
        val blurPadY = creaseBlur * 2.4f
        var uLeft = soleCreaseRects.first().left
        var uTop = soleCreaseRects.first().top
        var uRight = soleCreaseRects.first().right
        var uBottom = soleCreaseRects.first().bottom
        for (sr in soleCreaseRects) {
            if (sr.left < uLeft) uLeft = sr.left
            if (sr.top < uTop) uTop = sr.top
            if (sr.right > uRight) uRight = sr.right
            if (sr.bottom > uBottom) uBottom = sr.bottom
        }
        val unionRect = RectF(
            (uLeft - blurPadX).coerceAtLeast(0f),
            (uTop - blurPadY).coerceAtLeast(0f),
            (uRight + blurPadX).coerceAtMost(cW),
            (uBottom + blurPadY).coerceAtMost(cH)
        )
        val unionW = unionRect.width().coerceAtLeast(16f)
        val unionH = unionRect.height().coerceAtLeast(12f)

        val tileW = 256
        val tileH = 128
        val sx = tileW.toFloat() / unionW
        val sy = tileH.toFloat() / unionH
        shadowTile = Bitmap.createBitmap(tileW, tileH, Bitmap.Config.ARGB_8888)
        val shadowCanvas = Canvas(shadowTile)

        fun mapToTile(srcRect: RectF): RectF {
            return RectF(
                ((srcRect.left - unionRect.left) * sx).coerceIn(2f, tileW - 6f),
                ((srcRect.top - unionRect.top) * sy).coerceIn(2f, tileH - 5f),
                ((srcRect.right - unionRect.left) * sx).coerceIn(4f, tileW - 2f),
                ((srcRect.bottom - unionRect.top) * sy).coerceIn(4f, tileH - 2f)
            )
        }

        val tileCreaseBlur = (creaseBlur * minOf(sx, sy)).coerceIn(1.5f, 12f)
        for (sr in soleCreaseRects) {
            val tileCreaseRect = mapToTile(sr)
            val creasePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                maskFilter = BlurMaskFilter(tileCreaseBlur, BlurMaskFilter.Blur.NORMAL)
                shader = RadialGradient(
                    tileCreaseRect.centerX(),
                    tileCreaseRect.centerY(),
                    (tileCreaseRect.width() * 0.52f).coerceAtLeast(4f),
                    intArrayOf(
                        Color.argb(creaseMaxAlpha, natR, natG, natB),
                        Color.argb((creaseMaxAlpha * 0.52f).toInt(), natR, natG, natB),
                        Color.argb((creaseMaxAlpha * 0.14f).toInt(), natR, natG, natB),
                        Color.TRANSPARENT
                    ),
                    floatArrayOf(0.0f, 0.35f, 0.72f, 1.0f),
                    Shader.TileMode.CLAMP
                )
            }
            shadowCanvas.drawOval(tileCreaseRect, creasePaint)
        }

        val drawPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(shadowTile, null, unionRect, drawPaint)
    } catch (_: Throwable) {
    } finally {
        try {
            if (castTile != null && !castTile.isRecycled) castTile.recycle()
            if (shadowTile != null && !shadowTile.isRecycled) shadowTile.recycle()
        } catch (_: Throwable) {}
    }
}


package com.aistudio.worldcamai.smxuqv

import android.graphics.Bitmap
import androidx.camera.core.CameraSelector
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun LiveVideoForegroundLayer(
    bgBitmap: Bitmap? = null,
    personBitmap: Bitmap?,
    userScale: Float,
    userXOffset: Float,
    userYOffset: Float,
    userRotation: Float,
    shadowDepth: Float = 0.38f,
    filterMatrixValues: FloatArray? = null,
    colorFilter: ColorFilter?,
    lensFacing: Int,
    countdownSeconds: Int,
    isRecording: Boolean,
    recordingRemainingSeconds: Int,
    isFinalizingVideo: Boolean,
    selectedSong: SelectedSongInfo?,
    onTransformChange: (panX: Float, panY: Float, zoom: Float, rotation: Float) -> Unit,
    onFlipCamera: () -> Unit,
    onExitVideoMode: () -> Unit
) {
    // 1. Precompute subtle camera depth-of-field blur & automatic location lighting profile off the main thread
    val blurredBgBitmap by produceState<Bitmap?>(initialValue = bgBitmap, bgBitmap) {
        value = if (bgBitmap != null && !bgBitmap.isRecycled) {
            withContext(Dispatchers.IO) {
                getOrCreateVideoDepthBlurBitmap(bgBitmap)
            }
        } else {
            bgBitmap
        }
    }

    val locationLighting by produceState(
        initialValue = analyzeVideoBackgroundLighting(null),
        bgBitmap
    ) {
        value = withContext(Dispatchers.IO) {
            analyzeVideoBackgroundLighting(bgBitmap)
        }
    }

    // Real-time color & lighting match ColorFilter for the live camera person (+ any active filter)
    val matchedPersonColorFilter = remember(locationLighting, filterMatrixValues, colorFilter) {
        val composedValues = composePersonColorMatrix(locationLighting, filterMatrixValues)
        ColorFilter.colorMatrix(ColorMatrix(composedValues))
    }

    // Lightweight sensor grain tick so unified grain subtly animates like a live video sensor
    var grainTick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(85L)
            grainTick++
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures(panZoomLock = false) { _, pan, zoom, rotation ->
                    onTransformChange(pan.x, pan.y, zoom, rotation)
                }
            }
    ) {
        // 0. Subtle DSLR Depth-of-Field Blurred Location Background during Video Mode
        val activeBlurredBg = blurredBgBitmap
        if (activeBlurredBg != null && !activeBlurredBg.isRecycled) {
            Image(
                bitmap = activeBlurredBg.asImageBitmap(),
                contentDescription = "Depth Blurred Video Location Background",
                contentScale = ContentScale.Crop,
                filterQuality = FilterQuality.High,
                colorFilter = colorFilter,
                modifier = Modifier.fillMaxSize()
            )
        }

        // 1. Realistic Dynamic Directional & Grounded Contact Shadow + Relit Live ML Kit Segmented User
        if (personBitmap != null && !personBitmap.isRecycled) {
            val aspect = if (personBitmap.height > 0) {
                personBitmap.width.toFloat() / personBitmap.height.toFloat()
            } else 0.75f
            val baseHeight = 210f * userScale

            // Real-time dynamic shadow moving smoothly with live segmented body & POS/SIZE controls
            Canvas(modifier = Modifier.fillMaxSize()) {
                val targetUserHeight = size.height * (baseHeight / 380f)
                val targetUserWidth = targetUserHeight * aspect
                val centerX = (size.width / 2f) + userXOffset
                val bottomY = size.height + userYOffset
                val top = bottomY - targetUserHeight
                val left = centerX - (targetUserWidth / 2f)

                drawIntoCanvas { canvas ->
                    drawDynamicVideoPersonShadow(
                        canvas = canvas.nativeCanvas,
                        personBitmap = personBitmap,
                        lighting = locationLighting,
                        shadowDepth = shadowDepth,
                        left = left,
                        top = top,
                        targetUserWidth = targetUserWidth,
                        targetUserHeight = targetUserHeight,
                        centerX = centerX,
                        bottomY = bottomY,
                        userRotation = userRotation
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(
                        width = (baseHeight * aspect).dp,
                        height = baseHeight.dp
                    )
                    .align(Alignment.BottomCenter)
                    .offset {
                        IntOffset(
                            x = userXOffset.roundToInt(),
                            y = userYOffset.roundToInt()
                        )
                    }
                    .graphicsLayer {
                        rotationZ = userRotation
                    }
            ) {
                Image(
                    bitmap = personBitmap.asImageBitmap(),
                    contentDescription = "Live Video Cutout",
                    contentScale = ContentScale.Fit,
                    filterQuality = FilterQuality.High,
                    colorFilter = matchedPersonColorFilter,
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            // Waiting for first camera frame indicator
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xAA0F172A),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Color(0xFF38BDF8),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Starting Live Camera...",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // 1b. Unified Subtle Camera Lens Grain across both background & live user
        Canvas(modifier = Modifier.fillMaxSize()) {
            val seed = grainTick + (personBitmap?.hashCode()?.toLong() ?: 0L)
            drawIntoCanvas { canvas ->
                drawUnifiedVideoCameraGrain(
                    canvas = canvas.nativeCanvas,
                    width = size.width,
                    height = size.height,
                    frameSeed = seed
                )
            }
        }

        // 2. Top-left Live / Recording Status Pill
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isRecording) Color(0xCCDC2626) else Color(0xAA0F172A),
            border = BorderStroke(1.dp, if (isRecording) Color(0xFFFCA5A5) else Color(0xFF38BDF8).copy(alpha = 0.6f)),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .testTag("video_mode_status_pill")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(if (isRecording) Color.White else Color(0xFF4ADE80), CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isRecording) {
                        "REC 00:${recordingRemainingSeconds.toString().padStart(2, '0')}"
                    } else if (selectedSong != null) {
                        "LIVE • 🎵 ${selectedSong.title.take(12)}"
                    } else {
                        "LIVE VIDEO (${if (lensFacing == CameraSelector.LENS_FACING_FRONT) "FRONT" else "BACK"})"
                    },
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 3. Top-right Front/Back Flip Camera & Exit Video Mode Icons
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (!isRecording && !isFinalizingVideo) {
                Surface(
                    onClick = onFlipCamera,
                    shape = CircleShape,
                    color = Color(0xBB0F172A),
                    border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.6f)),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("flip_video_camera_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Cameraswitch,
                            contentDescription = "Flip Front/Back Camera",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Surface(
                    onClick = onExitVideoMode,
                    shape = CircleShape,
                    color = Color(0xBB0F172A),
                    border = BorderStroke(1.dp, Color(0xFF94A3B8).copy(alpha = 0.5f)),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("close_video_mode_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Exit Video Mode",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // 4. Center 3-2-1 Countdown Overlay
        if (countdownSeconds > 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x55000000)),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xCC7C3AED),
                    border = BorderStroke(3.dp, Color.White),
                    modifier = Modifier.size(96.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "$countdownSeconds",
                            color = Color.White,
                            fontSize = 44.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }

        // 5. Finalizing Video Spinner Overlay
        if (isFinalizingVideo) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xAA020617)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(
                        color = Color(0xFF38BDF8),
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Rendering 15s Video + Audio...",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // 6. "WorldCam AI" Watermark at Bottom Center
        Text(
            text = "WorldCam AI",
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp)
                .shadow(4.dp)
        )
    }
}

@Composable
fun VideoModeActionBar(
    isRecording: Boolean,
    countdownSeconds: Int,
    recordingRemainingSeconds: Int,
    isFinalizingVideo: Boolean,
    selectedSong: SelectedSongInfo?,
    onStartOrStopRecord: () -> Unit,
    onOpenSongPicker: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B).copy(alpha = 0.95f)),
        border = BorderStroke(1.dp, Color(0xFFEC4899).copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onStartOrStopRecord,
                enabled = !isFinalizingVideo && countdownSeconds == 0,
                modifier = Modifier
                    .weight(1.2f)
                    .height(48.dp)
                    .testTag("start_stop_video_record_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRecording) Color(0xFFDC2626) else Color(0xFFEC4899)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                    contentDescription = if (isRecording) "Stop Recording" else "Start 15s Video",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = when {
                        countdownSeconds > 0 -> "Get Ready ($countdownSeconds)..."
                        isRecording -> "Stop (${recordingRemainingSeconds}s)"
                        else -> "Record 15s"
                    },
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            OutlinedButton(
                onClick = onOpenSongPicker,
                enabled = !isRecording && !isFinalizingVideo && countdownSeconds == 0,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("video_bar_song_button"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFF472B6).copy(alpha = 0.7f))
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = "Song",
                    tint = Color(0xFFF472B6),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = selectedSong?.let {
                        "${it.title.take(10)} (${formatMillisToTime(it.startTimeMs)})"
                    } ?: "No Song",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

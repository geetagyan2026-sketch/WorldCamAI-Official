package com.aistudio.worldcamai.smxuqv

import android.graphics.Bitmap
import androidx.camera.core.CameraSelector
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun LiveVideoForegroundLayer(
    personBitmap: Bitmap?,
    userScale: Float,
    userXOffset: Float,
    userYOffset: Float,
    userRotation: Float,
    colorFilter: ColorFilter?,
    lensFacing: Int,
    countdownSeconds: Int,
    isRecording: Boolean,
    recordingRemainingSeconds: Int,
    isFinalizingVideo: Boolean,
    selectedSong: SelectedSongInfo?,
    onTransformChange: (panX: Float, panY: Float, zoom: Float, rotation: Float) -> Unit,
    onFlipCamera: () -> Unit,
    onExitVideoMode: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures(panZoomLock = false) { _, pan, zoom, rotation ->
                    onTransformChange(pan.x, pan.y, zoom, rotation)
                }
            }
    ) {
        // 1. Live ML Kit segmented user cutout positioned with the exact POS / SIZE controls
        if (personBitmap != null && !personBitmap.isRecycled) {
            val aspect = if (personBitmap.height > 0) {
                personBitmap.width.toFloat() / personBitmap.height.toFloat()
            } else 0.75f
            val baseHeight = 210f * userScale

            Box(
                modifier = Modifier
                    .size(
                        width = (baseHeight * aspect).dp,
                        height = baseHeight.dp
                    )
                    .align(Alignment.BottomCenter)
                    .offset {
                        IntOffset(
                            x = userXOffset.roundToInt(),
                            y = userYOffset.roundToInt()
                        )
                    }
                    .graphicsLayer {
                        rotationZ = userRotation
                    }
            ) {
                Image(
                    bitmap = personBitmap.asImageBitmap(),
                    contentDescription = "Live Video Cutout",
                    contentScale = ContentScale.Fit,
                    filterQuality = FilterQuality.High,
                    colorFilter = colorFilter,
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            // Waiting for first camera frame indicator
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xAA0F172A),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Color(0xFF38BDF8),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Starting Live Camera...",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // 2. Top-left Live / Recording Status Pill
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isRecording) Color(0xCCDC2626) else Color(0xAA0F172A),
            border = BorderStroke(1.dp, if (isRecording) Color(0xFFFCA5A5) else Color(0xFF38BDF8).copy(alpha = 0.6f)),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .testTag("video_mode_status_pill")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(if (isRecording) Color.White else Color(0xFF4ADE80), CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isRecording) {
                        "REC 00:${recordingRemainingSeconds.toString().padStart(2, '0')}"
                    } else if (selectedSong != null) {
                        "LIVE • 🎵 ${selectedSong.title.take(12)}"
                    } else {
                        "LIVE VIDEO (${if (lensFacing == CameraSelector.LENS_FACING_FRONT) "FRONT" else "BACK"})"
                    },
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 3. Top-right Front/Back Flip Camera & Exit Video Mode Icons
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (!isRecording && !isFinalizingVideo) {
                Surface(
                    onClick = onFlipCamera,
                    shape = CircleShape,
                    color = Color(0xBB0F172A),
                    border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.6f)),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("flip_video_camera_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Cameraswitch,
                            contentDescription = "Flip Front/Back Camera",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Surface(
                    onClick = onExitVideoMode,
                    shape = CircleShape,
                    color = Color(0xBB0F172A),
                    border = BorderStroke(1.dp, Color(0xFF94A3B8).copy(alpha = 0.5f)),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("close_video_mode_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Exit Video Mode",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // 4. Center 3-2-1 Countdown Overlay
        if (countdownSeconds > 0) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x55000000)),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xCC7C3AED),
                    border = BorderStroke(3.dp, Color.White),
                    modifier = Modifier.size(96.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "$countdownSeconds",
                            color = Color.White,
                            fontSize = 44.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }

        // 5. Finalizing Video Spinner Overlay
        if (isFinalizingVideo) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xAA020617)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(
                        color = Color(0xFF38BDF8),
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Rendering 15s Video + Audio...",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // 6. "WorldCam AI" Watermark at Bottom Center
        Text(
            text = "WorldCam AI",
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp)
                .shadow(4.dp)
        )
    }
}

@Composable
fun VideoModeActionBar(
    isRecording: Boolean,
    countdownSeconds: Int,
    recordingRemainingSeconds: Int,
    isFinalizingVideo: Boolean,
    selectedSong: SelectedSongInfo?,
    onStartOrStopRecord: () -> Unit,
    onOpenSongPicker: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B).copy(alpha = 0.95f)),
        border = BorderStroke(1.dp, Color(0xFFEC4899).copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onStartOrStopRecord,
                enabled = !isFinalizingVideo && countdownSeconds == 0,
                modifier = Modifier
                    .weight(1.2f)
                    .height(48.dp)
                    .testTag("start_stop_video_record_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRecording) Color(0xFFDC2626) else Color(0xFFEC4899)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                    contentDescription = if (isRecording) "Stop Recording" else "Start 15s Video",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = when {
                        countdownSeconds > 0 -> "Get Ready ($countdownSeconds)..."
                        isRecording -> "Stop (${recordingRemainingSeconds}s)"
                        else -> "Record 15s"
                    },
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            OutlinedButton(
                onClick = onOpenSongPicker,
                enabled = !isRecording && !isFinalizingVideo && countdownSeconds == 0,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("video_bar_song_button"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFF472B6).copy(alpha = 0.7f))
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = "Song",
                    tint = Color(0xFFF472B6),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = selectedSong?.let {
                        "${it.title.take(10)} (${formatMillisToTime(it.startTimeMs)})"
                    } ?: "No Song",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

package com.aistudio.worldcamai.smxuqv

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import java.util.Locale

data class SelectedSongInfo(
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val startTimeMs: Long = 0L
)

fun extractAudioMetadata(context: Context, uri: Uri): SelectedSongInfo {
    var displayName = "Selected Song"
    try {
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) {
                    val name = cursor.getString(idx)
                    if (!name.isNullOrBlank()) {
                        displayName = name.substringBeforeLast('.')
                    }
                }
            }
        }
    } catch (_: Throwable) {}

    var durationMs = 180_000L
    val retriever = MediaMetadataRetriever()
    try {
        retriever.setDataSource(context, uri)
        val metaTitle = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
        if (!metaTitle.isNullOrBlank()) {
            displayName = metaTitle.trim()
        }
        val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
        val parsed = durStr?.toLongOrNull()
        if (parsed != null && parsed > 0L) {
            durationMs = parsed
        }
    } catch (_: Throwable) {
    } finally {
        try {
            retriever.release()
        } catch (_: Throwable) {}
    }

    return SelectedSongInfo(
        uri = uri,
        title = displayName,
        durationMs = durationMs,
        startTimeMs = 0L
    )
}

fun formatMillisToTime(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val mins = totalSec / 60L
    val secs = totalSec % 60L
    return String.format(Locale.US, "%d:%02d", mins, secs)
}

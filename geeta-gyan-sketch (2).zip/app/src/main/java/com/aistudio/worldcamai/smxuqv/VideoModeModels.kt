package com.aistudio.worldcamai.smxuqv

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.TimeUnit

data class SelectedSongInfo(
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val startTimeMs: Long = 0L
)

data class OnlineMusicTrack(
    val id: String,
    val title: String,
    val subtitle: String,
    val moodTag: String,
    val streamUrl: String,
    val fallbackUrl: String,
    val moodKeywords: List<String>
)

val ONLINE_TRENDING_REEL_TRACKS: List<OnlineMusicTrack> = listOf(
    OnlineMusicTrack(
        id = "travel_cinematic",
        title = "Travel Cinematic",
        subtitle = "Uplifting acoustic & sweeping strings",
        moodTag = "Travel",
        streamUrl = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/Perspectives.mp3",
        fallbackUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
        moodKeywords = listOf("travel", "paris", "eiffel", "landmark", "monument", "tour", "heritage", "india", "taj")
    ),
    OnlineMusicTrack(
        id = "romantic_piano",
        title = "Romantic Piano",
        subtitle = "Soft emotional keys for iconic spots",
        moodTag = "Romantic",
        streamUrl = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/Gymnopedie%20No%201.mp3",
        fallbackUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
        moodKeywords = listOf("taj", "taj mahal", "love", "romantic", "agra", "venice", "palace", "sunset", "piano")
    ),
    OnlineMusicTrack(
        id = "lofi_chill",
        title = "Lo-Fi Chill",
        subtitle = "Smooth laid-back aesthetic vibe",
        moodTag = "Lo-Fi",
        streamUrl = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/Chill.mp3",
        fallbackUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
        moodKeywords = listOf("lofi", "chill", "cafe", "aesthetic", "street", "rain", "lake")
    ),
    OnlineMusicTrack(
        id = "desert_sunset",
        title = "Desert Sunset",
        subtitle = "Golden dunes & warm horizon glow",
        moodTag = "Desert",
        streamUrl = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/Desert%20City.mp3",
        fallbackUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
        moodKeywords = listOf("desert", "jaisalmer", "thar", "sand", "dunes", "dubai", "pyramid", "jaipur", "rajasthan")
    ),
    OnlineMusicTrack(
        id = "energetic_beat",
        title = "Energetic Beat",
        subtitle = "Upbeat reel rhythm & party pulse",
        moodTag = "Energetic",
        streamUrl = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/Carefree.mp3",
        fallbackUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
        moodKeywords = listOf("dance", "party", "happy", "fun", "energetic", "beat", "fast", "club")
    ),
    OnlineMusicTrack(
        id = "tropical_vibes",
        title = "Tropical Vibes",
        subtitle = "Breezy island & coastal groove",
        moodTag = "Beach",
        streamUrl = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/Bassa%20Island%20Game%20Loop.mp3",
        fallbackUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3",
        moodKeywords = listOf("beach", "ocean", "sea", "goa", "maldives", "bali", "island", "tropical")
    ),
    OnlineMusicTrack(
        id = "night_city_neon",
        title = "Night City Neon",
        subtitle = "Sleek synth & midnight skyline mood",
        moodTag = "Night",
        streamUrl = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/Wallpaper.mp3",
        fallbackUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3",
        moodKeywords = listOf("night", "neon", "tokyo", "times square", "city", "lights", "cyber", "london")
    ),
    OnlineMusicTrack(
        id = "mountain_breeze",
        title = "Mountain Breeze",
        subtitle = "Crisp alpine & snowy valley calm",
        moodTag = "Mountain",
        streamUrl = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/Morning.mp3",
        fallbackUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",
        moodKeywords = listOf("snow", "mountain", "manali", "gulmarg", "swiss", "ladakh", "kashmir", "kedarnath", "fuji")
    ),
    OnlineMusicTrack(
        id = "golden_horizon",
        title = "Golden Horizon",
        subtitle = "Dreamy ambient shimmer for reels",
        moodTag = "Dreamy",
        streamUrl = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/Aerosol%20of%20My%20Love.mp3",
        fallbackUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3",
        moodKeywords = listOf("santorini", "golden", "sunset", "dream", "sky", "sunrise", "riverfront")
    ),
    OnlineMusicTrack(
        id = "urban_lounge",
        title = "Urban Lounge",
        subtitle = "Modern cosmopolitan walk beat",
        moodTag = "Urban",
        streamUrl = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/Airport%20Lounge.mp3",
        fallbackUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3",
        moodKeywords = listOf("mall", "kota", "airport", "mumbai", "delhi", "singapore", "modern", "plaza")
    )
)

private val onlineMusicHttpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
}

private fun downloadAudioUrlToFile(url: String, destFile: File): Boolean {
    if (url.isBlank()) return false
    val tempFile = File(destFile.parentFile, "${destFile.nameWithoutExtension}_${System.currentTimeMillis()}.tmp")
    return try {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) WorldCamAI/1.0")
            .build()
        onlineMusicHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return false
            val contentType = response.header("Content-Type")?.lowercase(Locale.US).orEmpty()
            if (contentType.contains("text/html")) return false
            val body = response.body ?: return false
            body.byteStream().use { input ->
                FileOutputStream(tempFile).use { output ->
                    val buffer = ByteArray(8192)
                    var totalBytes = 0L
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        output.write(buffer, 0, read)
                        totalBytes += read
                        // Guard against oversized streams while allowing full standard MP3 files
                        if (totalBytes > 24L * 1024L * 1024L) break
                    }
                    output.flush()
                }
            }
        }
        if (tempFile.exists() && tempFile.length() > 16_384L) {
            if (destFile.exists()) destFile.delete()
            if (!tempFile.renameTo(destFile)) {
                tempFile.copyTo(destFile, overwrite = true)
                tempFile.delete()
            }
            destFile.exists() && destFile.length() > 16_384L
        } else {
            tempFile.delete()
            false
        }
    } catch (_: Throwable) {
        try { tempFile.delete() } catch (_: Throwable) {}
        false
    }
}

/**
 * Streams/caches a royalty-free track on demand into context.cacheDir without bundling MP3s in the APK.
 */
suspend fun fetchOrCacheOnlineMusicTrack(
    context: Context,
    track: OnlineMusicTrack
): SelectedSongInfo? = withContext(Dispatchers.IO) {
    try {
        val cacheFolder = File(context.cacheDir, "online_music").apply { mkdirs() }
        val cachedFile = File(cacheFolder, "${track.id}.mp3")
        val ready = if (cachedFile.exists() && cachedFile.length() > 16_384L) {
            true
        } else {
            downloadAudioUrlToFile(track.streamUrl, cachedFile) ||
                downloadAudioUrlToFile(track.fallbackUrl, cachedFile)
        }
        if (!ready || !cachedFile.exists()) return@withContext null

        val meta = extractAudioMetadata(context, Uri.fromFile(cachedFile))
        if (meta.durationMs <= 1000L) return@withContext null
        meta.copy(title = track.title)
    } catch (_: Throwable) {
        null
    }
}

fun matchOnlineTrackForVoiceScene(query: String, mood: VoiceSceneMood): OnlineMusicTrack {
    val qLower = query.lowercase(Locale.US)
    val byKeyword = ONLINE_TRENDING_REEL_TRACKS.firstOrNull { track ->
        track.moodKeywords.any { kw -> qLower.contains(kw) }
    }
    if (byKeyword != null) return byKeyword

    return when (mood) {
        VoiceSceneMood.SNOW, VoiceSceneMood.MOUNTAIN ->
            ONLINE_TRENDING_REEL_TRACKS.first { it.id == "mountain_breeze" }
        VoiceSceneMood.NIGHT ->
            ONLINE_TRENDING_REEL_TRACKS.first { it.id == "night_city_neon" }
        VoiceSceneMood.SUNSET ->
            ONLINE_TRENDING_REEL_TRACKS.first { it.id == "golden_horizon" }
        VoiceSceneMood.BEACH ->
            ONLINE_TRENDING_REEL_TRACKS.first { it.id == "tropical_vibes" }
        VoiceSceneMood.DESERT ->
            ONLINE_TRENDING_REEL_TRACKS.first { it.id == "desert_sunset" }
        VoiceSceneMood.AUTO ->
            ONLINE_TRENDING_REEL_TRACKS.first { it.id == "travel_cinematic" }
    }
}

data class ItunesSearchTrack(
    val trackId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val previewUrl: String,
    val artworkUrl: String
)

suspend fun searchItunesMusicTracks(query: String): List<ItunesSearchTrack> = withContext(Dispatchers.IO) {
    val cleanQuery = query.trim()
    if (cleanQuery.isBlank()) return@withContext emptyList()
    try {
        val encoded = java.net.URLEncoder.encode(cleanQuery, "UTF-8")
        val url = "https://itunes.apple.com/search?term=$encoded&media=music&limit=15"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "WorldCamAI/1.0")
            .header("Accept", "application/json")
            .build()
        onlineMusicHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext emptyList()
            val rawJson = response.body?.string().orEmpty()
            if (rawJson.isBlank()) return@withContext emptyList()
            val root = org.json.JSONObject(rawJson)
            val arr = root.optJSONArray("results") ?: return@withContext emptyList()
            val tracks = ArrayList<ItunesSearchTrack>(arr.length())
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val preview = item.optString("previewUrl", "").trim()
                if (preview.isBlank()) continue
                val trackId = item.optLong("trackId", i.toLong())
                val title = item.optString("trackName", "").trim().ifBlank { "Untitled Track" }
                val artist = item.optString("artistName", "").trim().ifBlank { "Unknown Artist" }
                val album = item.optString("collectionName", "").trim()
                val artwork = item.optString("artworkUrl100", "").trim()
                tracks.add(
                    ItunesSearchTrack(
                        trackId = trackId,
                        title = title,
                        artist = artist,
                        album = album,
                        previewUrl = preview,
                        artworkUrl = artwork
                    )
                )
            }
            tracks
        }
    } catch (_: Throwable) {
        emptyList()
    }
}

suspend fun fetchOrCacheItunesPreview(
    context: Context,
    track: ItunesSearchTrack
): SelectedSongInfo? = withContext(Dispatchers.IO) {
    try {
        val cacheFolder = File(context.cacheDir, "itunes_songs").apply { mkdirs() }
        val ext = if (track.previewUrl.contains(".mp3", ignoreCase = true)) "mp3" else "m4a"
        val cachedFile = File(cacheFolder, "itunes_${track.trackId}.$ext")
        val ready = if (cachedFile.exists() && cachedFile.length() > 16_384L) {
            true
        } else {
            downloadAudioUrlToFile(track.previewUrl, cachedFile)
        }
        if (!ready || !cachedFile.exists()) return@withContext null

        val meta = extractAudioMetadata(context, Uri.fromFile(cachedFile))
        val safeDur = if (meta.durationMs > 1000L) meta.durationMs else 30_000L
        val displayTitle = if (track.artist.isNotBlank()) "${track.title} • ${track.artist}" else track.title
        meta.copy(
            title = displayTitle,
            durationMs = safeDur,
            startTimeMs = 0L
        )
    } catch (_: Throwable) {
        null
    }
}

fun extractAudioMetadata(context: Context, uri: Uri): SelectedSongInfo {
    var displayName = "Selected Song"
    try {
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) {
                    val name = cursor.getString(idx)
                    if (!name.isNullOrBlank()) {
                        displayName = name.substringBeforeLast('.')
                    }
                }
            }
        }
    } catch (_: Throwable) {}

    var durationMs = 180_000L
    val retriever = MediaMetadataRetriever()
    try {
        retriever.setDataSource(context, uri)
        val metaTitle = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
        if (!metaTitle.isNullOrBlank()) {
            displayName = metaTitle.trim()
        }
        val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
        val parsed = durStr?.toLongOrNull()
        if (parsed != null && parsed > 0L) {
            durationMs = parsed
        }
    } catch (_: Throwable) {
    } finally {
        try {
            retriever.release()
        } catch (_: Throwable) {}
    }

    return SelectedSongInfo(
        uri = uri,
        title = displayName,
        durationMs = durationMs,
        startTimeMs = 0L
    )
}

fun formatMillisToTime(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val mins = totalSec / 60L
    val secs = totalSec % 60L
    return String.format(Locale.US, "%d:%02d", mins, secs)
}

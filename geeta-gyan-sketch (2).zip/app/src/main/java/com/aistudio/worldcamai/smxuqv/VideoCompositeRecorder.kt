package com.aistudio.worldcamai.smxuqv

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.util.WeakHashMap
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

data class VideoLocationLightingProfile(
    val avgBrightness: Float,
    val warmth: Float,
    val sunDirectionX: Float,
    val shadowTintColor: Int,
    val personColorMatrixValues: FloatArray
)

private val videoLightingCache = WeakHashMap<Bitmap, VideoLocationLightingProfile>()
private val videoDepthBlurCache = WeakHashMap<Bitmap, Bitmap>()
private val videoShadowSilhouetteCache = WeakHashMap<Bitmap, Bitmap>()

@Volatile
private var sharedCameraGrainBitmap: Bitmap? = null

private val defaultVideoLightingProfile = VideoLocationLightingProfile(
    avgBrightness = 0.55f,
    warmth = 0.0f,
    sunDirectionX = 0.35f,
    shadowTintColor = Color.rgb(14, 18, 26),
    personColorMatrixValues = ColorMatrix().array
)

fun analyzeVideoBackgroundLighting(bgBitmap: Bitmap?): VideoLocationLightingProfile {
    if (bgBitmap == null || bgBitmap.isRecycled || bgBitmap.width <= 0 || bgBitmap.height <= 0) {
        return defaultVideoLightingProfile
    }
    synchronized(videoLightingCache) {
        videoLightingCache[bgBitmap]?.let { return it }
    }

    return try {
        val w = bgBitmap.width
        val h = bgBitmap.height
        val grid = 20
        var sumR = 0.0
        var sumG = 0.0
        var sumB = 0.0
        var sumLuma = 0.0
        var sumLumaSq = 0.0
        var leftLuma = 0.0
        var rightLuma = 0.0
        var leftCount = 0
        var rightCount = 0
        var count = 0

        for (gy in 0 until grid) {
            val py = ((gy + 0.5f) * h / grid).toInt().coerceIn(0, h - 1)
            for (gx in 0 until grid) {
                val px = ((gx + 0.5f) * w / grid).toInt().coerceIn(0, w - 1)
                val pixel = bgBitmap.getPixel(px, py)
                val r = (pixel ushr 16) and 0xFF
                val g = (pixel ushr 8) and 0xFF
                val b = pixel and 0xFF
                val luma = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
                sumR += r
                sumG += g
                sumB += b
                sumLuma += luma
                sumLumaSq += luma * luma
                if (gx < grid / 2) {
                    leftLuma += luma
                    leftCount++
                } else {
                    rightLuma += luma
                    rightCount++
                }
                count++
            }
        }

        val c = count.coerceAtLeast(1)
        val avgR = (sumR / c).toFloat()
        val avgG = (sumG / c).toFloat()
        val avgB = (sumB / c).toFloat()
        val avgLuma = (sumLuma / c).toFloat().coerceIn(0.05f, 0.95f)
        val variance = ((sumLumaSq / c) - (avgLuma * avgLuma)).toFloat().coerceAtLeast(0f)
        val stdDev = sqrt(variance)

        val lLeft = if (leftCount > 0) (leftLuma / leftCount).toFloat() else avgLuma
        val lRight = if (rightCount > 0) (rightLuma / rightCount).toFloat() else avgLuma
        val rawDir = ((lLeft - lRight) * 3.8f).coerceIn(-0.85f, 0.85f)
        val sunDirectionX = if (abs(rawDir) < 0.14f) 0.30f else rawDir

        val warmth = ((avgR - avgB) / 255f).coerceIn(-0.55f, 0.55f)

        // Normalize dominant chromatic balance of the location
        val avgRgbMean = ((avgR + avgG + avgB) / 3f).coerceAtLeast(18f)
        val normR = (avgR / avgRgbMean).coerceIn(0.75f, 1.32f)
        val normG = (avgG / avgRgbMean).coerceIn(0.80f, 1.22f)
        val normB = (avgB / avgRgbMean).coerceIn(0.72f, 1.35f)

        // Blend ~26% of location ambient chromaticity + brightness/contrast match onto the live person
        val tintStrength = 0.26f
        val rTint = 1f + (normR - 1f) * tintStrength
        val gTint = 1f + (normG - 1f) * tintStrength
        val bTint = 1f + (normB - 1f) * tintStrength

        val exposureScale = when {
            avgLuma < 0.24f -> 0.74f + (avgLuma / 0.24f) * 0.10f // Night / dark interior
            avgLuma < 0.42f -> 0.84f + ((avgLuma - 0.24f) / 0.18f) * 0.12f // Dusk / shaded
            avgLuma > 0.70f -> 1.04f + ((avgLuma - 0.70f) / 0.25f) * 0.05f // Bright sunny day
            else -> 0.96f + ((avgLuma - 0.42f) / 0.28f) * 0.08f
        }.coerceIn(0.72f, 1.10f)

        val contrast = (0.96f + stdDev * 0.42f).coerceIn(0.94f, 1.14f)
        val brightnessLift = when {
            avgLuma < 0.26f -> -16f
            avgLuma < 0.42f -> -6f
            avgLuma > 0.74f -> 6f
            else -> 0f
        }

        // Subtle atmospheric color wash from background into shadows/midtones
        val washR = (avgR - 128f) * 0.09f
        val washG = (avgG - 128f) * 0.09f
        val washB = (avgB - 128f) * 0.09f

        val cm = ColorMatrix()
        // Slight saturation match: slightly calmer saturation at night, richer in vivid daylight/sunset
        val sat = when {
            avgLuma < 0.25f -> 0.86f
            warmth > 0.16f -> 1.07f
            else -> 0.98f
        }
        cm.setSaturation(sat)

        val contrastShift = 128f * (1f - contrast)
        val relightMatrix = ColorMatrix(
            floatArrayOf(
                rTint * exposureScale * contrast, 0f, 0f, 0f, contrastShift + brightnessLift + washR,
                0f, gTint * exposureScale * contrast, 0f, 0f, contrastShift + brightnessLift + washG,
                0f, 0f, bTint * exposureScale * contrast, 0f, contrastShift + brightnessLift + washB,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(relightMatrix)

        val shadowR = (avgR * 0.16f).toInt().coerceIn(8, 34)
        val shadowG = (avgG * 0.16f).toInt().coerceIn(8, 34)
        val shadowB = (avgB * 0.18f).toInt().coerceIn(10, 42)

        val profile = VideoLocationLightingProfile(
            avgBrightness = avgLuma,
            warmth = warmth,
            sunDirectionX = sunDirectionX,
            shadowTintColor = Color.rgb(shadowR, shadowG, shadowB),
            personColorMatrixValues = cm.array.copyOf()
        )
        synchronized(videoLightingCache) {
            videoLightingCache[bgBitmap] = profile
        }
        profile
    } catch (_: Throwable) {
        defaultVideoLightingProfile
    }
}

fun composePersonColorMatrix(
    lighting: VideoLocationLightingProfile,
    filterMatrixValues: FloatArray?
): FloatArray {
    val cm = ColorMatrix(lighting.personColorMatrixValues)
    if (filterMatrixValues != null && filterMatrixValues.size >= 20) {
        cm.postConcat(ColorMatrix(filterMatrixValues))
    }
    return cm.array
}

fun getOrCreateVideoDepthBlurBitmap(bgBitmap: Bitmap?): Bitmap? {
    if (bgBitmap == null || bgBitmap.isRecycled || bgBitmap.width <= 0 || bgBitmap.height <= 0) {
        return bgBitmap
    }
    synchronized(videoDepthBlurCache) {
        videoDepthBlurCache[bgBitmap]?.let { cached ->
            if (!cached.isRecycled) return cached
        }
    }

    return try {
        val maxSide = 760f
        val scale = (maxSide / maxOf(bgBitmap.width, bgBitmap.height).toFloat()).coerceIn(0.15f, 1f)
        val sw = (bgBitmap.width * scale).toInt().coerceAtLeast(32)
        val sh = (bgBitmap.height * scale).toInt().coerceAtLeast(32)
        val small = Bitmap.createScaledBitmap(bgBitmap, sw, sh, true)

        val total = sw * sh
        val src = IntArray(total)
        val tmp = IntArray(total)
        val dst = IntArray(total)
        small.getPixels(src, 0, sw, 0, 0, sw, sh)

        // Fast 2-pass separable radius-3 optical depth blur on ~760px bitmap for crisp 1080p bokeh
        val radius = 3
        val div = radius * 2 + 1
        for (y in 0 until sh) {
            val row = y * sw
            for (x in 0 until sw) {
                var sr = 0
                var sg = 0
                var sb = 0
                for (k in -radius..radius) {
                    val px = src[row + (x + k).coerceIn(0, sw - 1)]
                    sr += (px ushr 16) and 0xFF
                    sg += (px ushr 8) and 0xFF
                    sb += px and 0xFF
                }
                tmp[row + x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
            }
        }
        for (y in 0 until sh) {
            val row = y * sw
            for (x in 0 until sw) {
                var sr = 0
                var sg = 0
                var sb = 0
                for (k in -radius..radius) {
                    val px = tmp[(y + k).coerceIn(0, sh - 1) * sw + x]
                    sr += (px ushr 16) and 0xFF
                    sg += (px ushr 8) and 0xFF
                    sb += px and 0xFF
                }
                dst[row + x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
            }
        }

        val blurred = Bitmap.createBitmap(dst, sw, sh, Bitmap.Config.ARGB_8888)
        if (small != blurred && !small.isRecycled) {
            small.recycle()
        }
        synchronized(videoDepthBlurCache) {
            videoDepthBlurCache[bgBitmap] = blurred
        }
        blurred
    } catch (_: Throwable) {
        bgBitmap
    }
}

private fun getOrCreateSoftShadowSilhouette(
    personBitmap: Bitmap,
    shadowTintColor: Int
): Bitmap? {
    if (personBitmap.isRecycled || personBitmap.width <= 0 || personBitmap.height <= 0) return null
    synchronized(videoShadowSilhouetteCache) {
        videoShadowSilhouetteCache[personBitmap]?.let { cached ->
            if (!cached.isRecycled) return cached
        }
    }
    return try {
        val sw = 44
        val sh = ((personBitmap.height.toFloat() / personBitmap.width.toFloat()) * sw)
            .toInt()
            .coerceIn(32, 72)
        val tiny = Bitmap.createScaledBitmap(personBitmap, sw, sh, true)
        val total = sw * sh
        val px = IntArray(total)
        val alphaBuf = IntArray(total)
        val blurBuf = IntArray(total)
        tiny.getPixels(px, 0, sw, 0, 0, sw, sh)
        if (tiny != personBitmap && !tiny.isRecycled) tiny.recycle()

        for (i in 0 until total) {
            alphaBuf[i] = (px[i] ushr 24) and 0xFF
        }

        // Fast 3x3 box blur on the 44px silhouette alpha for buttery soft shadow edges
        for (y in 0 until sh) {
            for (x in 0 until sw) {
                var sum = 0
                for (dy in -1..1) {
                    val sy = (y + dy).coerceIn(0, sh - 1)
                    for (dx in -1..1) {
                        val sx = (x + dx).coerceIn(0, sw - 1)
                        sum += alphaBuf[sy * sw + sx]
                    }
                }
                blurBuf[y * sw + x] = (sum / 9).coerceIn(0, 255)
            }
        }

        val baseRgb = shadowTintColor and 0x00FFFFFF
        for (i in 0 until total) {
            val a = blurBuf[i]
            px[i] = if (a <= 2) 0 else (a shl 24) or baseRgb
        }
        val silhouette = Bitmap.createBitmap(px, sw, sh, Bitmap.Config.ARGB_8888)
        synchronized(videoShadowSilhouetteCache) {
            videoShadowSilhouetteCache[personBitmap] = silhouette
        }
        silhouette
    } catch (_: Throwable) {
        null
    }
}

fun drawDynamicVideoPersonShadow(
    canvas: Canvas,
    personBitmap: Bitmap,
    lighting: VideoLocationLightingProfile,
    shadowDepth: Float,
    left: Float,
    top: Float,
    targetUserWidth: Float,
    targetUserHeight: Float,
    centerX: Float,
    bottomY: Float,
    userRotation: Float
) {
    if (shadowDepth <= 0.04f) return
    val depth = shadowDepth.coerceIn(0.05f, 0.85f)

    // Adjust directional shadow strength so it looks real in both daylight and low-light scenes
    val ambientFactor = (0.70f + lighting.avgBrightness * 0.45f).coerceIn(0.65f, 1.15f)

    // 1. Directional soft silhouette cast shadow behind & offset from user
    val silhouette = getOrCreateSoftShadowSilhouette(personBitmap, lighting.shadowTintColor)
    if (silhouette != null && !silhouette.isRecycled) {
        val silhouetteAlpha = ((depth * 0.56f * ambientFactor) * 255f).toInt().coerceIn(22, 140)
        val castPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            alpha = silhouetteAlpha
        }
        val offsetX = lighting.sunDirectionX * targetUserWidth * (0.06f + depth * 0.11f)
        val offsetY = targetUserHeight * (0.012f + depth * 0.018f)

        canvas.save()
        if (userRotation != 0f) {
            canvas.rotate(userRotation, centerX, top + targetUserHeight / 2f)
        }
        val shadowMatrix = Matrix().apply {
            // Subtle perspective lean anchored around subject center-bottom
            postScale(1.03f, 0.99f, centerX, bottomY)
            postSkew(lighting.sunDirectionX * 0.09f, 0f, centerX, bottomY)
            postTranslate(offsetX, offsetY)
        }
        canvas.concat(shadowMatrix)
        val shadowRect = RectF(left, top, left + targetUserWidth, bottomY)
        canvas.drawBitmap(silhouette, null, shadowRect, castPaint)
        canvas.restore()
    }

    // 2. Grounded soft radial contact umbra right beneath the user's lower edge
    val contactRadiusX = (targetUserWidth * 0.48f).coerceAtLeast(24f)
    val contactRadiusY = (targetUserHeight * 0.055f).coerceAtLeast(8f)
    val contactCy = bottomY - (contactRadiusY * 0.20f)
    val maxContactAlpha = ((depth * 0.62f * ambientFactor) * 255f).toInt().coerceIn(28, 155)
    val baseColor = lighting.shadowTintColor and 0x00FFFFFF
    val centerColor = (maxContactAlpha shl 24) or baseColor
    val midColor = ((maxContactAlpha * 0.45f).toInt() shl 24) or baseColor

    canvas.save()
    canvas.translate(centerX + lighting.sunDirectionX * targetUserWidth * 0.03f, contactCy)
    canvas.scale(1f, contactRadiusY / contactRadiusX)
    val contactPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(
            0f,
            0f,
            contactRadiusX,
            intArrayOf(centerColor, midColor, Color.TRANSPARENT),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
    }
    canvas.drawCircle(0f, 0f, contactRadiusX, contactPaint)
    canvas.restore()
}

private fun getOrCreateCameraGrainBitmap(): Bitmap {
    sharedCameraGrainBitmap?.let { if (!it.isRecycled) return it }
    val size = 192
    val pixels = IntArray(size * size)
    val rng = Random(20250419)
    for (i in pixels.indices) {
        val bright = rng.nextBoolean()
        val alpha = rng.nextInt(5, 19)
        val luma = if (bright) rng.nextInt(195, 255) else rng.nextInt(0, 55)
        pixels[i] = (alpha shl 24) or (luma shl 16) or (luma shl 8) or luma
    }
    val bmp = Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
    sharedCameraGrainBitmap = bmp
    return bmp
}

fun drawUnifiedVideoCameraGrain(
    canvas: Canvas,
    width: Float,
    height: Float,
    frameSeed: Long
) {
    if (width <= 0f || height <= 0f) return
    val grainBmp = getOrCreateCameraGrainBitmap()
    val shiftX = ((frameSeed * 37L) % 192L).toFloat()
    val shiftY = ((frameSeed * 61L) % 192L).toFloat()
    val shader = BitmapShader(grainBmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    val matrix = Matrix().apply {
        setTranslate(shiftX, shiftY)
    }
    shader.setLocalMatrix(matrix)
    val grainPaint = Paint().apply {
        this.shader = shader
        alpha = 185
    }
    canvas.drawRect(0f, 0f, width, height, grainPaint)
}

fun drawCompositeVideoFrame(
    canvas: Canvas,
    width: Int,
    height: Int,
    bgBitmap: Bitmap?,
    personBitmap: Bitmap?,
    userScale: Float,
    userXOffset: Float,
    userYOffset: Float,
    userRotation: Float,
    previewWidthPx: Float,
    previewHeightPx: Float,
    filterMatrixValues: FloatArray?,
    shadowDepth: Float = 0.38f,
    frameSeed: Long = 0L,
    showWatermark: Boolean = true
) {
    val lighting = analyzeVideoBackgroundLighting(bgBitmap)
    val blurredBg = getOrCreateVideoDepthBlurBitmap(bgBitmap) ?: bgBitmap

    val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        if (filterMatrixValues != null) {
            colorFilter = ColorMatrixColorFilter(filterMatrixValues)
        }
    }

    if (blurredBg != null && !blurredBg.isRecycled && blurredBg.width > 0 && blurredBg.height > 0) {
        val bgAspect = blurredBg.width.toFloat() / blurredBg.height.toFloat()
        val outAspect = width.toFloat() / height.toFloat()
        val drawW: Float
        val drawH: Float
        if (bgAspect > outAspect) {
            drawH = height.toFloat()
            drawW = drawH * bgAspect
        } else {
            drawW = width.toFloat()
            drawH = drawW / bgAspect
        }
        val drawX = (width - drawW) / 2f
        val drawY = (height - drawH) / 2f
        canvas.drawBitmap(blurredBg, null, RectF(drawX, drawY, drawX + drawW, drawY + drawH), bgPaint)
    } else {
        val fallbackPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                Color.parseColor("#0F172A"), Color.parseColor("#1E1B4B"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fallbackPaint)
    }

    if (personBitmap != null && !personBitmap.isRecycled && personBitmap.width > 0 && personBitmap.height > 0) {
        val pW = previewWidthPx.coerceAtLeast(300f)
        val pH = previewHeightPx.coerceAtLeast(300f)
        val scaleToExport = width.toFloat() / pW

        val targetUserHeight = height.toFloat() * ((210f * userScale) / 380f)
        val userAspect = personBitmap.width.toFloat() / personBitmap.height.toFloat().coerceAtLeast(0.01f)
        val targetUserWidth = targetUserHeight * userAspect

        val centerX = (pW / 2f + userXOffset) * scaleToExport
        val bottomY = height.toFloat() + (userYOffset * (height.toFloat() / pH))
        val top = bottomY - targetUserHeight
        val left = centerX - (targetUserWidth / 2f)

        // Realistic dynamic directional & contact shadow behind/beneath user
        drawDynamicVideoPersonShadow(
            canvas = canvas,
            personBitmap = personBitmap,
            lighting = lighting,
            shadowDepth = shadowDepth,
            left = left,
            top = top,
            targetUserWidth = targetUserWidth,
            targetUserHeight = targetUserHeight,
            centerX = centerX,
            bottomY = bottomY,
            userRotation = userRotation
        )

        // Real-time location color & lighting matched Paint (+ any selected filter)
        val personColorMatrix = composePersonColorMatrix(lighting, filterMatrixValues)
        val personPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(personColorMatrix)
        }
        val destRect = RectF(left, top, left + targetUserWidth, bottomY)
        canvas.save()
        if (userRotation != 0f) {
            canvas.rotate(userRotation, centerX, top + targetUserHeight / 2f)
        }
        canvas.drawBitmap(personBitmap, null, destRect, personPaint)
        canvas.restore()
    }

    // Unified subtle camera lens grain over both depth-blurred background and relit user
    drawUnifiedVideoCameraGrain(canvas, width.toFloat(), height.toFloat(), frameSeed)

    if (showWatermark) {
        val wmPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = (width * 0.044f).coerceAtLeast(28f)
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            alpha = 215
            setShadowLayer(6f, 0f, 2f, Color.argb(180, 0, 0, 0))
        }
        canvas.drawText("WorldCam AI", width / 2f, height - (height * 0.032f), wmPaint)
    }
}

class CompositeVideoSurfaceRecorder(
    private val width: Int = 1080,
    private val height: Int = 1920,
    private val outputFile: File
) {
    private val executor = Executors.newSingleThreadExecutor()
    private val isRecording = AtomicBoolean(false)
    private val pendingFrames = AtomicInteger(0)

    private var encoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var muxer: MediaMuxer? = null
    private var videoTrackIndex = -1
    private var muxerStarted = false
    private var firstPtsUs = -1L
    private var frameCount = 0

    fun start(): Boolean {
        return try {
            executor.submit(Callable {
                val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                    setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                    setInteger(MediaFormat.KEY_BIT_RATE, 12_000_000)
                    setInteger(MediaFormat.KEY_FRAME_RATE, 30)
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                }
                val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
                codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val surface = codec.createInputSurface()
                codec.start()

                if (outputFile.exists()) outputFile.delete()
                val mediaMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

                encoder = codec
                inputSurface = surface
                muxer = mediaMuxer
                videoTrackIndex = -1
                muxerStarted = false
                firstPtsUs = -1L
                frameCount = 0
                isRecording.set(true)
                true
            }).get()
        } catch (e: Throwable) {
            Log.e("VideoRecorder", "Failed to start recorder: ${e.message}", e)
            cleanup()
            false
        }
    }

    fun submitFrame(
        bgBitmap: Bitmap?,
        personBitmap: Bitmap?,
        userScale: Float,
        userXOffset: Float,
        userYOffset: Float,
        userRotation: Float,
        previewWidthPx: Float,
        previewHeightPx: Float,
        filterMatrixValues: FloatArray?,
        shadowDepth: Float = 0.38f,
        showWatermark: Boolean = true
    ) {
        if (!isRecording.get()) return
        if (pendingFrames.get() >= 2) return // Keep latency crisp if encoder is busy

        val bgSnap = bgBitmap?.takeIf { !it.isRecycled }
        val personSnap = personBitmap?.takeIf { !it.isRecycled }

        pendingFrames.incrementAndGet()
        executor.execute {
            try {
                if (!isRecording.get()) return@execute
                val surface = inputSurface ?: return@execute
                val canvas = surface.lockCanvas(null)
                try {
                    drawCompositeVideoFrame(
                        canvas = canvas,
                        width = width,
                        height = height,
                        bgBitmap = bgSnap,
                        personBitmap = personSnap,
                        userScale = userScale,
                        userXOffset = userXOffset,
                        userYOffset = userYOffset,
                        userRotation = userRotation,
                        previewWidthPx = previewWidthPx,
                        previewHeightPx = previewHeightPx,
                        filterMatrixValues = filterMatrixValues,
                        shadowDepth = shadowDepth,
                        frameSeed = frameCount.toLong(),
                        showWatermark = showWatermark
                    )
                } finally {
                    surface.unlockCanvasAndPost(canvas)
                }
                frameCount++
                drainEncoder(endOfStream = false)
            } catch (t: Throwable) {
                Log.w("VideoRecorder", "Frame encode error: ${t.message}")
            } finally {
                pendingFrames.decrementAndGet()
            }
        }
    }

    fun stopAndFinalize(): File? {
        if (!isRecording.compareAndSet(true, false)) {
            return null
        }
        return try {
            executor.submit(Callable {
                try {
                    encoder?.signalEndOfInputStream()
                    drainEncoder(endOfStream = true)
                } catch (e: Throwable) {
                    Log.e("VideoRecorder", "Error draining EOS: ${e.message}", e)
                }
                val valid = muxerStarted && frameCount > 0 && outputFile.exists() && outputFile.length() > 0L
                cleanup()
                if (valid) outputFile else null
            }).get()
        } catch (e: Throwable) {
            Log.e("VideoRecorder", "Stop failed: ${e.message}", e)
            cleanup()
            null
        } finally {
            try {
                executor.shutdown()
            } catch (_: Throwable) {}
        }
    }

    private fun drainEncoder(endOfStream: Boolean) {
        val codec = encoder ?: return
        val mediaMuxer = muxer ?: return
        val bufferInfo = MediaCodec.BufferInfo()
        val timeoutUs = if (endOfStream) 10_000L else 0L
        var emptyTries = 0

        while (true) {
            val outIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            when {
                outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream) break
                    emptyTries++
                    if (emptyTries > 25) break
                }
                outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (!muxerStarted) {
                        val newFormat = codec.outputFormat
                        videoTrackIndex = mediaMuxer.addTrack(newFormat)
                        mediaMuxer.start()
                        muxerStarted = true
                    }
                }
                outIndex >= 0 -> {
                    val encodedData = codec.getOutputBuffer(outIndex)
                    if (encodedData != null) {
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }
                        if (bufferInfo.size > 0 && muxerStarted && videoTrackIndex >= 0) {
                            if (firstPtsUs < 0L) {
                                firstPtsUs = bufferInfo.presentationTimeUs
                            }
                            bufferInfo.presentationTimeUs = (bufferInfo.presentationTimeUs - firstPtsUs).coerceAtLeast(0L)
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            mediaMuxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                        }
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            }
        }
    }

    private fun cleanup() {
        isRecording.set(false)
        try {
            encoder?.stop()
        } catch (_: Throwable) {}
        try {
            encoder?.release()
        } catch (_: Throwable) {}
        encoder = null

        try {
            inputSurface?.release()
        } catch (_: Throwable) {}
        inputSurface = null

        try {
            if (muxerStarted) {
                muxer?.stop()
            }
        } catch (_: Throwable) {}
        try {
            muxer?.release()
        } catch (_: Throwable) {}
        muxer = null
    }
}

fun muxSongAudioWithVideo(
    context: Context,
    videoFile: File,
    audioUri: Uri?,
    songStartTimeMs: Long,
    outputFile: File
): File {
    if (audioUri == null) {
        videoFile.copyTo(outputFile, overwrite = true)
        return outputFile
    }

    val videoExtractor = MediaExtractor()
    val audioExtractor = MediaExtractor()
    var audioDecoder: MediaCodec? = null
    var audioEncoder: MediaCodec? = null
    var muxer: MediaMuxer? = null
    var muxerStarted = false

    return try {
        videoExtractor.setDataSource(videoFile.absolutePath)
        var srcVideoTrack = -1
        var videoFormat: MediaFormat? = null
        for (i in 0 until videoExtractor.trackCount) {
            val fmt = videoExtractor.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("video/")) {
                srcVideoTrack = i
                videoFormat = fmt
                break
            }
        }
        if (srcVideoTrack < 0 || videoFormat == null) {
            videoFile.copyTo(outputFile, overwrite = true)
            return outputFile
        }
        videoExtractor.selectTrack(srcVideoTrack)

        // Determine actual recorded video duration
        var maxVideoPtsUs = 15_000_000L
        if (videoFormat.containsKey(MediaFormat.KEY_DURATION)) {
            maxVideoPtsUs = videoFormat.getLong(MediaFormat.KEY_DURATION).coerceIn(500_000L, 15_500_000L)
        } else {
            val scanBuf = ByteBuffer.allocate(256 * 1024)
            var lastPts = 0L
            while (true) {
                val sz = videoExtractor.readSampleData(scanBuf, 0)
                if (sz < 0) break
                if (videoExtractor.sampleTime > lastPts) lastPts = videoExtractor.sampleTime
                videoExtractor.advance()
            }
            if (lastPts > 0L) maxVideoPtsUs = lastPts + 33_333L
            videoExtractor.seekTo(0L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        }

        // Open audio extractor
        audioExtractor.setDataSource(context, audioUri, null)
        var srcAudioTrack = -1
        var srcAudioFormat: MediaFormat? = null
        for (i in 0 until audioExtractor.trackCount) {
            val fmt = audioExtractor.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                srcAudioTrack = i
                srcAudioFormat = fmt
                break
            }
        }
        if (srcAudioTrack < 0 || srcAudioFormat == null) {
            videoFile.copyTo(outputFile, overwrite = true)
            return outputFile
        }
        audioExtractor.selectTrack(srcAudioTrack)
        val seekUs = (songStartTimeMs * 1000L).coerceAtLeast(0L)
        audioExtractor.seekTo(seekUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

        val srcMime = srcAudioFormat.getString(MediaFormat.KEY_MIME) ?: "audio/mpeg"
        var sampleRate = if (srcAudioFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
            srcAudioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        } else 44100
        var channelCount = if (srcAudioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
            srcAudioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        } else 2

        val decoder = MediaCodec.createDecoderByType(srcMime)
        decoder.configure(srcAudioFormat, null, null, 0)
        decoder.start()
        audioDecoder = decoder

        val encFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channelCount).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        encoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()
        audioEncoder = encoder

        // Transcode exact 15s (maxVideoPtsUs) audio clip to AAC frames in memory first
        val aacSamples = ArrayList<Pair<ByteArray, MediaCodec.BufferInfo>>()
        var actualEncoderFormat: MediaFormat? = null

        val decInfo = MediaCodec.BufferInfo()
        val encInfo = MediaCodec.BufferInfo()
        var extractorDone = false
        var decoderDone = false
        var encoderDone = false
        var firstDecodedPtsUs = -1L
        var encodedPtsUs = 0L

        while (!encoderDone) {
            if (!extractorDone) {
                val inIdx = decoder.dequeueInputBuffer(5_000L)
                if (inIdx >= 0) {
                    val inBuf = decoder.getInputBuffer(inIdx)
                    if (inBuf != null) {
                        val sampleSize = audioExtractor.readSampleData(inBuf, 0)
                        val samplePts = audioExtractor.sampleTime
                        if (sampleSize < 0 || (firstDecodedPtsUs >= 0L && (samplePts - firstDecodedPtsUs) > maxVideoPtsUs + 200_000L)) {
                            decoder.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            extractorDone = true
                        } else {
                            if (firstDecodedPtsUs < 0L) firstDecodedPtsUs = samplePts
                            decoder.queueInputBuffer(inIdx, 0, sampleSize, samplePts, 0)
                            audioExtractor.advance()
                        }
                    }
                }
            }

            if (!decoderDone) {
                val decOutIdx = decoder.dequeueOutputBuffer(decInfo, 5_000L)
                if (decOutIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFmt = decoder.outputFormat
                    if (newFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        sampleRate = newFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (newFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channelCount = newFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                } else if (decOutIdx >= 0) {
                    val decOutBuf = decoder.getOutputBuffer(decOutIdx)
                    val isEos = (decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    if (decOutBuf != null && decInfo.size > 0 && encodedPtsUs < maxVideoPtsUs) {
                        decOutBuf.position(decInfo.offset)
                        decOutBuf.limit(decInfo.offset + decInfo.size)
                        val pcmBytes = ByteArray(decInfo.size)
                        decOutBuf.get(pcmBytes)

                        var offset = 0
                        while (offset < pcmBytes.size && encodedPtsUs < maxVideoPtsUs) {
                            val encInIdx = encoder.dequeueInputBuffer(10_000L)
                            if (encInIdx >= 0) {
                                val encInBuf = encoder.getInputBuffer(encInIdx)
                                if (encInBuf != null) {
                                    encInBuf.clear()
                                    val chunk = minOf(encInBuf.remaining(), pcmBytes.size - offset)
                                    encInBuf.put(pcmBytes, offset, chunk)
                                    val bytesPerSec = (sampleRate * channelCount * 2).coerceAtLeast(1)
                                    val chunkDurationUs = (chunk.toLong() * 1_000_000L) / bytesPerSec
                                    encoder.queueInputBuffer(encInIdx, 0, chunk, encodedPtsUs, 0)
                                    encodedPtsUs += chunkDurationUs
                                    offset += chunk
                                }
                            }
                        }
                    }
                    decoder.releaseOutputBuffer(decOutIdx, false)
                    if (isEos || encodedPtsUs >= maxVideoPtsUs) {
                        val encInIdx = encoder.dequeueInputBuffer(10_000L)
                        if (encInIdx >= 0) {
                            encoder.queueInputBuffer(encInIdx, 0, 0, encodedPtsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        }
                        decoderDone = true
                    }
                }
            }

            while (true) {
                val encOutIdx = encoder.dequeueOutputBuffer(encInfo, 2_000L)
                if (encOutIdx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    break
                } else if (encOutIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    actualEncoderFormat = encoder.outputFormat
                } else if (encOutIdx >= 0) {
                    val encOutBuf = encoder.getOutputBuffer(encOutIdx)
                    if (encOutBuf != null && encInfo.size > 0 && (encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        encOutBuf.position(encInfo.offset)
                        encOutBuf.limit(encInfo.offset + encInfo.size)
                        val data = ByteArray(encInfo.size)
                        encOutBuf.get(data)
                        val copyInfo = MediaCodec.BufferInfo().apply {
                            set(0, data.size, encInfo.presentationTimeUs, encInfo.flags)
                        }
                        aacSamples.add(data to copyInfo)
                    }
                    val isEos = (encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    encoder.releaseOutputBuffer(encOutIdx, false)
                    if (isEos) {
                        encoderDone = true
                        break
                    }
                }
            }
        }

        if (actualEncoderFormat == null || aacSamples.isEmpty()) {
            videoFile.copyTo(outputFile, overwrite = true)
            return outputFile
        }

        if (outputFile.exists()) outputFile.delete()
        val mediaMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer = mediaMuxer
        val outVideoTrack = mediaMuxer.addTrack(videoFormat)
        val outAudioTrack = mediaMuxer.addTrack(actualEncoderFormat!!)
        mediaMuxer.start()
        muxerStarted = true

        // Write video samples
        val vBuf = ByteBuffer.allocate(2 * 1024 * 1024)
        val vInfo = MediaCodec.BufferInfo()
        while (true) {
            val sz = videoExtractor.readSampleData(vBuf, 0)
            if (sz < 0) break
            vInfo.offset = 0
            vInfo.size = sz
            vInfo.presentationTimeUs = videoExtractor.sampleTime.coerceAtLeast(0L)
            vInfo.flags = if ((videoExtractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                MediaCodec.BUFFER_FLAG_KEY_FRAME
            } else 0
            vBuf.position(0)
            vBuf.limit(sz)
            mediaMuxer.writeSampleData(outVideoTrack, vBuf, vInfo)
            videoExtractor.advance()
        }

        // Write AAC audio samples
        for ((bytes, info) in aacSamples) {
            val aBuf = ByteBuffer.wrap(bytes)
            mediaMuxer.writeSampleData(outAudioTrack, aBuf, info)
        }

        outputFile
    } catch (e: Throwable) {
        Log.e("VideoMuxer", "Audio muxing fallback to video-only: ${e.message}", e)
        try {
            videoFile.copyTo(outputFile, overwrite = true)
        } catch (_: Throwable) {}
        outputFile
    } finally {
        try { videoExtractor.release() } catch (_: Throwable) {}
        try { audioExtractor.release() } catch (_: Throwable) {}
        try { audioDecoder?.stop(); audioDecoder?.release() } catch (_: Throwable) {}
        try { audioEncoder?.stop(); audioEncoder?.release() } catch (_: Throwable) {}
        try { if (muxerStarted) muxer?.stop() } catch (_: Throwable) {}
        try { muxer?.release() } catch (_: Throwable) {}
    }
}

fun saveVideoToGallery(context: Context, videoFile: File, locationName: String): Uri? {
    return try {
        val resolver = context.contentResolver
        val sanitized = locationName.replace(Regex("[^a-zA-Z0-9]"), "_").take(30)
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "WorldCam_Video_${sanitized}_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/WorldCamAI")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val videoUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
        if (videoUri != null) {
            resolver.openOutputStream(videoUri)?.use { out ->
                FileInputStream(videoFile).use { input ->
                    input.copyTo(out)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(videoUri, contentValues, null, null)
            }
        }
        videoUri
    } catch (e: Throwable) {
        Log.e("VideoGallerySave", "Failed saving video to gallery: ${e.message}", e)
        null
    }
}

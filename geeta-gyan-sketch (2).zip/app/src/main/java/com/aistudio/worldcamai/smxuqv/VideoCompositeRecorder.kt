package com.aistudio.worldcamai.smxuqv

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

fun drawCompositeVideoFrame(
    canvas: Canvas,
    width: Int,
    height: Int,
    bgBitmap: Bitmap?,
    personBitmap: Bitmap?,
    userScale: Float,
    userXOffset: Float,
    userYOffset: Float,
    userRotation: Float,
    previewWidthPx: Float,
    previewHeightPx: Float,
    filterMatrixValues: FloatArray?,
    showWatermark: Boolean = true
) {
    val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        if (filterMatrixValues != null) {
            colorFilter = ColorMatrixColorFilter(filterMatrixValues)
        }
    }

    if (bgBitmap != null && !bgBitmap.isRecycled && bgBitmap.width > 0 && bgBitmap.height > 0) {
        val bgAspect = bgBitmap.width.toFloat() / bgBitmap.height.toFloat()
        val outAspect = width.toFloat() / height.toFloat()
        val drawW: Float
        val drawH: Float
        if (bgAspect > outAspect) {
            drawH = height.toFloat()
            drawW = drawH * bgAspect
        } else {
            drawW = width.toFloat()
            drawH = drawW / bgAspect
        }
        val drawX = (width - drawW) / 2f
        val drawY = (height - drawH) / 2f
        canvas.drawBitmap(bgBitmap, null, RectF(drawX, drawY, drawX + drawW, drawY + drawH), bgPaint)
    } else {
        val fallbackPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                Color.parseColor("#0F172A"), Color.parseColor("#1E1B4B"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fallbackPaint)
    }

    if (personBitmap != null && !personBitmap.isRecycled && personBitmap.width > 0 && personBitmap.height > 0) {
        val pW = previewWidthPx.coerceAtLeast(300f)
        val pH = previewHeightPx.coerceAtLeast(300f)
        val scaleToExport = width.toFloat() / pW

        val targetUserHeight = height.toFloat() * ((210f * userScale) / 380f)
        val userAspect = personBitmap.width.toFloat() / personBitmap.height.toFloat().coerceAtLeast(0.01f)
        val targetUserWidth = targetUserHeight * userAspect

        val centerX = (pW / 2f + userXOffset) * scaleToExport
        val bottomY = height.toFloat() + (userYOffset * (height.toFloat() / pH))
        val top = bottomY - targetUserHeight
        val left = centerX - (targetUserWidth / 2f)

        val personPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG).apply {
            if (filterMatrixValues != null) {
                colorFilter = ColorMatrixColorFilter(filterMatrixValues)
            }
        }
        val destRect = RectF(left, top, left + targetUserWidth, bottomY)
        canvas.save()
        if (userRotation != 0f) {
            canvas.rotate(userRotation, centerX, top + targetUserHeight / 2f)
        }
        canvas.drawBitmap(personBitmap, null, destRect, personPaint)
        canvas.restore()
    }

    if (showWatermark) {
        val wmPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = (width * 0.044f).coerceAtLeast(28f)
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            alpha = 215
            setShadowLayer(6f, 0f, 2f, Color.argb(180, 0, 0, 0))
        }
        canvas.drawText("WorldCam AI", width / 2f, height - (height * 0.032f), wmPaint)
    }
}

class CompositeVideoSurfaceRecorder(
    private val width: Int = 720,
    private val height: Int = 960,
    private val outputFile: File
) {
    private val executor = Executors.newSingleThreadExecutor()
    private val isRecording = AtomicBoolean(false)
    private val pendingFrames = AtomicInteger(0)

    private var encoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var muxer: MediaMuxer? = null
    private var videoTrackIndex = -1
    private var muxerStarted = false
    private var firstPtsUs = -1L
    private var frameCount = 0

    fun start(): Boolean {
        return try {
            executor.submit(Callable {
                val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                    setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                    setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
                    setInteger(MediaFormat.KEY_FRAME_RATE, 30)
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                }
                val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
                codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val surface = codec.createInputSurface()
                codec.start()

                if (outputFile.exists()) outputFile.delete()
                val mediaMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

                encoder = codec
                inputSurface = surface
                muxer = mediaMuxer
                videoTrackIndex = -1
                muxerStarted = false
                firstPtsUs = -1L
                frameCount = 0
                isRecording.set(true)
                true
            }).get()
        } catch (e: Throwable) {
            Log.e("VideoRecorder", "Failed to start recorder: ${e.message}", e)
            cleanup()
            false
        }
    }

    fun submitFrame(
        bgBitmap: Bitmap?,
        personBitmap: Bitmap?,
        userScale: Float,
        userXOffset: Float,
        userYOffset: Float,
        userRotation: Float,
        previewWidthPx: Float,
        previewHeightPx: Float,
        filterMatrixValues: FloatArray?,
        showWatermark: Boolean
    ) {
        if (!isRecording.get()) return
        if (pendingFrames.get() >= 2) return // Keep latency crisp if encoder is busy

        val bgSnap = bgBitmap?.takeIf { !it.isRecycled }
        val personSnap = personBitmap?.takeIf { !it.isRecycled }

        pendingFrames.incrementAndGet()
        executor.execute {
            try {
                if (!isRecording.get()) return@execute
                val surface = inputSurface ?: return@execute
                val canvas = surface.lockCanvas(null)
                try {
                    drawCompositeVideoFrame(
                        canvas = canvas,
                        width = width,
                        height = height,
                        bgBitmap = bgSnap,
                        personBitmap = personSnap,
                        userScale = userScale,
                        userXOffset = userXOffset,
                        userYOffset = userYOffset,
                        userRotation = userRotation,
                        previewWidthPx = previewWidthPx,
                        previewHeightPx = previewHeightPx,
                        filterMatrixValues = filterMatrixValues,
                        showWatermark = showWatermark
                    )
                } finally {
                    surface.unlockCanvasAndPost(canvas)
                }
                frameCount++
                drainEncoder(endOfStream = false)
            } catch (t: Throwable) {
                Log.w("VideoRecorder", "Frame encode error: ${t.message}")
            } finally {
                pendingFrames.decrementAndGet()
            }
        }
    }

    fun stopAndFinalize(): File? {
        if (!isRecording.compareAndSet(true, false)) {
            return null
        }
        return try {
            executor.submit(Callable {
                try {
                    encoder?.signalEndOfInputStream()
                    drainEncoder(endOfStream = true)
                } catch (e: Throwable) {
                    Log.e("VideoRecorder", "Error draining EOS: ${e.message}", e)
                }
                val valid = muxerStarted && frameCount > 0 && outputFile.exists() && outputFile.length() > 0L
                cleanup()
                if (valid) outputFile else null
            }).get()
        } catch (e: Throwable) {
            Log.e("VideoRecorder", "Stop failed: ${e.message}", e)
            cleanup()
            null
        } finally {
            try {
                executor.shutdown()
            } catch (_: Throwable) {}
        }
    }

    private fun drainEncoder(endOfStream: Boolean) {
        val codec = encoder ?: return
        val mediaMuxer = muxer ?: return
        val bufferInfo = MediaCodec.BufferInfo()
        val timeoutUs = if (endOfStream) 10_000L else 0L
        var emptyTries = 0

        while (true) {
            val outIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            when {
                outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream) break
                    emptyTries++
                    if (emptyTries > 25) break
                }
                outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (!muxerStarted) {
                        val newFormat = codec.outputFormat
                        videoTrackIndex = mediaMuxer.addTrack(newFormat)
                        mediaMuxer.start()
                        muxerStarted = true
                    }
                }
                outIndex >= 0 -> {
                    val encodedData = codec.getOutputBuffer(outIndex)
                    if (encodedData != null) {
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }
                        if (bufferInfo.size > 0 && muxerStarted && videoTrackIndex >= 0) {
                            if (firstPtsUs < 0L) {
                                firstPtsUs = bufferInfo.presentationTimeUs
                            }
                            bufferInfo.presentationTimeUs = (bufferInfo.presentationTimeUs - firstPtsUs).coerceAtLeast(0L)
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            mediaMuxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                        }
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            }
        }
    }

    private fun cleanup() {
        isRecording.set(false)
        try {
            encoder?.stop()
        } catch (_: Throwable) {}
        try {
            encoder?.release()
        } catch (_: Throwable) {}
        encoder = null

        try {
            inputSurface?.release()
        } catch (_: Throwable) {}
        inputSurface = null

        try {
            if (muxerStarted) {
                muxer?.stop()
            }
        } catch (_: Throwable) {}
        try {
            muxer?.release()
        } catch (_: Throwable) {}
        muxer = null
    }
}

fun muxSongAudioWithVideo(
    context: Context,
    videoFile: File,
    audioUri: Uri?,
    songStartTimeMs: Long,
    outputFile: File
): File {
    if (audioUri == null) {
        videoFile.copyTo(outputFile, overwrite = true)
        return outputFile
    }

    val videoExtractor = MediaExtractor()
    val audioExtractor = MediaExtractor()
    var audioDecoder: MediaCodec? = null
    var audioEncoder: MediaCodec? = null
    var muxer: MediaMuxer? = null
    var muxerStarted = false

    return try {
        videoExtractor.setDataSource(videoFile.absolutePath)
        var srcVideoTrack = -1
        var videoFormat: MediaFormat? = null
        for (i in 0 until videoExtractor.trackCount) {
            val fmt = videoExtractor.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("video/")) {
                srcVideoTrack = i
                videoFormat = fmt
                break
            }
        }
        if (srcVideoTrack < 0 || videoFormat == null) {
            videoFile.copyTo(outputFile, overwrite = true)
            return outputFile
        }
        videoExtractor.selectTrack(srcVideoTrack)

        // Determine actual recorded video duration
        var maxVideoPtsUs = 15_000_000L
        if (videoFormat.containsKey(MediaFormat.KEY_DURATION)) {
            maxVideoPtsUs = videoFormat.getLong(MediaFormat.KEY_DURATION).coerceIn(500_000L, 15_500_000L)
        } else {
            val scanBuf = ByteBuffer.allocate(256 * 1024)
            var lastPts = 0L
            while (true) {
                val sz = videoExtractor.readSampleData(scanBuf, 0)
                if (sz < 0) break
                if (videoExtractor.sampleTime > lastPts) lastPts = videoExtractor.sampleTime
                videoExtractor.advance()
            }
            if (lastPts > 0L) maxVideoPtsUs = lastPts + 33_333L
            videoExtractor.seekTo(0L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        }

        // Open audio extractor
        audioExtractor.setDataSource(context, audioUri, null)
        var srcAudioTrack = -1
        var srcAudioFormat: MediaFormat? = null
        for (i in 0 until audioExtractor.trackCount) {
            val fmt = audioExtractor.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                srcAudioTrack = i
                srcAudioFormat = fmt
                break
            }
        }
        if (srcAudioTrack < 0 || srcAudioFormat == null) {
            videoFile.copyTo(outputFile, overwrite = true)
            return outputFile
        }
        audioExtractor.selectTrack(srcAudioTrack)
        val seekUs = (songStartTimeMs * 1000L).coerceAtLeast(0L)
        audioExtractor.seekTo(seekUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

        val srcMime = srcAudioFormat.getString(MediaFormat.KEY_MIME) ?: "audio/mpeg"
        var sampleRate = if (srcAudioFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
            srcAudioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        } else 44100
        var channelCount = if (srcAudioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
            srcAudioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        } else 2

        val decoder = MediaCodec.createDecoderByType(srcMime)
        decoder.configure(srcAudioFormat, null, null, 0)
        decoder.start()
        audioDecoder = decoder

        val encFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channelCount).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        encoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()
        audioEncoder = encoder

        // Transcode exact 15s (maxVideoPtsUs) audio clip to AAC frames in memory first
        val aacSamples = ArrayList<Pair<ByteArray, MediaCodec.BufferInfo>>()
        var actualEncoderFormat: MediaFormat? = null

        val decInfo = MediaCodec.BufferInfo()
        val encInfo = MediaCodec.BufferInfo()
        var extractorDone = false
        var decoderDone = false
        var encoderDone = false
        var firstDecodedPtsUs = -1L
        var encodedPtsUs = 0L

        while (!encoderDone) {
            if (!extractorDone) {
                val inIdx = decoder.dequeueInputBuffer(5_000L)
                if (inIdx >= 0) {
                    val inBuf = decoder.getInputBuffer(inIdx)
                    if (inBuf != null) {
                        val sampleSize = audioExtractor.readSampleData(inBuf, 0)
                        val samplePts = audioExtractor.sampleTime
                        if (sampleSize < 0 || (firstDecodedPtsUs >= 0L && (samplePts - firstDecodedPtsUs) > maxVideoPtsUs + 200_000L)) {
                            decoder.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            extractorDone = true
                        } else {
                            if (firstDecodedPtsUs < 0L) firstDecodedPtsUs = samplePts
                            decoder.queueInputBuffer(inIdx, 0, sampleSize, samplePts, 0)
                            audioExtractor.advance()
                        }
                    }
                }
            }

            if (!decoderDone) {
                val decOutIdx = decoder.dequeueOutputBuffer(decInfo, 5_000L)
                if (decOutIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFmt = decoder.outputFormat
                    if (newFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        sampleRate = newFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (newFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channelCount = newFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                } else if (decOutIdx >= 0) {
                    val decOutBuf = decoder.getOutputBuffer(decOutIdx)
                    val isEos = (decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    if (decOutBuf != null && decInfo.size > 0 && encodedPtsUs < maxVideoPtsUs) {
                        decOutBuf.position(decInfo.offset)
                        decOutBuf.limit(decInfo.offset + decInfo.size)
                        val pcmBytes = ByteArray(decInfo.size)
                        decOutBuf.get(pcmBytes)

                        var offset = 0
                        while (offset < pcmBytes.size && encodedPtsUs < maxVideoPtsUs) {
                            val encInIdx = encoder.dequeueInputBuffer(10_000L)
                            if (encInIdx >= 0) {
                                val encInBuf = encoder.getInputBuffer(encInIdx)
                                if (encInBuf != null) {
                                    encInBuf.clear()
                                    val chunk = minOf(encInBuf.remaining(), pcmBytes.size - offset)
                                    encInBuf.put(pcmBytes, offset, chunk)
                                    val bytesPerSec = (sampleRate * channelCount * 2).coerceAtLeast(1)
                                    val chunkDurationUs = (chunk.toLong() * 1_000_000L) / bytesPerSec
                                    encoder.queueInputBuffer(encInIdx, 0, chunk, encodedPtsUs, 0)
                                    encodedPtsUs += chunkDurationUs
                                    offset += chunk
                                }
                            }
                        }
                    }
                    decoder.releaseOutputBuffer(decOutIdx, false)
                    if (isEos || encodedPtsUs >= maxVideoPtsUs) {
                        val encInIdx = encoder.dequeueInputBuffer(10_000L)
                        if (encInIdx >= 0) {
                            encoder.queueInputBuffer(encInIdx, 0, 0, encodedPtsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        }
                        decoderDone = true
                    }
                }
            }

            while (true) {
                val encOutIdx = encoder.dequeueOutputBuffer(encInfo, 2_000L)
                if (encOutIdx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    break
                } else if (encOutIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    actualEncoderFormat = encoder.outputFormat
                } else if (encOutIdx >= 0) {
                    val encOutBuf = encoder.getOutputBuffer(encOutIdx)
                    if (encOutBuf != null && encInfo.size > 0 && (encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        encOutBuf.position(encInfo.offset)
                        encOutBuf.limit(encInfo.offset + encInfo.size)
                        val data = ByteArray(encInfo.size)
                        encOutBuf.get(data)
                        val copyInfo = MediaCodec.BufferInfo().apply {
                            set(0, data.size, encInfo.presentationTimeUs, encInfo.flags)
                        }
                        aacSamples.add(data to copyInfo)
                    }
                    val isEos = (encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    encoder.releaseOutputBuffer(encOutIdx, false)
                    if (isEos) {
                        encoderDone = true
                        break
                    }
                }
            }
        }

        if (actualEncoderFormat == null || aacSamples.isEmpty()) {
            videoFile.copyTo(outputFile, overwrite = true)
            return outputFile
        }

        if (outputFile.exists()) outputFile.delete()
        val mediaMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer = mediaMuxer
        val outVideoTrack = mediaMuxer.addTrack(videoFormat)
        val outAudioTrack = mediaMuxer.addTrack(actualEncoderFormat!!)
        mediaMuxer.start()
        muxerStarted = true

        // Write video samples
        val vBuf = ByteBuffer.allocate(1024 * 1024)
        val vInfo = MediaCodec.BufferInfo()
        while (true) {
            val sz = videoExtractor.readSampleData(vBuf, 0)
            if (sz < 0) break
            vInfo.offset = 0
            vInfo.size = sz
            vInfo.presentationTimeUs = videoExtractor.sampleTime.coerceAtLeast(0L)
            vInfo.flags = if ((videoExtractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                MediaCodec.BUFFER_FLAG_KEY_FRAME
            } else 0
            vBuf.position(0)
            vBuf.limit(sz)
            mediaMuxer.writeSampleData(outVideoTrack, vBuf, vInfo)
            videoExtractor.advance()
        }

        // Write AAC audio samples
        for ((bytes, info) in aacSamples) {
            val aBuf = ByteBuffer.wrap(bytes)
            mediaMuxer.writeSampleData(outAudioTrack, aBuf, info)
        }

        outputFile
    } catch (e: Throwable) {
        Log.e("VideoMuxer", "Audio muxing fallback to video-only: ${e.message}", e)
        try {
            videoFile.copyTo(outputFile, overwrite = true)
        } catch (_: Throwable) {}
        outputFile
    } finally {
        try { videoExtractor.release() } catch (_: Throwable) {}
        try { audioExtractor.release() } catch (_: Throwable) {}
        try { audioDecoder?.stop(); audioDecoder?.release() } catch (_: Throwable) {}
        try { audioEncoder?.stop(); audioEncoder?.release() } catch (_: Throwable) {}
        try { if (muxerStarted) muxer?.stop() } catch (_: Throwable) {}
        try { muxer?.release() } catch (_: Throwable) {}
    }
}

fun saveVideoToGallery(context: Context, videoFile: File, locationName: String): Uri? {
    return try {
        val resolver = context.contentResolver
        val sanitized = locationName.replace(Regex("[^a-zA-Z0-9]"), "_").take(30)
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "WorldCam_Video_${sanitized}_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/WorldCamAI")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val videoUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
        if (videoUri != null) {
            resolver.openOutputStream(videoUri)?.use { out ->
                FileInputStream(videoFile).use { input ->
                    input.copyTo(out)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(videoUri, contentValues, null, null)
            }
        }
        videoUri
    } catch (e: Throwable) {
        Log.e("VideoGallerySave", "Failed saving video to gallery: ${e.message}", e)
        null
    }
}

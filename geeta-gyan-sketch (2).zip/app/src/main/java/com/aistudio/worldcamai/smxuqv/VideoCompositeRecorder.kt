package com.aistudio.worldcamai.smxuqv

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PaintFlagsDrawFilter
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.util.WeakHashMap
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

data class VideoLocationLightingProfile(
    val avgBrightness: Float,
    val warmth: Float,
    val sunDirectionX: Float,
    val shadowTintColor: Int,
    val personColorMatrixValues: FloatArray
)

private val videoLightingCache = WeakHashMap<Bitmap, VideoLocationLightingProfile>()
private val videoDepthBlurCache = WeakHashMap<Bitmap, Bitmap>()
private val videoFootAnchorCache = WeakHashMap<Bitmap, SubjectFootAnchor>()

@Volatile
private var sharedCameraGrainBitmap: Bitmap? = null

private val defaultVideoLightingProfile = VideoLocationLightingProfile(
    avgBrightness = 0.55f,
    warmth = 0.0f,
    sunDirectionX = 0.35f,
    shadowTintColor = Color.rgb(14, 18, 26),
    personColorMatrixValues = ColorMatrix().array
)

fun analyzeVideoBackgroundLighting(bgBitmap: Bitmap?): VideoLocationLightingProfile {
    if (bgBitmap == null || bgBitmap.isRecycled || bgBitmap.width <= 0 || bgBitmap.height <= 0) {
        return defaultVideoLightingProfile
    }
    synchronized(videoLightingCache) {
        videoLightingCache[bgBitmap]?.let { return it }
    }

    return try {
        val w = bgBitmap.width
        val h = bgBitmap.height
        val grid = 20
        var sumR = 0.0
        var sumG = 0.0
        var sumB = 0.0
        var sumLuma = 0.0
        var sumLumaSq = 0.0
        var leftLuma = 0.0
        var rightLuma = 0.0
        var leftCount = 0
        var rightCount = 0

        // Separate upper sky vs lower-half ground/streetlamp ambient sampling
        var upperR = 0.0
        var upperG = 0.0
        var upperB = 0.0
        var upperLuma = 0.0
        var upperCount = 0

        var lowerR = 0.0
        var lowerG = 0.0
        var lowerB = 0.0
        var lowerLuma = 0.0
        var lowerCount = 0
        var count = 0

        for (gy in 0 until grid) {
            val py = ((gy + 0.5f) * h / grid).toInt().coerceIn(0, h - 1)
            val isUpper = gy < (grid * 0.42f).toInt()
            val isLower = gy >= grid / 2
            for (gx in 0 until grid) {
                val px = ((gx + 0.5f) * w / grid).toInt().coerceIn(0, w - 1)
                val pixel = bgBitmap.getPixel(px, py)
                val r = (pixel ushr 16) and 0xFF
                val g = (pixel ushr 8) and 0xFF
                val b = pixel and 0xFF
                val luma = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
                sumR += r
                sumG += g
                sumB += b
                sumLuma += luma
                sumLumaSq += luma * luma
                if (gx < grid / 2) {
                    leftLuma += luma
                    leftCount++
                } else {
                    rightLuma += luma
                    rightCount++
                }
                if (isUpper) {
                    upperR += r
                    upperG += g
                    upperB += b
                    upperLuma += luma
                    upperCount++
                }
                if (isLower) {
                    lowerR += r
                    lowerG += g
                    lowerB += b
                    lowerLuma += luma
                    lowerCount++
                }
                count++
            }
        }

        val c = count.coerceAtLeast(1)
        val avgR = (sumR / c).toFloat()
        val avgG = (sumG / c).toFloat()
        val avgB = (sumB / c).toFloat()
        val avgLuma = (sumLuma / c).toFloat().coerceIn(0.05f, 0.95f)
        val variance = ((sumLumaSq / c) - (avgLuma * avgLuma)).toFloat().coerceAtLeast(0f)
        val stdDev = sqrt(variance)

        val uc = upperCount.coerceAtLeast(1)
        val upperAvgR = (upperR / uc).toFloat()
        val upperAvgG = (upperG / uc).toFloat()
        val upperAvgB = (upperB / uc).toFloat()
        val upperAvgLuma = (upperLuma / uc).toFloat().coerceIn(0.05f, 0.95f)
        val upperMax = maxOf(upperAvgR, maxOf(upperAvgG, upperAvgB)).coerceAtLeast(1f)
        val upperMin = minOf(upperAvgR, minOf(upperAvgG, upperAvgB))
        val upperSkySat = (upperMax - upperMin) / upperMax

        val lc = lowerCount.coerceAtLeast(1)
        val lowerAvgR = (lowerR / lc).toFloat()
        val lowerAvgG = (lowerG / lc).toFloat()
        val lowerAvgB = (lowerB / lc).toFloat()
        val lowerAvgLuma = (lowerLuma / lc).toFloat().coerceIn(0.05f, 0.95f)

        val effectiveStandingLum = (lowerAvgLuma * 0.68f + avgLuma * 0.32f).coerceIn(0.05f, 0.95f)

        val lLeft = if (leftCount > 0) (leftLuma / leftCount).toFloat() else avgLuma
        val lRight = if (rightCount > 0) (rightLuma / rightCount).toFloat() else avgLuma
        val rawDir = ((lLeft - lRight) * 3.8f).coerceIn(-0.85f, 0.85f)
        val sunDirectionX = if (abs(rawDir) < 0.22f) {
            if (rawDir >= 0f) 0.30f else -0.30f
        } else rawDir

        val overallWarmth = ((avgR - avgB) / 255f).coerceIn(-0.55f, 0.55f)
        val lowerWarmGlow = ((lowerAvgR - lowerAvgB) / 255f).coerceIn(-0.55f, 0.55f)
        val warmth = (lowerWarmGlow * 0.65f + overallWarmth * 0.35f).coerceIn(-0.55f, 0.55f)

        val isCoolDuskSky = (upperAvgB >= upperAvgR * 1.03f && upperAvgLuma < 0.64f)
        val isSunsetScene = (warmth > 0.10f || lowerWarmGlow > 0.13f) && lowerAvgLuma < 0.64f
        val isEveningScene = (lowerAvgLuma < 0.40f && upperAvgLuma < 0.68f) ||
            (isCoolDuskSky && lowerAvgLuma < 0.50f)
        val isOvercastScene = !isEveningScene && !isSunsetScene && upperSkySat < 0.14f && upperAvgLuma in 0.38f..0.78f && stdDev < 0.24f

        // Blend lower-half ambient chromaticity (68%) + scene-wide balance (32%)
        val ambientR = lowerAvgR * 0.68f + avgR * 0.32f
        val ambientG = lowerAvgG * 0.68f + avgG * 0.32f
        val ambientB = lowerAvgB * 0.68f + avgB * 0.32f
        val ambientMean = ((ambientR + ambientG + ambientB) / 3f).coerceAtLeast(18f)
        val normR = (ambientR / ambientMean).coerceIn(0.72f, 1.34f)
        val normG = (ambientG / ambientMean).coerceIn(0.78f, 1.24f)
        val normB = (ambientB / ambientMean).coerceIn(0.70f, 1.36f)

        val tintStrength = when {
            isEveningScene || isSunsetScene -> 0.36f
            isOvercastScene -> 0.26f
            else -> 0.24f
        }
        val rTint = (1f + (normR - 1f) * tintStrength) * (if (isOvercastScene) 0.97f else 1f)
        val gTint = 1f + (normG - 1f) * tintStrength
        val bTint = (1f + (normB - 1f) * tintStrength) * (if (isOvercastScene) 1.04f else 1f)

        val exposureScale = when {
            effectiveStandingLum < 0.22f -> 0.64f + (effectiveStandingLum / 0.22f) * 0.10f
            effectiveStandingLum < 0.38f || isEveningScene ->
                (0.74f + ((effectiveStandingLum - 0.22f).coerceAtLeast(0f) / 0.20f) * 0.13f).coerceIn(0.72f, 0.88f)
            isSunsetScene -> 0.86f + ((effectiveStandingLum - 0.38f).coerceAtLeast(0f) / 0.24f) * 0.08f
            isOvercastScene -> 0.89f + ((effectiveStandingLum - 0.38f).coerceAtLeast(0f) / 0.35f) * 0.07f
            effectiveStandingLum > 0.70f -> 1.00f + ((effectiveStandingLum - 0.70f) / 0.25f) * 0.05f
            else -> 0.92f + ((effectiveStandingLum - 0.38f) / 0.32f) * 0.08f
        }.coerceIn(0.64f, 1.06f)

        val contrast = when {
            isOvercastScene -> (0.91f + stdDev * 0.25f).coerceIn(0.90f, 0.98f)
            isEveningScene -> (1.02f + stdDev * 0.35f).coerceIn(1.00f, 1.15f)
            else -> (0.96f + stdDev * 0.38f).coerceIn(0.95f, 1.12f)
        }
        val brightnessLift = when {
            effectiveStandingLum < 0.24f -> -22f
            effectiveStandingLum < 0.38f || isEveningScene -> -13f
            isSunsetScene -> -5f
            isOvercastScene -> 2f
            effectiveStandingLum > 0.74f -> 4f
            else -> 0f
        }

        // Dual-zone ambient wash: warm lower-half glow + subtle cool dusk/overcast sky fill
        val duskShadowBlue = if (isCoolDuskSky || isOvercastScene) 7f else 0f
        val duskShadowRed = if ((isCoolDuskSky || isOvercastScene) && lowerWarmGlow < 0.08f) -3f else 0f
        val washR = ((ambientR - 128f) * 0.11f) + (lowerWarmGlow * 12f) + duskShadowRed
        val washG = ((ambientG - 128f) * 0.10f) + (lowerWarmGlow * 4f)
        val washB = ((ambientB - 128f) * 0.10f) + duskShadowBlue - (lowerWarmGlow * 8f)

        val cm = ColorMatrix()
        val sat = when {
            effectiveStandingLum < 0.22f -> 0.84f
            isEveningScene -> 0.91f
            isOvercastScene -> 0.92f
            isSunsetScene -> 1.05f
            else -> 0.98f
        }
        cm.setSaturation(sat)

        val contrastShift = 128f * (1f - contrast)
        val relightMatrix = ColorMatrix(
            floatArrayOf(
                rTint * exposureScale * contrast, 0f, 0f, 0f, contrastShift + brightnessLift + washR,
                0f, gTint * exposureScale * contrast, 0f, 0f, contrastShift + brightnessLift + washG,
                0f, 0f, bTint * exposureScale * contrast, 0f, contrastShift + brightnessLift + washB,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(relightMatrix)

        val shadowR = (lowerAvgR * 0.14f).toInt().coerceIn(8, 32)
        val shadowG = (lowerAvgG * 0.14f).toInt().coerceIn(8, 32)
        val shadowB = (lowerAvgB * 0.16f).toInt().coerceIn(10, 40)

        val profile = VideoLocationLightingProfile(
            avgBrightness = effectiveStandingLum,
            warmth = warmth,
            sunDirectionX = sunDirectionX,
            shadowTintColor = Color.rgb(shadowR, shadowG, shadowB),
            personColorMatrixValues = cm.array.copyOf()
        )
        synchronized(videoLightingCache) {
            videoLightingCache[bgBitmap] = profile
        }
        profile
    } catch (_: Throwable) {
        defaultVideoLightingProfile
    }
}

fun composePersonColorMatrix(
    lighting: VideoLocationLightingProfile,
    filterMatrixValues: FloatArray?
): FloatArray {
    val cm = ColorMatrix(lighting.personColorMatrixValues)
    if (filterMatrixValues != null && filterMatrixValues.size >= 20) {
        cm.postConcat(ColorMatrix(filterMatrixValues))
    }
    return cm.array
}

fun getOrCreateVideoDepthBlurBitmap(bgBitmap: Bitmap?): Bitmap? {
    // Preserve full native camera resolution without downscaling or artificial box blur
    if (bgBitmap == null || bgBitmap.isRecycled || bgBitmap.width <= 0 || bgBitmap.height <= 0) {
        return bgBitmap
    }
    return bgBitmap
}

private data class CachedCleanedVideoPerson(
    val bgIdentity: Int,
    val result: Bitmap
)

private val videoBottomFeatherCache = WeakHashMap<Bitmap, CachedCleanedVideoPerson>()

fun applyUniversalBottomEdgeFeathering(
    src: Bitmap,
    bgBitmap: Bitmap? = null,
    personRectOnCanvas: RectF? = null,
    bgRectOnCanvas: RectF? = null
): Bitmap {
    if (src.isRecycled || src.width <= 8 || src.height <= 8) return src
    val bgHash = bgBitmap?.let { System.identityHashCode(it) } ?: 0
    synchronized(videoBottomFeatherCache) {
        videoBottomFeatherCache[src]?.let { cached ->
            if (!cached.result.isRecycled && (cached.bgIdentity == bgHash || bgHash == 0)) {
                return cached.result
            }
        }
    }
    return try {
        val w = src.width
        val h = src.height
        val total = w * h
        val pixels = IntArray(total)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        val rawAlpha = IntArray(total)
        for (i in 0 until total) {
            val a = (pixels[i] ushr 24) and 0xFF
            rawAlpha[i] = if (a < 22) 0 else a
        }

        // 1. Stray white dot & isolated speckle purge (3x3 + 5x5)
        val pass0Alpha = IntArray(total)
        for (y in 0 until h) {
            val rowOff = y * w
            for (x in 0 until w) {
                val idx = rowOff + x
                val a = rawAlpha[idx]
                if (a == 0) {
                    pass0Alpha[idx] = 0
                    continue
                }
                var hits3 = 0
                for (dy in -1..1) {
                    val ny = (y + dy).coerceIn(0, h - 1)
                    val nRow = ny * w
                    for (dx in -1..1) {
                        val nx = (x + dx).coerceIn(0, w - 1)
                        if (rawAlpha[nRow + nx] > 28) hits3++
                    }
                }
                pass0Alpha[idx] = if (hits3 <= 2) 0 else a
            }
        }

        val cleanedAlpha = IntArray(total)
        for (y in 0 until h) {
            val rowOff = y * w
            for (x in 0 until w) {
                val idx = rowOff + x
                val a = pass0Alpha[idx]
                if (a == 0) {
                    cleanedAlpha[idx] = 0
                    continue
                }
                var hits5 = 0
                for (dy in -2..2) {
                    val ny = (y + dy).coerceIn(0, h - 1)
                    val nRow = ny * w
                    for (dx in -2..2) {
                        val nx = (x + dx).coerceIn(0, w - 1)
                        if (pass0Alpha[nRow + nx] > 28) hits5++
                    }
                }
                cleanedAlpha[idx] = if (hits5 <= 6) 0 else a
            }
        }

        // 2. Sub-pixel Euclidean distance to transparent edge
        val distToEdge = FloatArray(total) { 99f }
        for (y in 0 until h) {
            val rowOff = y * w
            for (x in 0 until w) {
                val idx = rowOff + x
                if (cleanedAlpha[idx] == 0) {
                    distToEdge[idx] = 0f
                } else {
                    var minDistSq = 99
                    for (dy in -4..4) {
                        val ny = y + dy
                        if (ny !in 0 until h) continue
                        val nRow = ny * w
                        for (dx in -4..4) {
                            val nx = x + dx
                            if (nx !in 0 until w) continue
                            if (cleanedAlpha[nRow + nx] == 0) {
                                val dSq = dx * dx + dy * dy
                                if (dSq < minDistSq) minDistSq = dSq
                            }
                        }
                    }
                    distToEdge[idx] = if (minDistSq >= 99) 99f else sqrt(minDistSq.toFloat())
                }
            }
        }

        // 3. Clean 1.5px inward alpha trim + 1.5px smooth anti-aliased edge feathering (never cropping toes/shoes)
        val isFullBody = isFullBodyStanding(src)
        val featherZone = if (isFullBody) 0 else 2
        val startY = h - featherZone
        val erodedAlpha = IntArray(total)

        for (y in 0 until h) {
            val rowOff = y * w
            val bottomFade = if (featherZone > 0 && y >= startY) {
                val progress = (y - startY).toFloat() / featherZone.toFloat()
                (1f - (progress * progress * (3f - 2f * progress))).coerceIn(0f, 1f)
            } else 1f

            for (x in 0 until w) {
                val idx = rowOff + x
                val origA = cleanedAlpha[idx]
                if (origA == 0) {
                    erodedAlpha[idx] = 0
                    continue
                }
                val d = distToEdge[idx]
                val baseA = when {
                    d <= 1.5f -> 0
                    d <= 3.0f -> {
                        val t = ((d - 1.5f) / 1.5f).coerceIn(0f, 1f)
                        val smoothT = t * t * (3f - 2f * t)
                        val solidBase = if (origA >= 145) 255 else origA
                        (solidBase * smoothT).toInt().coerceIn(0, 255)
                    }
                    else -> if (origA >= 145) 255 else origA
                }
                erodedAlpha[idx] = (baseA * bottomFade).toInt().coerceIn(0, 255)
            }
        }

        // 4. Inner clothing/skin color pull to boundary + subtle 2px ambient edge light-wrap
        val validBg = bgBitmap != null && !bgBitmap.isRecycled && bgBitmap.width > 0 && bgBitmap.height > 0 &&
            personRectOnCanvas != null && bgRectOnCanvas != null &&
            bgRectOnCanvas.width() > 1f && bgRectOnCanvas.height() > 1f
        val bgW = bgBitmap?.width ?: 0
        val bgH = bgBitmap?.height ?: 0
        val outPixels = IntArray(total)

        for (y in 0 until h) {
            val rowOff = y * w
            val bgY = if (validBg) {
                val canvasY = personRectOnCanvas!!.top + (y.toFloat() / h.toFloat()) * personRectOnCanvas.height()
                (((canvasY - bgRectOnCanvas!!.top) / bgRectOnCanvas.height()) * bgH).toInt().coerceIn(0, bgH - 1)
            } else 0

            for (x in 0 until w) {
                val idx = rowOff + x
                val finalA = erodedAlpha[idx]
                if (finalA <= 8) {
                    outPixels[idx] = 0x00000000
                    continue
                }

                val px = pixels[idx]
                var r = (px ushr 16) and 0xFF
                var g = (px ushr 8) and 0xFF
                var b = px and 0xFF
                val d = distToEdge[idx]

                if (d <= 4.0f) {
                    var fgR = 0
                    var fgG = 0
                    var fgB = 0
                    var fgCount = 0
                    for (dy in -4..4) {
                        val ny = (y + dy).coerceIn(0, h - 1)
                        val nRow = ny * w
                        for (dx in -4..4) {
                            val nx = (x + dx).coerceIn(0, w - 1)
                            val nIdx = nRow + nx
                            if (distToEdge[nIdx] >= 2.8f && erodedAlpha[nIdx] >= 220) {
                                val nc = pixels[nIdx]
                                fgR += (nc ushr 16) and 0xFF
                                fgG += (nc ushr 8) and 0xFF
                                fgB += nc and 0xFF
                                fgCount++
                            }
                        }
                    }

                    if (fgCount > 0) {
                        val avgFgR = fgR / fgCount
                        val avgFgG = fgG / fgCount
                        val avgFgB = fgB / fgCount

                        val isBrightWhiteFringe =
                            ((r > avgFgR + 18 && g > avgFgG + 18 && b > avgFgB + 18) && (r > 148 && g > 148 && b > 148)) ||
                                (d <= 2.5f && (abs(r - avgFgR) + abs(g - avgFgG) + abs(b - avgFgB)) > 58)

                        if (isBrightWhiteFringe) {
                            r = avgFgR
                            g = avgFgG
                            b = avgFgB
                        } else {
                            val defringe = when {
                                d <= 2.3f -> 0.85f
                                d <= 3.1f -> 0.48f
                                else -> 0.18f
                            }
                            r = ((r * (1f - defringe)) + (avgFgR * defringe)).toInt().coerceIn(0, 255)
                            g = ((g * (1f - defringe)) + (avgFgG * defringe)).toInt().coerceIn(0, 255)
                            b = ((b * (1f - defringe)) + (avgFgB * defringe)).toInt().coerceIn(0, 255)
                        }
                    }

                    // Subtle 2px ambient edge light-wrap along outer silhouette boundary (1.5px .. 3.5px)
                    if (validBg && d <= 3.5f) {
                        val canvasX = personRectOnCanvas!!.left + (x.toFloat() / w.toFloat()) * personRectOnCanvas.width()
                        val bgX = (((canvasX - bgRectOnCanvas!!.left) / bgRectOnCanvas.width()) * bgW).toInt().coerceIn(0, bgW - 1)
                        val bgPx = bgBitmap!!.getPixel(bgX, bgY)
                        val bgR = (bgPx ushr 16) and 0xFF
                        val bgG = (bgPx ushr 8) and 0xFF
                        val bgB = bgPx and 0xFF

                        val wrapAlpha = ((3.5f - d) / 2.0f).coerceIn(0f, 1f) * 0.22f
                        r = ((r * (1f - wrapAlpha)) + (bgR * wrapAlpha)).toInt().coerceIn(0, 255)
                        g = ((g * (1f - wrapAlpha)) + (bgG * wrapAlpha)).toInt().coerceIn(0, 255)
                        b = ((b * (1f - wrapAlpha)) + (bgB * wrapAlpha)).toInt().coerceIn(0, 255)
                    }
                }

                outPixels[idx] = (finalA shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        val feathered = Bitmap.createBitmap(outPixels, w, h, Bitmap.Config.ARGB_8888)
        synchronized(videoBottomFeatherCache) {
            videoBottomFeatherCache[src] = CachedCleanedVideoPerson(bgHash, feathered)
        }
        feathered
    } catch (_: Throwable) {
        src
    }
}

fun isFullBodyStanding(personBitmap: Bitmap): Boolean {
    return try {
        val w = personBitmap.width
        val h = personBitmap.height
        if (w <= 0 || h <= 0) return false
        val sampleY = h - 2
        var nonTransparent = 0
        for (x in (w * 0.30).toInt()..(w * 0.70).toInt()) {
            val px = personBitmap.getPixel(x.coerceIn(0, w - 1), sampleY)
            if (((px ushr 24) and 0xFF) > 35) nonTransparent++
        }
        nonTransparent >= (w * 0.12)
    } catch (_: Throwable) {
        true
    }
}

private fun getCachedVideoFootAnchor(personBitmap: Bitmap): SubjectFootAnchor {
    synchronized(videoFootAnchorCache) {
        videoFootAnchorCache[personBitmap]?.let { return it }
    }
    val anchor = detectSubjectFootAnchor(personBitmap)
    synchronized(videoFootAnchorCache) {
        videoFootAnchorCache[personBitmap] = anchor
    }
    return anchor
}

fun drawDynamicVideoPersonShadow(
    canvas: Canvas,
    personBitmap: Bitmap,
    lighting: VideoLocationLightingProfile,
    shadowDepth: Float,
    left: Float,
    top: Float,
    targetUserWidth: Float,
    targetUserHeight: Float,
    centerX: Float,
    bottomY: Float,
    userRotation: Float,
    bgBitmap: Bitmap? = null,
    bgRectOnCanvas: RectF? = null,
    canvasWidth: Float = canvas.width.toFloat().coerceAtLeast(1080f),
    canvasHeight: Float = canvas.height.toFloat().coerceAtLeast(1920f)
) {
    if (shadowDepth <= 0.04f) return
    val depth = shadowDepth.coerceIn(0.10f, 0.85f)

    val anchor = getCachedVideoFootAnchor(personBitmap)
    val cW = canvasWidth.coerceAtLeast(320f)
    val cH = canvasHeight.coerceAtLeast(320f)
    val resScale = (cW / 1080f).coerceIn(0.75f, 1.8f)

    // Real detected shoe/foot baseline & center (never misplaced even on cropped or offset subjects)
    val feetCenterX = left + (anchor.feetCenterRatioX * targetUserWidth)
    val feetY = (top + (anchor.lowestContactYRatio * targetUserHeight)).coerceAtMost(bottomY).coerceIn(8f, cH - 4f)

    // Prevent fake ledge bars on waist-up portraits touching frame bottom
    val isCroppedWaistAtBottom = anchor.stanceWidthRatio > 0.56f && feetY >= (cH - 6f)
    val torsoAttenuation = if (isCroppedWaistAtBottom) 0.30f else 1.0f

    // Brightness-adaptive shadow opacity
    val brightnessFactor = (0.58f + lighting.avgBrightness.coerceIn(0.06f, 0.95f) * 0.56f).coerceIn(0.50f, 1.08f)
    val baseColor = lighting.shadowTintColor and 0x00FFFFFF

    // Ground-aware ledge & drop-off detection beneath the shoes/feet
    var leftSupport = 1.0f
    var rightSupport = 1.0f
    var centerSupport = 1.0f
    if (bgBitmap != null && !bgBitmap.isRecycled && bgRectOnCanvas != null &&
        bgRectOnCanvas.width() > 1f && bgRectOnCanvas.height() > 1f
    ) {
        val bgW = bgBitmap.width
        val bgH = bgBitmap.height
        fun probeGroundSupport(cx: Float, cy: Float): Float {
            val bx = (((cx - bgRectOnCanvas.left) / bgRectOnCanvas.width()) * bgW).toInt()
            val byFoot = (((cy - bgRectOnCanvas.top) / bgRectOnCanvas.height()) * bgH).toInt()
            val byBelow = ((((cy + (targetUserHeight * 0.032f).coerceAtLeast(10f)) - bgRectOnCanvas.top) / bgRectOnCanvas.height()) * bgH).toInt()
            if (bx !in 0 until bgW || byFoot !in 0 until bgH || byBelow !in 0 until bgH) return 0.25f

            val pFoot = bgBitmap.getPixel(bx, byFoot)
            val pBelow = bgBitmap.getPixel(bx, byBelow)
            val lumFoot = (0.299f * ((pFoot ushr 16) and 0xFF) + 0.587f * ((pFoot ushr 8) and 0xFF) + 0.114f * (pFoot and 0xFF)) / 255f
            val rB = (pBelow ushr 16) and 0xFF
            val gB = (pBelow ushr 8) and 0xFF
            val bB = pBelow and 0xFF
            val lumBelow = (0.299f * rB + 0.587f * gB + 0.114f * bB) / 255f

            val isSkyVoidBelow = (bB > rB * 1.15f && lumBelow > 0.58f && lumFoot < 0.48f)
            val isSharpLedgeCliff = abs(lumFoot - lumBelow) > 0.26f && lumBelow < lumFoot - 0.20f
            return when {
                isSkyVoidBelow -> 0.15f
                isSharpLedgeCliff -> 0.40f
                else -> 1.0f
            }
        }
        val spanHalf = (targetUserWidth * (anchor.stanceWidthRatio * 0.72f + 0.24f)).coerceAtLeast(24f)
        centerSupport = probeGroundSupport(feetCenterX, feetY)
        leftSupport = probeGroundSupport(feetCenterX - spanHalf, feetY)
        rightSupport = probeGroundSupport(feetCenterX + spanHalf, feetY)
    }

    val ledgeOpacity = ((centerSupport * 0.6f + leftSupport * 0.2f + rightSupport * 0.2f) * torsoAttenuation).coerceIn(0.20f, 1.0f)

    val tightBlur = (8f * resScale).coerceIn(6f, 16f)
    val wideBlur = (22f * resScale).coerceIn(16f, 40f)

    val tightMaxAlpha = (depth * 0.50f * brightnessFactor * ledgeOpacity * 255f).toInt().coerceIn(28, 128)
    val wideMaxAlpha = (depth * 0.28f * brightnessFactor * ledgeOpacity * 255f).toInt().coerceIn(16, 74)

    val tightOvalH = (targetUserHeight * 0.020f).coerceIn(6f * resScale, 16f * resScale)
    val wideOvalH = (targetUserHeight * 0.048f).coerceIn(14f * resScale, 36f * resScale)

    fun clampOval(cx: Float, cy: Float, rx: Float, ry: Float): RectF {
        val leftEdge = (cx - rx * leftSupport).coerceAtLeast(4f)
        val rightEdge = (cx + rx * rightSupport).coerceAtMost(cW - 4f)
        val topEdge = (cy - ry * 0.42f).coerceAtLeast(2f)
        val botEdge = (cy + ry * 0.58f).coerceAtMost(cH - 2f)
        return RectF(
            leftEdge,
            topEdge,
            rightEdge.coerceAtLeast(leftEdge + 6f),
            botEdge.coerceAtLeast(topEdge + 4f)
        )
    }

    // LAYER 2: Wider, soft diffuse ambient ground shadow (blurRadius = 22f)
    val wideRx = (targetUserWidth * (anchor.stanceWidthRatio * 0.78f + 0.28f)).coerceIn(targetUserWidth * 0.30f, targetUserWidth * 0.66f)
    val wideRect = clampOval(feetCenterX, feetY + (wideOvalH * 0.06f), wideRx, wideOvalH)
    val widePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        maskFilter = BlurMaskFilter(wideBlur, BlurMaskFilter.Blur.NORMAL)
        shader = RadialGradient(
            wideRect.centerX(),
            wideRect.centerY(),
            (wideRect.width() * 0.50f).coerceAtLeast(10f),
            intArrayOf(
                (wideMaxAlpha shl 24) or baseColor,
                ((wideMaxAlpha * 0.45f).toInt() shl 24) or baseColor,
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.52f, 1f),
            Shader.TileMode.CLAMP
        )
    }
    canvas.drawOval(wideRect, widePaint)

    // LAYER 1: Tight, soft dark sole-contact shadow directly under shoes/feet (blurRadius = 8f)
    if (anchor.isDualFoot && anchor.stanceWidthRatio > 0.08f) {
        val leftFootX = left + (anchor.leftFootRatioX * targetUserWidth)
        val rightFootX = left + (anchor.rightFootRatioX * targetUserWidth)
        val leftSoleY = (feetY - ((anchor.lowestContactYRatio - anchor.leftFootLowestYRatio) * targetUserHeight).coerceAtLeast(0f)).coerceIn(6f, cH - 4f)
        val rightSoleY = (feetY - ((anchor.lowestContactYRatio - anchor.rightFootLowestYRatio) * targetUserHeight).coerceAtLeast(0f)).coerceIn(6f, cH - 4f)
        val leftSoleRx = (anchor.leftSoleWidthRatio * targetUserWidth * 0.68f).coerceIn(14f * resScale, 48f * resScale)
        val rightSoleRx = (anchor.rightSoleWidthRatio * targetUserWidth * 0.68f).coerceIn(14f * resScale, 48f * resScale)

        for ((fx, fy, rx) in listOf(
            Triple(leftFootX, leftSoleY, leftSoleRx),
            Triple(rightFootX, rightSoleY, rightSoleRx)
        )) {
            val soleRect = clampOval(fx, fy, rx, tightOvalH)
            val solePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                maskFilter = BlurMaskFilter(tightBlur, BlurMaskFilter.Blur.NORMAL)
                shader = RadialGradient(
                    soleRect.centerX(),
                    soleRect.centerY(),
                    (soleRect.width() * 0.50f).coerceAtLeast(8f),
                    intArrayOf(
                        (tightMaxAlpha shl 24) or baseColor,
                        ((tightMaxAlpha * 0.42f).toInt() shl 24) or baseColor,
                        Color.TRANSPARENT
                    ),
                    floatArrayOf(0f, 0.50f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawOval(soleRect, solePaint)
        }
    } else {
        val singleSoleRx = (targetUserWidth * (anchor.stanceWidthRatio * 0.62f + 0.20f)).coerceIn(18f * resScale, targetUserWidth * 0.48f)
        val soleRect = clampOval(feetCenterX, feetY, singleSoleRx, tightOvalH)
        val solePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            maskFilter = BlurMaskFilter(tightBlur, BlurMaskFilter.Blur.NORMAL)
            shader = RadialGradient(
                soleRect.centerX(),
                soleRect.centerY(),
                (soleRect.width() * 0.50f).coerceAtLeast(8f),
                intArrayOf(
                    (tightMaxAlpha shl 24) or baseColor,
                    ((tightMaxAlpha * 0.42f).toInt() shl 24) or baseColor,
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.50f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawOval(soleRect, solePaint)
    }
}

private fun getOrCreateCameraGrainBitmap(): Bitmap {
    sharedCameraGrainBitmap?.let { if (!it.isRecycled) return it }
    val size = 192
    val pixels = IntArray(size * size)
    val rng = Random(20250419)
    for (i in pixels.indices) {
        val bright = rng.nextBoolean()
        val alpha = rng.nextInt(5, 19)
        val luma = if (bright) rng.nextInt(195, 255) else rng.nextInt(0, 55)
        pixels[i] = (alpha shl 24) or (luma shl 16) or (luma shl 8) or luma
    }
    val bmp = Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
    sharedCameraGrainBitmap = bmp
    return bmp
}

fun drawUnifiedVideoCameraGrain(
    canvas: Canvas,
    width: Float,
    height: Float,
    frameSeed: Long
) {
    if (width <= 0f || height <= 0f) return
    val grainBmp = getOrCreateCameraGrainBitmap()
    val shiftX = ((frameSeed * 37L) % 192L).toFloat()
    val shiftY = ((frameSeed * 61L) % 192L).toFloat()
    val shader = BitmapShader(grainBmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    val matrix = Matrix().apply {
        setTranslate(shiftX, shiftY)
    }
    shader.setLocalMatrix(matrix)
    val grainPaint = Paint().apply {
        this.shader = shader
        alpha = 68
    }
    canvas.drawRect(0f, 0f, width, height, grainPaint)
}

fun drawCompositeVideoFrame(
    canvas: Canvas,
    width: Int,
    height: Int,
    bgBitmap: Bitmap?,
    personBitmap: Bitmap?,
    userScale: Float,
    userXOffset: Float,
    userYOffset: Float,
    userRotation: Float,
    previewWidthPx: Float,
    previewHeightPx: Float,
    filterMatrixValues: FloatArray?,
    shadowDepth: Float = 0.38f,
    frameSeed: Long = 0L,
    showWatermark: Boolean = true,
    bgMotionProgress: Float = 0f
) {
    canvas.drawFilter = PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    val lighting = analyzeVideoBackgroundLighting(bgBitmap)
    val crispBg = bgBitmap?.takeIf { !it.isRecycled && it.width > 0 && it.height > 0 }

    val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG).apply {
        if (filterMatrixValues != null) {
            colorFilter = ColorMatrixColorFilter(filterMatrixValues)
        }
    }

    // Subtle, natural handheld camera breathing motion (keeps subject feet anchored to ground)
    val tSec = if (bgMotionProgress > 0f) {
        bgMotionProgress.coerceIn(0f, 1f) * 15f
    } else {
        (frameSeed.coerceAtLeast(0L).toFloat() / 30f)
    }
    val breathZoom = 1.026f +
        0.007f * kotlin.math.sin(tSec * 0.42f) +
        0.003f * kotlin.math.sin(tSec * 0.95f + 0.8f)
    val handheldPanX = (width * 0.0040f) * kotlin.math.sin(tSec * 0.68f) +
        (width * 0.0016f) * kotlin.math.sin(tSec * 1.45f + 1.1f)
    val handheldPanY = (height * 0.0030f) * kotlin.math.cos(tSec * 0.54f) +
        (height * 0.0014f) * kotlin.math.sin(tSec * 1.22f + 0.4f)
    val handheldRollDeg = 0.20f * kotlin.math.sin(tSec * 0.48f + 0.3f) +
        0.08f * kotlin.math.cos(tSec * 1.15f)
    val bgParallaxShiftX = (width * 0.0014f) * kotlin.math.sin(tSec * 0.42f)

    canvas.save()
    canvas.translate(handheldPanX, handheldPanY)
    canvas.scale(breathZoom, breathZoom, width / 2f, height / 2f)
    canvas.rotate(handheldRollDeg, width / 2f, height / 2f)

    var computedBgRect: RectF? = null
    if (crispBg != null) {
        val bgAspect = crispBg.width.toFloat() / crispBg.height.toFloat()
        val outAspect = width.toFloat() / height.toFloat()
        val drawW: Float
        val drawH: Float
        if (bgAspect > outAspect) {
            drawH = height.toFloat()
            drawW = drawH * bgAspect
        } else {
            drawW = width.toFloat()
            drawH = drawW / bgAspect
        }
        val drawX = (width - drawW) / 2f
        val drawY = (height - drawH) / 2f
        computedBgRect = RectF(drawX, drawY, drawX + drawW, drawY + drawH)
        canvas.save()
        canvas.translate(bgParallaxShiftX, 0f)
        canvas.drawBitmap(crispBg, null, computedBgRect, bgPaint)
        canvas.restore()
    } else {
        val fallbackPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, height.toFloat(),
                Color.parseColor("#0F172A"), Color.parseColor("#1E1B4B"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(-32f, -32f, width.toFloat() + 32f, height.toFloat() + 32f, fallbackPaint)
    }

    if (personBitmap != null && !personBitmap.isRecycled && personBitmap.width > 0 && personBitmap.height > 0) {
        val pW = previewWidthPx.coerceAtLeast(300f)
        val pH = previewHeightPx.coerceAtLeast(300f)
        val scaleToExport = width.toFloat() / pW

        val targetUserHeight = height.toFloat() * ((210f * userScale) / 380f)
        val userAspect = personBitmap.width.toFloat() / personBitmap.height.toFloat().coerceAtLeast(0.01f)
        val targetUserWidth = targetUserHeight * userAspect

        val centerX = (pW / 2f + userXOffset) * scaleToExport
        val bottomY = height.toFloat() + (userYOffset * (height.toFloat() / pH))
        val top = bottomY - targetUserHeight
        val left = centerX - (targetUserWidth / 2f)
        val destRect = RectF(left, top, left + targetUserWidth, bottomY)

        val featheredPerson = applyUniversalBottomEdgeFeathering(
            src = personBitmap,
            bgBitmap = bgBitmap,
            personRectOnCanvas = destRect,
            bgRectOnCanvas = computedBgRect
        )

        // Ground-aware two-layer contact shadow directly beneath the shoes/feet
        drawDynamicVideoPersonShadow(
            canvas = canvas,
            personBitmap = featheredPerson,
            lighting = lighting,
            shadowDepth = shadowDepth,
            left = left,
            top = top,
            targetUserWidth = targetUserWidth,
            targetUserHeight = targetUserHeight,
            centerX = centerX,
            bottomY = bottomY,
            userRotation = userRotation,
            bgBitmap = bgBitmap,
            bgRectOnCanvas = computedBgRect,
            canvasWidth = width.toFloat(),
            canvasHeight = height.toFloat()
        )

        // Real-time location color & lighting matched Paint (+ any selected filter)
        val personColorMatrix = composePersonColorMatrix(lighting, filterMatrixValues)
        val personPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(personColorMatrix)
        }
        canvas.save()
        if (userRotation != 0f) {
            canvas.rotate(userRotation, centerX, top + targetUserHeight / 2f)
        }
        canvas.drawBitmap(featheredPerson, null, destRect, personPaint)
        canvas.restore()
    }

    canvas.restore()

    // Unified subtle camera lens grain over both crisp background and relit user
    drawUnifiedVideoCameraGrain(canvas, width.toFloat(), height.toFloat(), frameSeed)

    if (showWatermark) {
        val wmPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = (width * 0.044f).coerceAtLeast(28f)
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            alpha = 215
            setShadowLayer(6f, 0f, 2f, Color.argb(180, 0, 0, 0))
        }
        canvas.drawText("WorldCam AI", width / 2f, height - (height * 0.032f), wmPaint)
    }
}

private fun buildCrystalClear1080pFormat(
    width: Int,
    height: Int,
    fps: Int,
    highProfile: Boolean
): MediaFormat {
    return MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
        setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        setInteger(MediaFormat.KEY_BIT_RATE, 12_000_000)
        setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        if (highProfile) {
            setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                setInteger(MediaFormat.KEY_LEVEL, MediaCodecInfo.CodecProfileLevel.AVCLevel4)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            }
        }
    }
}

class CompositeVideoSurfaceRecorder(
    private val width: Int = 1080,
    private val height: Int = 1920,
    private val outputFile: File
) {
    private val executor = Executors.newSingleThreadExecutor()
    private val isRecording = AtomicBoolean(false)
    private val pendingFrames = AtomicInteger(0)

    private var encoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var muxer: MediaMuxer? = null
    private var videoTrackIndex = -1
    private var muxerStarted = false
    private var firstPtsUs = -1L
    private var frameCount = 0

    fun start(): Boolean {
        return try {
            executor.submit(Callable {
                val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
                try {
                    codec.configure(
                        buildCrystalClear1080pFormat(width, height, 30, highProfile = true),
                        null,
                        null,
                        MediaCodec.CONFIGURE_FLAG_ENCODE
                    )
                } catch (_: Throwable) {
                    codec.reset()
                    codec.configure(
                        buildCrystalClear1080pFormat(width, height, 30, highProfile = false),
                        null,
                        null,
                        MediaCodec.CONFIGURE_FLAG_ENCODE
                    )
                }
                val surface = codec.createInputSurface()
                codec.start()

                if (outputFile.exists()) outputFile.delete()
                val mediaMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

                encoder = codec
                inputSurface = surface
                muxer = mediaMuxer
                videoTrackIndex = -1
                muxerStarted = false
                firstPtsUs = -1L
                frameCount = 0
                isRecording.set(true)
                true
            }).get()
        } catch (e: Throwable) {
            Log.e("VideoRecorder", "Failed to start recorder: ${e.message}", e)
            cleanup()
            false
        }
    }

    fun submitFrame(
        bgBitmap: Bitmap?,
        personBitmap: Bitmap?,
        userScale: Float,
        userXOffset: Float,
        userYOffset: Float,
        userRotation: Float,
        previewWidthPx: Float,
        previewHeightPx: Float,
        filterMatrixValues: FloatArray?,
        shadowDepth: Float = 0.38f,
        showWatermark: Boolean = true
    ) {
        if (!isRecording.get()) return
        if (pendingFrames.get() >= 2) return // Keep latency crisp if encoder is busy

        val bgSnap = bgBitmap?.takeIf { !it.isRecycled }
        val personSnap = personBitmap?.takeIf { !it.isRecycled }

        pendingFrames.incrementAndGet()
        executor.execute {
            try {
                if (!isRecording.get()) return@execute
                val surface = inputSurface ?: return@execute
                val canvas = surface.lockCanvas(null)
                try {
                    drawCompositeVideoFrame(
                        canvas = canvas,
                        width = width,
                        height = height,
                        bgBitmap = bgSnap,
                        personBitmap = personSnap,
                        userScale = userScale,
                        userXOffset = userXOffset,
                        userYOffset = userYOffset,
                        userRotation = userRotation,
                        previewWidthPx = previewWidthPx,
                        previewHeightPx = previewHeightPx,
                        filterMatrixValues = filterMatrixValues,
                        shadowDepth = shadowDepth,
                        frameSeed = frameCount.toLong(),
                        showWatermark = showWatermark,
                        bgMotionProgress = (frameCount.toFloat() / 450f).coerceIn(0f, 1f)
                    )
                } finally {
                    surface.unlockCanvasAndPost(canvas)
                }
                frameCount++
                drainEncoder(endOfStream = false)
            } catch (t: Throwable) {
                Log.w("VideoRecorder", "Frame encode error: ${t.message}")
            } finally {
                pendingFrames.decrementAndGet()
            }
        }
    }

    fun stopAndFinalize(): File? {
        if (!isRecording.compareAndSet(true, false)) {
            return null
        }
        return try {
            executor.submit(Callable {
                try {
                    encoder?.signalEndOfInputStream()
                    drainEncoder(endOfStream = true)
                } catch (e: Throwable) {
                    Log.e("VideoRecorder", "Error draining EOS: ${e.message}", e)
                }
                val valid = muxerStarted && frameCount > 0 && outputFile.exists() && outputFile.length() > 0L
                cleanup()
                if (valid) outputFile else null
            }).get()
        } catch (e: Throwable) {
            Log.e("VideoRecorder", "Stop failed: ${e.message}", e)
            cleanup()
            null
        } finally {
            try {
                executor.shutdown()
            } catch (_: Throwable) {}
        }
    }

    private fun drainEncoder(endOfStream: Boolean) {
        val codec = encoder ?: return
        val mediaMuxer = muxer ?: return
        val bufferInfo = MediaCodec.BufferInfo()
        val timeoutUs = if (endOfStream) 10_000L else 0L
        var emptyTries = 0

        while (true) {
            val outIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            when {
                outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream) break
                    emptyTries++
                    if (emptyTries > 25) break
                }
                outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (!muxerStarted) {
                        val newFormat = codec.outputFormat
                        videoTrackIndex = mediaMuxer.addTrack(newFormat)
                        mediaMuxer.start()
                        muxerStarted = true
                    }
                }
                outIndex >= 0 -> {
                    val encodedData = codec.getOutputBuffer(outIndex)
                    if (encodedData != null) {
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }
                        if (bufferInfo.size > 0 && muxerStarted && videoTrackIndex >= 0) {
                            if (firstPtsUs < 0L) {
                                firstPtsUs = bufferInfo.presentationTimeUs
                            }
                            bufferInfo.presentationTimeUs = (bufferInfo.presentationTimeUs - firstPtsUs).coerceAtLeast(0L)
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            mediaMuxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                        }
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            }
        }
    }

    private fun cleanup() {
        isRecording.set(false)
        try {
            encoder?.stop()
        } catch (_: Throwable) {}
        try {
            encoder?.release()
        } catch (_: Throwable) {}
        encoder = null

        try {
            inputSurface?.release()
        } catch (_: Throwable) {}
        inputSurface = null

        try {
            if (muxerStarted) {
                muxer?.stop()
            }
        } catch (_: Throwable) {}
        try {
            muxer?.release()
        } catch (_: Throwable) {}
        muxer = null
    }
}

fun muxSongAudioWithVideo(
    context: Context,
    videoFile: File,
    audioUri: Uri?,
    songStartTimeMs: Long,
    outputFile: File
): File {
    if (audioUri == null) {
        videoFile.copyTo(outputFile, overwrite = true)
        return outputFile
    }

    val videoExtractor = MediaExtractor()
    val audioExtractor = MediaExtractor()
    var audioDecoder: MediaCodec? = null
    var audioEncoder: MediaCodec? = null
    var muxer: MediaMuxer? = null
    var muxerStarted = false

    return try {
        videoExtractor.setDataSource(videoFile.absolutePath)
        var srcVideoTrack = -1
        var videoFormat: MediaFormat? = null
        for (i in 0 until videoExtractor.trackCount) {
            val fmt = videoExtractor.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("video/")) {
                srcVideoTrack = i
                videoFormat = fmt
                break
            }
        }
        if (srcVideoTrack < 0 || videoFormat == null) {
            videoFile.copyTo(outputFile, overwrite = true)
            return outputFile
        }
        videoExtractor.selectTrack(srcVideoTrack)

        // Determine actual recorded video duration
        var maxVideoPtsUs = 15_000_000L
        if (videoFormat.containsKey(MediaFormat.KEY_DURATION)) {
            maxVideoPtsUs = videoFormat.getLong(MediaFormat.KEY_DURATION).coerceIn(500_000L, 15_500_000L)
        } else {
            val scanBuf = ByteBuffer.allocate(256 * 1024)
            var lastPts = 0L
            while (true) {
                val sz = videoExtractor.readSampleData(scanBuf, 0)
                if (sz < 0) break
                if (videoExtractor.sampleTime > lastPts) lastPts = videoExtractor.sampleTime
                videoExtractor.advance()
            }
            if (lastPts > 0L) maxVideoPtsUs = lastPts + 33_333L
            videoExtractor.seekTo(0L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        }

        // Open audio extractor
        audioExtractor.setDataSource(context, audioUri, null)
        var srcAudioTrack = -1
        var srcAudioFormat: MediaFormat? = null
        for (i in 0 until audioExtractor.trackCount) {
            val fmt = audioExtractor.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                srcAudioTrack = i
                srcAudioFormat = fmt
                break
            }
        }
        if (srcAudioTrack < 0 || srcAudioFormat == null) {
            videoFile.copyTo(outputFile, overwrite = true)
            return outputFile
        }
        audioExtractor.selectTrack(srcAudioTrack)
        val seekUs = (songStartTimeMs * 1000L).coerceAtLeast(0L)
        audioExtractor.seekTo(seekUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

        val srcMime = srcAudioFormat.getString(MediaFormat.KEY_MIME) ?: "audio/mpeg"
        var sampleRate = if (srcAudioFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
            srcAudioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        } else 44100
        var channelCount = if (srcAudioFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
            srcAudioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        } else 2

        val decoder = MediaCodec.createDecoderByType(srcMime)
        decoder.configure(srcAudioFormat, null, null, 0)
        decoder.start()
        audioDecoder = decoder

        val encFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channelCount).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        encoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()
        audioEncoder = encoder

        // Transcode exact 15s (maxVideoPtsUs) audio clip to AAC frames in memory first
        val aacSamples = ArrayList<Pair<ByteArray, MediaCodec.BufferInfo>>()
        var actualEncoderFormat: MediaFormat? = null

        val decInfo = MediaCodec.BufferInfo()
        val encInfo = MediaCodec.BufferInfo()
        var extractorDone = false
        var decoderDone = false
        var encoderDone = false
        var firstDecodedPtsUs = -1L
        var encodedPtsUs = 0L

        while (!encoderDone) {
            if (!extractorDone) {
                val inIdx = decoder.dequeueInputBuffer(5_000L)
                if (inIdx >= 0) {
                    val inBuf = decoder.getInputBuffer(inIdx)
                    if (inBuf != null) {
                        val sampleSize = audioExtractor.readSampleData(inBuf, 0)
                        val samplePts = audioExtractor.sampleTime
                        if (sampleSize < 0 || (firstDecodedPtsUs >= 0L && (samplePts - firstDecodedPtsUs) > maxVideoPtsUs + 200_000L)) {
                            decoder.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            extractorDone = true
                        } else {
                            if (firstDecodedPtsUs < 0L) firstDecodedPtsUs = samplePts
                            decoder.queueInputBuffer(inIdx, 0, sampleSize, samplePts, 0)
                            audioExtractor.advance()
                        }
                    }
                }
            }

            if (!decoderDone) {
                val decOutIdx = decoder.dequeueOutputBuffer(decInfo, 5_000L)
                if (decOutIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFmt = decoder.outputFormat
                    if (newFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        sampleRate = newFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (newFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channelCount = newFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                } else if (decOutIdx >= 0) {
                    val decOutBuf = decoder.getOutputBuffer(decOutIdx)
                    val isEos = (decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    if (decOutBuf != null && decInfo.size > 0 && encodedPtsUs < maxVideoPtsUs) {
                        decOutBuf.position(decInfo.offset)
                        decOutBuf.limit(decInfo.offset + decInfo.size)
                        val pcmBytes = ByteArray(decInfo.size)
                        decOutBuf.get(pcmBytes)

                        var offset = 0
                        while (offset < pcmBytes.size && encodedPtsUs < maxVideoPtsUs) {
                            val encInIdx = encoder.dequeueInputBuffer(10_000L)
                            if (encInIdx >= 0) {
                                val encInBuf = encoder.getInputBuffer(encInIdx)
                                if (encInBuf != null) {
                                    encInBuf.clear()
                                    val chunk = minOf(encInBuf.remaining(), pcmBytes.size - offset)
                                    encInBuf.put(pcmBytes, offset, chunk)
                                    val bytesPerSec = (sampleRate * channelCount * 2).coerceAtLeast(1)
                                    val chunkDurationUs = (chunk.toLong() * 1_000_000L) / bytesPerSec
                                    encoder.queueInputBuffer(encInIdx, 0, chunk, encodedPtsUs, 0)
                                    encodedPtsUs += chunkDurationUs
                                    offset += chunk
                                }
                            }
                        }
                    }
                    decoder.releaseOutputBuffer(decOutIdx, false)
                    if (isEos || encodedPtsUs >= maxVideoPtsUs) {
                        val encInIdx = encoder.dequeueInputBuffer(10_000L)
                        if (encInIdx >= 0) {
                            encoder.queueInputBuffer(encInIdx, 0, 0, encodedPtsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        }
                        decoderDone = true
                    }
                }
            }

            while (true) {
                val encOutIdx = encoder.dequeueOutputBuffer(encInfo, 2_000L)
                if (encOutIdx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    break
                } else if (encOutIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    actualEncoderFormat = encoder.outputFormat
                } else if (encOutIdx >= 0) {
                    val encOutBuf = encoder.getOutputBuffer(encOutIdx)
                    if (encOutBuf != null && encInfo.size > 0 && (encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        encOutBuf.position(encInfo.offset)
                        encOutBuf.limit(encInfo.offset + encInfo.size)
                        val data = ByteArray(encInfo.size)
                        encOutBuf.get(data)
                        val copyInfo = MediaCodec.BufferInfo().apply {
                            set(0, data.size, encInfo.presentationTimeUs, encInfo.flags)
                        }
                        aacSamples.add(data to copyInfo)
                    }
                    val isEos = (encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    encoder.releaseOutputBuffer(encOutIdx, false)
                    if (isEos) {
                        encoderDone = true
                        break
                    }
                }
            }
        }

        if (actualEncoderFormat == null || aacSamples.isEmpty()) {
            videoFile.copyTo(outputFile, overwrite = true)
            return outputFile
        }

        if (outputFile.exists()) outputFile.delete()
        val mediaMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer = mediaMuxer
        val outVideoTrack = mediaMuxer.addTrack(videoFormat)
        val outAudioTrack = mediaMuxer.addTrack(actualEncoderFormat!!)
        mediaMuxer.start()
        muxerStarted = true

        // Write video samples
        val vBuf = ByteBuffer.allocate(2 * 1024 * 1024)
        val vInfo = MediaCodec.BufferInfo()
        while (true) {
            val sz = videoExtractor.readSampleData(vBuf, 0)
            if (sz < 0) break
            vInfo.offset = 0
            vInfo.size = sz
            vInfo.presentationTimeUs = videoExtractor.sampleTime.coerceAtLeast(0L)
            vInfo.flags = if ((videoExtractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                MediaCodec.BUFFER_FLAG_KEY_FRAME
            } else 0
            vBuf.position(0)
            vBuf.limit(sz)
            mediaMuxer.writeSampleData(outVideoTrack, vBuf, vInfo)
            videoExtractor.advance()
        }

        // Write AAC audio samples
        for ((bytes, info) in aacSamples) {
            val aBuf = ByteBuffer.wrap(bytes)
            mediaMuxer.writeSampleData(outAudioTrack, aBuf, info)
        }

        outputFile
    } catch (e: Throwable) {
        Log.e("VideoMuxer", "Audio muxing fallback to video-only: ${e.message}", e)
        try {
            videoFile.copyTo(outputFile, overwrite = true)
        } catch (_: Throwable) {}
        outputFile
    } finally {
        try { videoExtractor.release() } catch (_: Throwable) {}
        try { audioExtractor.release() } catch (_: Throwable) {}
        try { audioDecoder?.stop(); audioDecoder?.release() } catch (_: Throwable) {}
        try { audioEncoder?.stop(); audioEncoder?.release() } catch (_: Throwable) {}
        try { if (muxerStarted) muxer?.stop() } catch (_: Throwable) {}
        try { muxer?.release() } catch (_: Throwable) {}
    }
}

fun saveVideoToGallery(context: Context, videoFile: File, locationName: String): Uri? {
    return try {
        val resolver = context.contentResolver
        val sanitized = locationName.replace(Regex("[^a-zA-Z0-9]"), "_").take(30)
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "WorldCam_Video_${sanitized}_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/WorldCamAI")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val videoUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
        if (videoUri != null) {
            resolver.openOutputStream(videoUri)?.use { out ->
                FileInputStream(videoFile).use { input ->
                    input.copyTo(out)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(videoUri, contentValues, null, null)
            }
        }
        videoUri
    } catch (e: Throwable) {
        Log.e("VideoGallerySave", "Failed saving video to gallery: ${e.message}", e)
        null
    }
}

/**
 * High-speed deterministic 15-second 1080x1920 30fps Video Renderer for Voice AI:
 * Renders 450 frames with smooth Ken Burns background motion, auto-realism lighting,
 * and ground-contact 3D shadows in ~2-3 seconds while writing exact 33,333us PTS intervals.
 */
fun renderAutoRealisticVideo15s(
    outputFile: File,
    bgBitmap: Bitmap?,
    personBitmap: Bitmap?,
    userScale: Float,
    userXOffset: Float,
    userYOffset: Float,
    userRotation: Float,
    previewWidthPx: Float,
    previewHeightPx: Float,
    filterMatrixValues: FloatArray?,
    shadowDepth: Float,
    width: Int = 1080,
    height: Int = 1920,
    fps: Int = 30,
    durationSeconds: Int = 15,
    onProgress: ((Float) -> Unit)? = null
): File? {
    val totalFrames = fps * durationSeconds
    val frameStepUs = 1_000_000L / fps
    var codec: MediaCodec? = null
    var inputSurface: Surface? = null
    var muxer: MediaMuxer? = null
    var muxerStarted = false
    var videoTrackIndex = -1
    var writtenSamples = 0L

    return try {
        // Pre-warm lighting profile cache once before 450-frame 1080x1920 12Mbps render loop
        analyzeVideoBackgroundLighting(bgBitmap)

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        try {
            encoder.configure(
                buildCrystalClear1080pFormat(width, height, fps, highProfile = true),
                null,
                null,
                MediaCodec.CONFIGURE_FLAG_ENCODE
            )
        } catch (_: Throwable) {
            encoder.reset()
            encoder.configure(
                buildCrystalClear1080pFormat(width, height, fps, highProfile = false),
                null,
                null,
                MediaCodec.CONFIGURE_FLAG_ENCODE
            )
        }
        val surface = encoder.createInputSurface()
        encoder.start()
        codec = encoder
        inputSurface = surface

        if (outputFile.exists()) outputFile.delete()
        val mediaMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer = mediaMuxer

        val bufferInfo = MediaCodec.BufferInfo()

        fun drain(endOfStream: Boolean) {
            val timeoutUs = if (endOfStream) 10_000L else 0L
            var emptyTries = 0
            while (true) {
                val outIdx = encoder.dequeueOutputBuffer(bufferInfo, timeoutUs)
                when {
                    outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!endOfStream) break
                        emptyTries++
                        if (emptyTries > 40) break
                    }
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        if (!muxerStarted) {
                            videoTrackIndex = mediaMuxer.addTrack(encoder.outputFormat)
                            mediaMuxer.start()
                            muxerStarted = true
                        }
                    }
                    outIdx >= 0 -> {
                        val encoded = encoder.getOutputBuffer(outIdx)
                        if (encoded != null) {
                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                                bufferInfo.size = 0
                            }
                            if (bufferInfo.size > 0 && muxerStarted && videoTrackIndex >= 0) {
                                // Enforce deterministic 30fps timestamps so 450 frames = exact 15.0s MP4
                                bufferInfo.presentationTimeUs = writtenSamples * frameStepUs
                                writtenSamples++
                                encoded.position(bufferInfo.offset)
                                encoded.limit(bufferInfo.offset + bufferInfo.size)
                                mediaMuxer.writeSampleData(videoTrackIndex, encoded, bufferInfo)
                            }
                        }
                        encoder.releaseOutputBuffer(outIdx, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            break
                        }
                    }
                }
            }
        }

        for (frameIdx in 0 until totalFrames) {
            val progress = frameIdx.toFloat() / (totalFrames - 1).coerceAtLeast(1).toFloat()
            val canvas = surface.lockCanvas(null)
            try {
                drawCompositeVideoFrame(
                    canvas = canvas,
                    width = width,
                    height = height,
                    bgBitmap = bgBitmap,
                    personBitmap = personBitmap,
                    userScale = userScale,
                    userXOffset = userXOffset,
                    userYOffset = userYOffset,
                    userRotation = userRotation,
                    previewWidthPx = previewWidthPx,
                    previewHeightPx = previewHeightPx,
                    filterMatrixValues = filterMatrixValues,
                    shadowDepth = shadowDepth,
                    frameSeed = frameIdx.toLong(),
                    showWatermark = true,
                    bgMotionProgress = progress
                )
            } finally {
                surface.unlockCanvasAndPost(canvas)
            }
            drain(endOfStream = false)
            if (frameIdx % 15 == 0) {
                onProgress?.invoke(progress)
            }
        }

        encoder.signalEndOfInputStream()
        drain(endOfStream = true)
        onProgress?.invoke(1f)

        if (muxerStarted && writtenSamples > 0 && outputFile.exists() && outputFile.length() > 0L) {
            outputFile
        } else {
            null
        }
    } catch (t: Throwable) {
        Log.e("VoiceVideoRender", "Auto 15s video render failed: ${t.message}", t)
        null
    } finally {
        try { codec?.stop() } catch (_: Throwable) {}
        try { codec?.release() } catch (_: Throwable) {}
        try { inputSurface?.release() } catch (_: Throwable) {}
        try { if (muxerStarted) muxer?.stop() } catch (_: Throwable) {}
        try { muxer?.release() } catch (_: Throwable) {}
    }
}

package com.aistudio.worldcamai.smxuqv

import android.graphics.Bitmap
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseLandmark
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class NormPoint(val x: Float, val y: Float)

data class PoseSkeletonInfo(
    val nose: NormPoint?,
    val leftShoulder: NormPoint?,
    val rightShoulder: NormPoint?,
    val leftElbow: NormPoint?,
    val rightElbow: NormPoint?,
    val leftWrist: NormPoint?,
    val rightWrist: NormPoint?,
    val leftHip: NormPoint?,
    val rightHip: NormPoint?,
    val leftKnee: NormPoint?,
    val rightKnee: NormPoint?,
    val leftAnkle: NormPoint?,
    val rightAnkle: NormPoint?,
    val leftHeel: NormPoint?,
    val rightHeel: NormPoint?,
    val leftToe: NormPoint?,
    val rightToe: NormPoint?,
    val footRegions: PoseFootRegions?
) {
    private fun distSeg(px: Float, py: Float, a: NormPoint?, b: NormPoint?): Float {
        if (a == null || b == null) return Float.MAX_VALUE
        val abx = b.x - a.x
        val aby = b.y - a.y
        val lenSq = abx * abx + aby * aby
        if (lenSq <= 1e-7f) return hypot(px - a.x, py - a.y)
        val t = (((px - a.x) * abx + (py - a.y) * aby) / lenSq).coerceIn(0f, 1f)
        return hypot(px - (a.x + t * abx), py - (a.y + t * aby))
    }

    val hipY: Float?
        get() = when {
            leftHip != null && rightHip != null -> (leftHip.y + rightHip.y) * 0.5f
            leftHip != null -> leftHip.y
            rightHip != null -> rightHip.y
            else -> null
        }

    val shoulderY: Float?
        get() = when {
            leftShoulder != null && rightShoulder != null -> (leftShoulder.y + rightShoulder.y) * 0.5f
            leftShoulder != null -> leftShoulder.y
            rightShoulder != null -> rightShoulder.y
            else -> null
        }

    fun shoulderWidth(): Float {
        if (leftShoulder != null && rightShoulder != null) {
            return abs(leftShoulder.x - rightShoulder.x).coerceIn(0.08f, 0.70f)
        }
        return 0.22f
    }

    fun isInsideTorsoOrHeadCore(nx: Float, ny: Float): Boolean {
        val sw = shoulderWidth()
        if (nose != null) {
            val headR = (sw * 0.44f).coerceIn(0.045f, 0.16f)
            if (hypot(nx - nose.x, (ny - (nose.y - headR * 0.12f)) * 0.85f) <= headR) return true
        }
        val sY = shoulderY
        if (sY != null) {
            val sMidX = when {
                leftShoulder != null && rightShoulder != null -> (leftShoulder.x + rightShoulder.x) * 0.5f
                leftShoulder != null -> leftShoulder.x
                rightShoulder != null -> rightShoulder.x
                else -> nose?.x ?: 0.5f
            }
            val sMinX = if (leftShoulder != null && rightShoulder != null) min(leftShoulder.x, rightShoulder.x) else sMidX - sw * 0.5f
            val sMaxX = if (leftShoulder != null && rightShoulder != null) max(leftShoulder.x, rightShoulder.x) else sMidX + sw * 0.5f

            val hY = hipY ?: (sY + sw * 1.48f).coerceAtMost(0.96f)
            val hMinX: Float
            val hMaxX: Float
            if (leftHip != null && rightHip != null) {
                hMinX = min(leftHip.x, rightHip.x)
                hMaxX = max(leftHip.x, rightHip.x)
            } else {
                val hHalf = max(sw * 0.42f, 0.06f)
                val hMid = leftHip?.x?.let { if (it < sMidX) it + hHalf else it - hHalf }
                    ?: rightHip?.x?.let { if (it < sMidX) it + hHalf else it - hHalf }
                    ?: sMidX
                hMinX = hMid - hHalf
                hMaxX = hMid + hHalf
            }

            val topY = sY - sw * 0.08f
            val botY = hY + sw * 0.10f
            if (ny in topY..botY) {
                val t = ((ny - sY) / (hY - sY).coerceAtLeast(0.05f)).coerceIn(0f, 1f)
                val leftEdge = (sMinX + (hMinX - sMinX) * t) - sw * 0.12f
                val rightEdge = (sMaxX + (hMaxX - sMaxX) * t) + sw * 0.12f
                if (nx in min(leftEdge, rightEdge)..max(leftEdge, rightEdge)) return true
            }
        }
        return false
    }

    /**
     * Strict interior chest/stomach polygon inset from shoulders & hips so it never overlaps
     * under-arm or between-leg background gaps while guaranteeing solid white/light torso clothing.
     */
    fun isInsideStrictInnerTorso(nx: Float, ny: Float): Boolean {
        val sY = shoulderY ?: return false
        val sw = shoulderWidth()
        val sMidX = when {
            leftShoulder != null && rightShoulder != null -> (leftShoulder.x + rightShoulder.x) * 0.5f
            leftShoulder != null -> leftShoulder.x
            rightShoulder != null -> rightShoulder.x
            else -> nose?.x ?: return false
        }
        val sMinX = if (leftShoulder != null && rightShoulder != null) min(leftShoulder.x, rightShoulder.x) else sMidX - sw * 0.42f
        val sMaxX = if (leftShoulder != null && rightShoulder != null) max(leftShoulder.x, rightShoulder.x) else sMidX + sw * 0.42f
        val hY = hipY ?: (sY + sw * 1.42f).coerceAtMost(0.95f)
        val hHalf = max(sw * 0.34f, 0.045f)
        val hMinX: Float
        val hMaxX: Float
        if (leftHip != null && rightHip != null) {
            hMinX = min(leftHip.x, rightHip.x)
            hMaxX = max(leftHip.x, rightHip.x)
        } else {
            val hMid = leftHip?.x?.let { if (it < sMidX) it + hHalf else it - hHalf }
                ?: rightHip?.x?.let { if (it < sMidX) it + hHalf else it - hHalf }
                ?: sMidX
            hMinX = hMid - hHalf
            hMaxX = hMid + hHalf
        }
        val topY = sY + sw * 0.06f
        val botY = hY - sw * 0.03f
        if (botY <= topY || ny !in topY..botY) return false
        val t = ((ny - sY) / (hY - sY).coerceAtLeast(0.05f)).coerceIn(0f, 1f)
        val inset = sw * 0.14f
        val leftEdge = (sMinX + (hMinX - sMinX) * t) + inset
        val rightEdge = (sMaxX + (hMaxX - sMaxX) * t) - inset
        return rightEdge > leftEdge && nx in leftEdge..rightEdge
    }

    fun isNearBodyBone(nx: Float, ny: Float): Boolean {
        if (footRegions != null && footRegions.classifyPixel(nx, ny, strictCore = false) != 0) {
            return true
        }
        if (isInsideTorsoOrHeadCore(nx, ny)) return true

        val sw = shoulderWidth()
        val armRad = (sw * 0.18f).coerceIn(0.020f, 0.058f)
        val legRad = (sw * 0.22f).coerceIn(0.024f, 0.072f)

        // Arms
        if (distSeg(nx, ny, leftShoulder, leftElbow) <= armRad) return true
        if (distSeg(nx, ny, leftElbow, leftWrist) <= armRad) return true
        if (distSeg(nx, ny, rightShoulder, rightElbow) <= armRad) return true
        if (distSeg(nx, ny, rightElbow, rightWrist) <= armRad) return true
        // Legs
        if (distSeg(nx, ny, leftHip, leftKnee) <= legRad) return true
        if (distSeg(nx, ny, leftKnee, leftAnkle) <= legRad * 0.90f) return true
        if (distSeg(nx, ny, rightHip, rightKnee) <= legRad) return true
        if (distSeg(nx, ny, rightKnee, rightAnkle) <= legRad * 0.90f) return true
        if (distSeg(nx, ny, leftAnkle, leftToe) <= legRad * 0.85f) return true
        if (distSeg(nx, ny, rightAnkle, rightToe) <= legRad * 0.85f) return true
        return false
    }

    fun isInUnderArmGapZone(nx: Float, ny: Float): Boolean {
        val sY = shoulderY ?: return false
        val hY = hipY ?: (sY + 0.34f)
        if (ny < sY + 0.02f || ny > hY + 0.08f) return false
        if (isNearBodyBone(nx, ny)) return false

        val leftTorsoX = min(leftShoulder?.x ?: 0.5f, leftHip?.x ?: 0.5f)
        val rightTorsoX = max(rightShoulder?.x ?: 0.5f, rightHip?.x ?: 0.5f)
        val minTX = min(leftTorsoX, rightTorsoX)
        val maxTX = max(leftTorsoX, rightTorsoX)

        val lArmMaxX = maxOf(leftElbow?.x ?: -1f, leftWrist?.x ?: -1f)
        val lArmMinX = minOf(leftElbow?.x ?: 2f, leftWrist?.x ?: 2f)
        val rArmMaxX = maxOf(rightElbow?.x ?: -1f, rightWrist?.x ?: -1f)
        val rArmMinX = minOf(rightElbow?.x ?: 2f, rightWrist?.x ?: 2f)

        val inLeftLoop = (leftElbow != null) && (
            (lArmMaxX > maxTX + 0.03f && nx in maxTX..lArmMaxX) ||
                (lArmMinX < minTX - 0.03f && nx in lArmMinX..minTX)
            )
        val inRightLoop = (rightElbow != null) && (
            (rArmMaxX > maxTX + 0.03f && nx in maxTX..rArmMaxX) ||
                (rArmMinX < minTX - 0.03f && nx in rArmMinX..minTX)
            )
        return inLeftLoop || inRightLoop
    }

    fun isInBetweenLegsGapZone(nx: Float, ny: Float): Boolean {
        val hY = hipY ?: return false
        if (ny < hY + 0.01f) return false
        if (isNearBodyBone(nx, ny)) return false

        fun interpLegX(hip: NormPoint?, knee: NormPoint?, ankle: NormPoint?): Float? {
            if (hip == null) return knee?.x ?: ankle?.x
            if (knee != null && ny <= knee.y) {
                val span = (knee.y - hip.y).coerceAtLeast(0.01f)
                val t = ((ny - hip.y) / span).coerceIn(0f, 1f)
                return hip.x + (knee.x - hip.x) * t
            }
            if (knee != null && ankle != null) {
                val span = (ankle.y - knee.y).coerceAtLeast(0.01f)
                val t = ((ny - knee.y) / span).coerceIn(0f, 1.15f)
                return knee.x + (ankle.x - knee.x) * t
            }
            return ankle?.x ?: knee?.x ?: hip.x
        }

        val lx = interpLegX(leftHip, leftKnee, leftAnkle)
        val rx = interpLegX(rightHip, rightKnee, rightAnkle)
        if (lx != null && rx != null) {
            val lo = min(lx, rx)
            val hi = max(lx, rx)
            if (hi - lo > 0.02f && nx in lo..hi) return true
        }
        return false
    }

    fun legCorridorBoundsAtY(ny: Float): Pair<Float, Float>? {
        val hY = hipY ?: return null
        if (ny < hY + 0.02f) return null
        fun interp(hip: NormPoint?, knee: NormPoint?, ankle: NormPoint?): Float? {
            if (hip == null) return knee?.x ?: ankle?.x
            if (knee != null && ny <= knee.y) {
                val t = ((ny - hip.y) / (knee.y - hip.y).coerceAtLeast(0.01f)).coerceIn(0f, 1f)
                return hip.x + (knee.x - hip.x) * t
            }
            if (knee != null && ankle != null) {
                val t = ((ny - knee.y) / (ankle.y - knee.y).coerceAtLeast(0.01f)).coerceIn(0f, 1.1f)
                return knee.x + (ankle.x - knee.x) * t
            }
            return ankle?.x ?: knee?.x ?: hip.x
        }
        val lx = interp(leftHip, leftKnee, leftAnkle)
        val rx = interp(rightHip, rightKnee, rightAnkle)
        return if (lx != null && rx != null && abs(lx - rx) > 0.025f) {
            min(lx, rx) to max(lx, rx)
        } else null
    }
}

fun buildPoseSkeletonInfo(
    pose: Pose?,
    width: Int,
    height: Int,
    footRegions: PoseFootRegions?
): PoseSkeletonInfo? {
    if (pose == null || width <= 0 || height <= 0) return null
    val w = width.toFloat()
    val h = height.toFloat()
    fun pt(type: Int): NormPoint? {
        val lm = pose.getPoseLandmark(type) ?: return null
        if (lm.inFrameLikelihood < 0.42f) return null
        return NormPoint((lm.position.x / w).coerceIn(-0.05f, 1.05f), (lm.position.y / h).coerceIn(-0.05f, 1.05f))
    }
    val nose = pt(PoseLandmark.NOSE)
    val ls = pt(PoseLandmark.LEFT_SHOULDER)
    val rs = pt(PoseLandmark.RIGHT_SHOULDER)
    val lh = pt(PoseLandmark.LEFT_HIP)
    val rh = pt(PoseLandmark.RIGHT_HIP)
    if (nose == null && ls == null && rs == null && lh == null && rh == null && footRegions == null) {
        return null
    }
    return PoseSkeletonInfo(
        nose = nose,
        leftShoulder = ls,
        rightShoulder = rs,
        leftElbow = pt(PoseLandmark.LEFT_ELBOW),
        rightElbow = pt(PoseLandmark.RIGHT_ELBOW),
        leftWrist = pt(PoseLandmark.LEFT_WRIST),
        rightWrist = pt(PoseLandmark.RIGHT_WRIST),
        leftHip = lh,
        rightHip = rh,
        leftKnee = pt(PoseLandmark.LEFT_KNEE),
        rightKnee = pt(PoseLandmark.RIGHT_KNEE),
        leftAnkle = pt(PoseLandmark.LEFT_ANKLE),
        rightAnkle = pt(PoseLandmark.RIGHT_ANKLE),
        leftHeel = pt(PoseLandmark.LEFT_HEEL),
        rightHeel = pt(PoseLandmark.RIGHT_HEEL),
        leftToe = pt(PoseLandmark.LEFT_FOOT_INDEX),
        rightToe = pt(PoseLandmark.RIGHT_FOOT_INDEX),
        footRegions = footRegions
    )
}

object GuidedAlphaMatteRefiner {

    fun scrubInnerGapsAndKeepMainSubject(
        conf: FloatArray,
        w: Int,
        h: Int,
        pixels: IntArray,
        skeleton: PoseSkeletonInfo?,
        poseRegions: PoseFootRegions?
    ) {
        val total = w * h
        if (total <= 0 || conf.size < total || pixels.size < total) return

        // 1. Sample confirmed outer background RGB clusters (upper & lower halves separately)
        val upperBgR = IntArray(32)
        val upperBgG = IntArray(32)
        val upperBgB = IntArray(32)
        var upperBgCount = 0

        val lowerBgR = IntArray(32)
        val lowerBgG = IntArray(32)
        val lowerBgB = IntArray(32)
        var lowerBgCount = 0

        val hipRow = ((skeleton?.hipY ?: 0.50f) * h).toInt().coerceIn(h / 4, (h * 3) / 4)
        val stepY = (h / 18).coerceAtLeast(1)
        val stepX = (w / 18).coerceAtLeast(1)
        for (y in 0 until h step stepY) {
            val rowOff = y * w
            val ny = (y + 0.5f) / h.toFloat()
            for (x in 0 until w step stepX) {
                val idx = rowOff + x
                if (conf[idx] < 0.08f) {
                    val nx = (x + 0.5f) / w.toFloat()
                    if (skeleton?.isNearBodyBone(nx, ny) == true) continue
                    val c = pixels[idx]
                    val r = (c ushr 16) and 0xFF
                    val g = (c ushr 8) and 0xFF
                    val b = c and 0xFF
                    if (y < hipRow) {
                        if (upperBgCount < 32) {
                            upperBgR[upperBgCount] = r
                            upperBgG[upperBgCount] = g
                            upperBgB[upperBgCount] = b
                            upperBgCount++
                        }
                    } else if (lowerBgCount < 32) {
                        lowerBgR[lowerBgCount] = r
                        lowerBgG[lowerBgCount] = g
                        lowerBgB[lowerBgCount] = b
                        lowerBgCount++
                    }
                }
            }
        }

        fun minBgDist(r: Int, g: Int, b: Int, isLower: Boolean): Float {
            val count = if (isLower && lowerBgCount > 0) lowerBgCount else upperBgCount
            val br = if (isLower && lowerBgCount > 0) lowerBgR else upperBgR
            val bg = if (isLower && lowerBgCount > 0) lowerBgG else upperBgG
            val bb = if (isLower && lowerBgCount > 0) lowerBgB else upperBgB
            if (count == 0) return 999f
            var best = 999f
            for (i in 0 until count) {
                val dr = (r - br[i]).toFloat()
                val dg = (g - bg[i]).toFloat()
                val db = (b - bb[i]).toFloat()
                val d = sqrt(dr * dr + dg * dg + db * db)
                if (d < best) best = d
            }
            return best
        }

        // 2. Flood-fill open exterior background (including floor corridor between separated shoes)
        // Strictly block exterior flood-fill from invading torso/chest/stomach core
        val isExterior = BooleanArray(total)
        val queue = IntArray(total)
        var qHead = 0
        var qTail = 0

        fun trySeedExterior(idx: Int) {
            if (!isExterior[idx] && conf[idx] < 0.52f) {
                val x = idx % w
                val y = idx / w
                val nx = (x + 0.5f) / w.toFloat()
                val ny = (y + 0.5f) / h.toFloat()
                val onShoeCore = poseRegions?.classifyPixel(nx, ny, strictCore = true) ?: 0
                if (onShoeCore != 0 && conf[idx] >= 0.22f) return
                if (skeleton?.isInsideStrictInnerTorso(nx, ny) == true) return
                if (skeleton?.isInsideTorsoOrHeadCore(nx, ny) == true && conf[idx] >= 0.05f) return
                isExterior[idx] = true
                queue[qTail++] = idx
            }
        }

        for (x in 0 until w) {
            trySeedExterior(x)
            trySeedExterior((h - 1) * w + x)
        }
        for (y in 0 until h) {
            trySeedExterior(y * w)
            trySeedExterior(y * w + w - 1)
        }
        // Seed bottom inter-shoe floor opening if both feet are separated
        if (poseRegions?.leftShoe != null && poseRegions.rightShoe != null) {
            val midX = (((poseRegions.leftShoe.centerX + poseRegions.rightShoe.centerX) * 0.5f) * w).toInt()
            val spanHalf = (abs(poseRegions.leftShoe.centerX - poseRegions.rightShoe.centerX) * w * 0.24f).toInt().coerceIn(2, w / 5)
            val floorY = (max(poseRegions.leftShoe.soleY, poseRegions.rightShoe.soleY) * h).toInt().coerceIn(0, h - 1)
            for (y in (floorY - 4).coerceAtLeast(0) until h) {
                for (x in (midX - spanHalf).coerceAtLeast(0)..(midX + spanHalf).coerceAtMost(w - 1)) {
                    if (conf[y * w + x] < 0.60f) {
                        trySeedExterior(y * w + x)
                    }
                }
            }
        }

        while (qHead < qTail) {
            val curr = queue[qHead++]
            val cx = curr % w
            val cy = curr / w
            if (cx > 0) trySeedExterior(curr - 1)
            if (cx + 1 < w) trySeedExterior(curr + 1)
            if (cy > 0) trySeedExterior(curr - w)
            if (cy + 1 < h) trySeedExterior(curr + w)
        }

        for (i in 0 until total) {
            if (isExterior[i]) conf[i] = 0f
        }
        if (skeleton != null) {
            for (y in 0 until h) {
                val ny = (y + 0.5f) / h.toFloat()
                val rowOff = y * w
                for (x in 0 until w) {
                    val nx = (x + 0.5f) / w.toFloat()
                    if (skeleton.isInsideStrictInnerTorso(nx, ny)) {
                        val idx = rowOff + x
                        isExterior[idx] = false
                        conf[idx] = 1f
                    }
                }
            }
        }

        // Compute foreground vertical & horizontal silhouette bounds for solid interior body enforcement
        var fgMinY = h
        var fgMaxY = -1
        val rowLeft = IntArray(h) { w }
        val rowRight = IntArray(h) { -1 }
        for (y in 0 until h) {
            val rowOff = y * w
            for (x in 0 until w) {
                if (!isExterior[rowOff + x] && conf[rowOff + x] >= 0.45f) {
                    if (y < fgMinY) fgMinY = y
                    if (y > fgMaxY) fgMaxY = y
                    if (x < rowLeft[y]) rowLeft[y] = x
                    if (x > rowRight[y]) rowRight[y] = x
                }
            }
        }

        val hasLowerLimbPose = skeleton?.let {
            it.leftKnee != null || it.rightKnee != null || it.leftAnkle != null || it.rightAnkle != null || (poseRegions?.hasAnyShoe() == true)
        } ?: false
        val skHipY = skeleton?.hipY
        val crotchRow = if (skHipY != null) {
            ((skHipY + 0.03f) * h).toInt().coerceIn(0, h - 1)
        } else if (fgMaxY > fgMinY) {
            (fgMinY + ((fgMaxY - fgMinY) * 0.62f).toInt()).coerceIn(0, h - 1)
        } else {
            (h * 0.62f).toInt()
        }

        // 3. Enclosed Inner-Gap Detection ONLY in anatomical gap zones (between legs below crotch, under-arm loops)
        // NEVER punch holes inside torso, chest, stomach, white shirts, arms, or legs.
        val pocketVisited = BooleanArray(total)
        val pocketIndices = IntArray(total)
        for (y in 2 until h - 2) {
            val rowOff = y * w
            val ny = (y + 0.5f) / h.toFloat()
            val isLower = y >= hipRow
            for (x in 2 until w - 2) {
                val startIdx = rowOff + x
                if (isExterior[startIdx] || pocketVisited[startIdx]) continue
                if (conf[startIdx] >= 0.64f) continue
                val nx = (x + 0.5f) / w.toFloat()
                if (skeleton?.isNearBodyBone(nx, ny) == true) continue

                var pHead = 0
                var pTail = 0
                pocketVisited[startIdx] = true
                pocketIndices[pTail++] = startIdx

                var sumConf = 0f
                var underArmHits = 0
                var legGapHits = 0
                var torsoCoreHits = 0
                var sumR = 0L
                var sumG = 0L
                var sumB = 0L
                var borderFgR = 0L
                var borderFgG = 0L
                var borderFgB = 0L
                var borderFgCount = 0

                while (pHead < pTail) {
                    val cIdx = pocketIndices[pHead++]
                    val cx = cIdx % w
                    val cy = cIdx / w
                    val cnx = (cx + 0.5f) / w.toFloat()
                    val cny = (cy + 0.5f) / h.toFloat()
                    sumConf += conf[cIdx]
                    if (skeleton?.isInsideTorsoOrHeadCore(cnx, cny) == true) torsoCoreHits++
                    if (skeleton?.isInUnderArmGapZone(cnx, cny) == true) underArmHits++
                    if (skeleton?.isInBetweenLegsGapZone(cnx, cny) == true || (hasLowerLimbPose && cy > crotchRow && conf[cIdx] < 0.52f)) {
                        legGapHits++
                    }
                    val px = pixels[cIdx]
                    sumR += (px ushr 16) and 0xFF
                    sumG += (px ushr 8) and 0xFF
                    sumB += px and 0xFF

                    val nbOffsets = intArrayOf(-1, 1, -w, w)
                    for (off in nbOffsets) {
                        val nIdx = cIdx + off
                        if (nIdx < 0 || nIdx >= total) continue
                        val nbx = nIdx % w
                        val nby = nIdx / w
                        if (abs(nbx - cx) + abs(nby - cy) != 1) continue
                        if (isExterior[nIdx] || pocketVisited[nIdx]) continue
                        val nConf = conf[nIdx]
                        if (nConf >= 0.64f) {
                            val npx = pixels[nIdx]
                            borderFgR += (npx ushr 16) and 0xFF
                            borderFgG += (npx ushr 8) and 0xFF
                            borderFgB += npx and 0xFF
                            borderFgCount++
                        } else {
                            val nbxN = (nbx + 0.5f) / w.toFloat()
                            val nbyN = (nby + 0.5f) / h.toFloat()
                            val onShoe = (poseRegions?.classifyPixel(nbxN, nbyN, strictCore = true) ?: 0) != 0
                            if (!onShoe && skeleton?.isNearBodyBone(nbxN, nbyN) != true) {
                                pocketVisited[nIdx] = true
                                pocketIndices[pTail++] = nIdx
                            }
                        }
                    }
                }

                if (pTail <= 0) continue
                // Never delete any pocket touching the torso/chest/stomach core
                if (torsoCoreHits > 0) continue

                val avgConf = sumConf / pTail.toFloat()
                val avgR = (sumR / pTail).toInt()
                val avgG = (sumG / pTail).toInt()
                val avgB = (sumB / pTail).toInt()
                val bgDist = minBgDist(avgR, avgG, avgB, isLower)

                val fgDist = if (borderFgCount > 0) {
                    val fR = (borderFgR / borderFgCount).toFloat()
                    val fG = (borderFgG / borderFgCount).toFloat()
                    val fB = (borderFgB / borderFgCount).toFloat()
                    sqrt((avgR - fR) * (avgR - fR) + (avgG - fG) * (avgG - fG) + (avgB - fB) * (avgB - fB))
                } else 999f

                val inLegGapRatio = legGapHits.toFloat() / pTail.toFloat()
                val inUnderArmRatio = underArmHits.toFloat() / pTail.toFloat()

                val removeLegGap = inLegGapRatio >= 0.35f && (
                    avgConf < 0.44f || bgDist + 6f < fgDist || (bgDist < 40f && avgConf < 0.58f)
                    )
                val removeUnderArmGap = inUnderArmRatio >= 0.35f && (
                    avgConf < 0.44f || bgDist + 8f < fgDist || (bgDist < 38f && avgConf < 0.56f)
                    )

                if (removeLegGap || removeUnderArmGap) {
                    for (k in 0 until pTail) {
                        val pIdx = pocketIndices[k]
                        conf[pIdx] = 0f
                        isExterior[pIdx] = true
                    }
                }
            }
        }

        // 3B. Strict Interior Body Lock: EVERY remaining non-exterior pixel inside the body (torso, chest, stomach, white shirt, arms, legs)
        // is guaranteed 100% solid (1.0f -> alpha = 255)
        if (fgMaxY > fgMinY) {
            for (y in fgMinY..fgMaxY) {
                val rl = rowLeft[y]
                val rr = rowRight[y]
                if (rr <= rl) continue
                val rowOff = y * w
                val ny = (y + 0.5f) / h.toFloat()
                val inTorsoY = y < crotchRow
                val rowMid = (rl + rr) * 0.5f
                val rowSpan = (rr - rl).toFloat()
                for (x in rl..rr) {
                    val idx = rowOff + x
                    if (isExterior[idx]) continue
                    val nx = (x + 0.5f) / w.toFloat()
                    val inTorsoCore = skeleton?.isInsideTorsoOrHeadCore(nx, ny) == true
                    val nearSpine = abs(x - rowMid) <= rowSpan * 0.42f
                    if (inTorsoCore || inTorsoY || nearSpine || conf[idx] >= 0.16f) {
                        conf[idx] = 1f
                    }
                }
            }
        }

        // 4. Keep primary human subject connected component (+ pose-linked shoe components) and strip far background noise
        val compLabel = IntArray(total)
        val compSizes = IntArray(total / 4 + 16)
        val compHasPose = BooleanArray(total / 4 + 16)
        var nextComp = 1
        var bestComp = 0
        var bestCompSize = 0
        val bfs = IntArray(total)

        for (i in 0 until total) {
            if (conf[i] < 0.48f || compLabel[i] != 0) continue
            val cid = nextComp++
            if (cid >= compSizes.size) break
            var head = 0
            var tail = 0
            compLabel[i] = cid
            bfs[tail++] = i
            var hasPose = false
            while (head < tail) {
                val cIdx = bfs[head++]
                val cx = cIdx % w
                val cy = cIdx / w
                if (!hasPose) {
                    val cnx = (cx + 0.5f) / w.toFloat()
                    val cny = (cy + 0.5f) / h.toFloat()
                    if (skeleton?.isNearBodyBone(cnx, cny) == true) hasPose = true
                }
                if (cx > 0 && conf[cIdx - 1] >= 0.48f && compLabel[cIdx - 1] == 0) {
                    compLabel[cIdx - 1] = cid; bfs[tail++] = cIdx - 1
                }
                if (cx + 1 < w && conf[cIdx + 1] >= 0.48f && compLabel[cIdx + 1] == 0) {
                    compLabel[cIdx + 1] = cid; bfs[tail++] = cIdx + 1
                }
                if (cy > 0 && conf[cIdx - w] >= 0.48f && compLabel[cIdx - w] == 0) {
                    compLabel[cIdx - w] = cid; bfs[tail++] = cIdx - w
                }
                if (cy + 1 < h && conf[cIdx + w] >= 0.48f && compLabel[cIdx + w] == 0) {
                    compLabel[cIdx + w] = cid; bfs[tail++] = cIdx + w
                }
            }
            compSizes[cid] = tail
            compHasPose[cid] = hasPose
            if (tail > bestCompSize) {
                bestCompSize = tail
                bestComp = cid
            }
        }

        if (bestComp > 0) {
            val minKeepSize = max(12, (bestCompSize * 0.015f).toInt())
            for (i in 0 until total) {
                val cid = compLabel[i]
                if (cid != 0 && cid != bestComp) {
                    val keep = compHasPose[cid] && compSizes[cid] >= 10 || compSizes[cid] >= minKeepSize
                    if (!keep) {
                        conf[i] = 0f
                    }
                }
            }
        }
    }

    /**
     * Separable O(N) Box Mean Filter for Fast Guided Filter.
     */
    private fun boxMean(src: FloatArray, w: Int, h: Int, radius: Int): FloatArray {
        val temp = FloatArray(w * h)
        val dst = FloatArray(w * h)
        for (y in 0 until h) {
            val rowOff = y * w
            var sum = 0f
            var count = 0
            for (x in 0..min(radius, w - 1)) {
                sum += src[rowOff + x]
                count++
            }
            for (x in 0 until w) {
                if (x > radius) {
                    sum -= src[rowOff + x - radius - 1]
                    count--
                }
                val addX = x + radius
                if (x > 0 && addX < w) {
                    sum += src[rowOff + addX]
                    count++
                }
                temp[rowOff + x] = sum / count.coerceAtLeast(1)
            }
        }
        for (x in 0 until w) {
            var sum = 0f
            var count = 0
            for (y in 0..min(radius, h - 1)) {
                sum += temp[y * w + x]
                count++
            }
            for (y in 0 until h) {
                if (y > radius) {
                    sum -= temp[(y - radius - 1) * w + x]
                    count--
                }
                val addY = y + radius
                if (y > 0 && addY < h) {
                    sum += temp[addY * w + x]
                    count++
                }
                dst[y * w + x] = sum / count.coerceAtLeast(1)
            }
        }
        return dst
    }

    /**
     * Memory-safe Fast Guided Filter (He & Sun): computes linear edge coefficients (meanA, meanB) at
     * <= 1280px long-edge, then evaluates q = meanA * lum_orig + meanB at full native resolution for
     * razor-sharp 1px hair/clothing/shoe boundaries with minimal RAM overhead.
     */
    fun refineAndCompositeFullRes(
        origBitmap: Bitmap,
        workConf: FloatArray,
        workW: Int,
        workH: Int,
        poseRegions: PoseFootRegions?
    ): Bitmap {
        val origW = origBitmap.width
        val origH = origBitmap.height
        val total = origW * origH

        val srcPixels = IntArray(total)
        origBitmap.getPixels(srcPixels, 0, origW, 0, 0, origW, origH)

        // 1. Compute Fast Guided Filter coefficients at bounded <= 1280px long edge
        val maxOrig = max(origW, origH)
        val guideScale = if (maxOrig > 1280) 1280f / maxOrig.toFloat() else 1f
        val guideW = (origW * guideScale).toInt().coerceAtLeast(32)
        val guideH = (origH * guideScale).toInt().coerceAtLeast(32)
        val guideTotal = guideW * guideH
        val guideRadius = (min(guideW, guideH) / 220).coerceIn(3, 6)

        val (meanA, meanB) = run {
            val gLum = FloatArray(guideTotal)
            val gP = FloatArray(guideTotal)
            val gLumSq = FloatArray(guideTotal)
            val gLumP = FloatArray(guideTotal)

            val sxScale = (origW - 1).coerceAtLeast(1).toFloat() / (guideW - 1).coerceAtLeast(1).toFloat()
            val syScale = (origH - 1).coerceAtLeast(1).toFloat() / (guideH - 1).coerceAtLeast(1).toFloat()
            val wxScale = (workW - 1).coerceAtLeast(1).toFloat() / (guideW - 1).coerceAtLeast(1).toFloat()
            val wyScale = (workH - 1).coerceAtLeast(1).toFloat() / (guideH - 1).coerceAtLeast(1).toFloat()

            for (gy in 0 until guideH) {
                val oy = (gy * syScale).toInt().coerceIn(0, origH - 1)
                val oRow = oy * origW

                val wfy = gy * wyScale
                val wy0 = wfy.toInt().coerceIn(0, workH - 1)
                val wy1 = (wy0 + 1).coerceAtMost(workH - 1)
                val wdy = wfy - wy0
                val wr0 = wy0 * workW
                val wr1 = wy1 * workW

                val gRow = gy * guideW
                for (gx in 0 until guideW) {
                    val ox = (gx * sxScale).toInt().coerceIn(0, origW - 1)
                    val c = srcPixels[oRow + ox]
                    val l = (0.299f * ((c ushr 16) and 0xFF) + 0.587f * ((c ushr 8) and 0xFF) + 0.114f * (c and 0xFF)) / 255f

                    val wfx = gx * wxScale
                    val wx0 = wfx.toInt().coerceIn(0, workW - 1)
                    val wx1 = (wx0 + 1).coerceAtMost(workW - 1)
                    val wdx = wfx - wx0
                    val top = workConf[wr0 + wx0] + (workConf[wr0 + wx1] - workConf[wr0 + wx0]) * wdx
                    val bot = workConf[wr1 + wx0] + (workConf[wr1 + wx1] - workConf[wr1 + wx0]) * wdx
                    val p = (top + (bot - top) * wdy).coerceIn(0f, 1f)

                    val gi = gRow + gx
                    gLum[gi] = l
                    gP[gi] = p
                    gLumSq[gi] = l * l
                    gLumP[gi] = l * p
                }
            }

            val meanI = boxMean(gLum, guideW, guideH, guideRadius)
            val meanP = boxMean(gP, guideW, guideH, guideRadius)
            val corrI = boxMean(gLumSq, guideW, guideH, guideRadius)
            val corrIP = boxMean(gLumP, guideW, guideH, guideRadius)

            val aCoeff = FloatArray(guideTotal)
            val bCoeff = FloatArray(guideTotal)
            val eps = 0.005f
            for (i in 0 until guideTotal) {
                val mI = meanI[i]
                val mP = meanP[i]
                val varI = (corrI[i] - mI * mI).coerceAtLeast(0f)
                val covIP = corrIP[i] - mI * mP
                val a = covIP / (varI + eps)
                aCoeff[i] = a
                bCoeff[i] = mP - a * mI
            }
            boxMean(aCoeff, guideW, guideH, guideRadius) to boxMean(bCoeff, guideW, guideH, guideRadius)
        }

        // 2. Evaluate upsampled guided filter against full-resolution luminance and tighten alpha edge
        val alphaInt = IntArray(total)
        val hasPose = poseRegions != null && poseRegions.hasAnyShoe()
        val fallbackShoeStartY = (origH * 0.85f).toInt()
        val wScaleX = (workW - 1).coerceAtLeast(1).toFloat() / (origW - 1).coerceAtLeast(1).toFloat()
        val wScaleY = (workH - 1).coerceAtLeast(1).toFloat() / (origH - 1).coerceAtLeast(1).toFloat()
        val gScaleX = (guideW - 1).coerceAtLeast(1).toFloat() / (origW - 1).coerceAtLeast(1).toFloat()
        val gScaleY = (guideH - 1).coerceAtLeast(1).toFloat() / (origH - 1).coerceAtLeast(1).toFloat()

        for (y in 0 until origH) {
            val rowOff = y * origW
            val ny = (y + 0.5f) / origH.toFloat()

            val wfy = y * wScaleY
            val wy0 = wfy.toInt().coerceIn(0, workH - 1)
            val wy1 = (wy0 + 1).coerceAtMost(workH - 1)
            val wdy = wfy - wy0
            val wr0 = wy0 * workW
            val wr1 = wy1 * workW

            val gfy = y * gScaleY
            val gy0 = gfy.toInt().coerceIn(0, guideH - 1)
            val gy1 = (gy0 + 1).coerceAtMost(guideH - 1)
            val gdy = gfy - gy0
            val gr0 = gy0 * guideW
            val gr1 = gy1 * guideW

            for (x in 0 until origW) {
                val i = rowOff + x

                val wfx = x * wScaleX
                val wx0 = wfx.toInt().coerceIn(0, workW - 1)
                val wx1 = (wx0 + 1).coerceAtMost(workW - 1)
                val wdx = wfx - wx0
                val wTop = workConf[wr0 + wx0] + (workConf[wr0 + wx1] - workConf[wr0 + wx0]) * wdx
                val wBot = workConf[wr1 + wx0] + (workConf[wr1 + wx1] - workConf[wr1 + wx0]) * wdx
                val coarse = (wTop + (wBot - wTop) * wdy).coerceIn(0f, 1f)

                val nx = (x + 0.5f) / origW.toFloat()
                val inShoeZone = if (hasPose) {
                    poseRegions!!.classifyPixel(nx, ny, strictCore = false) != 0
                } else {
                    y >= fallbackShoeStartY
                }

                val refined = if (coarse >= 0.96f) {
                    1f
                } else if (coarse <= 0.04f) {
                    0f
                } else {
                    val gfx = x * gScaleX
                    val gx0 = gfx.toInt().coerceIn(0, guideW - 1)
                    val gx1 = (gx0 + 1).coerceAtMost(guideW - 1)
                    val gdx = gfx - gx0
                    val aTop = meanA[gr0 + gx0] + (meanA[gr0 + gx1] - meanA[gr0 + gx0]) * gdx
                    val aBot = meanA[gr1 + gx0] + (meanA[gr1 + gx1] - meanA[gr1 + gx0]) * gdx
                    val localA = aTop + (aBot - aTop) * gdy

                    val bTop = meanB[gr0 + gx0] + (meanB[gr0 + gx1] - meanB[gr0 + gx0]) * gdx
                    val bBot = meanB[gr1 + gx0] + (meanB[gr1 + gx1] - meanB[gr1 + gx0]) * gdx
                    val localB = bTop + (bBot - bTop) * gdy

                    val c = srcPixels[i]
                    val l = (0.299f * ((c ushr 16) and 0xFF) + 0.587f * ((c ushr 8) and 0xFF) + 0.114f * (c and 0xFF)) / 255f
                    val q = (localA * l + localB).coerceIn(0f, 1f)
                    // Blend guided edge with coarse probability inside pose-protected shoes so bright white sneakers never erode
                    val blended = if (inShoeZone && coarse >= 0.58f) {
                        max(coarse, q * 0.65f + coarse * 0.35f)
                    } else {
                        q
                    }
                    // Contrast S-curve tightening so studio haze (< 0.24) drops to 0 and core (>= 0.88) locks to 1
                    val lowCut = if (inShoeZone) 0.34f else 0.24f
                    val highCut = 0.88f
                    when {
                        blended <= lowCut -> 0f
                        blended >= highCut -> 1f
                        else -> {
                            val t = ((blended - lowCut) / (highCut - lowCut)).coerceIn(0f, 1f)
                            t * t * (3f - 2f * t)
                        }
                    }
                }
                alphaInt[i] = (refined * 255f).toInt().coerceIn(0, 255)
            }
        }

        // 3. Fast 1-2px Edge Color Decontamination (eliminates white/grey outline halo around hair, pants, shoes)
        val outPixels = IntArray(total)
        val sampleRad = (min(origW, origH) / 360).coerceIn(3, 5)
        for (y in 0 until origH) {
            val rowOff = y * origW
            val ny = (y + 0.5f) / origH.toFloat()
            for (x in 0 until origW) {
                val idx = rowOff + x
                var a = alphaInt[idx]
                if (a <= 6) {
                    outPixels[idx] = 0x00000000
                    continue
                }

                // Check if within 2px of background (alpha == 0)
                val touchesBg1 =
                    (x > 0 && alphaInt[idx - 1] <= 6) ||
                        (x + 1 < origW && alphaInt[idx + 1] <= 6) ||
                        (y > 0 && alphaInt[idx - origW] <= 6) ||
                        (y + 1 < origH && alphaInt[idx + origW] <= 6)

                val nearBg2 = touchesBg1 || a < 248 ||
                    (x > 1 && alphaInt[idx - 2] <= 6) ||
                    (x + 2 < origW && alphaInt[idx + 2] <= 6) ||
                    (y > 1 && alphaInt[idx - 2 * origW] <= 6) ||
                    (y + 2 < origH && alphaInt[idx + 2 * origW] <= 6)

                val px = srcPixels[idx]
                if (!nearBg2) {
                    outPixels[idx] = (0xFF shl 24) or (px and 0x00FFFFFF)
                    continue
                }

                var r = (px ushr 16) and 0xFF
                var g = (px ushr 8) and 0xFF
                var b = px and 0xFF

                // Sample nearest solid interior FG (alpha == 255) and nearest exterior BG (alpha == 0)
                var fgR = 0L; var fgG = 0L; var fgB = 0L; var fgCnt = 0
                var bgR = 0L; var bgG = 0L; var bgB = 0L; var bgCnt = 0
                for (dy in -sampleRad..sampleRad step 2) {
                    val sy = (y + dy).coerceIn(0, origH - 1)
                    val sRow = sy * origW
                    for (dx in -sampleRad..sampleRad step 2) {
                        val sx = (x + dx).coerceIn(0, origW - 1)
                        val sIdx = sRow + sx
                        val sa = alphaInt[sIdx]
                        val sc = srcPixels[sIdx]
                        if (sa == 255 && abs(dx) + abs(dy) >= 2) {
                            fgR += (sc ushr 16) and 0xFF
                            fgG += (sc ushr 8) and 0xFF
                            fgB += sc and 0xFF
                            fgCnt++
                        } else if (sa <= 6) {
                            bgR += (sc ushr 16) and 0xFF
                            bgG += (sc ushr 8) and 0xFF
                            bgB += sc and 0xFF
                            bgCnt++
                        }
                    }
                }

                if (fgCnt > 0) {
                    val fR = (fgR / fgCnt).toFloat()
                    val fG = (fgG / fgCnt).toFloat()
                    val fB = (fgB / fgCnt).toFloat()
                    val nx = (x + 0.5f) / origW.toFloat()
                    val inShoeZone = if (hasPose) {
                        poseRegions!!.classifyPixel(nx, ny, strictCore = false) != 0
                    } else {
                        y >= fallbackShoeStartY
                    }

                    if (bgCnt > 0) {
                        val bR = (bgR / bgCnt).toFloat()
                        val bG = (bgG / bgCnt).toFloat()
                        val bB = (bgB / bgCnt).toFloat()
                        val vR = fR - bR
                        val vG = fG - bG
                        val vB = fB - bB
                        val lenSq = vR * vR + vG * vG + vB * vB

                        if (lenSq > 625f) { // FG and BG are meaningfully distinct (>25 RGB dist)
                            val dot = (r - bR) * vR + (g - bG) * vG + (b - bB) * vB
                            val projT = (dot / lenSq).coerceIn(0f, 1f)

                            // If outer pixel is overwhelmingly background spill (<28% along B->F), drop halo
                            if (projT < 0.28f && (a < 215 || touchesBg1)) {
                                outPixels[idx] = 0x00000000
                                continue
                            }

                            val bLum = 0.299f * bR + 0.587f * bG + 0.114f * bB
                            val pxLum = 0.299f * r + 0.587f * g + 0.114f * b
                            val fLum = 0.299f * fR + 0.587f * fG + 0.114f * fB
                            val isLightHalo = bLum > 165f && pxLum > fLum + 18f

                            val deconMix = when {
                                touchesBg1 && (a < 225 || isLightHalo) -> 0.88f
                                touchesBg1 -> if (inShoeZone && !isLightHalo) 0.55f else 0.72f
                                a < 240 -> 0.65f
                                else -> 0.38f
                            }
                            r = (r * (1f - deconMix) + fR * deconMix).toInt().coerceIn(0, 255)
                            g = (g * (1f - deconMix) + fG * deconMix).toInt().coerceIn(0, 255)
                            b = (b * (1f - deconMix) + fB * deconMix).toInt().coerceIn(0, 255)
                        }
                    } else if (a < 240) {
                        val pull = 0.65f
                        r = (r * (1f - pull) + fR * pull).toInt().coerceIn(0, 255)
                        g = (g * (1f - pull) + fG * pull).toInt().coerceIn(0, 255)
                        b = (b * (1f - pull) + fB * pull).toInt().coerceIn(0, 255)
                    }
                }

                if (a >= 248 && !touchesBg1) a = 255
                outPixels[idx] = (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        val outBitmap = Bitmap.createBitmap(origW, origH, Bitmap.Config.ARGB_8888)
        outBitmap.setPixels(outPixels, 0, origW, 0, 0, origW, origH)
        registerPoseFootRegions(outBitmap, poseRegions)
        return outBitmap
    }
}

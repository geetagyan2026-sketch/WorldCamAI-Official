package com.aistudio.worldcamai.smxuqv

import android.graphics.Bitmap
import android.util.Base64
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.WeakHashMap
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

enum class VoiceOutputType {
    PHOTO,
    VIDEO_15S
}

enum class VoicePositionHint {
    AUTO,
    LEFT,
    CENTER,
    RIGHT
}

enum class VoiceSizeHint {
    AUTO,
    SMALL,
    MEDIUM,
    LARGE
}

enum class VoiceSceneMood {
    AUTO,
    SNOW,
    NIGHT,
    SUNSET,
    BEACH,
    DESERT,
    MOUNTAIN
}

enum class VoiceIntentAction {
    UNDO,
    ADJUST_CURRENT_SCENE,
    CHANGE_LOCATION
}

enum class VoiceLanguageStyle {
    HINDI_DEVANAGARI,
    HINGLISH,
    ENGLISH
}

enum class VoiceScaleDelta {
    NONE,
    SCALE_DOWN,
    SCALE_UP,
    SCALE_RESET
}

enum class VoicePositionNudge {
    NONE,
    NUDGE_LEFT,
    NUDGE_RIGHT,
    STEP_BACK,
    STEP_FORWARD
}

enum class VoiceShadowHint {
    NONE,
    SOFT,
    NATURAL,
    DEEP_3D
}

enum class VoiceLightingHint {
    NONE,
    MATCH_AUTO,
    WARM,
    COOL
}

enum class VoiceModeRequest {
    NONE,
    VIDEO_15S,
    PHOTO,
    LIVE_CAMERA_VIDEO,
    START_LIVE_RECORDING,
    STOP_LIVE_RECORDING,
    FLIP_LIVE_CAMERA,
    FRONT_LIVE_CAMERA,
    BACK_LIVE_CAMERA
}

data class ParsedVoiceCommand(
    val rawTranscript: String,
    val locationQuery: String,
    val displayLocation: String,
    val outputType: VoiceOutputType,
    val positionHint: VoicePositionHint,
    val sizeHint: VoiceSizeHint,
    val wantsMusic: Boolean,
    val sceneMood: VoiceSceneMood,
    val preferSidePlacement: Boolean = false,
    val wantsWalkwayOrGroundFix: Boolean = false,
    val intentAction: VoiceIntentAction = VoiceIntentAction.CHANGE_LOCATION,
    val hasExplicitLocation: Boolean = true,
    val hasExplicitOutputType: Boolean = false,
    val languageStyle: VoiceLanguageStyle = VoiceLanguageStyle.ENGLISH,
    val scaleDelta: VoiceScaleDelta = VoiceScaleDelta.NONE,
    val positionNudge: VoicePositionNudge = VoicePositionNudge.NONE,
    val shadowHint: VoiceShadowHint = VoiceShadowHint.NONE,
    val lightingHint: VoiceLightingHint = VoiceLightingHint.NONE,
    val modeRequest: VoiceModeRequest = VoiceModeRequest.NONE
)

data class VoiceAutoRealismPlan(
    val userScale: Float,
    val userXOffset: Float,
    val userYOffset: Float,
    val shadowDepth: Float,
    val environmentBlend: Float,
    val isCoolToneScene: Boolean,
    val summaryLabel: String,
    val waterGuardrailTriggered: Boolean = false,
    val hasSecondPerson: Boolean = false,
    val userScale2: Float = 0.72f,
    val userXOffset2: Float = 150f,
    val userYOffset2: Float = 60f,
    val shadowDepth2: Float = 0.35f
)

data class VoiceUndoSnapshot(
    val bgBitmap: Bitmap?,
    val bgLighting: AdaptiveSceneLighting?,
    val selectedLandmark: TravelLandmark,
    val selectedCustomPlace: GooglePlaceResult?,
    val customLocationName: String,
    val isSearchingCustomLocation: Boolean,
    val userScale: Float,
    val userXOffset: Float,
    val userYOffset: Float,
    val isGroundLockEnabled: Boolean,
    val shadowDepth: Float,
    val environmentBlend: Float,
    val isCoolToneScene: Boolean,
    val isVideoMode: Boolean,
    val visualAnalysisStatus: String,
    val userScale2: Float = 0.72f,
    val userXOffset2: Float = 150f,
    val userYOffset2: Float = 60f,
    val shadowDepth2: Float = 0.35f,
    val isGroundLockEnabled2: Boolean = false
)

private val hindiToEnglishLocationTerms = linkedMapOf(
    "मनाली" to "Manali",
    "शिमला" to "Shimla",
    "ताजमहल" to "Taj Mahal",
    "ताज महल" to "Taj Mahal",
    "tajmahal" to "Taj Mahal",
    "लाल किला" to "Red Fort Delhi",
    "कुतुब मीनार" to "Qutub Minar Delhi",
    "चारमीनार" to "Charminar Hyderabad",
    "गेटवे ऑफ इंडिया" to "Gateway of India Mumbai",
    "मरीन ड्राइव" to "Marine Drive Mumbai",
    "रोहतांग" to "Rohtang Pass Manali",
    "नैनीताल" to "Nainital Lake",
    "मसूरी" to "Mussoorie Hills",
    "दार्जिलिंग" to "Darjeeling Hills",
    "ऊटी" to "Ooty Hills",
    "कन्याकुमारी" to "Kanyakumari",
    "पेरिस" to "Paris Eiffel Tower",
    "एफिल टॉवर" to "Eiffel Tower Paris",
    "एफिल टावर" to "Eiffel Tower Paris",
    "लंदन" to "London Big Ben",
    "दुबई बीच" to "Dubai Beach",
    "दुबई" to "Dubai Burj Khalifa",
    "बुर्ज खलीफा" to "Burj Khalifa Dubai",
    "न्यूयॉर्क" to "New York Times Square",
    "टोक्यो" to "Tokyo",
    "जापान" to "Mount Fuji Japan",
    "माउंट फूजी" to "Mount Fuji Japan",
    "स्विट्जरलैंड" to "Swiss Alps Switzerland",
    "स्विट्ज़रलैंड" to "Swiss Alps Switzerland",
    "कश्मीर" to "Kashmir Dal Lake",
    "सोनमर्ग" to "Sonmarg Kashmir",
    "गुलमर्ग" to "Gulmarg snow Kashmir",
    "लद्दाख" to "Ladakh Pangong Lake",
    "लेह" to "Leh Ladakh",
    "जयपुर" to "Hawa Mahal Jaipur",
    "हवा महल" to "Hawa Mahal Jaipur",
    "जैसलमेर" to "Jaisalmer Thar Desert",
    "गोवा बीच" to "Goa Beach",
    "गोवा" to "Goa Beach",
    "केरल" to "Kerala Backwaters",
    "ऋषिकेश" to "Rishikesh Ganga",
    "हरिद्वार" to "Haridwar Har Ki Pauri",
    "वाराणसी" to "Varanasi Ghats",
    "बनारस" to "Varanasi Ghats",
    "मुंबई" to "Gateway of India Mumbai",
    "दिल्ली" to "India Gate Delhi",
    "इंडिया गेट" to "India Gate Delhi",
    "केदारनाथ" to "Kedarnath Temple snow",
    "बद्रीनाथ" to "Badrinath Temple",
    "उदयपुर" to "Udaipur Lake Palace",
    "जोधपुर" to "Mehrangarh Fort Jodhpur",
    "जल महल" to "Jal Mahal Jaipur",
    "आमेर" to "Amber Fort Jaipur",
    "जंतर मंतर" to "Jantar Mantar Jaipur",
    "कोटा" to "Kota Chambal Riverfront",
    "अयोध्या" to "Ayodhya Ram Mandir",
    "राम मंदिर" to "Ram Mandir Ayodhya",
    "गोल्डन टेम्पल" to "Golden Temple Amritsar",
    "स्वर्ण मंदिर" to "Golden Temple Amritsar",
    "लंदन ब्रिज" to "Tower Bridge London",
    "हम्पी" to "Hampi Karnataka",
    "आगरा" to "Taj Mahal Agra",
    "रोम" to "Colosseum Rome",
    "इटली" to "Colosseum Rome Italy",
    "मालदीव" to "Maldives beach",
    "बाली" to "Bali Indonesia",
    "सिंगापुर" to "Marina Bay Sands Singapore",
    "थाईलैंड" to "Thailand beach",
    "सैंटोरिनी" to "Santorini Greece",
    "ग्रीस" to "Santorini Greece",
    "बर्फ" to "snow",
    "बर्फीले" to "snow mountains",
    "पहाड़" to "mountains",
    "पहाड़ों" to "mountains",
    "पहाड़ों में" to "mountains",
    "रेगिस्तान" to "desert sand dunes",
    "समुद्र" to "ocean beach",
    "बीच" to "beach",
    "झील" to "lake",
    "नदी" to "river",
    "रात" to "night lights",
    "शाम" to "sunset",
    "सूरज" to "sunset"
)

private val hindiStopWords = setOf(
    "मेरी", "मेरा", "मेरे", "मुझे", "मुझको", "हमारी", "हमारा", "हमको", "हमें", "मैं", "मे", "में",
    "फोटो", "तस्वीर", "पिक्चर", "इमेज", "सेल्फी", "विडिओ", "वीडियो", "रील", "रिल",
    "का", "की", "के", "को", "से", "पर", "तक", "साथ", "वाला", "वाली",
    "बना", "बनाओ", "बनाई", "दो", "दीजिए", "कर", "करो", "करदो", "करना", "करके", "दे", "देना", "है", "हूं",
    "एक", "और", "या", "प्लीज", "ज़रा", "जरा", "अभी", "तुरंत", "अच्छी", "अच्छा", "सुंदर", "रियल", "नेचुरल", "बिल्कुल",
    "चाहिए", "लगा", "लगाओ", "डालो", "सामने", "तरफ", "थोड़ा", "थोड़ी", "थोड़े", "ज्यादा", "ज़्यादा",
    "खड़ा", "खड़े", "खड़ी", "सेट", "रखो", "लाओ", "ले", "चलो", "जाओ", "बैठाओ", "दिखाओ", "भेजो",
    "ज़मीन", "जमीन", "धरती", "फर्श", "रास्ते", "वॉकवे", "सड़क", "सही", "जगह", "स्थान",
    "साइड", "कोने", "कोना", "किनारे", "बाजू", "पास", "दूर", "नजदीक", "करीब", "आगे", "पीछे",
    "गाना", "गाने", "म्यूजिक", "संगीत", "साउंड", "सॉन्ग",
    "बाएं", "बाएँ", "दाएं", "दाएँ", "बीच", "छोटा", "छोटी", "बड़ा", "बड़ी", "सेकंड", "सेकेंड",
    "पहले", "जैसा", "वापस", "पिछला", "पुराना", "अनडू", "लाइट", "रोशनी", "मैच", "शैडो", "परछाई", "सॉफ्ट", "हल्की", "गहरी", "ज़ूम", "साइज", "मोड",
    "लाइव", "कैमरा", "खोलो", "खोल", "चालू", "रिकॉर्ड", "रिकॉर्डिंग", "शुरू", "रोको", "बंद", "घुमाओ", "पलटो", "दूसरा", "फ्रंट", "बैक",
    "meri", "mera", "mere", "mujhe", "mujhko", "humko", "hume", "humein", "main", "mai", "hum", "aap", "mujko",
    "photo", "selfie", "tasveer", "image", "pic", "picture", "portrait",
    "video", "reel", "reels", "shorts", "15s", "15sec", "15", "second", "seconds", "sec", "clip",
    "ki", "ka", "ke", "ko", "mein", "me", "par", "pe", "per", "se", "tak", "saath", "sath", "wali", "wala", "vale", "wale",
    "bana", "banao", "banado", "banaao", "banana", "do", "de", "dena", "dijiye", "kar", "karo", "kardo", "karna", "karke", "please", "pls",
    "chahiye", "laga", "lagao", "lagado", "dalo", "daalo", "rakho", "rakh", "rakhdo", "lao", "laao", "le", "chalo", "jao", "bhejo", "pahuncha",
    "khada", "khade", "khadi", "bithao", "dikhao", "dikha",
    "samne", "saamne", "taraf", "ek", "thoda", "thodi", "thode", "bahut", "zara", "jara", "aur", "bilkul", "sahi", "jagah", "jageh",
    "paas", "pas", "nazdeek", "kareeb", "dur", "door", "aage", "age", "peeche", "piche", "upar", "neeche", "niche",
    "zameen", "jameen", "jamin", "dharti", "farsh", "sadak", "raste", "raaste", "walkway", "footpath", "sidewalk", "pavement", "pathway", "path",
    "gana", "gaana", "gaane", "gane", "music", "song", "songs", "audio", "track", "bgm", "beat",
    "pehle", "pahle", "jaisa", "jaise", "wapas", "vapas", "pichla", "pichle", "purana", "purani", "undo", "revert", "restore", "reset", "cancel", "previous",
    "light", "lighting", "roshni", "relight", "match", "blend", "tone", "color", "warm", "cool", "cold", "golden", "glow",
    "shadow", "shadows", "parchhai", "parchai", "3d", "soft", "softer", "deep", "deeper", "dark", "darker", "strong", "heavy", "halki", "halka", "gehri", "gehre", "kam", "zyada", "jyada", "badhao",
    "chota", "chhota", "chhoti", "choti", "bada", "badi", "size", "zoom", "out", "in", "step", "back", "forward", "shift", "move", "closer",
    "mode", "switch", "turn", "live", "camera", "save", "record", "recording", "render", "convert",
    "kholo", "khol", "chalu", "shuru", "roko", "band", "start", "stop", "flip", "ghumao", "palto", "dusra", "doosra", "front", "exit", "close", "open",
    "create", "make", "generate", "put", "place", "edit", "show", "set", "align", "adjust", "stand", "standing", "pose", "posing", "take", "bring", "keep",
    "a", "an", "the", "in", "at", "on", "to", "into", "with", "and", "or", "of", "for", "from", "by", "my", "me", "near", "beside", "next", "onto", "here", "there", "this", "that", "it",
    "left", "right", "center", "centre", "middle", "small", "smaller", "tiny", "far", "distant", "big", "bigger", "large", "larger", "close", "closeup",
    "side", "corner", "kone", "kona", "kinare", "kinaare", "baju", "frame", "background", "bg", "location", "place", "spot", "ground", "floor", "surface",
    "natural", "realistic", "real", "perfect", "properly", "auto", "normal", "default", "medium", "little", "bit", "more", "less", "yaar", "bhai", "bro", "arre", "hey", "hi", "hello", "can", "you"
)

/**
 * Simple phonetic Devanagari -> Latin transliterator so even rural towns / unlisted landmarks
 * spoken in Hindi script resolve cleanly via keyless real-world photo search.
 */
fun transliterateDevanagariToLatin(input: String): String {
    if (input.none { it in '\u0900'..'\u097F' }) return input
    val consonants = mapOf(
        '\u0915' to "k", '\u0916' to "kh", '\u0917' to "g", '\u0918' to "gh", '\u0919' to "ng",
        '\u091A' to "ch", '\u091B' to "chh", '\u091C' to "j", '\u091D' to "jh", '\u091E' to "ny",
        '\u091F' to "t", '\u0920' to "th", '\u0921' to "d", '\u0922' to "dh", '\u0923' to "n",
        '\u0924' to "t", '\u0925' to "th", '\u0926' to "d", '\u0927' to "dh", '\u0928' to "n",
        '\u092A' to "p", '\u092B' to "ph", '\u092C' to "b", '\u092D' to "bh", '\u092E' to "m",
        '\u092F' to "y", '\u0930' to "r", '\u0932' to "l", '\u0935' to "v", '\u0936' to "sh",
        '\u0937' to "sh", '\u0938' to "s", '\u0939' to "h",
        '\u095C' to "r", '\u095D' to "rh", '\u0958' to "q", '\u0959' to "kh",
        '\u095A' to "gh", '\u095B' to "z", '\u095E' to "f"
    )
    val vowels = mapOf(
        '\u0905' to "a", '\u0906' to "aa", '\u0907' to "i", '\u0908' to "ee", '\u0909' to "u", '\u090A' to "oo",
        '\u090F' to "e", '\u0910' to "ai", '\u0913' to "o", '\u0914' to "au", '\u090B' to "ri"
    )
    val matras = mapOf(
        '\u093E' to "a", '\u093F' to "i", '\u0940' to "i", '\u0941' to "u", '\u0942' to "u",
        '\u0947' to "e", '\u0948' to "ai", '\u094B' to "o", '\u094C' to "au", '\u0943' to "ri",
        '\u0902' to "n", '\u0901' to "n", '\u0903' to "h"
    )
    val virama = '\u094D'
    val nukta = '\u093C'

    val sb = StringBuilder()
    var i = 0
    while (i < input.length) {
        val ch = input[i]
        when {
            ch in consonants -> {
                var base = consonants[ch]!!
                val next = input.getOrNull(i + 1)
                if (next == nukta) {
                    base = when (ch) {
                        '\u091C' -> "z"
                        '\u092B' -> "f"
                        '\u0921' -> "r"
                        '\u0922' -> "rh"
                        '\u0915' -> "q"
                        else -> base
                    }
                    i++
                }
                sb.append(base)
                val after = input.getOrNull(i + 1)
                if (after == virama) {
                    i++ // suppress inherent 'a'
                } else if (after != null && after in matras) {
                    sb.append(matras[after])
                    i++
                } else if (after != null && (after in consonants || after in vowels)) {
                    sb.append('a')
                }
            }
            ch in vowels -> sb.append(vowels[ch])
            ch in matras -> sb.append(matras[ch])
            ch == virama || ch == nukta -> {}
            else -> sb.append(ch)
        }
        i++
    }
    return sb.toString()
}

private fun containsWordBoundary(text: String, phrases: List<String>): Boolean {
    return phrases.any { phrase ->
        if (phrase.any { it.code > 127 } || phrase.contains(' ')) {
            text.contains(phrase)
        } else {
            Regex("(?<![\\p{L}\\p{N}])${Regex.escape(phrase)}(?![\\p{L}\\p{N}])").containsMatchIn(text)
        }
    }
}

fun parseVoiceAiCommand(transcript: String): ParsedVoiceCommand {
    val cleanRaw = transcript.trim()
    val lower = cleanRaw.lowercase()

    // 0. Language style detection for natural friendly voice replies
    val hasDevanagari = cleanRaw.any { it in '\u0900'..'\u097F' }
    val hinglishMarkers = listOf(
        "karo", "kardo", "le chalo", "chalo", "khada", "mein", "peeche", "piche",
        "bada", "chota", "chhota", "banao", "pehle", "pahle", "jaisa", "thoda",
        "halki", "halka", "gehri", "mujhe", "mera", "meri", "aage", "paas",
        "door", "dur", "zameen", "jameen", "saamne", "samne", "wapas", "sahi",
        "pichla", "par", "taraf", "baju", "kinare", "roshni", "gana", "gaana",
        "kholo", "chalu", "roko", "ghumao", "palto", "shuru",
        "lagao", "rakho", "dikhao", "dijiye", "kijiye", "batao", "hatao", "jao", "aao", "lao"
    )
    val languageStyle = when {
        hasDevanagari -> VoiceLanguageStyle.HINDI_DEVANAGARI
        containsWordBoundary(lower, hinglishMarkers) -> VoiceLanguageStyle.HINGLISH
        else -> VoiceLanguageStyle.ENGLISH
    }

    // 1. Undo intent (checked early so "pehle jaisa karo" / "undo" never searches as location)
    val wantsUndo = containsWordBoundary(
        lower,
        listOf(
            "pehle jaisa", "pahle jaisa", "wapas pehle", "wapas karo", "vapas karo",
            "pichla wala", "pichle wala", "purana wala", "undo", "revert", "restore previous",
            "go back", "back to previous", "previous look", "cancel last", "reset position",
            "पहले जैसा", "पहला वाला", "पिछला वाला", "वापस करो", "अनडू"
        )
    )

    // 2. Output Type / Live Camera / Mode Switch Request
    val videoKeywords = listOf(
        "video", "15s", "15 sec", "15 second", "reel", "reels", "shorts", "clip",
        "वीडियो", "विडिओ", "रील", "रिल", "15 सेकंड", "15 सेकेंड", "moving"
    )
    val photoKeywords = listOf(
        "photo", "4k photo", "picture", "pic", "tasveer", "selfie", "image",
        "फोटो", "तस्वीर", "पिक्चर"
    )
    val wantsStopLiveRecord = containsWordBoundary(
        lower,
        listOf(
            "stop recording", "recording roko", "recording band", "stop live recording",
            "stop live video", "video roko", "stop video", "end recording",
            "रिकॉर्डिंग रोको", "रिकॉर्डिंग बंद", "वीडियो रोको"
        )
    )
    val wantsStartLiveRecord = !wantsStopLiveRecord && containsWordBoundary(
        lower,
        listOf(
            "live video banao", "live video record", "record 15s", "15s video record",
            "15 second video record", "15 sec video record", "video record karo",
            "live record karo", "record karo", "recording karo", "recording start",
            "recording shuru", "start recording", "start live recording", "start live video",
            "record live video", "record a video", "record video",
            "लाइव वीडियो बनाओ", "वीडियो रिकॉर्ड करो", "रिकॉर्ड करो", "रिकॉर्डिंग शुरू",
            "15 सेकंड वीडियो रिकॉर्ड"
        )
    )
    val wantsFrontCam = containsWordBoundary(
        lower,
        listOf("front camera", "selfie camera", "aage ka camera", "samne ka camera", "saamne ka camera", "फ्रंट कैमरा")
    )
    val wantsBackCam = containsWordBoundary(
        lower,
        listOf("back camera", "rear camera", "peeche ka camera", "piche ka camera", "बैक कैमरा")
    )
    val wantsFlipCam = !wantsFrontCam && !wantsBackCam && containsWordBoundary(
        lower,
        listOf(
            "flip camera", "switch camera", "camera flip", "camera ghumao",
            "camera palto", "dusra camera", "doosra camera", "कैमरा घुमाओ"
        )
    )
    val wantsExitLiveMode = containsWordBoundary(
        lower,
        listOf(
            "exit video mode", "exit live", "close live camera", "close video mode",
            "live camera band", "video mode band", "photo mode", "photo mode mein",
            "लाइव कैमरा बंद", "फोटो मोड"
        )
    )
    val explicitLiveCam = !wantsExitLiveMode && containsWordBoundary(
        lower,
        listOf(
            "live video mode", "camera video", "live camera", "open live camera",
            "open live video", "open video camera", "video camera", "live camera kholo",
            "live video kholo", "live video chalu", "live camera chalu", "video camera kholo",
            "live mode", "लाइव कैमरा", "लाइव वीडियो मोड", "लाइव वीडियो खोलो"
        )
    )
    val mentionsVideo = containsWordBoundary(lower, videoKeywords)
    val mentionsPhoto = containsWordBoundary(lower, photoKeywords) || wantsExitLiveMode
    val hasExplicitOutputType = mentionsVideo || mentionsPhoto || explicitLiveCam ||
        wantsStartLiveRecord || wantsStopLiveRecord || wantsFlipCam || wantsFrontCam || wantsBackCam

    val outputType = if (mentionsVideo || explicitLiveCam || wantsStartLiveRecord || wantsStopLiveRecord) {
        VoiceOutputType.VIDEO_15S
    } else {
        VoiceOutputType.PHOTO
    }
    val modeRequest = when {
        wantsStopLiveRecord -> VoiceModeRequest.STOP_LIVE_RECORDING
        wantsStartLiveRecord -> VoiceModeRequest.START_LIVE_RECORDING
        wantsFrontCam -> VoiceModeRequest.FRONT_LIVE_CAMERA
        wantsBackCam -> VoiceModeRequest.BACK_LIVE_CAMERA
        wantsFlipCam -> VoiceModeRequest.FLIP_LIVE_CAMERA
        wantsExitLiveMode -> VoiceModeRequest.PHOTO
        explicitLiveCam -> VoiceModeRequest.LIVE_CAMERA_VIDEO
        mentionsVideo -> VoiceModeRequest.VIDEO_15S
        mentionsPhoto -> VoiceModeRequest.PHOTO
        else -> VoiceModeRequest.NONE
    }

    // 3. Music Preference
    val musicKeywords = listOf(
        "music", "song", "songs", "audio", "bgm", "beat", "tune", "melody", "dance",
        "gana", "gaana", "gaane", "gane", "गाना", "गाने", "म्यूजिक", "संगीत", "सॉन्ग"
    )
    val wantsMusic = containsWordBoundary(lower, musicKeywords)

    // 4. Position & Nudge Hints
    val nudgeLeftIntent = containsWordBoundary(
        lower,
        listOf("thoda left", "aur left", "shift left", "move left", "thoda baye", "thoda baaye", "थोड़ा बाएं")
    )
    val nudgeRightIntent = containsWordBoundary(
        lower,
        listOf("thoda right", "aur right", "shift right", "move right", "thoda daye", "thoda daaye", "थोड़ा दाएं")
    )
    val explicitLeft = containsWordBoundary(lower, listOf("left", "बाएं", "बाएँ", "baye", "baayen", "baaye", "bayan", "बायां", "बायाँ", "बायीं"))
    val explicitRight = containsWordBoundary(lower, listOf("right", "दाएं", "दाएँ", "daye", "daayen", "daaye", "dayan", "दायां", "दायाँ", "दायीं"))
    val explicitCenter = containsWordBoundary(lower, listOf("center", "centre", "middle", "बीच में", "बीच पर", "beech mein", "beech me", "bich mein", "bich me", "mid mein", "mid me"))
    val preferSidePlacement = !explicitLeft && !explicitRight && !explicitCenter && containsWordBoundary(
        lower,
        listOf(
            "side mein", "side me", "side pe", "ek side", "side par", "kinare", "kinaare",
            "corner", "kone", "ek taraf", "baju mein", "baju me", "बगल में", "साइड में",
            "एक साइड", "किनारे", "कोने में", "बाजू में", "side"
        )
    )

    val positionHint = when {
        explicitLeft && !nudgeLeftIntent -> VoicePositionHint.LEFT
        explicitRight && !nudgeRightIntent -> VoicePositionHint.RIGHT
        explicitCenter -> VoicePositionHint.CENTER
        else -> VoicePositionHint.AUTO
    }

    val wantsWalkwayOrGroundFix = containsWordBoundary(
        lower,
        listOf(
            "walkway", "ground", "floor", "surface", "zameen", "jameen", "jamin", "farsh",
            "sahi jagah", "sahi jageh", "paani se door", "pani se door", "ज़मीन", "जमीन",
            "सही जगह", "वॉकवे", "फर्श", "रास्ते पर"
        )
    )

    // 5. Scale / Step Back / Step Forward Intent
    val stepBackIntent = !wantsBackCam && containsWordBoundary(
        lower,
        listOf(
            "thoda peeche", "peeche", "peeche jao", "peeche karo", "piche", "step back", "move back", "pull back",
            "thoda door", "thoda dur", "aur door", "aur dur", "door rakho", "dur rakho", "पीछे", "थोड़ा पीछे", "थोड़ा दूर"
        )
    )
    val stepForwardIntent = !wantsFrontCam && containsWordBoundary(
        lower,
        listOf(
            "thoda paas", "aur paas", "paas lao", "paas laao", "paas karo", "paas kardo",
            "paas rakho", "aage lao", "aage laao", "aage karo", "thoda aage", "come closer", "step forward",
            "camera ke paas", "थोड़ा पास", "और पास", "पास लाओ", "पास करो", "आगे लाओ"
        )
    )
    val scaleDownIntent = containsWordBoundary(
        lower,
        listOf(
            "thoda chota", "thoda chhota", "chota", "chhota", "chhoti", "choti", "zoom out",
            "small", "smaller", "tiny", "size kam", "size chota", "छोटा", "छोटी", "थोड़ा छोटा", "ज़ूम आउट"
        )
    )
    val scaleUpIntent = containsWordBoundary(
        lower,
        listOf(
            "thoda bada", "bada", "badi", "zoom in", "large", "big", "bigger", "larger",
            "close", "closeup", "close up", "closer", "size badhao", "size bada", "बड़ा", "बड़ी", "ज़ूम इन"
        )
    )
    val scaleResetIntent = containsWordBoundary(
        lower,
        listOf("normal size", "default size", "auto size", "medium size", "sahi size")
    )

    val positionNudge = when {
        nudgeLeftIntent -> VoicePositionNudge.NUDGE_LEFT
        nudgeRightIntent -> VoicePositionNudge.NUDGE_RIGHT
        stepBackIntent -> VoicePositionNudge.STEP_BACK
        stepForwardIntent -> VoicePositionNudge.STEP_FORWARD
        else -> VoicePositionNudge.NONE
    }

    val scaleDelta = when {
        scaleResetIntent -> VoiceScaleDelta.SCALE_RESET
        scaleDownIntent || stepBackIntent -> VoiceScaleDelta.SCALE_DOWN
        scaleUpIntent || stepForwardIntent -> VoiceScaleDelta.SCALE_UP
        else -> VoiceScaleDelta.NONE
    }

    val sizeHint = when {
        scaleDownIntent || stepBackIntent -> VoiceSizeHint.SMALL
        scaleUpIntent || stepForwardIntent -> VoiceSizeHint.LARGE
        scaleResetIntent || containsWordBoundary(lower, listOf("medium", "normal", "default")) -> VoiceSizeHint.MEDIUM
        else -> VoiceSizeHint.AUTO
    }

    // 6. Shadow & Lighting Hints
    val shadowHint = when {
        containsWordBoundary(
            lower,
            listOf(
                "deep 3d shadow", "deep shadow", "3d shadow", "dark shadow", "strong shadow",
                "heavy shadow", "gehri shadow", "zyada shadow", "shadow badhao", "गहरी शैडो", "3डी शैडो"
            )
        ) -> VoiceShadowHint.DEEP_3D
        containsWordBoundary(
            lower,
            listOf(
                "shadow soft", "soft shadow", "halki shadow", "halka shadow", "kam shadow",
                "light shadow", "shadow kam", "parchhai kam", "शैडो सॉफ्ट", "हल्की शैडो"
            )
        ) -> VoiceShadowHint.SOFT
        containsWordBoundary(lower, listOf("natural shadow", "normal shadow", "auto shadow")) -> VoiceShadowHint.NATURAL
        else -> VoiceShadowHint.NONE
    }

    val lightingHint = when {
        containsWordBoundary(lower, listOf("warm light", "golden light", "sunset light", "garm light", "warm tone")) -> VoiceLightingHint.WARM
        containsWordBoundary(lower, listOf("cool light", "cold light", "blue light", "thandi light", "cool tone")) -> VoiceLightingHint.COOL
        containsWordBoundary(
            lower,
            listOf(
                "light match", "lighting match", "match light", "match lighting", "auto light",
                "relight", "blend match", "color match", "light sahi", "roshni match", "लाइट मैच", "रोशनी मैच"
            )
        ) -> VoiceLightingHint.MATCH_AUTO
        else -> VoiceLightingHint.NONE
    }

    // 7. Scene Mood
    val sceneMood = when {
        containsWordBoundary(lower, listOf("snow", "ice", "winter", "glacier", "बर्फ", "बर्फीले", "barf", "manali", "gulmarg", "swiss")) -> VoiceSceneMood.SNOW
        containsWordBoundary(lower, listOf("night", "neon", "midnight", "evening lights", "रात", "raat", "tokyo", "times square")) -> VoiceSceneMood.NIGHT
        containsWordBoundary(lower, listOf("sunset", "golden", "dusk", "sunrise", "शाम", "shaam")) -> VoiceSceneMood.SUNSET
        containsWordBoundary(lower, listOf("beach", "ocean", "sea", "coast", "island", "समुद्र", "बीच", "goa", "maldives")) -> VoiceSceneMood.BEACH
        containsWordBoundary(lower, listOf("desert", "dunes", "sand", "रेगिस्तान", "thar", "jaisalmer", "dubai desert")) -> VoiceSceneMood.DESERT
        containsWordBoundary(lower, listOf("mountain", "hill", "peak", "valley", "पहाड़", "पहाड़ों", "pahad", "ladakh", "kashmir", "fuji")) -> VoiceSceneMood.MOUNTAIN
        else -> VoiceSceneMood.AUTO
    }

    // 8. Location Extraction (protect Devanagari "बीच में" as CENTER before translating "बीच" -> "beach")
    var working = cleanRaw
        .replace("बीच में", " center ")
        .replace("बीच पर", " center ")
    val sortedDict = hindiToEnglishLocationTerms.entries.sortedByDescending { it.key.length }
    for ((hi, en) in sortedDict) {
        if (working.contains(hi, ignoreCase = true)) {
            working = working.replace(hi, " $en ", ignoreCase = true)
        }
    }

    val rawTokens = working
        .replace(Regex("[,.;:!?\"'()\\[\\]{}]"), " ")
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }

    val keptTokens = mutableListOf<String>()
    for (tok in rawTokens) {
        val tokLower = tok.lowercase()
        if (tokLower in hindiStopWords) continue
        if (tokLower.matches(Regex("\\d+s?"))) continue
        val converted = if (tok.any { it in '\u0900'..'\u097F' }) {
            transliterateDevanagariToLatin(tok)
        } else {
            tok
        }
        val convLower = converted.lowercase().trim()
        if (convLower.isNotBlank() && convLower !in hindiStopWords) {
            keptTokens.add(converted.trim())
        }
    }

    val deduped = mutableListOf<String>()
    for (t in keptTokens) {
        if (deduped.lastOrNull()?.equals(t, ignoreCase = true) != true) {
            deduped.add(t)
        }
    }

    val hasMoodSceneWord = (sceneMood != VoiceSceneMood.AUTO) &&
        lightingHint == VoiceLightingHint.NONE &&
        shadowHint == VoiceShadowHint.NONE
    val hasExplicitLocation = !wantsUndo && (deduped.isNotEmpty() || hasMoodSceneWord)

    val extractedQuery = deduped.joinToString(" ").trim().ifBlank {
        when (sceneMood) {
            VoiceSceneMood.SNOW -> "Manali snow mountains"
            VoiceSceneMood.NIGHT -> "Tokyo night city"
            VoiceSceneMood.SUNSET -> "Santorini sunset"
            VoiceSceneMood.BEACH -> "Maldives tropical beach"
            VoiceSceneMood.DESERT -> "Sam Sand Dunes Jaisalmer"
            VoiceSceneMood.MOUNTAIN -> "Swiss Alps mountains"
            VoiceSceneMood.AUTO -> ""
        }
    }

    val displayName = extractedQuery
        .split(" ")
        .filter { it.isNotBlank() }
        .joinToString(" ") { word ->
            word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }

    val intentAction = when {
        wantsUndo -> VoiceIntentAction.UNDO
        hasExplicitLocation -> VoiceIntentAction.CHANGE_LOCATION
        else -> VoiceIntentAction.ADJUST_CURRENT_SCENE
    }

    return ParsedVoiceCommand(
        rawTranscript = cleanRaw,
        locationQuery = extractedQuery,
        displayLocation = displayName,
        outputType = outputType,
        positionHint = positionHint,
        sizeHint = sizeHint,
        wantsMusic = wantsMusic,
        sceneMood = sceneMood,
        preferSidePlacement = preferSidePlacement,
        wantsWalkwayOrGroundFix = wantsWalkwayOrGroundFix,
        intentAction = intentAction,
        hasExplicitLocation = hasExplicitLocation,
        hasExplicitOutputType = hasExplicitOutputType,
        languageStyle = languageStyle,
        scaleDelta = scaleDelta,
        positionNudge = positionNudge,
        shadowHint = shadowHint,
        lightingHint = lightingHint,
        modeRequest = modeRequest
    )
}

private enum class SceneCellClass {
    WALKABLE_STONE,
    WALKABLE_SAND,
    WALKABLE_GRASS,
    WALKABLE_ROAD,
    WALKABLE_INDOOR,
    WALKABLE_SNOW,
    WATER_OR_REFLECTION,
    SKY_OR_MID_AIR,
    WALL_OR_ROOF,
    CROWD_OR_OBSTACLE
}

private data class VisualSceneAnalysis(
    val xOffsetPx: Float,
    val bestVisXRatio: Float,
    val bestGroundYRatio: Float,
    val horizonYRatio: Float,
    val perspectiveScale: Float,
    val surfaceLabel: String,
    val centerHasWaterOrHazard: Boolean,
    val leftWalkableScore: Float,
    val centerWalkableScore: Float,
    val rightWalkableScore: Float,
    val leftBestYRatio: Float,
    val centerBestYRatio: Float,
    val rightBestYRatio: Float,
    val leftBestXRatio: Float,
    val centerBestXRatio: Float,
    val rightBestXRatio: Float,
    val leftSafeCount: Int,
    val centerSafeCount: Int,
    val rightSafeCount: Int,
    val visColsCount: Int = 1,
    val anySafeGroundInScene: Boolean = true,
    val colHasSafeGround: BooleanArray = booleanArrayOf(true),
    val colBestVisX: FloatArray = floatArrayOf(0.50f),
    val colBestSafeY: FloatArray = floatArrayOf(0.90f),
    val colMinSafeY: FloatArray = floatArrayOf(0.62f),
    val colMaxSafeY: FloatArray = floatArrayOf(0.945f),
    val colBestScore: FloatArray = floatArrayOf(0.5f),
    val colSurfaceLabels: Array<String> = arrayOf("Stone Walkway")
)

data class SafeSolidGroundSnap(
    val xOffsetPx: Float,
    val yOffsetPx: Float,
    val groundYRatio: Float,
    val surfaceLabel: String,
    val perspectiveScale: Float,
    val snappedAwayFromHazard: Boolean,
    val verifiedSolidGround: Boolean
)

private val visualSceneAnalysisCache = WeakHashMap<Bitmap, MutableMap<String, VisualSceneAnalysis>>()

/**
 * Universal 2D Visual Scene & Ground-Plane Analyzer:
 * Builds a spatial full-width surface/hazard map of ANY global background photo and strictly forbids
 * placing feet on water, swimming pools, reflecting pools, fountains, rivers, lakes, ocean waves/foam,
 * wet mirror reflections, or mid-air sky/rooftop drop-offs. Snaps feet strictly onto verified
 * solid walkable ground (stone walkways, marble platforms, sidewalks, dry beach sand, grass, paved roads)
 * with realistic perspective scale identically across Photo Mode and 15s Video Mode.
 */
private fun analyzeVisualSceneForTouristPlacement(
    bgBitmap: Bitmap?,
    locationName: String?,
    previewWidth: Float,
    previewHeight: Float = 0f,
    preferSidePlacement: Boolean = false,
    isVideoViewport: Boolean = false
): VisualSceneAnalysis {
    val pW = previewWidth.coerceAtLeast(360f)
    val sideShift = (pW * 0.21f).coerceAtLeast(88f)
    val defaultAnalysis = VisualSceneAnalysis(
        xOffsetPx = 0f,
        bestVisXRatio = 0.50f,
        bestGroundYRatio = 0.90f,
        horizonYRatio = 0.52f,
        perspectiveScale = 0.68f,
        surfaceLabel = "Center Ground",
        centerHasWaterOrHazard = false,
        leftWalkableScore = 0.5f,
        centerWalkableScore = 0.5f,
        rightWalkableScore = 0.5f,
        leftBestYRatio = 0.90f,
        centerBestYRatio = 0.90f,
        rightBestYRatio = 0.90f,
        leftBestXRatio = 0.24f,
        centerBestXRatio = 0.50f,
        rightBestXRatio = 0.76f,
        leftSafeCount = 1,
        centerSafeCount = 1,
        rightSafeCount = 1
    )
    if (bgBitmap == null || bgBitmap.isRecycled || bgBitmap.width < 32 || bgBitmap.height < 32) {
        return defaultAnalysis
    }

    val containerAspect = when {
        isVideoViewport -> 9f / 16f
        previewHeight > 120f -> (pW / previewHeight).coerceIn(0.45f, 1.35f)
        else -> 0.84f
    }
    val aspectBucket = (containerAspect * 20f).roundToInt()
    val cacheKey = "${locationName.orEmpty().trim().lowercase()}|$aspectBucket|$preferSidePlacement|$isVideoViewport"
    synchronized(visualSceneAnalysisCache) {
        visualSceneAnalysisCache[bgBitmap]?.get(cacheKey)?.let { cached ->
            val scaledX = (cached.bestVisXRatio - 0.50f) * pW
            return cached.copy(xOffsetPx = scaledX)
        }
    }

    var proxy: Bitmap? = null
    return try {
        val gridW = 160
        val gridH = 120
        proxy = Bitmap.createScaledBitmap(bgBitmap, gridW, gridH, true)
        val pixels = IntArray(gridW * gridH)
        proxy.getPixels(pixels, 0, gridW, 0, 0, gridW, gridH)

        // Match preview container's ContentScale.Crop visible viewport (including 1.07x video overscan)
        val bgAspect = bgBitmap.width.toFloat() / bgBitmap.height.toFloat().coerceAtLeast(1f)
        val overscan = if (isVideoViewport) 1f / 1.07f else 1f
        val visMinX: Float
        val visMaxX: Float
        val visMinY: Float
        val visMaxY: Float
        if (bgAspect > containerAspect) {
            val visFracW = ((containerAspect / bgAspect) * overscan).coerceIn(0.32f, 1.0f)
            visMinX = (0.5f - visFracW * 0.5f).coerceIn(0f, 0.34f)
            visMaxX = (0.5f + visFracW * 0.5f).coerceIn(0.66f, 1.0f)
            val yTrim = (1f - overscan) * 0.5f
            visMinY = yTrim
            visMaxY = 1f - yTrim
        } else {
            val visFracH = ((bgAspect / containerAspect) * overscan).coerceIn(0.40f, 1.0f)
            val xTrim = (1f - overscan) * 0.5f
            visMinX = xTrim
            visMaxX = 1f - xTrim
            visMinY = (0.5f - visFracH * 0.5f).coerceIn(0f, 0.30f)
            visMaxY = (0.5f + visFracH * 0.5f).coerceIn(0.70f, 1.0f)
        }

        val xStart = (visMinX * (gridW - 1)).roundToInt().coerceIn(2, gridW - 6)
        val xEnd = (visMaxX * (gridW - 1)).roundToInt().coerceIn(xStart + 8, gridW - 3)
        val yStart = (visMinY * (gridH - 1)).roundToInt().coerceIn(2, gridH - 6)
        val yEnd = (visMaxY * (gridH - 1)).roundToInt().coerceIn(yStart + 8, gridH - 3)
        val visSpanX = (xEnd - xStart).coerceAtLeast(1).toFloat()
        val visSpanY = (yEnd - yStart).coerceAtLeast(1).toFloat()

        fun rgb(x: Int, y: Int): Int = pixels[y.coerceIn(0, gridH - 1) * gridW + x.coerceIn(0, gridW - 1)]
        fun lumAt(x: Int, y: Int): Float {
            val c = rgb(x, y)
            return 0.299f * ((c ushr 16) and 0xFF) + 0.587f * ((c ushr 8) and 0xFF) + 0.114f * (c and 0xFF)
        }

        // Step 1: Universal Visual Horizon & Structural Gradient Analysis (no location/color hardcoding)
        val rowLum = FloatArray(gridH)
        val rowSmoothFrac = FloatArray(gridH)
        val rowWallVert = FloatArray(gridH)
        val rowHorizFloor = FloatArray(gridH)
        val rowBoundaryScore = FloatArray(gridH)

        for (y in yStart..yEnd) {
            var sumL = 0f
            var smoothCount = 0
            var vertDom = 0f
            var horizDom = 0f
            var colsCount = 0
            for (x in xStart..xEnd) {
                val c = rgb(x, y)
                val r = (c ushr 16) and 0xFF
                val g = (c ushr 8) and 0xFF
                val b = c and 0xFF
                val l = 0.299f * r + 0.587f * g + 0.114f * b

                val cRight = rgb(x + 1, y)
                val cDown = rgb(x, y + 1)
                val dx = (abs(r - ((cRight ushr 16) and 0xFF)) +
                    abs(g - ((cRight ushr 8) and 0xFF)) +
                    abs(b - (cRight and 0xFF))) / 3f
                val dy = (abs(r - ((cDown ushr 16) and 0xFF)) +
                    abs(g - ((cDown ushr 8) and 0xFF)) +
                    abs(b - (cDown and 0xFF))) / 3f

                sumL += l
                if (dx < 8f && dy < 8f && l > 96f) {
                    smoothCount++
                }
                if (dx > dy * 1.45f && dx > 9f) vertDom += 1f
                if (dy >= dx * 0.85f && dy in 1.2f..18f && dx < 16f) horizDom += 1f
                colsCount++
            }
            val denom = colsCount.coerceAtLeast(1).toFloat()
            rowLum[y] = sumL / denom
            rowSmoothFrac[y] = smoothCount / denom
            rowWallVert[y] = vertDom / denom
            rowHorizFloor[y] = horizDom / denom
        }

        var skyEndRow = yStart + (visSpanY * 0.28f).roundToInt()
        for (y in yStart..(yStart + (visSpanY * 0.54f).roundToInt()).coerceAtMost(yEnd)) {
            if (rowSmoothFrac[y] >= 0.52f) {
                skyEndRow = y
            }
        }
        val hMinRow = max(skyEndRow, yStart + (visSpanY * 0.24f).roundToInt()).coerceIn(yStart + 2, yEnd - 8)
        val hMaxRow = (yStart + (visSpanY * 0.70f).roundToInt()).coerceIn(hMinRow + 2, yEnd - 4)
        var bestHorizonRow = (yStart + (visSpanY * 0.48f).roundToInt()).coerceIn(hMinRow, hMaxRow)
        var bestBoundaryScore = -1f
        for (y in hMinRow..hMaxRow) {
            val lumJump = abs(rowLum[y + 1] - rowLum[y - 2]) / 255f
            val wallDrop = (rowWallVert[(y - 2).coerceAtLeast(yStart)] - rowWallVert[(y + 2).coerceAtMost(yEnd)]).coerceAtLeast(0f)
            val floorGain = (rowHorizFloor[(y + 3).coerceAtMost(yEnd)] - rowHorizFloor[(y - 2).coerceAtLeast(yStart)]).coerceAtLeast(0f)
            val score = lumJump * 1.0f + wallDrop * 1.35f + floorGain * 1.30f
            rowBoundaryScore[y] = score
            if (score > bestBoundaryScore) {
                bestBoundaryScore = score
                bestHorizonRow = y
            }
        }
        val groundPlane = detectBackgroundGroundPlane(bgBitmap, locationName.orEmpty())
        val computedHorizonVisY = ((bestHorizonRow - yStart) / visSpanY).coerceIn(0.24f, 0.68f)
        val horizonYRatio = (computedHorizonVisY * 0.70f + groundPlane.horizonYRatio * 0.30f).coerceIn(0.25f, 0.68f)
        val horizonRowInGrid = (yStart + horizonYRatio * visSpanY).roundToInt().coerceIn(yStart + 2, yEnd - 4)

        // Candidate shoreline / reflection symmetry rows for mirror-like pools, lakes, and rivers worldwide
        val symAxes = mutableListOf(horizonRowInGrid, bestHorizonRow)
        var secAxis = -1
        var secScore = -1f
        for (y in (yStart + (visSpanY * 0.34f).roundToInt())..(yStart + (visSpanY * 0.74f).roundToInt()).coerceAtMost(yEnd - 4)) {
            if (abs(y - bestHorizonRow) >= 5 && rowBoundaryScore[y] > secScore) {
                secScore = rowBoundaryScore[y]
                secAxis = y
            }
        }
        if (secAxis > 0) symAxes.add(secAxis)
        val distinctSymAxes = symAxes.distinct()
        val mirrorScaleFactors = floatArrayOf(1.0f, 0.85f, 0.72f)

        // Step 2A: Connected Top-Down Sky Flood-Fill (identifies true open sky/abyss without falsely tagging bright snow/sand/marble floors below)
        val isTopConnectedSky = Array(gridH) { BooleanArray(gridW) }
        val skyQueue = ArrayDeque<Int>()
        val topSeedLimit = (yStart + visSpanY * 0.08f).roundToInt().coerceAtMost(yEnd)
        for (y in yStart..topSeedLimit) {
            for (x in xStart..xEnd) {
                val c = rgb(x, y)
                val r = (c ushr 16) and 0xFF
                val g = (c ushr 8) and 0xFF
                val b = c and 0xFF
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                val grad = abs(l - lumAt(x + 1, y)) + abs(l - lumAt(x, y + 1))
                if (grad < 12f && (l > 95f || b >= r - 6)) {
                    isTopConnectedSky[y][x] = true
                    skyQueue.addLast(y * gridW + x)
                }
            }
        }
        val skyMaxY = (yStart + visSpanY * 0.62f).roundToInt().coerceAtMost(yEnd)
        while (skyQueue.isNotEmpty()) {
            val packed = skyQueue.removeFirst()
            val cy = packed / gridW
            val cx = packed % gridW
            val cl = lumAt(cx, cy)
            val neighbors = intArrayOf(
                cy * gridW + (cx - 1), cy * gridW + (cx + 1),
                (cy - 1) * gridW + cx, (cy + 1) * gridW + cx
            )
            for (np in neighbors) {
                val ny = np / gridW
                val nx = np % gridW
                if (nx < xStart || nx > xEnd || ny < yStart || ny > skyMaxY) continue
                if (isTopConnectedSky[ny][nx]) continue
                val nl = lumAt(nx, ny)
                val nGrad = abs(nl - lumAt(nx + 1, ny)) + abs(nl - lumAt(nx, ny + 1))
                if (abs(nl - cl) < 16f && nGrad < 14f) {
                    isTopConnectedSky[ny][nx] = true
                    skyQueue.addLast(np)
                }
            }
        }

        // Step 2B: Multi-Scale Visual Texture, Edge Density, Surface Flatness & Reflection Analysis across lower frame
        val cellClass = Array(gridH) { Array(gridW) { SceneCellClass.SKY_OR_MID_AIR } }
        val cellWalkScore = Array(gridH) { FloatArray(gridW) }
        val cellFlatness = Array(gridH) { FloatArray(gridW) }
        val cellEdgeDensity = Array(gridH) { FloatArray(gridW) }
        val cellMicroTex = Array(gridH) { FloatArray(gridW) }
        val cellSmoothness = Array(gridH) { FloatArray(gridW) }
        val upperSkyOrDistantCount = intArrayOf(0, 0)

        for (y in yStart..yEnd) {
            val visY = (y - yStart) / visSpanY
            for (x in xStart..xEnd) {
                val c = rgb(x, y)
                val r = (c ushr 16) and 0xFF
                val g = (c ushr 8) and 0xFF
                val b = c and 0xFF
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                val maxCh = max(r, max(g, b))
                val minCh = min(r, min(g, b))
                val sat = if (maxCh > 0) (maxCh - minCh).toFloat() / maxCh else 0f

                if (visY < 0.52f) {
                    upperSkyOrDistantCount[1]++
                    if (isTopConnectedSky[y][x] || (l > 142f && b >= r - 10)) upperSkyOrDistantCount[0]++
                }

                // Above scan region or top-connected sky is never walkable ground
                if (visY < 0.52f || isTopConnectedSky[y][x]) {
                    cellClass[y][x] = SceneCellClass.SKY_OR_MID_AIR
                    cellWalkScore[y][x] = -5.0f
                    continue
                }

                // 3x3 directional gradients
                val cL = rgb(x - 1, y); val cR = rgb(x + 1, y)
                val cU = rgb(x, y - 1); val cD = rgb(x, y + 1)
                val cUL = rgb(x - 1, y - 1); val cDR = rgb(x + 1, y + 1)

                val dx = (abs(((cR ushr 16) and 0xFF) - ((cL ushr 16) and 0xFF)) +
                    abs(((cR ushr 8) and 0xFF) - ((cL ushr 8) and 0xFF)) +
                    abs((cR and 0xFF) - (cL and 0xFF))) / 3f
                val dy = (abs(((cD ushr 16) and 0xFF) - ((cU ushr 16) and 0xFF)) +
                    abs(((cD ushr 8) and 0xFF) - ((cU ushr 8) and 0xFF)) +
                    abs((cD and 0xFF) - (cU and 0xFF))) / 3f
                val dDiag = (abs(((cDR ushr 16) and 0xFF) - ((cUL ushr 16) and 0xFF)) +
                    abs(((cDR ushr 8) and 0xFF) - ((cUL ushr 8) and 0xFF)) +
                    abs((cDR and 0xFF) - (cUL and 0xFF))) / 3f
                val patchVar = (dx + dy + dDiag) / 3f
                cellSmoothness[y][x] = patchVar

                // 5x5 local texture variance & edge density (universal surface signature)
                var sumAbsDiff3 = 0f
                var count3 = 0
                var strongEdgeCount5 = 0
                var sumAbsDiff5 = 0f
                var horizDiff5 = 0f
                var vertDiff5 = 0f
                var count5 = 0
                for (wy in (y - 2).coerceAtLeast(yStart)..(y + 2).coerceAtMost(yEnd)) {
                    for (wx in (x - 2).coerceAtLeast(xStart)..(x + 2).coerceAtMost(xEnd)) {
                        val wc = rgb(wx, wy)
                        val wr = (wc ushr 16) and 0xFF
                        val wg = (wc ushr 8) and 0xFF
                        val wb = wc and 0xFF
                        val wl = 0.299f * wr + 0.587f * wg + 0.114f * wb
                        val diffCenter = abs(wl - l)
                        sumAbsDiff5 += diffCenter
                        if (abs(wx - x) <= 1 && abs(wy - y) <= 1 && (wx != x || wy != y)) {
                            sumAbsDiff3 += diffCenter
                            count3++
                        }
                        val gxLocal = abs(wl - lumAt(wx + 1, wy))
                        val gyLocal = abs(wl - lumAt(wx, wy + 1))
                        horizDiff5 += gxLocal
                        vertDiff5 += gyLocal
                        if (gxLocal + gyLocal > 14f) strongEdgeCount5++
                        count5++
                    }
                }
                val microTex = if (count3 > 0) sumAbsDiff3 / count3 else patchVar
                val macroTex = if (count5 > 0) sumAbsDiff5 / count5 else patchVar
                val edgeDensity = if (count5 > 0) strongEdgeCount5.toFloat() / count5.toFloat() else 0f
                val avgGx = if (count5 > 0) horizDiff5 / count5 else dx
                val avgGy = if (count5 > 0) vertDiff5 / count5 else dy
                cellMicroTex[y][x] = microTex
                cellEdgeDensity[y][x] = edgeDensity

                // Vertical Mirror-Symmetry Check across candidate shoreline/horizon axes (catches reflective pools, lakes, rivers of ANY hue)
                var minMirrorDiff = 999f
                for (axis in distinctSymAxes) {
                    if (y <= axis + 1) continue
                    val distBelow = y - axis
                    for (mScale in mirrorScaleFactors) {
                        val mirrorY = (axis - (distBelow / mScale).roundToInt()).coerceIn(yStart, axis)
                        val mc = rgb(x, mirrorY)
                        val mDiff = (abs(r - ((mc ushr 16) and 0xFF)) +
                            abs(g - ((mc ushr 8) and 0xFF)) +
                            abs(b - (mc and 0xFF))) / 3f
                        if (mDiff < minMirrorDiff) minMirrorDiff = mDiff
                    }
                }

                // Universal Smooth / Reflective / Liquid Signatures (no location keywords)
                val isTrueVegetationOrGrass = g > r * 1.05f && g > b * 1.13f && microTex >= 1.2f
                val isWarmGranularEarthOrSand = r > b + 12 && microTex >= 1.2f && edgeDensity in 0.02f..0.46f
                val isMirrorReflective = !isTrueVegetationOrGrass &&
                    minMirrorDiff < 29f && l > 42f && avgGx < 13f &&
                    (avgGy >= avgGx * 0.85f || microTex < 8.5f)
                val isUltraSmoothUniformLiquid = !isTrueVegetationOrGrass && !isWarmGranularEarthOrSand &&
                    microTex < 1.35f && macroTex < 2.3f && edgeDensity < 0.03f &&
                    (b >= r - 2 || l > 175f || l < 24f)
                val isLiquidChromaticWater = !isTrueVegetationOrGrass && (
                    (b > r + 7 && b >= g - 5 && sat > 0.07f && edgeDensity < 0.36f) ||
                    (g > r + 7 && b > r + 4 && b >= g * 0.74f && sat > 0.09f && edgeDensity < 0.34f) ||
                    (b > r + 4 && b >= g && l < 116f && microTex < 14f)
                )
                val isWaveOrReflectionStreak = !isTrueVegetationOrGrass && !isWarmGranularEarthOrSand &&
                    avgGx < 8.5f && avgGy > avgGx * 1.65f + 4.5f && edgeDensity < 0.42f && l > 58f

                // Universal Vertical Wall / Cliff / Obstacle / Dense Clutter Signatures
                val isVerticalWallOrPillar = avgGx > avgGy * 1.48f && avgGx > 8.5f && edgeDensity > 0.14f
                val isChaoticObstacleOrBush = edgeDensity > 0.56f && macroTex > 21f
                val isPitchDarkAbyss = l < 12f && microTex < 1.5f

                // Surface Flatness Score: rewards planar horizontal texture & consistent macro flatness, penalizes high clutter
                val flatnessScore = (
                    (1f - (macroTex / 26f).coerceIn(0f, 1f)) * 0.55f +
                        (1f - (edgeDensity / 0.55f).coerceIn(0f, 1f)) * 0.45f
                    ).coerceIn(0f, 1f)
                cellFlatness[y][x] = flatnessScore

                when {
                    isMirrorReflective || isLiquidChromaticWater || isUltraSmoothUniformLiquid || isWaveOrReflectionStreak -> {
                        cellClass[y][x] = SceneCellClass.WATER_OR_REFLECTION
                        cellWalkScore[y][x] = -5.0f
                    }
                    isPitchDarkAbyss -> {
                        cellClass[y][x] = SceneCellClass.SKY_OR_MID_AIR
                        cellWalkScore[y][x] = -4.5f
                    }
                    isVerticalWallOrPillar -> {
                        cellClass[y][x] = SceneCellClass.WALL_OR_ROOF
                        cellWalkScore[y][x] = -3.2f
                    }
                    isChaoticObstacleOrBush -> {
                        cellClass[y][x] = SceneCellClass.CROWD_OR_OBSTACLE
                        cellWalkScore[y][x] = -1.6f
                    }
                    else -> {
                        // Classify solid walkable surface solely from visual properties (never location name)
                        val isSnowTex = r > 174 && g > 178 && b > 184 && l > 142f && microTex >= 0.9f
                        val isGrassTex = !isSnowTex && isTrueVegetationOrGrass
                        val isSandTex = !isSnowTex && !isGrassTex && r > 134 && g > 94 && b < 142 && r > b + 14 && l > 78f
                        val isRoadTex = !isSnowTex && !isGrassTex && !isSandTex && sat < 0.14f && l in 30f..136f
                        val mat = when {
                            isSnowTex -> SceneCellClass.WALKABLE_SNOW
                            isGrassTex -> SceneCellClass.WALKABLE_GRASS
                            isSandTex -> SceneCellClass.WALKABLE_SAND
                            isRoadTex -> SceneCellClass.WALKABLE_ROAD
                            else -> SceneCellClass.WALKABLE_STONE
                        }
                        cellClass[y][x] = mat
                        // Ideal solid ground has noticeable walkable texture (microTex 1.5..14), good flatness, and moderate edge density (0.04..0.34)
                        val texQuality = when {
                            microTex in 1.6f..14.0f && edgeDensity in 0.03f..0.34f -> 1.45f
                            microTex in 1.0f..20.0f && edgeDensity < 0.44f -> 1.15f
                            else -> 0.85f
                        }
                        val planarBonus = if (avgGy >= avgGx * 0.80f) 0.25f else 0f
                        cellWalkScore[y][x] = texQuality + flatnessScore * 0.60f + planarBonus
                    }
                }
            }
        }

        // Step 2C: 3-pass wet-foam / smooth reflection border expansion so wet shorelines & surf never score as dry solid ground
        for (pass in 0 until 3) {
            val nextWater = Array(gridH) { BooleanArray(gridW) }
            for (y in yStart..yEnd) {
                for (x in xStart..xEnd) {
                    if (cellClass[y][x] == SceneCellClass.WATER_OR_REFLECTION) continue
                    val c = rgb(x, y)
                    val r = (c ushr 16) and 0xFF
                    val g = (c ushr 8) and 0xFF
                    val b = c and 0xFF
                    val l = 0.299f * r + 0.587f * g + 0.114f * b
                    val maxCh = max(r, max(g, b))
                    val minCh = min(r, min(g, b))
                    val sat = if (maxCh > 0) (maxCh - minCh).toFloat() / maxCh else 0f
                    val isLikelySurfOrWetRim = (l > 162f && b >= r - 3 && sat < 0.20f && cellSmoothness[y][x] < 16f) ||
                        (cellMicroTex[y][x] < 2.0f && b >= r - 2 && cellEdgeDensity[y][x] < 0.08f)
                    if (isLikelySurfOrWetRim) {
                        var nearWater = false
                        val rad = if (pass == 0) 2 else 1
                        for (ny in (y - rad).coerceAtLeast(yStart)..(y + rad).coerceAtMost(yEnd)) {
                            for (nx in (x - rad).coerceAtLeast(xStart)..(x + rad).coerceAtMost(xEnd)) {
                                if (cellClass[ny][nx] == SceneCellClass.WATER_OR_REFLECTION) {
                                    nearWater = true
                                    break
                                }
                            }
                            if (nearWater) break
                        }
                        if (nearWater) nextWater[y][x] = true
                    }
                }
            }
            var changed = false
            for (y in yStart..yEnd) {
                for (x in xStart..xEnd) {
                    if (nextWater[y][x]) {
                        cellClass[y][x] = SceneCellClass.WATER_OR_REFLECTION
                        cellWalkScore[y][x] = -5.0f
                        changed = true
                    }
                }
            }
            if (!changed) break
        }

        // Fill enclosed single/tiny water pockets surrounded by water neighbors
        val fillPockets = Array(gridH) { BooleanArray(gridW) }
        for (y in (yStart + 1)..(yEnd - 1)) {
            for (x in (xStart + 1)..(xEnd - 1)) {
                if (cellClass[y][x] == SceneCellClass.WATER_OR_REFLECTION) continue
                var wCount = 0
                for (ny in (y - 1)..(y + 1)) {
                    for (nx in (x - 1)..(x + 1)) {
                        if (nx == x && ny == y) continue
                        if (cellClass[ny][nx] == SceneCellClass.WATER_OR_REFLECTION) wCount++
                    }
                }
                if (wCount >= 5) fillPockets[y][x] = true
            }
        }
        for (y in yStart..yEnd) {
            for (x in xStart..xEnd) {
                if (fillPockets[y][x]) {
                    cellClass[y][x] = SceneCellClass.WATER_OR_REFLECTION
                    cellWalkScore[y][x] = -5.0f
                }
            }
        }

        // Step 3: Scan Horizontal Width (x = 0.15f to 0.85f) & Lower-to-Mid Vertical Area (y = 0.55f to 0.90f)
        // to find the WIDEST, FLATTEST solid ground texture worldwide!
        data class CandidateSpot(
            val visX: Float,
            val visY: Float,
            val score: Float,
            val hazardPenaltySum: Int,
            val lane: Int, // 0=Left, 1=Center, 2=Right
            val mat: SceneCellClass,
            val contiguousWidthFrac: Float
        )

        val minGroundVisY = max(horizonYRatio + 0.04f, 0.55f).coerceIn(0.55f, 0.80f)
        val maxGroundVisY = 0.90f
        val stanceHalfW = (visSpanX * 0.052f).roundToInt().coerceAtLeast(2)
        val stanceHalfH = (visSpanY * 0.022f).roundToInt().coerceAtLeast(1)

        val yGridMin = (yStart + minGroundVisY * visSpanY).roundToInt().coerceIn(yStart + 2, yEnd - 3)
        val yGridMax = (yStart + maxGroundVisY * visSpanY).roundToInt().coerceIn(yGridMin, yEnd - 2)
        val xGridMin = (xStart + 0.15f * visSpanX).roundToInt().coerceIn(xStart + 2, xEnd - 4)
        val xGridMax = (xStart + 0.85f * visSpanX).roundToInt().coerceIn(xGridMin + 4, xEnd - 2)
        val visColsCount = (xGridMax - xGridMin + 1).coerceAtLeast(1)

        fun isHazardClass(cls: SceneCellClass): Boolean {
            return cls == SceneCellClass.WATER_OR_REFLECTION ||
                cls == SceneCellClass.SKY_OR_MID_AIR ||
                cls == SceneCellClass.WALL_OR_ROOF
        }

        // Precompute per-row contiguous horizontal solid ground spans so we measure true ground width at every (x, y)
        val cellZeroHazard = Array(gridH) { BooleanArray(gridW) }
        val cellContiguousSpan = Array(gridH) { IntArray(gridW) }
        val cellWidthCenterScore = Array(gridH) { FloatArray(gridW) }

        for (cy in yGridMin..yGridMax) {
            for (cx in xGridMin..xGridMax) {
                var hazardFound = false
                for (sy in (cy - stanceHalfH).coerceAtLeast(yStart)..(cy + stanceHalfH + 1).coerceAtMost(yEnd)) {
                    for (sx in (cx - stanceHalfW).coerceAtLeast(xStart)..(cx + stanceHalfW).coerceAtMost(xEnd)) {
                        if (isHazardClass(cellClass[sy][sx])) {
                            hazardFound = true
                            break
                        }
                    }
                    if (hazardFound) break
                }
                if (!hazardFound) {
                    val mLeft = (cx - stanceHalfW - 2).coerceAtLeast(xStart)
                    val mRight = (cx + stanceHalfW + 2).coerceAtMost(xEnd)
                    val mBot = (cy + stanceHalfH + 3).coerceAtMost(yEnd)
                    for (sy in (cy - stanceHalfH).coerceAtLeast(yStart)..mBot) {
                        if (isHazardClass(cellClass[sy][mLeft]) || isHazardClass(cellClass[sy][mRight])) {
                            hazardFound = true
                            break
                        }
                    }
                    if (!hazardFound) {
                        for (sx in mLeft..mRight step 2) {
                            if (isHazardClass(cellClass[mBot][sx])) {
                                hazardFound = true
                                break
                            }
                        }
                    }
                }
                cellZeroHazard[cy][cx] = !hazardFound
            }

            // Compute contiguous horizontal solid runs on row cy
            var runStart = -1
            for (cx in xGridMin..(xGridMax + 1)) {
                val safe = cx <= xGridMax && cellZeroHazard[cy][cx]
                if (safe && runStart < 0) {
                    runStart = cx
                } else if (!safe && runStart >= 0) {
                    val runEnd = cx - 1
                    val runLen = runEnd - runStart + 1
                    val runMid = (runStart + runEnd) * 0.5f
                    for (rx in runStart..runEnd) {
                        cellContiguousSpan[cy][rx] = runLen
                        // Reward standing comfortably inside the wide ground span rather than on its cliff/water edge
                        val normDistFromRunCenter = abs(rx - runMid) / (runLen * 0.5f).coerceAtLeast(1f)
                        cellWidthCenterScore[cy][rx] = (1f - normDistFromRunCenter * 0.55f).coerceIn(0.35f, 1.0f)
                    }
                    runStart = -1
                }
            }
        }

        val colHasSafeGround = BooleanArray(visColsCount)
        val colBestVisX = FloatArray(visColsCount) { idx ->
            ((xGridMin + idx - xStart) / visSpanX).coerceIn(0.15f, 0.85f)
        }
        val colBestSafeY = FloatArray(visColsCount) { 0.86f }
        val colMinSafeY = FloatArray(visColsCount) { 0.90f }
        val colMaxSafeY = FloatArray(visColsCount) { 0.55f }
        val colBestScore = FloatArray(visColsCount) { -999f }
        val colSurfaceLabels = Array(visColsCount) { "Solid Ground" }

        val colFallbackHaz = IntArray(visColsCount) { Int.MAX_VALUE }
        val colFallbackScore = FloatArray(visColsCount) { -999f }
        val colFallbackY = FloatArray(visColsCount) { 0.86f }
        val colFallbackLabel = Array(visColsCount) { "Solid Ground" }

        val laneBestSafeScore = floatArrayOf(-999f, -999f, -999f)
        val laneBestSafeY = floatArrayOf(0.86f, 0.86f, 0.86f)
        val laneBestSafeX = floatArrayOf(0.26f, 0.50f, 0.74f)
        val laneSafeCount = intArrayOf(0, 0, 0)

        val laneBestAnyScore = floatArrayOf(-999f, -999f, -999f)
        val laneBestAnyY = floatArrayOf(0.86f, 0.86f, 0.86f)
        val laneBestAnyX = floatArrayOf(0.26f, 0.50f, 0.74f)

        val laneHazardHits = intArrayOf(0, 0, 0)
        val laneSampleTotal = intArrayOf(0, 0, 0)
        var bestSafeOverall: CandidateSpot? = null
        var bestFallbackOverall: CandidateSpot? = null

        fun matToSurfaceLabel(mat: SceneCellClass): String = when (mat) {
            SceneCellClass.WALKABLE_SAND -> "Sandy Ground"
            SceneCellClass.WALKABLE_GRASS -> "Grass Ground"
            SceneCellClass.WALKABLE_ROAD -> "Paved Road"
            SceneCellClass.WALKABLE_INDOOR -> "Solid Floor"
            SceneCellClass.WALKABLE_SNOW -> "Snow Ground"
            else -> "Stone Walkway"
        }

        val scanWidthCols = (xGridMax - xGridMin + 1).coerceAtLeast(1).toFloat()

        for (cy in yGridMin..yGridMax) {
            val visY = (cy - yStart) / visSpanY
            for (cx in xGridMin..xGridMax) {
                val colIdx = cx - xGridMin
                val visX = (cx - xStart) / visSpanX
                val lane = when {
                    visX < 0.38f -> 0
                    visX <= 0.62f -> 1
                    else -> 2
                }
                laneSampleTotal[lane]++
                val centerCls = cellClass[cy][cx]
                if (isHazardClass(centerCls)) {
                    laneHazardHits[lane]++
                }

                var patchScore = 0f
                var patchFlat = 0f
                var hazardCells = 0
                var crowdCells = 0
                var totalCells = 0
                for (sy in (cy - stanceHalfH).coerceAtLeast(yStart)..(cy + stanceHalfH + 1).coerceAtMost(yEnd)) {
                    for (sx in (cx - stanceHalfW).coerceAtLeast(xStart)..(cx + stanceHalfW).coerceAtMost(xEnd)) {
                        val sc = cellClass[sy][sx]
                        patchScore += cellWalkScore[sy][sx]
                        patchFlat += cellFlatness[sy][sx]
                        if (isHazardClass(sc)) {
                            hazardCells++
                        } else if (sc == SceneCellClass.CROWD_OR_OBSTACLE) {
                            crowdCells++
                        }
                        totalCells++
                    }
                }

                var marginHazards = 0
                val mLeft = (cx - stanceHalfW - 2).coerceAtLeast(xStart)
                val mRight = (cx + stanceHalfW + 2).coerceAtMost(xEnd)
                val mTop = (cy - stanceHalfH - 1).coerceAtLeast(yStart)
                val mBot = (cy + stanceHalfH + 3).coerceAtMost(yEnd)
                for (sy in mTop..mBot) {
                    if (isHazardClass(cellClass[sy][mLeft])) marginHazards++
                    if (isHazardClass(cellClass[sy][mRight])) marginHazards++
                }
                for (sx in mLeft..mRight step 2) {
                    if (isHazardClass(cellClass[mBot][sx])) marginHazards++
                }

                val avgWalk = if (totalCells > 0) patchScore / totalCells else -2f
                val avgFlatness = if (totalCells > 0) patchFlat / totalCells else 0f
                val crowdFrac = if (totalCells > 0) crowdCells.toFloat() / totalCells else 0f

                var upperBlocked = 0
                var upperChecked = 0
                for (uy in (cy - (visSpanY * 0.22f).roundToInt()).coerceAtLeast(yStart)..(cy - stanceHalfH - 1).coerceAtLeast(yStart) step 2) {
                    val uCls = cellClass[uy][cx]
                    if (uCls == SceneCellClass.CROWD_OR_OBSTACLE) upperBlocked++
                    upperChecked++
                }
                val upperBlockedFrac = if (upperChecked > 0) upperBlocked.toFloat() / upperChecked else 0f

                val isZeroHazard = cellZeroHazard[cy][cx] && hazardCells == 0 && marginHazards == 0 && !isHazardClass(centerCls)
                val contiguousWidthFrac = (cellContiguousSpan[cy][cx].toFloat() / scanWidthCols).coerceIn(0f, 1f)
                val interiorBonus = cellWidthCenterScore[cy][cx]

                val hazardPenalty = -(hazardCells * 12.0f + marginHazards * 3.0f)
                val crowdPenalty = -(crowdFrac * 1.9f + upperBlockedFrac * 0.85f)
                // Prefer natural foreground-to-midground Y in [0.72..0.88] within the [0.55..0.90] range
                val depthNaturalBonus = (1f - abs(visY - 0.83f) * 3.1f).coerceIn(-0.45f, 0.65f)
                val widthAndFlatnessScore = (contiguousWidthFrac * 2.40f) + (avgFlatness * 1.15f) + (interiorBonus * 0.45f)
                val sideCompositionBonus = when {
                    preferSidePlacement && lane != 1 -> 0.95f
                    preferSidePlacement && lane == 1 -> -0.65f
                    lane == 1 && isZeroHazard && contiguousWidthFrac >= 0.25f -> 0.22f
                    else -> 0.05f
                }
                val totalScore = avgWalk + widthAndFlatnessScore + hazardPenalty + crowdPenalty + depthNaturalBonus + sideCompositionBonus
                val hazardRank = hazardCells * 20 + marginHazards * 4

                if (isZeroHazard) {
                    colHasSafeGround[colIdx] = true
                    if (visY < colMinSafeY[colIdx]) colMinSafeY[colIdx] = visY
                    if (visY > colMaxSafeY[colIdx]) colMaxSafeY[colIdx] = visY
                    if (totalScore > colBestScore[colIdx]) {
                        colBestScore[colIdx] = totalScore
                        colBestSafeY[colIdx] = visY
                        colSurfaceLabels[colIdx] = matToSurfaceLabel(centerCls)
                    }

                    laneSafeCount[lane]++
                    if (totalScore > laneBestSafeScore[lane]) {
                        laneBestSafeScore[lane] = totalScore
                        laneBestSafeY[lane] = visY
                        laneBestSafeX[lane] = visX
                    }
                    val spot = CandidateSpot(visX, visY, totalScore, 0, lane, centerCls, contiguousWidthFrac)
                    if (bestSafeOverall == null || spot.score > bestSafeOverall.score) {
                        bestSafeOverall = spot
                    }
                } else if (!colHasSafeGround[colIdx]) {
                    if (hazardRank < colFallbackHaz[colIdx] ||
                        (hazardRank == colFallbackHaz[colIdx] && totalScore > colFallbackScore[colIdx])
                    ) {
                        colFallbackHaz[colIdx] = hazardRank
                        colFallbackScore[colIdx] = totalScore
                        colFallbackY[colIdx] = visY
                        colFallbackLabel[colIdx] = matToSurfaceLabel(centerCls)
                    }
                }

                if (totalScore > laneBestAnyScore[lane]) {
                    laneBestAnyScore[lane] = totalScore
                    laneBestAnyY[lane] = visY
                    laneBestAnyX[lane] = visX
                }
                val fbSpot = CandidateSpot(visX, visY, totalScore, hazardRank, lane, centerCls, contiguousWidthFrac)
                if (bestFallbackOverall == null ||
                    fbSpot.hazardPenaltySum < bestFallbackOverall.hazardPenaltySum ||
                    (fbSpot.hazardPenaltySum == bestFallbackOverall.hazardPenaltySum && fbSpot.score > bestFallbackOverall.score)
                ) {
                    bestFallbackOverall = fbSpot
                }
            }
        }

        val anySafeGroundInScene = colHasSafeGround.any { it }
        for (i in 0 until visColsCount) {
            if (!colHasSafeGround[i]) {
                colBestSafeY[i] = colFallbackY[i]
                colMinSafeY[i] = minGroundVisY
                colMaxSafeY[i] = maxGroundVisY
                colBestScore[i] = colFallbackScore[i]
                colSurfaceLabels[i] = colFallbackLabel[i]
            } else {
                if (colMinSafeY[i] > colMaxSafeY[i]) {
                    colMinSafeY[i] = colBestSafeY[i]
                    colMaxSafeY[i] = colBestSafeY[i]
                }
            }
        }

        val centerHazardRatio = if (laneSampleTotal[1] > 0) {
            laneHazardHits[1].toFloat() / laneSampleTotal[1].toFloat()
        } else 0f
        val centerBlocked = laneSafeCount[1] == 0 || centerHazardRatio > 0.14f

        val finalLaneBestScore = FloatArray(3) { i ->
            if (laneSafeCount[i] > 0) laneBestSafeScore[i] else laneBestAnyScore[i]
        }
        val finalLaneBestY = FloatArray(3) { i ->
            if (laneSafeCount[i] > 0) laneBestSafeY[i] else laneBestAnyY[i]
        }
        val finalLaneBestX = FloatArray(3) { i ->
            if (laneSafeCount[i] > 0) laneBestSafeX[i] else laneBestAnyX[i]
        }

        val chosenSpot = bestSafeOverall ?: bestFallbackOverall ?: CandidateSpot(
            0.50f, 0.86f, 0.5f, 0, 1, SceneCellClass.WALKABLE_STONE, 0.5f
        )

        val bestVisX = when {
            preferSidePlacement -> {
                val pickLeft = when {
                    laneSafeCount[0] > 0 && laneSafeCount[2] == 0 -> true
                    laneSafeCount[2] > 0 && laneSafeCount[0] == 0 -> false
                    else -> finalLaneBestScore[0] >= finalLaneBestScore[2]
                }
                if (pickLeft) finalLaneBestX[0] else finalLaneBestX[2]
            }
            centerBlocked && (laneSafeCount[0] > 0 || laneSafeCount[2] > 0) -> {
                val pickLeft = when {
                    laneSafeCount[0] > 0 && laneSafeCount[2] == 0 -> true
                    laneSafeCount[2] > 0 && laneSafeCount[0] == 0 -> false
                    else -> finalLaneBestScore[0] >= finalLaneBestScore[2]
                }
                if (pickLeft) finalLaneBestX[0] else finalLaneBestX[2]
            }
            else -> chosenSpot.visX
        }.coerceIn(0.15f, 0.85f)

        val xOffsetPx = when {
            bestVisX < 0.39f -> -((0.50f - bestVisX) * pW).coerceIn(sideShift * 0.60f, pW * 0.35f)
            bestVisX > 0.61f -> +((bestVisX - 0.50f) * pW).coerceIn(sideShift * 0.60f, pW * 0.35f)
            else -> ((bestVisX - 0.50f) * pW * 0.80f)
        }

        val chosenColFinal = ((bestVisX - 0.15f) / 0.70f * (visColsCount - 1)).roundToInt().coerceIn(0, visColsCount - 1)
        val bestGroundY = (if (colHasSafeGround[chosenColFinal]) colBestSafeY[chosenColFinal] else chosenSpot.visY)
            .coerceIn(minGroundVisY, maxGroundVisY)

        // Perspective-accurate tourist scale (derived purely from horizon distance, floor depth span & sky openness)
        val opennessRatio = if (upperSkyOrDistantCount[1] > 0) {
            upperSkyOrDistantCount[0].toFloat() / upperSkyOrDistantCount[1].toFloat()
        } else 0.40f
        val groundDepthSpan = (bestGroundY - horizonYRatio).coerceIn(0.10f, 0.64f)

        val depthDrivenScale = (0.49f + groundDepthSpan * 0.55f).coerceIn(0.50f, 0.79f)
        val vistaScale = when {
            opennessRatio > 0.58f || horizonYRatio > 0.58f -> 0.58f
            opennessRatio > 0.42f || horizonYRatio > 0.52f -> 0.64f
            opennessRatio < 0.22f -> 0.74f
            else -> 0.70f
        }
        val perspectiveScale = (depthDrivenScale * 0.58f + vistaScale * 0.42f).coerceIn(0.50f, 0.80f)

        val surfaceLabel = colSurfaceLabels.getOrElse(chosenColFinal) { matToSurfaceLabel(chosenSpot.mat) }

        val result = VisualSceneAnalysis(
            xOffsetPx = xOffsetPx,
            bestVisXRatio = bestVisX,
            bestGroundYRatio = bestGroundY,
            horizonYRatio = horizonYRatio,
            perspectiveScale = perspectiveScale,
            surfaceLabel = surfaceLabel,
            centerHasWaterOrHazard = centerBlocked,
            leftWalkableScore = finalLaneBestScore[0],
            centerWalkableScore = finalLaneBestScore[1],
            rightWalkableScore = finalLaneBestScore[2],
            leftBestYRatio = finalLaneBestY[0],
            centerBestYRatio = finalLaneBestY[1],
            rightBestYRatio = finalLaneBestY[2],
            leftBestXRatio = finalLaneBestX[0],
            centerBestXRatio = finalLaneBestX[1],
            rightBestXRatio = finalLaneBestX[2],
            leftSafeCount = laneSafeCount[0],
            centerSafeCount = laneSafeCount[1],
            rightSafeCount = laneSafeCount[2],
            visColsCount = visColsCount,
            anySafeGroundInScene = anySafeGroundInScene,
            colHasSafeGround = colHasSafeGround,
            colBestVisX = colBestVisX,
            colBestSafeY = colBestSafeY,
            colMinSafeY = colMinSafeY,
            colMaxSafeY = colMaxSafeY,
            colBestScore = colBestScore,
            colSurfaceLabels = colSurfaceLabels
        )
        synchronized(visualSceneAnalysisCache) {
            val inner = visualSceneAnalysisCache.getOrPut(bgBitmap) { mutableMapOf() }
            if (inner.size > 12) inner.clear()
            inner[cacheKey] = result
        }
        result
    } catch (_: Throwable) {
        defaultAnalysis
    } finally {
        try {
            if (proxy != null && !proxy.isRecycled) proxy.recycle()
        } catch (_: Throwable) {}
    }
}

private fun VisualSceneAnalysis.findColumnForVisX(targetVisX: Float): Int {
    if (visColsCount <= 1 || colBestVisX.isEmpty()) return 0
    val first = colBestVisX.first()
    val last = colBestVisX.last()
    if (targetVisX <= first) return 0
    if (targetVisX >= last) return visColsCount - 1
    val frac = ((targetVisX - first) / (last - first).coerceAtLeast(0.01f)).coerceIn(0f, 1f)
    return (frac * (visColsCount - 1)).roundToInt().coerceIn(0, visColsCount - 1)
}

private data class FeetGroundPatchStats(
    val waterFraction: Float,
    val solidFraction: Float,
    val isWaterUnderFeet: Boolean
)

private fun evaluateFeetGroundPatch(
    sampleBitmap: Bitmap,
    previewWidthPx: Float,
    previewHeightPx: Float,
    isVideoViewport: Boolean,
    xOffsetPx: Float,
    groundYRatio: Float,
    userHeightPx: Float
): FeetGroundPatchStats {
    if (sampleBitmap.isRecycled || sampleBitmap.width < 12 || sampleBitmap.height < 12) {
        return FeetGroundPatchStats(0f, 1f, false)
    }
    return try {
        val bgW = sampleBitmap.width.toFloat().coerceAtLeast(1f)
        val bgH = sampleBitmap.height.toFloat().coerceAtLeast(1f)
        val overscan = if (isVideoViewport) 1.07f else 1.0f
        val bgScale = maxOf(previewWidthPx / bgW, previewHeightPx / bgH) * overscan
        val bgDrawX = (previewWidthPx - bgW * bgScale) * 0.5f
        val bgDrawY = (previewHeightPx - bgH * bgScale) * 0.5f

        val centerPx = (previewWidthPx * 0.5f) + xOffsetPx
        val feetPy = (previewHeightPx * groundYRatio).coerceIn(previewHeightPx * 0.54f, previewHeightPx * 0.94f)
        val footHalfW = (userHeightPx * 0.14f).coerceIn(previewWidthPx * 0.05f, previewWidthPx * 0.11f)
        val stepPx = (sampleBitmap.width / 160).coerceIn(1, 6)

        var unwalkableHits = 0
        var solidHits = 0
        var total = 0

        for (iy in -2..2) {
            val py = (feetPy + (iy * previewHeightPx * 0.014f)).coerceIn(2f, previewHeightPx - 2f)
            val by = ((py - bgDrawY) / bgScale).roundToInt().coerceIn(stepPx, sampleBitmap.height - 1 - stepPx)
            for (ix in -3..3) {
                val px = (centerPx + (ix / 3f) * footHalfW).coerceIn(2f, previewWidthPx - 2f)
                val bx = ((px - bgDrawX) / bgScale).roundToInt().coerceIn(stepPx, sampleBitmap.width - 1 - stepPx)

                val c = sampleBitmap.getPixel(bx, by)
                val r = (c ushr 16) and 0xFF
                val g = (c ushr 8) and 0xFF
                val b = c and 0xFF
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                val maxCh = max(r, max(g, b))
                val minCh = min(r, min(g, b))
                val sat = if (maxCh > 0) (maxCh - minCh).toFloat() / maxCh else 0f

                val cL = sampleBitmap.getPixel(bx - stepPx, by)
                val cR = sampleBitmap.getPixel(bx + stepPx, by)
                val cU = sampleBitmap.getPixel(bx, by - stepPx)
                val cD = sampleBitmap.getPixel(bx, by + stepPx)
                val lL = 0.299f * ((cL ushr 16) and 0xFF) + 0.587f * ((cL ushr 8) and 0xFF) + 0.114f * (cL and 0xFF)
                val lR = 0.299f * ((cR ushr 16) and 0xFF) + 0.587f * ((cR ushr 8) and 0xFF) + 0.114f * (cR and 0xFF)
                val lU = 0.299f * ((cU ushr 16) and 0xFF) + 0.587f * ((cU ushr 8) and 0xFF) + 0.114f * (cU and 0xFF)
                val lD = 0.299f * ((cD ushr 16) and 0xFF) + 0.587f * ((cD ushr 8) and 0xFF) + 0.114f * (cD and 0xFF)
                val dx = (abs(((cR ushr 16) and 0xFF) - ((cL ushr 16) and 0xFF)) +
                    abs(((cR ushr 8) and 0xFF) - ((cL ushr 8) and 0xFF)) +
                    abs((cR and 0xFF) - (cL and 0xFF))) / 3f
                val dy = (abs(((cD ushr 16) and 0xFF) - ((cU ushr 16) and 0xFF)) +
                    abs(((cD ushr 8) and 0xFF) - ((cU ushr 8) and 0xFF)) +
                    abs((cD and 0xFF) - (cU and 0xFF))) / 3f
                val microTex = (abs(lL - l) + abs(lR - l) + abs(lU - l) + abs(lD - l)) * 0.25f

                val isGrass = g > r * 1.05f && g > b * 1.13f && microTex >= 1.0f
                val isWarmSandOrEarth = r > b + 12 && microTex >= 1.0f
                val isLiquidWater = !isGrass && (
                    (b > r + 7 && b >= g - 5 && sat > 0.07f) ||
                    (g > r + 7 && b > r + 4 && b >= g * 0.74f && sat > 0.09f) ||
                    (b > r + 4 && b >= g && l < 116f && microTex < 14f)
                )
                val isSmoothUniformOrReflective = !isGrass && !isWarmSandOrEarth && (
                    (microTex < 1.25f && (b >= r - 2 || l > 175f || l < 16f)) ||
                    (dx < 8f && dy > dx * 1.65f + 4.5f && l > 58f)
                )
                val isVerticalWallOrObstacle = dx > dy * 1.50f && dx > 12f

                if (isLiquidWater || isSmoothUniformOrReflective || isVerticalWallOrObstacle) {
                    unwalkableHits++
                } else if (microTex >= 1.1f || isGrass || isWarmSandOrEarth) {
                    solidHits++
                }
                total++
            }
        }
        val waterFrac = if (total > 0) unwalkableHits.toFloat() / total.toFloat() else 0f
        val solidFrac = if (total > 0) solidHits.toFloat() / total.toFloat() else 1f
        FeetGroundPatchStats(
            waterFraction = waterFrac,
            solidFraction = solidFrac,
            isWaterUnderFeet = waterFrac >= 0.16f
        )
    } catch (_: Throwable) {
        FeetGroundPatchStats(0f, 1f, false)
    }
}

/**
 * Universal Worldwide Solid Ground Enforcer (x = 0.15f..0.85f, y = 0.55f..0.90f):
 * Uses texture, edge density, surface flatness, and pixel verification around the feet
 * to place Person 1 and Person 2 on the nearest widest/flattest solid surface worldwide,
 * automatically avoiding smooth/reflective water, sky, and vertical walls/obstacles.
 */
fun snapPlacementToVerifiedSolidGround(
    bgBitmap: Bitmap?,
    locationName: String?,
    desiredXOffsetPx: Float,
    userScale: Float,
    footAnchor: SubjectFootAnchor,
    previewWidthPx: Float,
    previewHeightPx: Float,
    isVideoViewport: Boolean = false,
    desiredGroundYRatioOverride: Float? = null,
    surfaceSinkRatio: Float = 0f
): SafeSolidGroundSnap {
    val pH = previewHeightPx.coerceAtLeast(300f)
    val pW = if (previewWidthPx > 60f) previewWidthPx else pH * (if (isVideoViewport) 9f / 16f else 0.85f)
    val userH = pH * ((210f * userScale) / 380f)

    if (bgBitmap == null || bgBitmap.isRecycled) {
        val fallbackGroundY = 0.88f
        val targetGroundY = if (footAnchor.isHalfBodyCropped) pH * 0.985f else pH * fallbackGroundY
        val yOff = (targetGroundY - pH) + (userH * (1f - footAnchor.lowestContactYRatio))
        return SafeSolidGroundSnap(
            xOffsetPx = desiredXOffsetPx.coerceIn(-pW * 0.35f, pW * 0.35f),
            yOffsetPx = yOff,
            groundYRatio = fallbackGroundY,
            surfaceLabel = "Solid Ground",
            perspectiveScale = 0.68f,
            snappedAwayFromHazard = false,
            verifiedSolidGround = false
        )
    }

    val scene = analyzeVisualSceneForTouristPlacement(
        bgBitmap = bgBitmap,
        locationName = locationName,
        previewWidth = pW,
        previewHeight = pH,
        preferSidePlacement = false,
        isVideoViewport = isVideoViewport
    )

    val boundedDesiredX = desiredXOffsetPx.coerceIn(-pW * 0.35f, pW * 0.35f)
    val targetVisX = (0.50f + (boundedDesiredX / pW)).coerceIn(0.15f, 0.85f)
    val targetCol = scene.findColumnForVisX(targetVisX)

    var chosenCol = targetCol
    var snappedAway = false
    var finalXOffsetPx: Float

    if (scene.anySafeGroundInScene) {
        if (scene.colHasSafeGround.getOrElse(targetCol) { false }) {
            chosenCol = targetCol
            snappedAway = false
            finalXOffsetPx = boundedDesiredX
        } else {
            // Scan the entire x = 0.15f..0.85f width to snap onto the nearest wide, flat verified solid ground column
            var bestCol = -1
            var bestPenalty = Float.MAX_VALUE
            for (colIdx in 0 until scene.visColsCount) {
                if (!scene.colHasSafeGround[colIdx]) continue
                val dist = abs(scene.colBestVisX[colIdx] - targetVisX)
                val penalty = (dist * 3.5f) - (scene.colBestScore[colIdx] * 0.32f)
                if (penalty < bestPenalty) {
                    bestPenalty = penalty
                    bestCol = colIdx
                }
            }
            if (bestCol >= 0) {
                chosenCol = bestCol
                snappedAway = true
                finalXOffsetPx = ((scene.colBestVisX[bestCol] - 0.50f) * pW).coerceIn(-pW * 0.35f, pW * 0.35f)
            } else {
                finalXOffsetPx = scene.xOffsetPx.coerceIn(-pW * 0.35f, pW * 0.35f)
            }
        }
    } else {
        chosenCol = scene.findColumnForVisX(scene.bestVisXRatio)
        snappedAway = abs(scene.bestVisXRatio - targetVisX) > 0.04f
        finalXOffsetPx = scene.xOffsetPx.coerceIn(-pW * 0.35f, pW * 0.35f)
    }

    var colMinY = scene.colMinSafeY.getOrElse(chosenCol) { 0.55f }.coerceIn(0.55f, 0.90f)
    var colMaxY = scene.colMaxSafeY.getOrElse(chosenCol) { 0.90f }.coerceIn(colMinY, 0.90f)
    val colBestY = scene.colBestSafeY.getOrElse(chosenCol) { scene.bestGroundYRatio }.coerceIn(colMinY, colMaxY)
    var lockedGroundYRatio = (desiredGroundYRatioOverride ?: colBestY).coerceIn(colMinY, colMaxY)

    // Direct pixel-level verification around the actual feet area across x = 0.15..0.85
    var tempSwBmp: Bitmap? = null
    try {
        val sampleBmp: Bitmap = if (android.os.Build.VERSION.SDK_INT >= 26 && bgBitmap.config == Bitmap.Config.HARDWARE) {
            bgBitmap.copy(Bitmap.Config.ARGB_8888, false).also { tempSwBmp = it }
        } else {
            bgBitmap
        }
        val initialFeetCheckY = if (footAnchor.isHalfBodyCropped) 0.90f else lockedGroundYRatio
        val currentPatch = evaluateFeetGroundPatch(
            sampleBitmap = sampleBmp,
            previewWidthPx = pW,
            previewHeightPx = pH,
            isVideoViewport = isVideoViewport,
            xOffsetPx = finalXOffsetPx,
            groundYRatio = initialFeetCheckY,
            userHeightPx = userH
        )
        if (currentPatch.isWaterUnderFeet) {
            val stepPx = (pW * 0.030f).coerceAtLeast(10f)
            val maxShiftPx = pW * 0.38f
            val maxSteps = (maxShiftPx / stepPx).roundToInt().coerceAtLeast(1)
            var foundCandX: Float? = null
            var foundCandCol = chosenCol
            var foundCandY = lockedGroundYRatio
            var bestFallbackDryX: Float? = null
            var bestFallbackDryCol = chosenCol
            var bestFallbackDryY = lockedGroundYRatio
            var bestFallbackWater = currentPatch.waterFraction
            var bestFallbackSolid = currentPatch.solidFraction

            for (stepIdx in 1..maxSteps) {
                val delta = stepIdx * stepPx
                val candidates = listOf(finalXOffsetPx - delta, finalXOffsetPx + delta)
                var chosenAtThisDist: Triple<Float, Int, Float>? = null
                var chosenAtThisDistWater = Float.MAX_VALUE
                var chosenAtThisDistSolid = -1f

                for (rawCandX in candidates) {
                    if (rawCandX < -pW * 0.35f || rawCandX > pW * 0.35f) continue
                    val candVisX = (0.50f + (rawCandX / pW)).coerceIn(0.15f, 0.85f)
                    val candCol = scene.findColumnForVisX(candVisX)
                    val candMinY = scene.colMinSafeY.getOrElse(candCol) { 0.55f }.coerceIn(0.55f, 0.90f)
                    val candMaxY = scene.colMaxSafeY.getOrElse(candCol) { 0.90f }.coerceIn(candMinY, 0.90f)
                    val candColBestY = scene.colBestSafeY.getOrElse(candCol) { scene.bestGroundYRatio }.coerceIn(candMinY, candMaxY)
                    val candGroundY = if (footAnchor.isHalfBodyCropped) 0.90f else (desiredGroundYRatioOverride ?: candColBestY).coerceIn(candMinY, candMaxY)
                    val candCheckY = if (footAnchor.isHalfBodyCropped) 0.90f else candGroundY

                    val stats = evaluateFeetGroundPatch(
                        sampleBitmap = sampleBmp,
                        previewWidthPx = pW,
                        previewHeightPx = pH,
                        isVideoViewport = isVideoViewport,
                        xOffsetPx = rawCandX,
                        groundYRatio = candCheckY,
                        userHeightPx = userH
                    )
                    if (!stats.isWaterUnderFeet && stats.waterFraction <= 0.08f && stats.solidFraction >= 0.42f) {
                        val isColSafe = !scene.anySafeGroundInScene || scene.colHasSafeGround.getOrElse(candCol) { false }
                        val colQuality = scene.colBestScore.getOrElse(candCol) { 0f }.coerceIn(0f, 3f) * 0.2f
                        val scorePrefer = (if (isColSafe) 1f else 0f) + stats.solidFraction + colQuality - stats.waterFraction * 2f
                        val prevScorePrefer = chosenAtThisDistSolid - chosenAtThisDistWater * 2f
                        if (chosenAtThisDist == null || scorePrefer > prevScorePrefer) {
                            chosenAtThisDist = Triple(rawCandX, candCol, candGroundY)
                            chosenAtThisDistWater = stats.waterFraction
                            chosenAtThisDistSolid = stats.solidFraction + colQuality + (if (isColSafe) 1f else 0f)
                        }
                    } else if (stats.waterFraction < bestFallbackWater - 0.05f ||
                        (abs(stats.waterFraction - bestFallbackWater) <= 0.05f && stats.solidFraction > bestFallbackSolid)
                    ) {
                        bestFallbackWater = stats.waterFraction
                        bestFallbackSolid = stats.solidFraction
                        bestFallbackDryX = rawCandX
                        bestFallbackDryCol = candCol
                        bestFallbackDryY = candGroundY
                    }
                }
                if (chosenAtThisDist != null) {
                    foundCandX = chosenAtThisDist.first
                    foundCandCol = chosenAtThisDist.second
                    foundCandY = chosenAtThisDist.third
                    break
                }
            }

            if (foundCandX != null) {
                finalXOffsetPx = foundCandX
                chosenCol = foundCandCol
                colMinY = scene.colMinSafeY.getOrElse(chosenCol) { 0.55f }.coerceIn(0.55f, 0.90f)
                colMaxY = scene.colMaxSafeY.getOrElse(chosenCol) { 0.90f }.coerceIn(colMinY, 0.90f)
                lockedGroundYRatio = foundCandY.coerceIn(colMinY, colMaxY)
                snappedAway = true
            } else if (bestFallbackDryX != null && bestFallbackWater < currentPatch.waterFraction * 0.70f) {
                finalXOffsetPx = bestFallbackDryX
                chosenCol = bestFallbackDryCol
                colMinY = scene.colMinSafeY.getOrElse(chosenCol) { 0.55f }.coerceIn(0.55f, 0.90f)
                colMaxY = scene.colMaxSafeY.getOrElse(chosenCol) { 0.90f }.coerceIn(colMinY, 0.90f)
                lockedGroundYRatio = bestFallbackDryY.coerceIn(colMinY, colMaxY)
                snappedAway = true
            }
        }
    } catch (_: Throwable) {
    } finally {
        try {
            if (tempSwBmp != null && !tempSwBmp!!.isRecycled) tempSwBmp!!.recycle()
        } catch (_: Throwable) {}
    }

    val sinkPx = userH * surfaceSinkRatio
    val targetGroundY = if (footAnchor.isHalfBodyCropped) {
        pH * 0.985f
    } else {
        val rawGroundY = pH * lockedGroundYRatio
        val maxColGroundY = pH * colMaxY
        val minHeadClearY = (footAnchor.lowestContactYRatio * userH) + 8f
        if (minHeadClearY > rawGroundY) {
            min(minHeadClearY, max(rawGroundY, maxColGroundY))
        } else {
            rawGroundY
        }
    }
    val finalYOffsetPx = (targetGroundY - pH) + (userH * (1f - footAnchor.lowestContactYRatio)) - sinkPx

    return SafeSolidGroundSnap(
        xOffsetPx = finalXOffsetPx,
        yOffsetPx = finalYOffsetPx,
        groundYRatio = lockedGroundYRatio,
        surfaceLabel = scene.colSurfaceLabels.getOrElse(chosenCol) { scene.surfaceLabel },
        perspectiveScale = scene.perspectiveScale,
        snappedAwayFromHazard = snappedAway,
        verifiedSolidGround = scene.anySafeGroundInScene && scene.colHasSafeGround.getOrElse(chosenCol) { false }
    )
}

fun findSafeWalkableGroundYForXOffset(
    bgBitmap: Bitmap?,
    locationName: String?,
    xOffsetPx: Float,
    previewWidthPx: Float,
    previewHeightPx: Float = 0f,
    isVideoViewport: Boolean = false
): Float? {
    if (bgBitmap == null || bgBitmap.isRecycled || previewWidthPx <= 0f) return null
    val scene = analyzeVisualSceneForTouristPlacement(
        bgBitmap = bgBitmap,
        locationName = locationName,
        previewWidth = previewWidthPx,
        previewHeight = previewHeightPx,
        preferSidePlacement = false,
        isVideoViewport = isVideoViewport
    )
    val visX = (0.50f + (xOffsetPx / previewWidthPx.coerceAtLeast(360f))).coerceIn(0.08f, 0.92f)
    val col = scene.findColumnForVisX(visX)
    return if (!scene.anySafeGroundInScene || scene.colHasSafeGround.getOrElse(col) { false }) {
        scene.colBestSafeY.getOrElse(col) { scene.bestGroundYRatio }
    } else {
        scene.bestGroundYRatio
    }
}

fun computeSmartSurfacePlacement(
    bgBitmap: Bitmap?,
    locationName: String?,
    previewWidth: Float,
    previewHeight: Float = 0f,
    isVideoViewport: Boolean = false
): Pair<Float, Float> {
    val scene = analyzeVisualSceneForTouristPlacement(
        bgBitmap = bgBitmap,
        locationName = locationName,
        previewWidth = previewWidth,
        previewHeight = previewHeight,
        preferSidePlacement = false,
        isVideoViewport = isVideoViewport
    )
    return Pair(scene.xOffsetPx, scene.perspectiveScale)
}

/**
 * Voice-AI-Only Photo Selector Scorer:
 * Evaluates a candidate background photo from the 5 fetched location photos to pick
 * the best eye-level ground shot with a wide, flat walkable foreground (skipping
 * aerial/drone, water-only, or steep cliff shots).
 */
fun scorePhotoForVoiceEyeLevelGround(
    bitmap: Bitmap?,
    isVideoViewport: Boolean = false
): Float {
    if (bitmap == null || bitmap.isRecycled || bitmap.width < 64 || bitmap.height < 64) {
        return -1000f
    }
    var tempSw: Bitmap? = null
    return try {
        val sampleBmp = if (android.os.Build.VERSION.SDK_INT >= 26 && bitmap.config == Bitmap.Config.HARDWARE) {
            bitmap.copy(Bitmap.Config.ARGB_8888, false).also { tempSw = it }
        } else {
            bitmap
        }
        val pW = 1080f
        val pH = if (isVideoViewport) 1920f else 1350f
        val scene = analyzeVisualSceneForTouristPlacement(
            bgBitmap = sampleBmp,
            locationName = null,
            previewWidth = pW,
            previewHeight = pH,
            preferSidePlacement = false,
            isVideoViewport = isVideoViewport
        )

        // Compute longest contiguous safe solid column span & total safe ground coverage across x = 0.15..0.85
        val totalCols = scene.visColsCount.coerceAtLeast(1)
        var safeCols = 0
        var maxRun = 0
        var curRun = 0
        var scoreSum = 0f
        for (i in 0 until totalCols) {
            if (scene.colHasSafeGround.getOrElse(i) { false }) {
                safeCols++
                curRun++
                if (curRun > maxRun) maxRun = curRun
                scoreSum += scene.colBestScore.getOrElse(i) { 0f }.coerceAtLeast(0f)
            } else {
                curRun = 0
            }
        }
        val safeColFrac = safeCols.toFloat() / totalCols.toFloat()
        val longestSpanFrac = maxRun.toFloat() / totalCols.toFloat()
        val avgSafeQuality = if (safeCols > 0) scoreSum / safeCols.toFloat() else -1f

        // Fast 48x36 grid check for aerial/drone top clutter vs eye-level sky, water-only, and steep cliffs
        val gw = 48
        val gh = 36
        val scaled = Bitmap.createScaledBitmap(sampleBmp, gw, gh, true)
        val px = IntArray(gw * gh)
        scaled.getPixels(px, 0, gw, 0, 0, gw, gh)
        if (!scaled.isRecycled && scaled !== sampleBmp) scaled.recycle()

        var topSky = 0
        var topClutter = 0
        var topTotal = 0
        var lowerWater = 0
        var lowerCliff = 0
        var lowerTotal = 0

        for (y in 1 until gh - 1) {
            for (x in 1 until gw - 1) {
                val c = px[y * gw + x]
                val r = (c ushr 16) and 0xFF
                val g = (c ushr 8) and 0xFF
                val b = c and 0xFF
                val lum = 0.299f * r + 0.587f * g + 0.114f * b
                val maxCh = max(r, max(g, b))
                val minCh = min(r, min(g, b))
                val sat = if (maxCh > 0) (maxCh - minCh).toFloat() / maxCh else 0f

                val cR = px[y * gw + (x + 1)]
                val cD = px[(y + 1) * gw + x]
                val lR = 0.299f * ((cR ushr 16) and 0xFF) + 0.587f * ((cR ushr 8) and 0xFF) + 0.114f * (cR and 0xFF)
                val lD = 0.299f * ((cD ushr 16) and 0xFF) + 0.587f * ((cD ushr 8) and 0xFF) + 0.114f * (cD and 0xFF)
                val gx = abs(lum - lR)
                val gy = abs(lum - lD)

                val normY = y.toFloat() / gh.toFloat()
                if (normY <= 0.26f) {
                    topTotal++
                    if ((b > r + 8 && lum > 85f) || (lum > 180f && sat < 0.22f) || (gx + gy < 12f && lum > 110f)) {
                        topSky++
                    }
                    if (gx + gy > 34f) topClutter++
                } else if (normY >= 0.55f) {
                    lowerTotal++
                    val isGrass = g > r * 1.05f && g > b * 1.13f
                    val isWater = !isGrass && (
                        (b > r + 10 && b >= g - 5 && sat > 0.09f) ||
                        (g > r + 10 && b > r + 6 && sat > 0.12f) ||
                        (gx < 3f && gy < 3f && b >= r - 2 && lum in 45f..190f)
                    )
                    val isCliffWall = gx > gy * 1.48f && gx > 12f
                    if (isWater) lowerWater++
                    if (isCliffWall) lowerCliff++
                }
            }
        }

        val topSkyFrac = if (topTotal > 0) topSky.toFloat() / topTotal else 0f
        val topClutterFrac = if (topTotal > 0) topClutter.toFloat() / topTotal else 0f
        val lowerWaterFrac = if (lowerTotal > 0) lowerWater.toFloat() / lowerTotal else 0f
        val lowerCliffFrac = if (lowerTotal > 0) lowerCliff.toFloat() / lowerTotal else 0f

        var score = 0f
        // Reward wide, flat walkable foreground & high surface flatness quality
        score += longestSpanFrac * 140f
        score += safeColFrac * 85f
        score += avgSafeQuality.coerceIn(-1f, 5f) * 20f
        // Reward eye-level camera framing with horizon & foreground ground depth
        val groundDepth = (scene.bestGroundYRatio - scene.horizonYRatio).coerceIn(0f, 0.65f)
        score += groundDepth * 45f
        if (scene.horizonYRatio in 0.25f..0.60f) score += 24f
        score += topSkyFrac.coerceAtMost(0.45f) * 35f
        if (!scene.centerHasWaterOrHazard) score += 18f

        // Skip / heavily penalize aerial-drone, water-only, and steep cliff shots
        val isAerialOrTopDown = topSkyFrac < 0.04f && topClutterFrac > 0.24f && scene.horizonYRatio < 0.30f
        if (isAerialOrTopDown) score -= 420f
        if (!scene.anySafeGroundInScene || longestSpanFrac < 0.14f) score -= 500f
        if (lowerWaterFrac > 0.60f && longestSpanFrac < 0.22f) score -= 360f
        if (lowerCliffFrac > 0.32f && longestSpanFrac < 0.24f) score -= 320f
        score -= lowerWaterFrac * 70f
        score -= lowerCliffFrac * 80f

        score
    } catch (_: Throwable) {
        0f
    } finally {
        try {
            if (tempSw != null && !tempSw!!.isRecycled) tempSw!!.recycle()
        } catch (_: Throwable) {}
    }
}

private data class CoupleGroundFit(
    val x1: Float,
    val y1: Float,
    val x2: Float,
    val y2: Float,
    val snappedAway: Boolean,
    val surfaceLabel: String
)

/**
 * Places Person 1 and Person 2 side-by-side naturally onto verified wide solid foreground ground
 * without overlapping, keeping both feet anchored at a consistent ground depth.
 */
private fun fitTwoPeopleSideBySideOnGround(
    bgBitmap: Bitmap?,
    locationName: String?,
    centerDesiredXOffset: Float,
    studioScale: Float,
    footAnchor1: SubjectFootAnchor,
    footAnchor2: SubjectFootAnchor,
    previewWidthPx: Float,
    previewHeightPx: Float,
    isVideoViewport: Boolean,
    desiredGroundYRatioOverride: Float? = null
): CoupleGroundFit {
    val pW = previewWidthPx.coerceAtLeast(360f)
    val pH = previewHeightPx.coerceAtLeast(300f)
    val spreadPx = (pW * 0.23f * (studioScale / 0.68f)).coerceIn(pW * 0.17f, pW * 0.30f)
    val halfSpread = spreadPx * 0.5f
    val clampedCenter = centerDesiredXOffset.coerceIn(-pW * 0.20f, pW * 0.20f)
    val rawX1 = (clampedCenter - halfSpread).coerceIn(-pW * 0.35f, pW * 0.35f)
    val rawX2 = (clampedCenter + halfSpread).coerceIn(-pW * 0.35f, pW * 0.35f)

    val snap1 = snapPlacementToVerifiedSolidGround(
        bgBitmap = bgBitmap,
        locationName = locationName,
        desiredXOffsetPx = rawX1,
        userScale = studioScale,
        footAnchor = footAnchor1,
        previewWidthPx = pW,
        previewHeightPx = pH,
        isVideoViewport = isVideoViewport,
        desiredGroundYRatioOverride = desiredGroundYRatioOverride
    )
    var snap2 = snapPlacementToVerifiedSolidGround(
        bgBitmap = bgBitmap,
        locationName = locationName,
        desiredXOffsetPx = rawX2,
        userScale = studioScale,
        footAnchor = footAnchor2,
        previewWidthPx = pW,
        previewHeightPx = pH,
        isVideoViewport = isVideoViewport,
        desiredGroundYRatioOverride = desiredGroundYRatioOverride ?: snap1.groundYRatio
    )

    // Prevent both cutouts from stacking onto the exact same column if one edge had water/hazard
    val minSeparation = pW * 0.145f
    if (abs(snap2.xOffsetPx - snap1.xOffsetPx) < minSeparation) {
        val rightCandX = (snap1.xOffsetPx + spreadPx).coerceIn(-pW * 0.35f, pW * 0.35f)
        val leftCandX = (snap1.xOffsetPx - spreadPx).coerceIn(-pW * 0.35f, pW * 0.35f)
        val candRight = snapPlacementToVerifiedSolidGround(
            bgBitmap = bgBitmap,
            locationName = locationName,
            desiredXOffsetPx = rightCandX,
            userScale = studioScale,
            footAnchor = footAnchor2,
            previewWidthPx = pW,
            previewHeightPx = pH,
            isVideoViewport = isVideoViewport,
            desiredGroundYRatioOverride = desiredGroundYRatioOverride ?: snap1.groundYRatio
        )
        val candLeft = snapPlacementToVerifiedSolidGround(
            bgBitmap = bgBitmap,
            locationName = locationName,
            desiredXOffsetPx = leftCandX,
            userScale = studioScale,
            footAnchor = footAnchor2,
            previewWidthPx = pW,
            previewHeightPx = pH,
            isVideoViewport = isVideoViewport,
            desiredGroundYRatioOverride = desiredGroundYRatioOverride ?: snap1.groundYRatio
        )
        val rightDist = abs(candRight.xOffsetPx - snap1.xOffsetPx)
        val leftDist = abs(candLeft.xOffsetPx - snap1.xOffsetPx)
        snap2 = when {
            rightDist >= minSeparation && leftDist >= minSeparation ->
                if (candRight.verifiedSolidGround && !candLeft.verifiedSolidGround) candRight
                else if (candLeft.verifiedSolidGround && !candRight.verifiedSolidGround) candLeft
                else if (abs(rightCandX) <= abs(leftCandX)) candRight else candLeft
            rightDist >= minSeparation -> candRight
            leftDist >= minSeparation -> candLeft
            else -> snap2
        }
    }

    return CoupleGroundFit(
        x1 = snap1.xOffsetPx,
        y1 = snap1.yOffsetPx,
        x2 = snap2.xOffsetPx,
        y2 = snap2.yOffsetPx,
        snappedAway = snap1.snappedAwayFromHazard || snap2.snappedAwayFromHazard,
        surfaceLabel = snap1.surfaceLabel
    )
}

data class GeminiVisionGroundResult(
    val x: Float,
    val y: Float,
    val scale: Float
)

private val voiceVisionHttpClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .callTimeout(14, TimeUnit.SECONDS)
        .build()
}

/**
 * Gemini Vision AI Voice Ground Detector:
 * Crops the selected background bitmap to the exact visible Preview Canvas / Video viewport
 * (matching ContentScale.Crop), sends it to Gemini Vision with a fast JSON prompt, and returns
 * exact normalized (x, y) coordinates (0.0..1.0) and human scale (0.2..0.8) where a person
 * can naturally stand flat on solid ground/sand/floor/walkway.
 */
suspend fun detectGroundPlacementWithGeminiVision(
    bgBitmap: Bitmap?,
    previewWidthPx: Float,
    previewHeightPx: Float,
    isVideoViewport: Boolean = false,
    apiKey: String = BuildConfig.GEMINI_API_KEY
): GeminiVisionGroundResult? = withContext(Dispatchers.IO) {
    if (bgBitmap == null || bgBitmap.isRecycled || bgBitmap.width < 32 || bgBitmap.height < 32) {
        return@withContext null
    }
    val effectiveKey = apiKey.trim()
    if (effectiveKey.isEmpty() ||
        effectiveKey == "MY_GEMINI_API_KEY" ||
        effectiveKey == "YOUR_GEMINI_API_KEY" ||
        effectiveKey.contains("TODO") ||
        effectiveKey.contains("YOUR_")
    ) {
        return@withContext null
    }

    var tempSw: Bitmap? = null
    var croppedBmp: Bitmap? = null
    var scaledBmp: Bitmap? = null
    try {
        val srcBmp = if (android.os.Build.VERSION.SDK_INT >= 26 && bgBitmap.config == Bitmap.Config.HARDWARE) {
            bgBitmap.copy(Bitmap.Config.ARGB_8888, false).also { tempSw = it }
        } else {
            bgBitmap
        }

        val pW = previewWidthPx.coerceAtLeast(360f)
        val pH = previewHeightPx.coerceAtLeast(300f)
        val containerAspect = when {
            isVideoViewport -> 9f / 16f
            previewHeightPx > 120f -> (pW / pH).coerceIn(0.45f, 1.35f)
            else -> 0.84f
        }
        val bgAspect = srcBmp.width.toFloat() / srcBmp.height.toFloat().coerceAtLeast(1f)
        val overscan = if (isVideoViewport) 1f / 1.07f else 1f
        val visMinX: Float
        val visMaxX: Float
        val visMinY: Float
        val visMaxY: Float
        if (bgAspect > containerAspect) {
            val visFracW = ((containerAspect / bgAspect) * overscan).coerceIn(0.32f, 1.0f)
            visMinX = (0.5f - visFracW * 0.5f).coerceIn(0f, 0.34f)
            visMaxX = (0.5f + visFracW * 0.5f).coerceIn(0.66f, 1.0f)
            val yTrim = (1f - overscan) * 0.5f
            visMinY = yTrim
            visMaxY = 1f - yTrim
        } else {
            val visFracH = ((bgAspect / containerAspect) * overscan).coerceIn(0.40f, 1.0f)
            val xTrim = (1f - overscan) * 0.5f
            visMinX = xTrim
            visMaxX = 1f - xTrim
            visMinY = (0.5f - visFracH * 0.5f).coerceIn(0f, 0.30f)
            visMaxY = (0.5f + visFracH * 0.5f).coerceIn(0.70f, 1.0f)
        }

        val cropX = (visMinX * srcBmp.width).roundToInt().coerceIn(0, (srcBmp.width - 16).coerceAtLeast(0))
        val cropY = (visMinY * srcBmp.height).roundToInt().coerceIn(0, (srcBmp.height - 16).coerceAtLeast(0))
        val cropW = ((visMaxX - visMinX) * srcBmp.width).roundToInt().coerceIn(16, (srcBmp.width - cropX).coerceAtLeast(16))
        val cropH = ((visMaxY - visMinY) * srcBmp.height).roundToInt().coerceIn(16, (srcBmp.height - cropY).coerceAtLeast(16))

        croppedBmp = if (cropX == 0 && cropY == 0 && cropW == srcBmp.width && cropH == srcBmp.height) {
            srcBmp
        } else {
            Bitmap.createBitmap(srcBmp, cropX, cropY, cropW, cropH)
        }

        val maxSide = max(croppedBmp.width, croppedBmp.height)
        scaledBmp = if (maxSide > 768) {
            val ratio = 768f / maxSide.toFloat()
            val targetW = (croppedBmp.width * ratio).roundToInt().coerceAtLeast(64)
            val targetH = (croppedBmp.height * ratio).roundToInt().coerceAtLeast(64)
            Bitmap.createScaledBitmap(croppedBmp, targetW, targetH, true)
        } else {
            croppedBmp
        }

        val baos = ByteArrayOutputStream()
        scaledBmp.compress(Bitmap.CompressFormat.JPEG, 82, baos)
        val base64Image = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)

        val visionPrompt = "Return the exact normalized (x, y) coordinates (from 0.0 to 1.0) and appropriate human scale (0.2 to 0.8) where a person can naturally stand flat on the ground/sand/floor/walkway—strictly avoiding rocks, ledges, walls, water, or mid-air. Return ONLY valid JSON like {\"x\": 0.50, \"y\": 0.82, \"scale\": 0.65}."

        val requestJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", visionPrompt)
                        })
                        put(JSONObject().apply {
                            put("inlineData", JSONObject().apply {
                                put("mimeType", "image/jpeg")
                                put("data", base64Image)
                            })
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.1)
                put("maxOutputTokens", 128)
                put("responseMimeType", "application/json")
            })
        }

        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$effectiveKey"
        val requestBody = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(endpoint)
            .post(requestBody)
            .build()

        voiceVisionHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext null
            val bodyStr = response.body?.string() ?: return@withContext null
            val respJson = JSONObject(bodyStr)
            val candidates = respJson.optJSONArray("candidates") ?: return@withContext null
            if (candidates.length() == 0) return@withContext null
            val parts = candidates.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts") ?: return@withContext null

            var rawText = ""
            for (i in 0 until parts.length()) {
                rawText += parts.optJSONObject(i)?.optString("text", "").orEmpty()
            }
            val cleaned = rawText
                .replace("```json", "", ignoreCase = true)
                .replace("```", "")
                .trim()
            val startIdx = cleaned.indexOf('{')
            val endIdx = cleaned.lastIndexOf('}')
            if (startIdx < 0 || endIdx <= startIdx) return@withContext null
            val payload = JSONObject(cleaned.substring(startIdx, endIdx + 1))

            if (!payload.has("x") || !payload.has("y") || !payload.has("scale")) {
                return@withContext null
            }
            val rawX = payload.getDouble("x").toFloat()
            val rawY = payload.getDouble("y").toFloat()
            val rawScale = payload.getDouble("scale").toFloat()
            if (rawX.isNaN() || rawY.isNaN() || rawScale.isNaN() ||
                rawX.isInfinite() || rawY.isInfinite() || rawScale.isInfinite()
            ) {
                return@withContext null
            }

            GeminiVisionGroundResult(
                x = rawX.coerceIn(0.08f, 0.92f),
                y = rawY.coerceIn(0.30f, 0.96f),
                scale = rawScale.coerceIn(0.20f, 0.80f)
            )
        }
    } catch (_: Throwable) {
        null
    } finally {
        try {
            val sw = tempSw
            if (scaledBmp != null && scaledBmp !== croppedBmp && scaledBmp !== sw && scaledBmp !== bgBitmap && !scaledBmp.isRecycled) {
                scaledBmp.recycle()
            }
            if (croppedBmp != null && croppedBmp !== sw && croppedBmp !== bgBitmap && !croppedBmp.isRecycled) {
                croppedBmp.recycle()
            }
            if (sw != null && sw !== bgBitmap && !sw.isRecycled) {
                sw.recycle()
            }
        } catch (_: Throwable) {}
    }
}

/**
 * 100% Original Auto-Realism Calculator:
 * Combines Gemini Vision exact flat-ground (x, y, scale) placement with local fallback
 * walkable ground analysis, exact shoe-sole grounding (for 1 or 2 persons side-by-side),
 * scene lighting, cool/warm tint, and contact 3D shadow depth from the live background bitmap.
 */
fun computeVoiceAutoRealism(
    bgBitmap: Bitmap?,
    command: ParsedVoiceCommand,
    sourceAnalysis: SourcePhotoAnalysis?,
    previewWidthPx: Float,
    previewHeightPx: Float,
    subjectBitmap: Bitmap? = null,
    subjectBitmap2: Bitmap? = null,
    isVideoViewport: Boolean = (command.outputType == VoiceOutputType.VIDEO_15S),
    geminiVisionGround: GeminiVisionGroundResult? = null
): VoiceAutoRealismPlan {
    val bgLighting = analyzeVideoBackgroundLighting(bgBitmap)
    val sceneAdaptive = analyzeAnyBackgroundBitmap(
        bgBitmap = bgBitmap,
        landmarkFallbackName = command.locationQuery,
        isCoolToneFallback = command.sceneMood == VoiceSceneMood.SNOW || command.sceneMood == VoiceSceneMood.NIGHT
    )

    val pW = previewWidthPx.coerceAtLeast(360f)
    val pH = previewHeightPx.coerceAtLeast(300f)
    val hasSecondPerson = subjectBitmap2 != null && !subjectBitmap2.isRecycled

    val footAnchor = if (subjectBitmap != null && !subjectBitmap.isRecycled) {
        detectSubjectFootAnchor(subjectBitmap)
    } else {
        SubjectFootAnchor()
    }

    val adjustedScale: Float
    val xOffset: Float
    val yOffset: Float
    val xOffset2: Float
    val yOffset2: Float
    val surfaceLabel: String
    var waterGuardrailTriggered = false

    if (geminiVisionGround != null) {
        val visionScale = geminiVisionGround.scale.coerceIn(0.20f, 0.80f)
        adjustedScale = visionScale

        val userH1 = pH * ((210f * visionScale) / 380f)
        val aspect1 = if (subjectBitmap != null && !subjectBitmap.isRecycled && subjectBitmap.height > 0) {
            subjectBitmap.width.toFloat() / subjectBitmap.height.toFloat()
        } else {
            0.72f
        }
        val userW1 = userH1 * aspect1
        val targetFeetX1 = pW * geminiVisionGround.x.coerceIn(0.08f, 0.92f)
        xOffset = (targetFeetX1 - (pW * 0.5f) - ((footAnchor.feetCenterRatioX - 0.5f) * userW1))
            .coerceIn(-pW * 0.42f, pW * 0.42f)

        val targetGroundY1 = if (footAnchor.isHalfBodyCropped) {
            pH * 0.985f
        } else {
            val rawY = pH * geminiVisionGround.y.coerceIn(0.30f, 0.96f)
            val minHeadClearY = (footAnchor.lowestContactYRatio * userH1) + 8f
            max(rawY, min(minHeadClearY, pH * 0.96f))
        }
        yOffset = (targetGroundY1 - pH) + (userH1 * (1f - footAnchor.lowestContactYRatio))

        if (hasSecondPerson) {
            val footAnchor2 = detectSubjectFootAnchor(subjectBitmap2!!)
            val userH2 = pH * ((210f * visionScale) / 380f)
            val aspect2 = if (subjectBitmap2.height > 0) {
                subjectBitmap2.width.toFloat() / subjectBitmap2.height.toFloat()
            } else {
                0.72f
            }
            val userW2 = userH2 * aspect2
            val spreadPx = (max(userW1, userW2) * 0.54f).coerceIn(pW * 0.14f, pW * 0.28f)
            val rightCandidate = xOffset + spreadPx
            val leftCandidate = xOffset - spreadPx
            xOffset2 = if (rightCandidate <= pW * 0.40f && (xOffset <= 0f || leftCandidate < -pW * 0.40f)) {
                rightCandidate.coerceIn(-pW * 0.42f, pW * 0.42f)
            } else {
                leftCandidate.coerceIn(-pW * 0.42f, pW * 0.42f)
            }
            val targetGroundY2 = if (footAnchor2.isHalfBodyCropped) {
                pH * 0.985f
            } else {
                val rawY2 = pH * geminiVisionGround.y.coerceIn(0.30f, 0.96f)
                val minHeadClearY2 = (footAnchor2.lowestContactYRatio * userH2) + 8f
                max(rawY2, min(minHeadClearY2, pH * 0.96f))
            }
            yOffset2 = (targetGroundY2 - pH) + (userH2 * (1f - footAnchor2.lowestContactYRatio))
        } else {
            xOffset2 = 150f
            yOffset2 = 60f
        }
        surfaceLabel = "Vision Ground"
    } else {
        val scene = analyzeVisualSceneForTouristPlacement(
            bgBitmap = bgBitmap,
            locationName = command.locationQuery,
            previewWidth = previewWidthPx,
            previewHeight = previewHeightPx,
            preferSidePlacement = command.preferSidePlacement,
            isVideoViewport = isVideoViewport
        )
        val baseScale = scene.perspectiveScale

        adjustedScale = when (command.sizeHint) {
            VoiceSizeHint.SMALL -> (baseScale * 0.78f).coerceIn(0.46f, 0.78f)
            VoiceSizeHint.LARGE -> (baseScale * 1.18f).coerceIn(0.54f, if (hasSecondPerson) 0.78f else 0.86f)
            VoiceSizeHint.MEDIUM -> baseScale.coerceIn(0.50f, if (hasSecondPerson) 0.75f else 0.80f)
            VoiceSizeHint.AUTO -> baseScale.coerceIn(0.50f, if (hasSecondPerson) 0.75f else 0.80f)
        }

        val rawDesiredXOffset: Float
        when (command.positionHint) {
            VoicePositionHint.LEFT -> {
                if (scene.leftSafeCount == 0 && (scene.rightSafeCount > 0 || scene.centerSafeCount > 0)) {
                    rawDesiredXOffset = scene.xOffsetPx
                    waterGuardrailTriggered = true
                } else {
                    val safeX = scene.leftBestXRatio.coerceIn(0.15f, 0.36f)
                    rawDesiredXOffset = (safeX - 0.50f) * pW
                }
            }
            VoicePositionHint.RIGHT -> {
                if (scene.rightSafeCount == 0 && (scene.leftSafeCount > 0 || scene.centerSafeCount > 0)) {
                    rawDesiredXOffset = scene.xOffsetPx
                    waterGuardrailTriggered = true
                } else {
                    val safeX = scene.rightBestXRatio.coerceIn(0.64f, 0.85f)
                    rawDesiredXOffset = (safeX - 0.50f) * pW
                }
            }
            VoicePositionHint.CENTER -> {
                if (scene.centerSafeCount == 0 && scene.centerHasWaterOrHazard) {
                    rawDesiredXOffset = scene.xOffsetPx
                    waterGuardrailTriggered = true
                } else {
                    rawDesiredXOffset = ((scene.centerBestXRatio - 0.50f) * pW * 0.60f)
                }
            }
            VoicePositionHint.AUTO -> {
                rawDesiredXOffset = scene.xOffsetPx
            }
        }

        if (hasSecondPerson) {
            val footAnchor2 = detectSubjectFootAnchor(subjectBitmap2!!)
            val coupleFit = fitTwoPeopleSideBySideOnGround(
                bgBitmap = bgBitmap,
                locationName = command.locationQuery,
                centerDesiredXOffset = rawDesiredXOffset,
                studioScale = adjustedScale,
                footAnchor1 = footAnchor,
                footAnchor2 = footAnchor2,
                previewWidthPx = pW,
                previewHeightPx = pH,
                isVideoViewport = isVideoViewport
            )
            xOffset = coupleFit.x1
            yOffset = coupleFit.y1
            xOffset2 = coupleFit.x2
            yOffset2 = coupleFit.y2
            surfaceLabel = coupleFit.surfaceLabel
            if (coupleFit.snappedAway) waterGuardrailTriggered = true
        } else {
            val snap = snapPlacementToVerifiedSolidGround(
                bgBitmap = bgBitmap,
                locationName = command.locationQuery,
                desiredXOffsetPx = rawDesiredXOffset,
                userScale = adjustedScale,
                footAnchor = footAnchor,
                previewWidthPx = pW,
                previewHeightPx = pH,
                isVideoViewport = isVideoViewport
            )
            xOffset = snap.xOffsetPx
            yOffset = snap.yOffsetPx
            xOffset2 = 150f
            yOffset2 = 60f
            surfaceLabel = snap.surfaceLabel
            if (snap.snappedAwayFromHazard) waterGuardrailTriggered = true
        }
    }

    // Adaptive 3D Shadow intensity (honoring explicit Soft / Natural / Deep 3D voice requests)
    val shadowDepth = when (command.shadowHint) {
        VoiceShadowHint.SOFT -> 0.20f
        VoiceShadowHint.NATURAL -> 0.38f
        VoiceShadowHint.DEEP_3D -> 0.65f
        VoiceShadowHint.NONE -> when {
            command.sceneMood == VoiceSceneMood.NIGHT || bgLighting.avgBrightness < 0.28f -> 0.30f
            command.sceneMood == VoiceSceneMood.SNOW -> 0.40f
            bgLighting.avgBrightness > 0.62f -> 0.50f
            else -> 0.42f
        }
    }

    val isCoolTone = when (command.lightingHint) {
        VoiceLightingHint.WARM -> false
        VoiceLightingHint.COOL -> true
        else -> when (command.sceneMood) {
            VoiceSceneMood.SNOW, VoiceSceneMood.NIGHT -> true
            VoiceSceneMood.SUNSET, VoiceSceneMood.DESERT -> false
            else -> bgLighting.warmth < -0.05f || sceneAdaptive.timeOfDay.contains("Snow", ignoreCase = true)
        }
    }

    val envBlend = when (command.lightingHint) {
        VoiceLightingHint.WARM -> 0.85f
        VoiceLightingHint.COOL -> 0.72f
        else -> when (command.sceneMood) {
            VoiceSceneMood.SUNSET, VoiceSceneMood.DESERT -> 0.70f
            VoiceSceneMood.NIGHT -> 0.65f
            else -> if (bgLighting.avgBrightness > 0.50f) 0.62f else 0.58f
        }
    }

    val sidePrefix = when {
        xOffset < -30f -> "Left"
        xOffset > 30f -> "Right"
        else -> "Center"
    }
    val posTag = if (hasSecondPerson) "Duo on $surfaceLabel" else "$sidePrefix $surfaceLabel"
    val toneTag = when {
        isCoolTone -> "Cool Ambient"
        bgLighting.warmth > 0.08f -> "Warm Sunlight"
        else -> "Natural Daylight"
    }
    return VoiceAutoRealismPlan(
        userScale = adjustedScale,
        userXOffset = xOffset,
        userYOffset = yOffset,
        shadowDepth = shadowDepth,
        environmentBlend = envBlend,
        isCoolToneScene = isCoolTone,
        summaryLabel = "${command.displayLocation} • $posTag (${(adjustedScale * 100).toInt()}%) • $toneTag",
        waterGuardrailTriggered = waterGuardrailTriggered,
        hasSecondPerson = hasSecondPerson,
        userScale2 = adjustedScale,
        userXOffset2 = xOffset2,
        userYOffset2 = yOffset2,
        shadowDepth2 = shadowDepth
    )
}

/**
 * In-Scene Voice AI Adjustment Calculator:
 * Applies position ("left mein", "right side", "center mein", "thoda peeche"),
 * size ("thoda chota karo", "bada karo", "zoom out"), lighting ("light match karo"),
 * and shadow ("shadow soft karo", "deep 3D shadow") directly on the current scene
 * while strictly keeping feet anchored on solid walkable ground (for 1 or 2 persons).
 */
fun computeInSceneVoiceAdjustment(
    bgBitmap: Bitmap?,
    currentLocationName: String,
    command: ParsedVoiceCommand,
    currentScale: Float,
    currentXOffset: Float,
    currentShadowDepth: Float,
    currentEnvBlend: Float,
    currentIsCoolTone: Boolean,
    previewWidthPx: Float,
    previewHeightPx: Float,
    subjectBitmap: Bitmap? = null,
    subjectBitmap2: Bitmap? = null,
    currentScale2: Float = currentScale,
    currentXOffset2: Float = 150f,
    currentShadowDepth2: Float = currentShadowDepth,
    isVideoViewport: Boolean = false,
    geminiVisionGround: GeminiVisionGroundResult? = null
): VoiceAutoRealismPlan {
    val pW = previewWidthPx.coerceAtLeast(360f)
    val pH = previewHeightPx.coerceAtLeast(300f)
    val bgLighting = analyzeVideoBackgroundLighting(bgBitmap)
    val sceneAdaptive = analyzeAnyBackgroundBitmap(
        bgBitmap = bgBitmap,
        landmarkFallbackName = currentLocationName,
        isCoolToneFallback = currentIsCoolTone
    )
    val hasSecondPerson = subjectBitmap2 != null && !subjectBitmap2.isRecycled
    val footAnchor = if (subjectBitmap != null && !subjectBitmap.isRecycled) {
        detectSubjectFootAnchor(subjectBitmap)
    } else {
        SubjectFootAnchor()
    }

    val newScale: Float
    val newScale2: Float
    val newXOffset: Float
    val newYOffset: Float
    val newXOffset2: Float
    val newYOffset2: Float
    val inSceneSurfaceLabel: String
    var waterGuardrailTriggered = false

    if (geminiVisionGround != null &&
        command.positionHint == VoicePositionHint.AUTO &&
        command.positionNudge == VoicePositionNudge.NONE &&
        !command.preferSidePlacement &&
        command.scaleDelta == VoiceScaleDelta.NONE
    ) {
        val visionScale = geminiVisionGround.scale.coerceIn(0.20f, 0.80f)
        newScale = visionScale
        newScale2 = visionScale

        val userH1 = pH * ((210f * visionScale) / 380f)
        val aspect1 = if (subjectBitmap != null && !subjectBitmap.isRecycled && subjectBitmap.height > 0) {
            subjectBitmap.width.toFloat() / subjectBitmap.height.toFloat()
        } else {
            0.72f
        }
        val userW1 = userH1 * aspect1
        val targetFeetX1 = pW * geminiVisionGround.x.coerceIn(0.08f, 0.92f)
        newXOffset = (targetFeetX1 - (pW * 0.5f) - ((footAnchor.feetCenterRatioX - 0.5f) * userW1))
            .coerceIn(-pW * 0.42f, pW * 0.42f)

        val targetGroundY1 = if (footAnchor.isHalfBodyCropped) {
            pH * 0.985f
        } else {
            val rawY = pH * geminiVisionGround.y.coerceIn(0.30f, 0.96f)
            val minHeadClearY = (footAnchor.lowestContactYRatio * userH1) + 8f
            max(rawY, min(minHeadClearY, pH * 0.96f))
        }
        newYOffset = (targetGroundY1 - pH) + (userH1 * (1f - footAnchor.lowestContactYRatio))

        if (hasSecondPerson) {
            val footAnchor2 = detectSubjectFootAnchor(subjectBitmap2!!)
            val userH2 = pH * ((210f * visionScale) / 380f)
            val aspect2 = if (subjectBitmap2.height > 0) {
                subjectBitmap2.width.toFloat() / subjectBitmap2.height.toFloat()
            } else {
                0.72f
            }
            val userW2 = userH2 * aspect2
            val spreadPx = (max(userW1, userW2) * 0.54f).coerceIn(pW * 0.14f, pW * 0.28f)
            val rightCandidate = newXOffset + spreadPx
            val leftCandidate = newXOffset - spreadPx
            newXOffset2 = if (rightCandidate <= pW * 0.40f && (newXOffset <= 0f || leftCandidate < -pW * 0.40f)) {
                rightCandidate.coerceIn(-pW * 0.42f, pW * 0.42f)
            } else {
                leftCandidate.coerceIn(-pW * 0.42f, pW * 0.42f)
            }
            val targetGroundY2 = if (footAnchor2.isHalfBodyCropped) {
                pH * 0.985f
            } else {
                val rawY2 = pH * geminiVisionGround.y.coerceIn(0.30f, 0.96f)
                val minHeadClearY2 = (footAnchor2.lowestContactYRatio * userH2) + 8f
                max(rawY2, min(minHeadClearY2, pH * 0.96f))
            }
            newYOffset2 = (targetGroundY2 - pH) + (userH2 * (1f - footAnchor2.lowestContactYRatio))
        } else {
            newXOffset2 = currentXOffset2
            newYOffset2 = 60f
        }
        inSceneSurfaceLabel = "Vision Ground"
    } else {
        val scene = analyzeVisualSceneForTouristPlacement(
            bgBitmap = bgBitmap,
            locationName = currentLocationName,
            previewWidth = pW,
            previewHeight = pH,
            preferSidePlacement = command.preferSidePlacement,
            isVideoViewport = isVideoViewport
        )
        inSceneSurfaceLabel = scene.surfaceLabel

        // 1. Scale adjustment (perspectively bounded, feet always remain locked to solid ground)
        newScale = when (command.scaleDelta) {
            VoiceScaleDelta.SCALE_DOWN -> (currentScale * 0.85f).coerceIn(0.44f, 0.94f)
            VoiceScaleDelta.SCALE_UP -> (currentScale * 1.16f).coerceIn(0.44f, 0.94f)
            VoiceScaleDelta.SCALE_RESET -> scene.perspectiveScale.coerceIn(0.50f, 0.80f)
            VoiceScaleDelta.NONE -> currentScale.coerceIn(0.44f, 0.94f)
        }
        newScale2 = when (command.scaleDelta) {
            VoiceScaleDelta.SCALE_DOWN -> (currentScale2 * 0.85f).coerceIn(0.44f, 0.94f)
            VoiceScaleDelta.SCALE_UP -> (currentScale2 * 1.16f).coerceIn(0.44f, 0.94f)
            VoiceScaleDelta.SCALE_RESET -> scene.perspectiveScale.coerceIn(0.50f, 0.76f)
            VoiceScaleDelta.NONE -> currentScale2.coerceIn(0.44f, 0.94f)
        }

        // 2. Position & Nudge with full-width solid ground verification
        var desiredXOffset = currentXOffset
        when {
            command.positionHint == VoicePositionHint.LEFT -> {
                if (scene.leftSafeCount == 0 && (scene.rightSafeCount > 0 || scene.centerSafeCount > 0)) {
                    desiredXOffset = scene.xOffsetPx
                    waterGuardrailTriggered = true
                } else {
                    desiredXOffset = (scene.leftBestXRatio.coerceIn(0.15f, 0.36f) - 0.50f) * pW
                }
            }
            command.positionHint == VoicePositionHint.RIGHT -> {
                if (scene.rightSafeCount == 0 && (scene.leftSafeCount > 0 || scene.centerSafeCount > 0)) {
                    desiredXOffset = scene.xOffsetPx
                    waterGuardrailTriggered = true
                } else {
                    desiredXOffset = (scene.rightBestXRatio.coerceIn(0.64f, 0.85f) - 0.50f) * pW
                }
            }
            command.positionHint == VoicePositionHint.CENTER -> {
                if (scene.centerSafeCount == 0 && scene.centerHasWaterOrHazard) {
                    desiredXOffset = scene.xOffsetPx
                    waterGuardrailTriggered = true
                } else {
                    desiredXOffset = (scene.centerBestXRatio - 0.50f) * pW * 0.60f
                }
            }
            command.preferSidePlacement -> {
                val pickLeft = when {
                    scene.leftSafeCount > 0 && scene.rightSafeCount == 0 -> true
                    scene.rightSafeCount > 0 && scene.leftSafeCount == 0 -> false
                    else -> scene.leftWalkableScore >= scene.rightWalkableScore
                }
                desiredXOffset = if (pickLeft) {
                    (scene.leftBestXRatio.coerceIn(0.15f, 0.36f) - 0.50f) * pW
                } else {
                    (scene.rightBestXRatio.coerceIn(0.64f, 0.85f) - 0.50f) * pW
                }
            }
            command.positionNudge == VoicePositionNudge.NUDGE_LEFT -> {
                desiredXOffset = (currentXOffset - pW * 0.14f).coerceIn(-pW * 0.35f, pW * 0.35f)
            }
            command.positionNudge == VoicePositionNudge.NUDGE_RIGHT -> {
                desiredXOffset = (currentXOffset + pW * 0.14f).coerceIn(-pW * 0.35f, pW * 0.35f)
            }
            command.wantsWalkwayOrGroundFix -> {
                desiredXOffset = scene.xOffsetPx
            }
        }

        // 3. Always snap & lock feet onto verified zero-hazard solid walkable ground across full width
        val curVisX = (0.50f + desiredXOffset / pW).coerceIn(0.15f, 0.85f)
        val curCol = scene.findColumnForVisX(curVisX)
        val colBaseY = scene.colBestSafeY.getOrElse(curCol) { scene.bestGroundYRatio }
        val requestedDepthOverride: Float? = when (command.positionNudge) {
            VoicePositionNudge.STEP_BACK -> (colBaseY - 0.035f)
            VoicePositionNudge.STEP_FORWARD -> (colBaseY + 0.025f)
            else -> null
        }

        if (hasSecondPerson) {
            val footAnchor2 = detectSubjectFootAnchor(subjectBitmap2!!)
            val hasGroupMove = command.positionHint != VoicePositionHint.AUTO ||
                command.preferSidePlacement ||
                command.wantsWalkwayOrGroundFix ||
                command.positionNudge != VoicePositionNudge.NONE
            if (hasGroupMove) {
                val groupCenter = if (command.positionNudge == VoicePositionNudge.NUDGE_LEFT ||
                    command.positionNudge == VoicePositionNudge.NUDGE_RIGHT
                ) {
                    val delta = if (command.positionNudge == VoicePositionNudge.NUDGE_LEFT) -pW * 0.12f else pW * 0.12f
                    ((currentXOffset + currentXOffset2) * 0.5f + delta).coerceIn(-pW * 0.24f, pW * 0.24f)
                } else {
                    desiredXOffset
                }
                val coupleFit = fitTwoPeopleSideBySideOnGround(
                    bgBitmap = bgBitmap,
                    locationName = currentLocationName,
                    centerDesiredXOffset = groupCenter,
                    studioScale = newScale,
                    footAnchor1 = footAnchor,
                    footAnchor2 = footAnchor2,
                    previewWidthPx = pW,
                    previewHeightPx = pH,
                    isVideoViewport = isVideoViewport,
                    desiredGroundYRatioOverride = requestedDepthOverride
                )
                newXOffset = coupleFit.x1
                newYOffset = coupleFit.y1
                newXOffset2 = coupleFit.x2
                newYOffset2 = coupleFit.y2
                if (coupleFit.snappedAway) waterGuardrailTriggered = true
            } else {
                val snap1 = snapPlacementToVerifiedSolidGround(
                    bgBitmap = bgBitmap,
                    locationName = currentLocationName,
                    desiredXOffsetPx = desiredXOffset,
                    userScale = newScale,
                    footAnchor = footAnchor,
                    previewWidthPx = pW,
                    previewHeightPx = pH,
                    isVideoViewport = isVideoViewport,
                    desiredGroundYRatioOverride = requestedDepthOverride
                )
                val snap2 = snapPlacementToVerifiedSolidGround(
                    bgBitmap = bgBitmap,
                    locationName = currentLocationName,
                    desiredXOffsetPx = currentXOffset2,
                    userScale = newScale2,
                    footAnchor = footAnchor2,
                    previewWidthPx = pW,
                    previewHeightPx = pH,
                    isVideoViewport = isVideoViewport,
                    desiredGroundYRatioOverride = requestedDepthOverride
                )
                newXOffset = snap1.xOffsetPx
                newYOffset = snap1.yOffsetPx
                newXOffset2 = snap2.xOffsetPx
                newYOffset2 = snap2.yOffsetPx
                if (snap1.snappedAwayFromHazard || snap2.snappedAwayFromHazard) waterGuardrailTriggered = true
            }
        } else {
            val snap = snapPlacementToVerifiedSolidGround(
                bgBitmap = bgBitmap,
                locationName = currentLocationName,
                desiredXOffsetPx = desiredXOffset,
                userScale = newScale,
                footAnchor = footAnchor,
                previewWidthPx = pW,
                previewHeightPx = pH,
                isVideoViewport = isVideoViewport,
                desiredGroundYRatioOverride = requestedDepthOverride
            )
            newXOffset = snap.xOffsetPx
            newYOffset = snap.yOffsetPx
            newXOffset2 = currentXOffset2
            newYOffset2 = 60f
            if (snap.snappedAwayFromHazard) waterGuardrailTriggered = true
        }
    }

    // 4. Shadow & Lighting updates
    val newShadowDepth = when (command.shadowHint) {
        VoiceShadowHint.SOFT -> 0.20f
        VoiceShadowHint.NATURAL -> 0.38f
        VoiceShadowHint.DEEP_3D -> 0.65f
        VoiceShadowHint.NONE -> currentShadowDepth
    }
    val newShadowDepth2 = when (command.shadowHint) {
        VoiceShadowHint.SOFT -> 0.20f
        VoiceShadowHint.NATURAL -> 0.38f
        VoiceShadowHint.DEEP_3D -> 0.65f
        VoiceShadowHint.NONE -> currentShadowDepth2
    }

    val newIsCoolTone = when (command.lightingHint) {
        VoiceLightingHint.WARM -> false
        VoiceLightingHint.COOL -> true
        VoiceLightingHint.MATCH_AUTO -> bgLighting.warmth < -0.05f || sceneAdaptive.timeOfDay.contains("Snow", ignoreCase = true)
        VoiceLightingHint.NONE -> currentIsCoolTone
    }
    val newEnvBlend = when (command.lightingHint) {
        VoiceLightingHint.WARM -> 0.85f
        VoiceLightingHint.COOL -> 0.72f
        VoiceLightingHint.MATCH_AUTO -> if (bgLighting.avgBrightness > 0.50f) 0.64f else 0.60f
        VoiceLightingHint.NONE -> currentEnvBlend
    }

    val sidePrefix = when {
        newXOffset < -30f -> "Left"
        newXOffset > 30f -> "Right"
        else -> "Center"
    }
    val shadowTag = when {
        newShadowDepth < 0.30f -> "Soft Shadow"
        newShadowDepth > 0.50f -> "Deep 3D Shadow"
        else -> "Natural Shadow"
    }

    return VoiceAutoRealismPlan(
        userScale = newScale,
        userXOffset = newXOffset,
        userYOffset = newYOffset,
        shadowDepth = newShadowDepth,
        environmentBlend = newEnvBlend,
        isCoolToneScene = newIsCoolTone,
        summaryLabel = "$currentLocationName • $sidePrefix $inSceneSurfaceLabel (${(newScale * 100).toInt()}%) • $shadowTag",
        waterGuardrailTriggered = waterGuardrailTriggered,
        hasSecondPerson = hasSecondPerson,
        userScale2 = newScale2,
        userXOffset2 = newXOffset2,
        userYOffset2 = newYOffset2,
        shadowDepth2 = newShadowDepth2
    )
}

/**
 * Generates very short, warm, friendly Voice AI confirmation replies in the user's
 * Hindi/Hinglish (spoken with hi-IN) or English (spoken with en-IN) tone.
 */
fun buildVoiceConfirmationMessage(
    command: ParsedVoiceCommand,
    locationName: String,
    waterGuardrailTriggered: Boolean = false,
    undoSucceeded: Boolean = false
): Pair<String, Boolean> {
    val isHindiTone = command.languageStyle != VoiceLanguageStyle.ENGLISH

    if (command.intentAction == VoiceIntentAction.UNDO) {
        return if (undoSucceeded) {
            if (isHindiTone) {
                "Pehle jaisa wapas kar diya hai." to true
            } else {
                "Done, restored your previous look." to false
            }
        } else {
            if (isHindiTone) {
                "Abhi koi purana step saved nahi hai." to true
            } else {
                "Nothing earlier to undo yet." to false
            }
        }
    }

    if (waterGuardrailTriggered) {
        return if (isHindiTone) {
            "Wahan paani tha, isliye $locationName ke safe ground par set kiya hai." to true
        } else {
            "Moved to solid ground near $locationName." to false
        }
    }

    if (command.intentAction == VoiceIntentAction.CHANGE_LOCATION) {
        val loc = command.displayLocation.ifBlank { locationName }
        return when (command.modeRequest) {
            VoiceModeRequest.START_LIVE_RECORDING ->
                if (isHindiTone) "Chalo, $loc par live recording shuru kar rahe hain." to true
                else "Starting live recording at $loc." to false
            VoiceModeRequest.LIVE_CAMERA_VIDEO ->
                if (isHindiTone) "$loc par live camera ready hai." to true
                else "Live camera is ready at $loc." to false
            else -> if (command.outputType == VoiceOutputType.VIDEO_15S) {
                if (isHindiTone) {
                    "$loc ka preview ground par set ho gaya hai, ab 15s video record kar sakte hain." to true
                } else {
                    "Preview at $loc is set on solid ground. Adjust freely or tap 15s Video." to false
                }
            } else {
                if (isHindiTone) {
                    "$loc par preview set ho gaya hai." to true
                } else {
                    "Preview set at $loc on solid ground." to false
                }
            }
        }
    }

    // In-scene adjustments (photo/video/live-camera/position/size/shadow/lighting)
    return when {
        command.modeRequest == VoiceModeRequest.START_LIVE_RECORDING ->
            if (isHindiTone) "Live recording shuru ho rahi hai." to true
            else "Starting live recording now." to false
        command.modeRequest == VoiceModeRequest.STOP_LIVE_RECORDING ->
            if (isHindiTone) "Recording stop karke video save kar rahe hain." to true
            else "Recording stopped, saving your video." to false
        command.modeRequest == VoiceModeRequest.FLIP_LIVE_CAMERA ->
            if (isHindiTone) "Camera flip kar diya hai." to true
            else "Flipped the camera." to false
        command.modeRequest == VoiceModeRequest.FRONT_LIVE_CAMERA ->
            if (isHindiTone) "Front camera on kar diya hai." to true
            else "Switched to front camera." to false
        command.modeRequest == VoiceModeRequest.BACK_LIVE_CAMERA ->
            if (isHindiTone) "Back camera on kar diya hai." to true
            else "Switched to back camera." to false
        command.modeRequest == VoiceModeRequest.LIVE_CAMERA_VIDEO ->
            if (isHindiTone) "Live video mode on ho gaya hai." to true
            else "Live video mode is on." to false
        command.modeRequest == VoiceModeRequest.VIDEO_15S ->
            if (isHindiTone) "$locationName ka 15s video ready hai." to true
            else "Your 15s video is ready." to false
        command.modeRequest == VoiceModeRequest.PHOTO ->
            if (isHindiTone) "$locationName ki photo ready hai." to true
            else "Your photo at $locationName is ready." to false
        command.positionHint == VoicePositionHint.LEFT || command.positionNudge == VoicePositionNudge.NUDGE_LEFT ->
            if (isHindiTone) "Left side mein set kar diya hai." to true
            else "Done, moved to the left." to false
        command.positionHint == VoicePositionHint.RIGHT || command.positionNudge == VoicePositionNudge.NUDGE_RIGHT ->
            if (isHindiTone) "Right side mein set kar diya hai." to true
            else "Done, moved to the right." to false
        command.positionHint == VoicePositionHint.CENTER ->
            if (isHindiTone) "Center mein set kar diya hai." to true
            else "Done, centered you." to false
        command.positionNudge == VoicePositionNudge.STEP_BACK ->
            if (isHindiTone) "Thoda peeche set kar diya hai." to true
            else "Moved slightly back." to false
        command.positionNudge == VoicePositionNudge.STEP_FORWARD ->
            if (isHindiTone) "Thoda paas set kar diya hai." to true
            else "Brought slightly closer." to false
        command.scaleDelta == VoiceScaleDelta.SCALE_DOWN ->
            if (isHindiTone) "Size thoda chota kar diya hai." to true
            else "Made it slightly smaller." to false
        command.scaleDelta == VoiceScaleDelta.SCALE_UP ->
            if (isHindiTone) "Size thoda bada kar diya hai." to true
            else "Made it slightly bigger." to false
        command.scaleDelta == VoiceScaleDelta.SCALE_RESET ->
            if (isHindiTone) "Size natural set kar diya hai." to true
            else "Reset to natural size." to false
        command.shadowHint == VoiceShadowHint.SOFT ->
            if (isHindiTone) "Shadow soft kar di hai." to true
            else "Softened the shadow." to false
        command.shadowHint == VoiceShadowHint.DEEP_3D ->
            if (isHindiTone) "Deep 3D shadow laga di hai." to true
            else "Applied deep 3D shadow." to false
        command.shadowHint == VoiceShadowHint.NATURAL ->
            if (isHindiTone) "Natural shadow set kar di hai." to true
            else "Set natural shadow." to false
        command.lightingHint != VoiceLightingHint.NONE ->
            if (isHindiTone) "Lighting match kar di hai." to true
            else "Matched scene lighting." to false
        else ->
            if (isHindiTone) "Scene update ho gaya hai." to true
            else "Done, scene updated." to false
    }
}

/**
 * Generates a clean 15-second warm stereo ambient travel soundtrack (.wav)
 * when the user requests "with music" via Voice AI without pre-selecting a custom MP3.
 */
fun generateAmbientTravelWav15s(outputFile: File): File {
    val sampleRate = 44100
    val channels = 2
    val durationSeconds = 15
    val totalSamples = sampleRate * durationSeconds
    val dataSize = totalSamples * channels * 2
    val byteRate = sampleRate * channels * 2

    // Warm uplifting travel progression (C - G - Am - F cycling smoothly)
    val chords = arrayOf(
        doubleArrayOf(261.63, 329.63, 392.00, 523.25), // Cmaj7 feel
        doubleArrayOf(196.00, 293.66, 392.00, 493.88), // G
        doubleArrayOf(220.00, 329.63, 440.00, 523.25), // Am
        doubleArrayOf(174.61, 261.63, 349.23, 440.00)  // F
    )

    FileOutputStream(outputFile).use { fos ->
        // Write 44-byte RIFF/WAVE header
        fun writeLeInt(v: Int) {
            fos.write(v and 0xFF)
            fos.write((v shr 8) and 0xFF)
            fos.write((v shr 16) and 0xFF)
            fos.write((v shr 24) and 0xFF)
        }
        fun writeLeShort(v: Int) {
            fos.write(v and 0xFF)
            fos.write((v shr 8) and 0xFF)
        }

        fos.write("RIFF".toByteArray(Charsets.US_ASCII))
        writeLeInt(36 + dataSize)
        fos.write("WAVE".toByteArray(Charsets.US_ASCII))
        fos.write("fmt ".toByteArray(Charsets.US_ASCII))
        writeLeInt(16) // PCM chunk size
        writeLeShort(1) // PCM format
        writeLeShort(channels)
        writeLeInt(sampleRate)
        writeLeInt(byteRate)
        writeLeShort(channels * 2) // block align
        writeLeShort(16) // bits per sample
        fos.write("data".toByteArray(Charsets.US_ASCII))
        writeLeInt(dataSize)

        val buffer = ByteArray(4096 * 4)
        var bufIdx = 0
        val bpm = 104.0
        val beatDur = 60.0 / bpm

        for (s in 0 until totalSamples) {
            val t = s.toDouble() / sampleRate.toDouble()
            val chordIdx = ((t / 3.75).toInt()).coerceIn(0, 3)
            val chord = chords[chordIdx]

            // Smooth global fade-in & fade-out
            val envIn = (t / 0.6).coerceIn(0.0, 1.0)
            val envOut = ((durationSeconds - t) / 0.8).coerceIn(0.0, 1.0)
            val masterEnv = envIn * envOut

            // Gentle plucked arpeggio + warm pad
            val chordLocalT = t % 3.75
            val pad = (
                0.30 * sin(2.0 * PI * chord[0] * t) +
                0.24 * sin(2.0 * PI * chord[1] * t) +
                0.20 * sin(2.0 * PI * chord[2] * t) +
                0.14 * sin(2.0 * PI * chord[3] * t + 0.35)
            ) * 0.45

            // Soft kick/pulse on quarter beats
            val beatPhase = (t % beatDur) / beatDur
            val kickEnv = exp(-beatPhase * 12.0)
            val kickFreq = 58.0 + 90.0 * exp(-beatPhase * 28.0)
            val kick = sin(2.0 * PI * kickFreq * beatPhase * beatDur) * kickEnv * 0.32

            // Gentle sparkle pluck every half beat
            val halfBeatPhase = (t % (beatDur * 0.5)) / (beatDur * 0.5)
            val arpNote = chord[((t / (beatDur * 0.5)).toInt()) % chord.size] * 2.0
            val arpEnv = exp(-halfBeatPhase * 7.5) * exp(-chordLocalT * 0.15)
            val arp = sin(2.0 * PI * arpNote * t) * arpEnv * 0.18

            val leftVal = ((pad + kick + arp * 0.85) * masterEnv * 14500.0).toInt().coerceIn(-32767, 32767)
            val rightVal = ((pad * 0.96 + kick + arp * 1.08) * masterEnv * 14500.0).toInt().coerceIn(-32767, 32767)

            buffer[bufIdx++] = (leftVal and 0xFF).toByte()
            buffer[bufIdx++] = ((leftVal shr 8) and 0xFF).toByte()
            buffer[bufIdx++] = (rightVal and 0xFF).toByte()
            buffer[bufIdx++] = ((rightVal shr 8) and 0xFF).toByte()

            if (bufIdx >= buffer.size) {
                fos.write(buffer, 0, bufIdx)
                bufIdx = 0
            }
        }
        if (bufIdx > 0) {
            fos.write(buffer, 0, bufIdx)
        }
    }
    return outputFile
}

@Composable
fun VoiceAiModalDialog(
    isListening: Boolean,
    isProcessing: Boolean,
    partialTranscript: String,
    processingStatus: String,
    lastReplyMessage: String = "",
    canUndo: Boolean = false,
    languageTag: String,
    isMuted: Boolean = false,
    hasUserPhoto: Boolean = true,
    onPickGalleryPhoto: () -> Unit = {},
    onOpenCamera: () -> Unit = {},
    onToggleLanguage: () -> Unit,
    onToggleMute: () -> Unit = {},
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    onSubmitCommand: (String) -> Unit,
    onAutoCreate: () -> Unit = {},
    onDismiss: () -> Unit
) {
    var typedCommand by remember(partialTranscript) { mutableStateOf(partialTranscript) }

    val pulseTransition = rememberInfiniteTransition(label = "voice_pulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isListening) 1.24f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "voice_orb_scale"
    )

    val quickExamples = remember(canUndo) {
        buildList {
            add("Live camera kholo")
            add("Record 15s video")
            add("Taj Mahal par le chalo")
            add("Dubai beach par khada karo")
            add("Left mein khada karo")
            add("Thoda chota karo")
            add("Deep 3D shadow")
            add("Light match karo")
            add("15s video banao")
            if (canUndo) add("Pehle jaisa karo")
        }
    }

    Dialog(onDismissRequest = { if (!isProcessing) onDismiss() }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = BorderStroke(1.2.dp, Color(0xFF334155)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("voice_ai_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Voice AI",
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Voice AI",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Surface(
                            onClick = onToggleLanguage,
                            enabled = !isProcessing,
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.6f)),
                            modifier = Modifier.testTag("voice_ai_lang_toggle")
                        ) {
                            Text(
                                text = if (languageTag.startsWith("hi")) "🇮🇳 हिंदी/EN" else "🌐 English",
                                color = Color(0xFFBAE6FD),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
                            )
                        }

                        IconButton(
                            onClick = onToggleMute,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("voice_ai_mute_toggle")
                        ) {
                            Icon(
                                imageVector = if (isMuted) {
                                    Icons.AutoMirrored.Filled.VolumeOff
                                } else {
                                    Icons.AutoMirrored.Filled.VolumeUp
                                },
                                contentDescription = if (isMuted) "Unmute Voice Reply" else "Mute Voice Reply",
                                tint = if (isMuted) Color(0xFFF87171) else Color(0xFF38BDF8),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        IconButton(
                            onClick = { if (!isProcessing) onDismiss() },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("voice_ai_close_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Voice AI",
                                tint = Color(0xFF94A3B8)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Interactive Animated Microphone Orb
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(116.dp)
                        .testTag("voice_ai_mic_orb")
                ) {
                    Box(
                        modifier = Modifier
                            .size(104.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = if (isListening) {
                                        listOf(Color(0x66EC4899), Color(0x22A855F7), Color.Transparent)
                                    } else if (isProcessing) {
                                        listOf(Color(0x6610B981), Color(0x2238BDF8), Color.Transparent)
                                    } else {
                                        listOf(Color(0x4438BDF8), Color.Transparent)
                                    }
                                )
                            )
                    )

                    Surface(
                        onClick = {
                            if (!isProcessing) {
                                if (isListening) onStopListening() else onStartListening()
                            }
                        },
                        shape = CircleShape,
                        color = when {
                            isProcessing -> Color(0xFF059669)
                            isListening -> Color(0xFFEC4899)
                            else -> Color(0xFF6366F1)
                        },
                        shadowElevation = 10.dp,
                        modifier = Modifier.size(76.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 3.dp,
                                    modifier = Modifier.size(32.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                                    contentDescription = if (isListening) "Stop Listening" else "Speak Command",
                                    tint = Color.White,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = when {
                        isProcessing -> processingStatus.ifBlank { "Generating realistic output..." }
                        !hasUserPhoto -> "Please select a photo or open Camera first so Voice AI can place you in the scene"
                        isListening -> "Listening... Speak in Hindi or English"
                        else -> "Tap mic & speak your scene (Hindi / English)"
                    },
                    color = when {
                        isProcessing -> Color(0xFF34D399)
                        !hasUserPhoto -> Color(0xFFFBBF24)
                        isListening -> Color(0xFFF472B6)
                        else -> Color(0xFFCBD5E1)
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )

                if (!hasUserPhoto && !isProcessing) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onPickGalleryPhoto,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("voice_ai_pick_gallery_button")
                        ) {
                            Text("Gallery Photo", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Button(
                            onClick = onOpenCamera,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("voice_ai_open_camera_button")
                        ) {
                            Text("Camera Selfie", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                if (lastReplyMessage.isNotBlank() && !isProcessing) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF064E3B).copy(alpha = 0.65f),
                        border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.6f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "✦ $lastReplyMessage",
                            color = Color(0xFFA7F3D0),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }

                if (partialTranscript.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF1E293B),
                        border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Transcript",
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "\"$partialTranscript\"",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Command input box (useful as fallback or quick edit before running)
                OutlinedTextField(
                    value = typedCommand,
                    onValueChange = { typedCommand = it },
                    enabled = !isProcessing,
                    singleLine = true,
                    placeholder = {
                        Text(
                            text = "e.g., Paris 15s video with music",
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    },
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                if (!isProcessing && typedCommand.isNotBlank()) {
                                    onSubmitCommand(typedCommand.trim())
                                }
                            },
                            enabled = !isProcessing && typedCommand.isNotBlank(),
                            modifier = Modifier.testTag("voice_ai_submit_text_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Run Voice Command",
                                tint = if (typedCommand.isNotBlank()) Color(0xFF38BDF8) else Color(0xFF475569)
                            )
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            if (!isProcessing && typedCommand.isNotBlank()) {
                                onSubmitCommand(typedCommand.trim())
                            }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF1E293B),
                        unfocusedContainerColor = Color(0xFF1E293B)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("voice_ai_command_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Try One-Tap Voice Commands:",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    quickExamples.forEachIndexed { idx, sample ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0xFF475569)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(enabled = !isProcessing) {
                                    typedCommand = sample
                                    onSubmitCommand(sample)
                                }
                                .testTag("voice_ai_sample_$idx")
                        ) {
                            Text(
                                text = sample,
                                color = Color(0xFFE2E8F0),
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { if (isListening) onStopListening() else onStartListening() },
                        enabled = !isProcessing,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isListening) Color(0xFFBE185D) else Color(0xFF0284C7)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("voice_ai_listen_toggle_button")
                    ) {
                        Text(
                            text = if (isListening) "Stop Mic" else "🎤 Speak Now",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Button(
                        onClick = {
                            if (typedCommand.isNotBlank()) {
                                onSubmitCommand(typedCommand.trim())
                            } else {
                                onAutoCreate()
                            }
                        },
                        enabled = !isProcessing,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF059669),
                            disabledContainerColor = Color(0xFF334155)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("voice_ai_generate_button")
                    ) {
                        Text(
                            text = "✨ Auto Create",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

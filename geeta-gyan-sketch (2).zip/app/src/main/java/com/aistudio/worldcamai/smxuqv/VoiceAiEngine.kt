package com.aistudio.worldcamai.smxuqv

import android.graphics.Bitmap
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

enum class VoiceOutputType {
    PHOTO,
    VIDEO_15S
}

enum class VoicePositionHint {
    AUTO,
    LEFT,
    CENTER,
    RIGHT
}

enum class VoiceSizeHint {
    AUTO,
    SMALL,
    MEDIUM,
    LARGE
}

enum class VoiceSceneMood {
    AUTO,
    SNOW,
    NIGHT,
    SUNSET,
    BEACH,
    DESERT,
    MOUNTAIN
}

data class ParsedVoiceCommand(
    val rawTranscript: String,
    val locationQuery: String,
    val displayLocation: String,
    val outputType: VoiceOutputType,
    val positionHint: VoicePositionHint,
    val sizeHint: VoiceSizeHint,
    val wantsMusic: Boolean,
    val sceneMood: VoiceSceneMood,
    val preferSidePlacement: Boolean = false,
    val wantsWalkwayOrGroundFix: Boolean = false
)

data class VoiceAutoRealismPlan(
    val userScale: Float,
    val userXOffset: Float,
    val userYOffset: Float,
    val shadowDepth: Float,
    val environmentBlend: Float,
    val isCoolToneScene: Boolean,
    val summaryLabel: String
)

private val hindiToEnglishLocationTerms = linkedMapOf(
    "मनाली" to "Manali",
    "शिमला" to "Shimla",
    "ताजमहल" to "Taj Mahal",
    "ताज महल" to "Taj Mahal",
    "tajmahal" to "Taj Mahal",
    "लाल किला" to "Red Fort Delhi",
    "कुतुब मीनार" to "Qutub Minar Delhi",
    "चारमीनार" to "Charminar Hyderabad",
    "गेटवे ऑफ इंडिया" to "Gateway of India Mumbai",
    "मरीन ड्राइव" to "Marine Drive Mumbai",
    "रोहतांग" to "Rohtang Pass Manali",
    "नैनीताल" to "Nainital Lake",
    "मसूरी" to "Mussoorie Hills",
    "दार्जिलिंग" to "Darjeeling Hills",
    "ऊटी" to "Ooty Hills",
    "कन्याकुमारी" to "Kanyakumari",
    "पेरिस" to "Paris Eiffel Tower",
    "एफिल टॉवर" to "Eiffel Tower Paris",
    "एफिल टावर" to "Eiffel Tower Paris",
    "लंदन" to "London Big Ben",
    "दुबई" to "Dubai Burj Khalifa",
    "बुर्ज खलीफा" to "Burj Khalifa Dubai",
    "न्यूयॉर्क" to "New York Times Square",
    "टोक्यो" to "Tokyo",
    "जापान" to "Mount Fuji Japan",
    "माउंट फूजी" to "Mount Fuji Japan",
    "स्विट्जरलैंड" to "Swiss Alps Switzerland",
    "स्विट्ज़रलैंड" to "Swiss Alps Switzerland",
    "कश्मीर" to "Kashmir Dal Lake",
    "सोनमर्ग" to "Sonmarg Kashmir",
    "गुलमर्ग" to "Gulmarg snow Kashmir",
    "लद्दाख" to "Ladakh Pangong Lake",
    "लेह" to "Leh Ladakh",
    "जयपुर" to "Hawa Mahal Jaipur",
    "हवा महल" to "Hawa Mahal Jaipur",
    "जैसलमेर" to "Jaisalmer Thar Desert",
    "गोवा" to "Goa Beach",
    "केरल" to "Kerala Backwaters",
    "ऋषिकेश" to "Rishikesh Ganga",
    "हरिद्वार" to "Haridwar Har Ki Pauri",
    "वाराणसी" to "Varanasi Ghats",
    "बनारस" to "Varanasi Ghats",
    "मुंबई" to "Gateway of India Mumbai",
    "दिल्ली" to "India Gate Delhi",
    "इंडिया गेट" to "India Gate Delhi",
    "केदारनाथ" to "Kedarnath Temple snow",
    "बद्रीनाथ" to "Badrinath Temple",
    "उदयपुर" to "Udaipur Lake Palace",
    "जोधपुर" to "Mehrangarh Fort Jodhpur",
    "जल महल" to "Jal Mahal Jaipur",
    "आमेर" to "Amber Fort Jaipur",
    "जंतर मंतर" to "Jantar Mantar Jaipur",
    "कोटा" to "Kota Chambal Riverfront",
    "अयोध्या" to "Ayodhya Ram Mandir",
    "राम मंदिर" to "Ram Mandir Ayodhya",
    "गोल्डन टेम्पल" to "Golden Temple Amritsar",
    "स्वर्ण मंदिर" to "Golden Temple Amritsar",
    "लंदन ब्रिज" to "Tower Bridge London",
    "हम्पी" to "Hampi Karnataka",
    "आगरा" to "Taj Mahal Agra",
    "रोम" to "Colosseum Rome",
    "इटली" to "Colosseum Rome Italy",
    "मालदीव" to "Maldives beach",
    "बाली" to "Bali Indonesia",
    "सिंगापुर" to "Marina Bay Sands Singapore",
    "थाईलैंड" to "Thailand beach",
    "सैंटोरिनी" to "Santorini Greece",
    "ग्रीस" to "Santorini Greece",
    "बर्फ" to "snow",
    "बर्फीले" to "snow mountains",
    "पहाड़" to "mountains",
    "पहाड़ों" to "mountains",
    "पहाड़ों में" to "mountains",
    "रेगिस्तान" to "desert sand dunes",
    "समुद्र" to "ocean beach",
    "बीच" to "beach",
    "झील" to "lake",
    "नदी" to "river",
    "रात" to "night lights",
    "शाम" to "sunset",
    "सूरज" to "sunset"
)

private val hindiStopWords = setOf(
    "मेरी", "मेरा", "मेरे", "मुझे", "मुझको", "हमारी", "हमारा", "हमको", "हमें", "मैं", "मे", "में",
    "फोटो", "तस्वीर", "पिक्चर", "इमेज", "सेल्फी", "विडिओ", "वीडियो", "रील", "रिल",
    "का", "की", "के", "को", "से", "पर", "तक", "साथ", "वाला", "वाली",
    "बना", "बनाओ", "बनाई", "दो", "दीजिए", "कर", "करो", "करदो", "करना", "दे", "देना", "है", "हूं",
    "एक", "और", "या", "प्लीज", "ज़रा", "जरा", "अभी", "तुरंत", "अच्छी", "अच्छा", "सुंदर", "रियल", "नेचुरल", "बिल्कुल",
    "चाहिए", "लगा", "लगाओ", "डालो", "सामने", "तरफ", "थोड़ा", "थोड़ी", "थोड़े", "ज्यादा", "ज़्यादा",
    "खड़ा", "खड़े", "खड़ी", "सेट", "रखो", "लाओ", "ले", "जाओ", "बैठाओ", "दिखाओ",
    "ज़मीन", "जमीन", "धरती", "फर्श", "रास्ते", "वॉकवे", "सड़क", "सही", "जगह", "स्थान",
    "साइड", "कोने", "कोना", "किनारे", "बाजू", "पास", "दूर", "नजदीक", "करीब", "आगे", "पीछे",
    "गाना", "गाने", "म्यूजिक", "संगीत", "साउंड", "सॉन्ग",
    "बाएं", "बाएँ", "दाएं", "दाएँ", "बीच", "छोटा", "छोटी", "बड़ा", "बड़ी", "सेकंड", "सेकेंड",
    "meri", "mera", "mere", "mujhe", "mujhko", "humko", "hume", "humein", "main", "mai",
    "photo", "selfie", "tasveer", "image", "pic", "picture",
    "video", "reel", "reels", "shorts", "15s", "15sec", "15", "second", "seconds", "sec",
    "ki", "ka", "ke", "ko", "mein", "me", "par", "pe", "per", "se", "tak", "saath", "sath", "wali", "wala",
    "bana", "banao", "banado", "banaao", "banana", "do", "de", "dena", "dijiye", "kar", "karo", "kardo", "karna", "please", "pls",
    "chahiye", "laga", "lagao", "dalo", "daalo", "rakho", "rakh", "lao", "laao", "le", "jao", "khada", "khade", "khadi", "bithao",
    "samne", "saamne", "taraf", "ek", "thoda", "thodi", "thode", "zara", "jara", "aur", "bilkul", "sahi", "jagah", "jageh",
    "paas", "pas", "nazdeek", "kareeb", "dur", "door", "aage", "age", "peeche", "piche", "upar", "neeche", "niche",
    "zameen", "jameen", "jamin", "dharti", "farsh", "sadak", "raste", "raaste", "walkway", "footpath", "sidewalk", "pavement", "pathway", "path",
    "gana", "gaana", "gaane", "gane", "music", "song", "audio", "track", "bgm", "beat",
    "create", "make", "generate", "put", "place", "blend", "edit", "render", "show", "set", "align", "adjust", "move", "shift", "stand", "standing", "pose", "posing",
    "a", "an", "the", "in", "at", "on", "to", "with", "and", "of", "for", "from", "by", "my", "near", "beside", "next", "onto",
    "left", "right", "center", "centre", "middle", "small", "smaller", "tiny", "far", "distant", "big", "large", "larger", "close", "closeup", "closer", "zoom",
    "side", "corner", "kone", "kona", "kinare", "kinaare", "baju", "frame", "background", "bg", "location", "place", "spot", "ground", "floor", "surface", "natural", "realistic", "real", "perfect", "properly"
)

/**
 * Simple phonetic Devanagari -> Latin transliterator so even rural towns / unlisted landmarks
 * spoken in Hindi script resolve cleanly via keyless real-world photo search.
 */
fun transliterateDevanagariToLatin(input: String): String {
    if (input.none { it in '\u0900'..'\u097F' }) return input
    val consonants = mapOf(
        '\u0915' to "k", '\u0916' to "kh", '\u0917' to "g", '\u0918' to "gh", '\u0919' to "ng",
        '\u091A' to "ch", '\u091B' to "chh", '\u091C' to "j", '\u091D' to "jh", '\u091E' to "ny",
        '\u091F' to "t", '\u0920' to "th", '\u0921' to "d", '\u0922' to "dh", '\u0923' to "n",
        '\u0924' to "t", '\u0925' to "th", '\u0926' to "d", '\u0927' to "dh", '\u0928' to "n",
        '\u092A' to "p", '\u092B' to "ph", '\u092C' to "b", '\u092D' to "bh", '\u092E' to "m",
        '\u092F' to "y", '\u0930' to "r", '\u0932' to "l", '\u0935' to "v", '\u0936' to "sh",
        '\u0937' to "sh", '\u0938' to "s", '\u0939' to "h",
        '\u095C' to "r", '\u095D' to "rh", '\u0958' to "q", '\u0959' to "kh",
        '\u095A' to "gh", '\u095B' to "z", '\u095E' to "f"
    )
    val vowels = mapOf(
        '\u0905' to "a", '\u0906' to "aa", '\u0907' to "i", '\u0908' to "ee", '\u0909' to "u", '\u090A' to "oo",
        '\u090F' to "e", '\u0910' to "ai", '\u0913' to "o", '\u0914' to "au", '\u090B' to "ri"
    )
    val matras = mapOf(
        '\u093E' to "a", '\u093F' to "i", '\u0940' to "i", '\u0941' to "u", '\u0942' to "u",
        '\u0947' to "e", '\u0948' to "ai", '\u094B' to "o", '\u094C' to "au", '\u0943' to "ri",
        '\u0902' to "n", '\u0901' to "n", '\u0903' to "h"
    )
    val virama = '\u094D'
    val nukta = '\u093C'

    val sb = StringBuilder()
    var i = 0
    while (i < input.length) {
        val ch = input[i]
        when {
            ch in consonants -> {
                var base = consonants[ch]!!
                val next = input.getOrNull(i + 1)
                if (next == nukta) {
                    base = when (ch) {
                        '\u091C' -> "z"
                        '\u092B' -> "f"
                        '\u0921' -> "r"
                        '\u0922' -> "rh"
                        '\u0915' -> "q"
                        else -> base
                    }
                    i++
                }
                sb.append(base)
                val after = input.getOrNull(i + 1)
                if (after == virama) {
                    i++ // suppress inherent 'a'
                } else if (after != null && after in matras) {
                    sb.append(matras[after])
                    i++
                } else if (after != null && (after in consonants || after in vowels)) {
                    sb.append('a')
                }
            }
            ch in vowels -> sb.append(vowels[ch])
            ch in matras -> sb.append(matras[ch])
            ch == virama || ch == nukta -> {}
            else -> sb.append(ch)
        }
        i++
    }
    return sb.toString()
}

private fun containsWordBoundary(text: String, phrases: List<String>): Boolean {
    return phrases.any { phrase ->
        if (phrase.any { it.code > 127 } || phrase.contains(' ')) {
            text.contains(phrase)
        } else {
            Regex("(?<![\\p{L}\\p{N}])${Regex.escape(phrase)}(?![\\p{L}\\p{N}])").containsMatchIn(text)
        }
    }
}

fun parseVoiceAiCommand(transcript: String): ParsedVoiceCommand {
    val cleanRaw = transcript.trim()
    val lower = cleanRaw.lowercase()

    // 1. Output Type: Photo vs 15s Video
    val videoKeywords = listOf(
        "video", "15s", "15 sec", "15 second", "reel", "reels", "shorts", "clip",
        "वीडियो", "विडिओ", "रील", "रिल", "15 सेकंड", "15 सेकेंड", "moving"
    )
    val outputType = if (containsWordBoundary(lower, videoKeywords)) {
        VoiceOutputType.VIDEO_15S
    } else {
        VoiceOutputType.PHOTO
    }

    // 2. Music Preference
    val musicKeywords = listOf(
        "music", "song", "songs", "audio", "bgm", "beat", "tune", "melody", "dance",
        "gana", "gaana", "gaane", "gane", "गाना", "गाने", "म्यूजिक", "संगीत", "सॉन्ग"
    )
    val wantsMusic = containsWordBoundary(lower, musicKeywords)

    // 3. Position Hint (supports explicit Left/Center/Right AND natural Hindi "side mein" / "kinare")
    val explicitLeft = containsWordBoundary(lower, listOf("left", "बाएं", "बाएँ", "baye", "baayen", "baaye", "bayan", "बायां", "बायाँ"))
    val explicitRight = containsWordBoundary(lower, listOf("right", "दाएं", "दाएँ", "daye", "daayen", "daaye", "dayan", "दायां", "दायाँ"))
    val explicitCenter = containsWordBoundary(lower, listOf("center", "centre", "middle", "बीच में", "beech mein", "beech me", "mid mein", "mid me"))
    val preferSidePlacement = !explicitLeft && !explicitRight && !explicitCenter && containsWordBoundary(
        lower,
        listOf(
            "side mein", "side me", "side pe", "ek side", "side par", "kinare", "kinaare",
            "corner", "kone", "ek taraf", "baju mein", "baju me", "बगल में", "साइड में",
            "एक साइड", "किनारे", "कोने में", "बाजू में", "side"
        )
    )

    val positionHint = when {
        explicitLeft -> VoicePositionHint.LEFT
        explicitRight -> VoicePositionHint.RIGHT
        explicitCenter -> VoicePositionHint.CENTER
        else -> VoicePositionHint.AUTO
    }

    val wantsWalkwayOrGroundFix = containsWordBoundary(
        lower,
        listOf(
            "walkway", "ground", "floor", "surface", "zameen", "jameen", "jamin", "farsh",
            "sahi jagah", "sahi jageh", "paani se door", "pani se door", "ज़मीन", "जमीन",
            "सही जगह", "वॉकवे", "फर्श", "रास्ते पर"
        )
    )

    // 4. Size Hint (distinguishes "Taj Mahal ke paas" [near landmark] vs "thoda paas lao" [closer scale])
    val isCloserIntent = containsWordBoundary(
        lower,
        listOf(
            "large", "big", "bigger", "close", "closeup", "close up", "closer", "zoom",
            "thoda paas", "aur paas", "paas lao", "paas laao", "paas karo", "paas kardo",
            "paas rakho", "paas le", "aage lao", "aage laao", "aage karo", "camera ke paas",
            "bada karo", "thoda bada", "बड़ा", "बड़ी", "थोड़ा पास", "और पास", "पास लाओ", "पास करो", "आगे लाओ"
        )
    )
    val isFurtherIntent = containsWordBoundary(
        lower,
        listOf(
            "small", "smaller", "tiny", "far", "distant", "step back", "pull back",
            "thoda dur", "thoda door", "aur door", "aur dur", "door rakho", "dur rakho",
            "piche", "peeche", "chhota", "chota", "chhoti", "छोटा", "छोटी", "थोड़ा दूर", "पीछे", "दूर रखो"
        )
    )
    val sizeHint = when {
        isFurtherIntent -> VoiceSizeHint.SMALL
        isCloserIntent -> VoiceSizeHint.LARGE
        containsWordBoundary(lower, listOf("medium", "normal", "default")) -> VoiceSizeHint.MEDIUM
        else -> VoiceSizeHint.AUTO
    }

    // 5. Scene Mood
    val sceneMood = when {
        containsWordBoundary(lower, listOf("snow", "ice", "winter", "glacier", "बर्फ", "बर्फीले", "barf", "manali", "gulmarg", "swiss")) -> VoiceSceneMood.SNOW
        containsWordBoundary(lower, listOf("night", "neon", "midnight", "evening lights", "रात", "raat", "tokyo", "times square")) -> VoiceSceneMood.NIGHT
        containsWordBoundary(lower, listOf("sunset", "golden", "dusk", "sunrise", "शाम", "shaam")) -> VoiceSceneMood.SUNSET
        containsWordBoundary(lower, listOf("beach", "ocean", "sea", "coast", "island", "समुद्र", "बीच", "goa", "maldives")) -> VoiceSceneMood.BEACH
        containsWordBoundary(lower, listOf("desert", "dunes", "sand", "रेगिस्तान", "thar", "jaisalmer", "dubai desert")) -> VoiceSceneMood.DESERT
        containsWordBoundary(lower, listOf("mountain", "hill", "peak", "valley", "पहाड़", "पहाड़ों", "pahad", "ladakh", "kashmir", "fuji")) -> VoiceSceneMood.MOUNTAIN
        else -> VoiceSceneMood.AUTO
    }

    // 6. Location Name Extraction (Translate known Hindi phrases first, then strip command/placement words)
    var working = cleanRaw
    val sortedDict = hindiToEnglishLocationTerms.entries.sortedByDescending { it.key.length }
    for ((hi, en) in sortedDict) {
        if (working.contains(hi, ignoreCase = true)) {
            working = working.replace(hi, " $en ", ignoreCase = true)
        }
    }

    val rawTokens = working
        .replace(Regex("[,.;:!?\"'()\\[\\]{}]"), " ")
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }

    val keptTokens = mutableListOf<String>()
    for (tok in rawTokens) {
        val tokLower = tok.lowercase()
        if (tokLower in hindiStopWords) continue
        if (tokLower.matches(Regex("\\d+s?"))) continue
        val converted = if (tok.any { it in '\u0900'..'\u097F' }) {
            transliterateDevanagariToLatin(tok)
        } else {
            tok
        }
        val convLower = converted.lowercase().trim()
        if (convLower.isNotBlank() && convLower !in hindiStopWords) {
            keptTokens.add(converted.trim())
        }
    }

    val deduped = mutableListOf<String>()
    for (t in keptTokens) {
        if (deduped.lastOrNull()?.equals(t, ignoreCase = true) != true) {
            deduped.add(t)
        }
    }

    val extractedQuery = deduped.joinToString(" ").trim().ifBlank {
        when (sceneMood) {
            VoiceSceneMood.SNOW -> "Manali snow mountains"
            VoiceSceneMood.NIGHT -> "Tokyo night city"
            VoiceSceneMood.SUNSET -> "Santorini sunset"
            VoiceSceneMood.BEACH -> "Maldives tropical beach"
            VoiceSceneMood.DESERT -> "Sam Sand Dunes Jaisalmer"
            VoiceSceneMood.MOUNTAIN -> "Swiss Alps mountains"
            VoiceSceneMood.AUTO -> "Paris Eiffel Tower"
        }
    }

    val displayName = extractedQuery
        .split(" ")
        .filter { it.isNotBlank() }
        .joinToString(" ") { word ->
            word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }

    return ParsedVoiceCommand(
        rawTranscript = cleanRaw,
        locationQuery = extractedQuery,
        displayLocation = displayName,
        outputType = outputType,
        positionHint = positionHint,
        sizeHint = sizeHint,
        wantsMusic = wantsMusic,
        sceneMood = sceneMood,
        preferSidePlacement = preferSidePlacement,
        wantsWalkwayOrGroundFix = wantsWalkwayOrGroundFix
    )
}

private enum class SceneCellClass {
    WALKABLE_STONE,
    WALKABLE_SAND,
    WALKABLE_GRASS,
    WALKABLE_ROAD,
    WALKABLE_INDOOR,
    WALKABLE_SNOW,
    WATER_OR_REFLECTION,
    SKY_OR_MID_AIR,
    WALL_OR_ROOF,
    CROWD_OR_OBSTACLE
}

private data class VisualSceneAnalysis(
    val xOffsetPx: Float,
    val bestVisXRatio: Float,
    val bestGroundYRatio: Float,
    val horizonYRatio: Float,
    val perspectiveScale: Float,
    val surfaceLabel: String,
    val centerHasWaterOrHazard: Boolean,
    val leftWalkableScore: Float,
    val centerWalkableScore: Float,
    val rightWalkableScore: Float,
    val leftBestYRatio: Float,
    val centerBestYRatio: Float,
    val rightBestYRatio: Float
)

/**
 * Human-like 2D Visual Scene Analyzer:
 * Builds a spatial surface/obstacle map of the background photo (sky, horizon line,
 * walkable floor/ground planes vs water pools, reflections, mid-air voids, steep roofs,
 * vertical walls, and foreground crowds) and computes perspective-accurate foot (X, Y)
 * coordinates plus human-proportion scale.
 */
private fun analyzeVisualSceneForTouristPlacement(
    bgBitmap: Bitmap?,
    locationName: String?,
    previewWidth: Float,
    previewHeight: Float = 0f,
    preferSidePlacement: Boolean = false
): VisualSceneAnalysis {
    val pW = previewWidth.coerceAtLeast(360f)
    val sideShift = (pW * 0.21f).coerceAtLeast(88f)
    val defaultAnalysis = VisualSceneAnalysis(
        xOffsetPx = 0f,
        bestVisXRatio = 0.50f,
        bestGroundYRatio = 0.90f,
        horizonYRatio = 0.52f,
        perspectiveScale = 0.68f,
        surfaceLabel = "Center Ground",
        centerHasWaterOrHazard = false,
        leftWalkableScore = 0.5f,
        centerWalkableScore = 0.5f,
        rightWalkableScore = 0.5f,
        leftBestYRatio = 0.90f,
        centerBestYRatio = 0.90f,
        rightBestYRatio = 0.90f
    )
    if (bgBitmap == null || bgBitmap.isRecycled || bgBitmap.width < 32 || bgBitmap.height < 32) {
        return defaultAnalysis
    }

    var proxy: Bitmap? = null
    return try {
        val gridW = 120
        val gridH = 90
        proxy = Bitmap.createScaledBitmap(bgBitmap, gridW, gridH, true)
        val pixels = IntArray(gridW * gridH)
        proxy.getPixels(pixels, 0, gridW, 0, 0, gridW, gridH)

        // Match preview container's ContentScale.Crop visible viewport
        val bgAspect = bgBitmap.width.toFloat() / bgBitmap.height.toFloat().coerceAtLeast(1f)
        val containerAspect = if (previewHeight > 120f) {
            (previewWidth.coerceAtLeast(240f) / previewHeight).coerceIn(0.45f, 1.35f)
        } else {
            0.84f
        }
        val visMinX: Float
        val visMaxX: Float
        val visMinY: Float
        val visMaxY: Float
        if (bgAspect > containerAspect) {
            val visFracW = (containerAspect / bgAspect).coerceIn(0.38f, 1.0f)
            visMinX = (0.5f - visFracW * 0.5f).coerceIn(0f, 0.31f)
            visMaxX = (0.5f + visFracW * 0.5f).coerceIn(0.69f, 1.0f)
            visMinY = 0f
            visMaxY = 1f
        } else {
            val visFracH = (bgAspect / containerAspect).coerceIn(0.45f, 1.0f)
            visMinX = 0f
            visMaxX = 1f
            visMinY = (0.5f - visFracH * 0.5f).coerceIn(0f, 0.27f)
            visMaxY = (0.5f + visFracH * 0.5f).coerceIn(0.73f, 1.0f)
        }

        val xStart = (visMinX * (gridW - 1)).roundToInt().coerceIn(1, gridW - 3)
        val xEnd = (visMaxX * (gridW - 1)).roundToInt().coerceIn(xStart + 4, gridW - 2)
        val yStart = (visMinY * (gridH - 1)).roundToInt().coerceIn(1, gridH - 3)
        val yEnd = (visMaxY * (gridH - 1)).roundToInt().coerceIn(yStart + 4, gridH - 2)
        val visSpanX = (xEnd - xStart).coerceAtLeast(1).toFloat()
        val visSpanY = (yEnd - yStart).coerceAtLeast(1).toFloat()

        fun rgb(x: Int, y: Int): Int = pixels[y.coerceIn(0, gridH - 1) * gridW + x.coerceIn(0, gridW - 1)]
        fun lum(c: Int): Float {
            val r = (c ushr 16) and 0xFF
            val g = (c ushr 8) and 0xFF
            val b = c and 0xFF
            return 0.299f * r + 0.587f * g + 0.114f * b
        }

        // Step 1: Row-wise sky, vertical wall edge, and horizon line estimation
        val rowLum = FloatArray(gridH)
        val rowSkyFrac = FloatArray(gridH)
        val rowWallVert = FloatArray(gridH)
        val rowHorizFloor = FloatArray(gridH)

        for (y in yStart..yEnd) {
            var sumL = 0f
            var skyCount = 0
            var vertDom = 0f
            var horizDom = 0f
            var colsCount = 0
            for (x in xStart..xEnd) {
                val c = rgb(x, y)
                val r = (c ushr 16) and 0xFF
                val g = (c ushr 8) and 0xFF
                val b = c and 0xFF
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                val maxCh = max(r, max(g, b))
                val minCh = min(r, min(g, b))
                val sat = if (maxCh > 0) (maxCh - minCh).toFloat() / maxCh else 0f

                val cRight = rgb(x + 1, y)
                val cDown = rgb(x, y + 1)
                val dx = (abs(r - ((cRight ushr 16) and 0xFF)) +
                    abs(g - ((cRight ushr 8) and 0xFF)) +
                    abs(b - (cRight and 0xFF))) / 3f
                val dy = (abs(r - ((cDown ushr 16) and 0xFF)) +
                    abs(g - ((cDown ushr 8) and 0xFF)) +
                    abs(b - (cDown and 0xFF))) / 3f

                sumL += l
                if ((b >= r - 8 && l > 135f && dx < 12f && dy < 12f) || (l > 186f && sat < 0.14f && dx < 9f)) {
                    skyCount++
                }
                if (dx > dy * 1.45f && dx > 9f) vertDom += 1f
                if (dy >= dx * 0.9f && dx in 2f..18f) horizDom += 1f
                colsCount++
            }
            val denom = colsCount.coerceAtLeast(1).toFloat()
            rowLum[y] = sumL / denom
            rowSkyFrac[y] = skyCount / denom
            rowWallVert[y] = vertDom / denom
            rowHorizFloor[y] = horizDom / denom
        }

        // Find where open sky ends cleanly and horizon / architectural floor boundary begins
        var skyEndRow = yStart + (visSpanY * 0.28f).roundToInt()
        for (y in yStart..(yStart + (visSpanY * 0.56f).roundToInt()).coerceAtMost(yEnd)) {
            if (rowSkyFrac[y] >= 0.48f) {
                skyEndRow = y
            }
        }
        val hMinRow = max(skyEndRow, yStart + (visSpanY * 0.26f).roundToInt()).coerceIn(yStart + 2, yEnd - 8)
        val hMaxRow = (yStart + (visSpanY * 0.72f).roundToInt()).coerceIn(hMinRow + 2, yEnd - 4)
        var bestHorizonRow = (yStart + (visSpanY * 0.50f).roundToInt()).coerceIn(hMinRow, hMaxRow)
        var bestBoundaryScore = -1f
        for (y in hMinRow..hMaxRow) {
            val lumJump = abs(rowLum[y + 1] - rowLum[y - 2]) / 255f
            val wallDrop = (rowWallVert[(y - 2).coerceAtLeast(yStart)] - rowWallVert[(y + 2).coerceAtMost(yEnd)]).coerceAtLeast(0f)
            val floorGain = (rowHorizFloor[(y + 3).coerceAtMost(yEnd)] - rowHorizFloor[(y - 2).coerceAtLeast(yStart)]).coerceAtLeast(0f)
            val score = lumJump * 1.1f + wallDrop * 1.3f + floorGain * 1.2f
            if (score > bestBoundaryScore) {
                bestBoundaryScore = score
                bestHorizonRow = y
            }
        }
        val groundPlane = detectBackgroundGroundPlane(bgBitmap, locationName.orEmpty())
        val computedHorizonVisY = ((bestHorizonRow - yStart) / visSpanY).coerceIn(0.26f, 0.72f)
        val horizonYRatio = (computedHorizonVisY * 0.65f + groundPlane.horizonYRatio * 0.35f).coerceIn(0.28f, 0.72f)
        val horizonRowInGrid = (yStart + horizonYRatio * visSpanY).roundToInt().coerceIn(yStart + 2, yEnd - 4)

        // Step 2: Classify every cell across visible viewport into Walkable Material vs Obstacles/Hazards
        val qLower = locationName.orEmpty().lowercase()
        val isReflectionPoolMonument = listOf(
            "taj mahal", "tajmahal", "jal mahal", "reflection", "reflecting pool",
            "fountain", "lotus pond", "india gate", "trevi", "palace of versailles"
        ).any { qLower.contains(it) }
        val isWaterKeyword = isReflectionPoolMonument || listOf(
            "lake", "pool", "water", "river", "riverfront", "beach", "ocean", "sea",
            "ghat", "venice", "waterfall", "dam", "canal", "backwater", "maldives"
        ).any { qLower.contains(it) }
        val isIndoorHint = listOf(
            "mall", "indoor", "museum", "hotel", "lobby", "cafe", "airport", "metro", "interior", "hall"
        ).any { qLower.contains(it) }

        val cellClass = Array(gridH) { Array(gridW) { SceneCellClass.SKY_OR_MID_AIR } }
        val cellWalkScore = Array(gridH) { FloatArray(gridW) }
        val upperSkyOrDistantCount = intArrayOf(0, 0) // [skyOrFar, total]

        for (y in yStart..yEnd) {
            val visY = (y - yStart) / visSpanY
            for (x in xStart..xEnd) {
                val c = rgb(x, y)
                val r = (c ushr 16) and 0xFF
                val g = (c ushr 8) and 0xFF
                val b = c and 0xFF
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                val maxCh = max(r, max(g, b))
                val minCh = min(r, min(g, b))
                val sat = if (maxCh > 0) (maxCh - minCh).toFloat() / maxCh else 0f

                if (visY < 0.54f) {
                    upperSkyOrDistantCount[1]++
                    if (l > 142f && b >= r - 10) upperSkyOrDistantCount[0]++
                }

                if (visY < horizonYRatio - 0.02f) {
                    cellClass[y][x] = SceneCellClass.SKY_OR_MID_AIR
                    cellWalkScore[y][x] = -2.2f
                    continue
                }

                // Local 3x3 gradient & variance
                val cL = rgb(x - 1, y); val cR = rgb(x + 1, y)
                val cU = rgb(x, y - 1); val cD = rgb(x, y + 1)
                val cUL = rgb(x - 1, y - 1); val cDR = rgb(x + 1, y + 1)

                val dx = (abs(((cR ushr 16) and 0xFF) - ((cL ushr 16) and 0xFF)) +
                    abs(((cR ushr 8) and 0xFF) - ((cL ushr 8) and 0xFF)) +
                    abs((cR and 0xFF) - (cL and 0xFF))) / 3f
                val dy = (abs(((cD ushr 16) and 0xFF) - ((cU ushr 16) and 0xFF)) +
                    abs(((cD ushr 8) and 0xFF) - ((cU ushr 8) and 0xFF)) +
                    abs((cD and 0xFF) - (cU and 0xFF))) / 3f
                val dDiag = (abs(((cDR ushr 16) and 0xFF) - ((cUL ushr 16) and 0xFF)) +
                    abs(((cDR ushr 8) and 0xFF) - ((cUL ushr 8) and 0xFF)) +
                    abs((cDR and 0xFF) - (cUL and 0xFF))) / 3f
                val patchVar = (dx + dy + dDiag) / 3f

                // Mirror reflection correlation against mirrored row above horizon
                val mirrorY = (2 * horizonRowInGrid - y).coerceIn(yStart, horizonRowInGrid)
                val mc = rgb(x, mirrorY)
                val mr = (mc ushr 16) and 0xFF
                val mg = (mc ushr 8) and 0xFF
                val mb = mc and 0xFF
                val mirrorDiff = (abs(r - mr) + abs(g - mg) + abs(b - mb)) / 3f
                val isMirrorShimmer = mirrorDiff < 26f && l > 95f && dx < 14f && dy >= dx * 1.05f

                // Hazard classifiers
                val isBlueOrTealWater = (b > r + 11 && b >= g - 4) ||
                    (g > r + 9 && b > r + 6 && l < 188f && dx < 14f)
                val isBrightSpecularWater = (l > 186f && sat < 0.18f && b >= r - 3 && dx < 12f && dy > dx * 1.12f)
                val isAirOrMistyDrop = (b > r + 9 && l > 165f && patchVar < 7f) || l < 15f
                val isVerticalWallOrPillar = (visY < 0.78f && dx > dy * 1.65f && dx > 13f) ||
                    (visY < 0.72f && dDiag > 16f && dy > 14f)
                val isDenseCrowdOrBush = patchVar > 25f && sat > 0.24f && visY in 0.56f..0.90f

                when {
                    isBlueOrTealWater || isBrightSpecularWater || isMirrorShimmer -> {
                        cellClass[y][x] = SceneCellClass.WATER_OR_REFLECTION
                        cellWalkScore[y][x] = -2.4f
                    }
                    isAirOrMistyDrop -> {
                        cellClass[y][x] = SceneCellClass.SKY_OR_MID_AIR
                        cellWalkScore[y][x] = -2.0f
                    }
                    isVerticalWallOrPillar -> {
                        cellClass[y][x] = SceneCellClass.WALL_OR_ROOF
                        cellWalkScore[y][x] = -1.6f
                    }
                    isDenseCrowdOrBush -> {
                        cellClass[y][x] = SceneCellClass.CROWD_OR_OBSTACLE
                        cellWalkScore[y][x] = -0.9f
                    }
                    else -> {
                        // Solid walkable ground material classification
                        val isSnow = r > 176 && g > 180 && b > 186 && l > 138f
                        val isGrass = !isSnow && g > r * 1.04f && g > b * 1.08f
                        val isSand = !isSnow && !isGrass && r > 142 && g > 102 && b < 130 && r > b * 1.24f && l > 92f
                        val isRoad = !isSnow && !isGrass && !isSand && sat < 0.13f && l in 38f..135f
                        val mat = when {
                            isIndoorHint && !isGrass -> SceneCellClass.WALKABLE_INDOOR
                            isSnow -> SceneCellClass.WALKABLE_SNOW
                            isGrass -> SceneCellClass.WALKABLE_GRASS
                            isSand -> SceneCellClass.WALKABLE_SAND
                            isRoad -> SceneCellClass.WALKABLE_ROAD
                            else -> SceneCellClass.WALKABLE_STONE
                        }
                        cellClass[y][x] = mat
                        // Smooth continuous walkable floors score highest
                        val textureBonus = if (patchVar in 2.5f..18f) 1.25f else 0.90f
                        cellWalkScore[y][x] = textureBonus
                    }
                }
            }
        }

        // Step 3: Evaluate candidate foot anchor points (visX, visY) across Left, Center, Right lanes
        data class CandidateSpot(
            val visX: Float,
            val visY: Float,
            val score: Float,
            val lane: Int, // 0=Left, 1=Center, 2=Right
            val mat: SceneCellClass
        )

        val minGroundVisY = max(horizonYRatio + 0.14f, 0.72f).coerceIn(0.66f, 0.88f)
        val maxGroundVisY = 0.945f
        val stanceHalfW = (visSpanX * 0.055f).roundToInt().coerceAtLeast(2)
        val stanceHalfH = (visSpanY * 0.024f).roundToInt().coerceAtLeast(1)

        val laneBestScore = floatArrayOf(-999f, -999f, -999f)
        val laneBestY = floatArrayOf(0.90f, 0.90f, 0.90f)
        val laneBestX = floatArrayOf(0.28f, 0.50f, 0.72f)
        val laneHazardHits = intArrayOf(0, 0, 0)
        val laneSampleTotal = intArrayOf(0, 0, 0)
        var bestOverallSpot: CandidateSpot? = null

        val yGridMin = (yStart + minGroundVisY * visSpanY).roundToInt().coerceIn(yStart + 2, yEnd - 2)
        val yGridMax = (yStart + maxGroundVisY * visSpanY).roundToInt().coerceIn(yGridMin, yEnd - 1)
        val xGridMin = (xStart + 0.16f * visSpanX).roundToInt().coerceIn(xStart + 2, xEnd - 4)
        val xGridMax = (xStart + 0.84f * visSpanX).roundToInt().coerceIn(xGridMin + 2, xEnd - 2)

        for (cy in yGridMin..yGridMax step 2) {
            val visY = (cy - yStart) / visSpanY
            for (cx in xGridMin..xGridMax step 2) {
                val visX = (cx - xStart) / visSpanX
                val lane = when {
                    visX < 0.37f -> 0
                    visX <= 0.63f -> 1
                    else -> 2
                }
                laneSampleTotal[lane]++
                val centerCls = cellClass[cy][cx]
                if (centerCls == SceneCellClass.WATER_OR_REFLECTION ||
                    centerCls == SceneCellClass.SKY_OR_MID_AIR ||
                    centerCls == SceneCellClass.WALL_OR_ROOF
                ) {
                    laneHazardHits[lane]++
                }

                // Evaluate full shoe-stance neighborhood + cast-shadow margin slightly below feet
                var patchScore = 0f
                var hazardCells = 0
                var crowdCells = 0
                var totalCells = 0
                for (sy in (cy - stanceHalfH).coerceAtLeast(yStart)..(cy + stanceHalfH + 1).coerceAtMost(yEnd)) {
                    for (sx in (cx - stanceHalfW).coerceAtLeast(xStart)..(cx + stanceHalfW).coerceAtMost(xEnd)) {
                        val sc = cellClass[sy][sx]
                        patchScore += cellWalkScore[sy][sx]
                        if (sc == SceneCellClass.WATER_OR_REFLECTION ||
                            sc == SceneCellClass.SKY_OR_MID_AIR ||
                            sc == SceneCellClass.WALL_OR_ROOF
                        ) {
                            hazardCells++
                        } else if (sc == SceneCellClass.CROWD_OR_OBSTACLE) {
                            crowdCells++
                        }
                        totalCells++
                    }
                }
                val avgWalk = if (totalCells > 0) patchScore / totalCells else -1f
                val hazardFrac = if (totalCells > 0) hazardCells.toFloat() / totalCells else 1f
                val crowdFrac = if (totalCells > 0) crowdCells.toFloat() / totalCells else 0f

                // Check torso clearance directly above stance so person doesn't overlap crowds or bushes
                var upperCrowd = 0
                var upperChecked = 0
                for (uy in (cy - (visSpanY * 0.22f).roundToInt()).coerceAtLeast(yStart)..(cy - stanceHalfH - 1).coerceAtLeast(yStart) step 2) {
                    if (cellClass[uy][cx] == SceneCellClass.CROWD_OR_OBSTACLE) upperCrowd++
                    upperChecked++
                }
                val upperCrowdFrac = if (upperChecked > 0) upperCrowd.toFloat() / upperChecked else 0f

                // Strict safety penalty if ANY water/reflection/mid-air/wall hits the sole stance
                val hazardPenalty = if (hazardCells > 0) -3.5f - (hazardFrac * 4.5f) else 0f
                val crowdPenalty = -(crowdFrac * 1.8f + upperCrowdFrac * 0.9f)

                // Human framing preference: foreground grounding (0.85..0.92) + rule-of-thirds on water/monument scenes
                val depthNaturalBonus = (1f - abs(visY - 0.89f) * 3.2f).coerceIn(-0.6f, 0.45f)
                val sideCompositionBonus = when {
                    preferSidePlacement && lane != 1 -> 0.95f
                    preferSidePlacement && lane == 1 -> -0.65f
                    (isReflectionPoolMonument || isWaterKeyword) && lane != 1 && hazardCells == 0 -> 0.55f
                    lane == 1 && hazardCells == 0 -> 0.25f
                    else -> 0.05f
                }
                val totalScore = avgWalk + hazardPenalty + crowdPenalty + depthNaturalBonus + sideCompositionBonus

                if (totalScore > laneBestScore[lane]) {
                    laneBestScore[lane] = totalScore
                    laneBestY[lane] = visY
                    laneBestX[lane] = visX
                }
                val candidate = CandidateSpot(visX, visY, totalScore, lane, centerCls)
                if (bestOverallSpot == null || candidate.score > bestOverallSpot.score) {
                    bestOverallSpot = candidate
                }
            }
        }

        val centerHazardRatio = if (laneSampleTotal[1] > 0) {
            laneHazardHits[1].toFloat() / laneSampleTotal[1].toFloat()
        } else 0f
        val centerBlocked = (isReflectionPoolMonument && (centerHazardRatio > 0.07f || isWaterKeyword)) ||
            centerHazardRatio > 0.18f ||
            laneBestScore[1] < 0.1f

        val chosenSpot = bestOverallSpot ?: CandidateSpot(0.50f, 0.90f, 0.5f, 1, groundPlane.surfaceCategory.let { SceneCellClass.WALKABLE_STONE })

        // Compute horizontal X offset cleanly matching preview coordinates
        val bestVisX = when {
            preferSidePlacement -> if (laneBestScore[0] >= laneBestScore[2]) laneBestX[0] else laneBestX[2]
            centerBlocked -> if (laneBestScore[0] >= laneBestScore[2]) laneBestX[0] else laneBestX[2]
            else -> chosenSpot.visX
        }.coerceIn(0.18f, 0.82f)

        val xOffsetPx = when {
            bestVisX < 0.39f -> -((0.50f - bestVisX) * pW).coerceIn(sideShift * 0.72f, pW * 0.27f)
            bestVisX > 0.61f -> +((bestVisX - 0.50f) * pW).coerceIn(sideShift * 0.72f, pW * 0.27f)
            else -> ((bestVisX - 0.50f) * pW * 0.65f)
        }

        val bestGroundY = when {
            bestVisX < 0.39f -> laneBestY[0]
            bestVisX > 0.61f -> laneBestY[2]
            else -> laneBestY[1]
        }.coerceIn(max(horizonYRatio + 0.12f, 0.74f), 0.94f)

        // Perspective-accurate tourist scale (derived from horizon distance, floor depth span & openness)
        val opennessRatio = if (upperSkyOrDistantCount[1] > 0) {
            upperSkyOrDistantCount[0].toFloat() / upperSkyOrDistantCount[1].toFloat()
        } else 0.40f
        val groundDepthSpan = (bestGroundY - horizonYRatio).coerceIn(0.10f, 0.64f)

        val depthDrivenScale = (0.50f + groundDepthSpan * 0.52f).coerceIn(0.52f, 0.78f)
        val vistaScale = when {
            isReflectionPoolMonument || opennessRatio > 0.62f || horizonYRatio > 0.60f -> 0.58f
            opennessRatio > 0.44f || horizonYRatio > 0.54f -> 0.64f
            isIndoorHint || opennessRatio < 0.24f -> 0.75f
            else -> 0.70f
        }
        val perspectiveScale = (depthDrivenScale * 0.55f + vistaScale * 0.45f).coerceIn(0.50f, 0.79f)

        val surfaceLabel = when (chosenSpot.mat) {
            SceneCellClass.WALKABLE_SAND -> "Sandy Ground"
            SceneCellClass.WALKABLE_GRASS -> "Park Lawn"
            SceneCellClass.WALKABLE_ROAD -> "Street Pavement"
            SceneCellClass.WALKABLE_INDOOR -> "Indoor Floor"
            SceneCellClass.WALKABLE_SNOW -> "Snow Trail"
            else -> "Stone Walkway"
        }

        VisualSceneAnalysis(
            xOffsetPx = xOffsetPx,
            bestVisXRatio = bestVisX,
            bestGroundYRatio = bestGroundY,
            horizonYRatio = horizonYRatio,
            perspectiveScale = perspectiveScale,
            surfaceLabel = surfaceLabel,
            centerHasWaterOrHazard = centerBlocked,
            leftWalkableScore = laneBestScore[0],
            centerWalkableScore = laneBestScore[1],
            rightWalkableScore = laneBestScore[2],
            leftBestYRatio = laneBestY[0],
            centerBestYRatio = laneBestY[1],
            rightBestYRatio = laneBestY[2]
        )
    } catch (_: Throwable) {
        defaultAnalysis
    } finally {
        try {
            if (proxy != null && !proxy.isRecycled) proxy.recycle()
        } catch (_: Throwable) {}
    }
}

fun computeSmartSurfacePlacement(
    bgBitmap: Bitmap?,
    locationName: String?,
    previewWidth: Float
): Pair<Float, Float> {
    val scene = analyzeVisualSceneForTouristPlacement(
        bgBitmap = bgBitmap,
        locationName = locationName,
        previewWidth = previewWidth,
        previewHeight = 0f,
        preferSidePlacement = false
    )
    return Pair(scene.xOffsetPx, scene.perspectiveScale)
}

/**
 * 100% Original Auto-Realism Calculator:
 * Combines 2D visual scene analysis (walkable floor vs water/reflection/mid-air/wall/crowd),
 * perspective-accurate human scale, exact shoe-sole grounding, scene lighting, cool/warm tint,
 * and contact 3D shadow depth from the live background bitmap.
 */
fun computeVoiceAutoRealism(
    bgBitmap: Bitmap?,
    command: ParsedVoiceCommand,
    sourceAnalysis: SourcePhotoAnalysis?,
    previewWidthPx: Float,
    previewHeightPx: Float,
    subjectBitmap: Bitmap? = null
): VoiceAutoRealismPlan {
    val bgLighting = analyzeVideoBackgroundLighting(bgBitmap)
    val sceneAdaptive = analyzeAnyBackgroundBitmap(
        bgBitmap = bgBitmap,
        landmarkFallbackName = command.locationQuery,
        isCoolToneFallback = command.sceneMood == VoiceSceneMood.SNOW || command.sceneMood == VoiceSceneMood.NIGHT
    )

    val scene = analyzeVisualSceneForTouristPlacement(
        bgBitmap = bgBitmap,
        locationName = command.locationQuery,
        previewWidth = previewWidthPx,
        previewHeight = previewHeightPx,
        preferSidePlacement = command.preferSidePlacement
    )
    val baseScale = scene.perspectiveScale

    val adjustedScale = when (command.sizeHint) {
        VoiceSizeHint.SMALL -> (baseScale * 0.78f).coerceIn(0.46f, 0.78f)
        VoiceSizeHint.LARGE -> (baseScale * 1.18f).coerceIn(0.54f, 0.86f)
        VoiceSizeHint.MEDIUM -> baseScale.coerceIn(0.50f, 0.80f)
        VoiceSizeHint.AUTO -> baseScale.coerceIn(0.50f, 0.80f)
    }

    val pW = previewWidthPx.coerceAtLeast(360f)
    val pH = previewHeightPx.coerceAtLeast(300f)
    val sideShift = (pW * 0.21f).coerceAtLeast(90f)

    val xOffset: Float
    val chosenGroundYRatio: Float
    when (command.positionHint) {
        VoicePositionHint.LEFT -> {
            xOffset = -sideShift
            chosenGroundYRatio = scene.leftBestYRatio
        }
        VoicePositionHint.RIGHT -> {
            xOffset = +sideShift
            chosenGroundYRatio = scene.rightBestYRatio
        }
        VoicePositionHint.CENTER -> {
            xOffset = 0f
            chosenGroundYRatio = scene.centerBestYRatio
        }
        VoicePositionHint.AUTO -> {
            xOffset = scene.xOffsetPx
            chosenGroundYRatio = scene.bestGroundYRatio
        }
    }

    // Perspective-accurate & ground-locked foot placement:
    // Plant full-body shoe soles directly on the verified solid ground Y; keep half-body crops flush at bottom.
    val footAnchor = if (subjectBitmap != null && !subjectBitmap.isRecycled) {
        detectSubjectFootAnchor(subjectBitmap)
    } else {
        SubjectFootAnchor()
    }
    val userH = pH * ((210f * adjustedScale) / 380f)
    val targetGroundY = if (footAnchor.isHalfBodyCropped) {
        pH * 0.985f
    } else {
        val rawGroundY = pH * chosenGroundYRatio.coerceIn(0.74f, 0.945f)
        val minHeadClearY = (footAnchor.lowestContactYRatio * userH) + (pH * 0.045f)
        if (minHeadClearY > rawGroundY) min(minHeadClearY, pH * 0.965f) else rawGroundY
    }
    val yOffset = (targetGroundY - pH) + (userH * (1f - footAnchor.lowestContactYRatio))

    // Adaptive 3D Shadow intensity based on ambient brightness & mood
    val shadowDepth = when {
        command.sceneMood == VoiceSceneMood.NIGHT || bgLighting.avgBrightness < 0.28f -> 0.28f
        command.sceneMood == VoiceSceneMood.SNOW -> 0.38f
        bgLighting.avgBrightness > 0.62f -> 0.50f
        else -> 0.42f
    }

    val isCoolTone = when (command.sceneMood) {
        VoiceSceneMood.SNOW, VoiceSceneMood.NIGHT -> true
        VoiceSceneMood.SUNSET, VoiceSceneMood.DESERT -> false
        else -> bgLighting.warmth < -0.05f || sceneAdaptive.timeOfDay.contains("Snow", ignoreCase = true)
    }

    val envBlend = when (command.sceneMood) {
        VoiceSceneMood.SUNSET, VoiceSceneMood.DESERT -> 0.70f
        VoiceSceneMood.NIGHT -> 0.65f
        else -> if (bgLighting.avgBrightness > 0.50f) 0.62f else 0.58f
    }

    val sidePrefix = when {
        xOffset < -30f -> "Left"
        xOffset > 30f -> "Right"
        else -> "Center"
    }
    val posTag = "$sidePrefix ${scene.surfaceLabel}"
    val toneTag = when {
        isCoolTone -> "Cool Ambient"
        bgLighting.warmth > 0.08f -> "Warm Sunlight"
        else -> "Natural Daylight"
    }
    return VoiceAutoRealismPlan(
        userScale = adjustedScale,
        userXOffset = xOffset,
        userYOffset = yOffset,
        shadowDepth = shadowDepth,
        environmentBlend = envBlend,
        isCoolToneScene = isCoolTone,
        summaryLabel = "${command.displayLocation} • $posTag (${(adjustedScale * 100).toInt()}%) • $toneTag"
    )
}

/**
 * Generates a clean 15-second warm stereo ambient travel soundtrack (.wav)
 * when the user requests "with music" via Voice AI without pre-selecting a custom MP3.
 */
fun generateAmbientTravelWav15s(outputFile: File): File {
    val sampleRate = 44100
    val channels = 2
    val durationSeconds = 15
    val totalSamples = sampleRate * durationSeconds
    val dataSize = totalSamples * channels * 2
    val byteRate = sampleRate * channels * 2

    // Warm uplifting travel progression (C - G - Am - F cycling smoothly)
    val chords = arrayOf(
        doubleArrayOf(261.63, 329.63, 392.00, 523.25), // Cmaj7 feel
        doubleArrayOf(196.00, 293.66, 392.00, 493.88), // G
        doubleArrayOf(220.00, 329.63, 440.00, 523.25), // Am
        doubleArrayOf(174.61, 261.63, 349.23, 440.00)  // F
    )

    FileOutputStream(outputFile).use { fos ->
        // Write 44-byte RIFF/WAVE header
        fun writeLeInt(v: Int) {
            fos.write(v and 0xFF)
            fos.write((v shr 8) and 0xFF)
            fos.write((v shr 16) and 0xFF)
            fos.write((v shr 24) and 0xFF)
        }
        fun writeLeShort(v: Int) {
            fos.write(v and 0xFF)
            fos.write((v shr 8) and 0xFF)
        }

        fos.write("RIFF".toByteArray(Charsets.US_ASCII))
        writeLeInt(36 + dataSize)
        fos.write("WAVE".toByteArray(Charsets.US_ASCII))
        fos.write("fmt ".toByteArray(Charsets.US_ASCII))
        writeLeInt(16) // PCM chunk size
        writeLeShort(1) // PCM format
        writeLeShort(channels)
        writeLeInt(sampleRate)
        writeLeInt(byteRate)
        writeLeShort(channels * 2) // block align
        writeLeShort(16) // bits per sample
        fos.write("data".toByteArray(Charsets.US_ASCII))
        writeLeInt(dataSize)

        val buffer = ByteArray(4096 * 4)
        var bufIdx = 0
        val bpm = 104.0
        val beatDur = 60.0 / bpm

        for (s in 0 until totalSamples) {
            val t = s.toDouble() / sampleRate.toDouble()
            val chordIdx = ((t / 3.75).toInt()).coerceIn(0, 3)
            val chord = chords[chordIdx]

            // Smooth global fade-in & fade-out
            val envIn = (t / 0.6).coerceIn(0.0, 1.0)
            val envOut = ((durationSeconds - t) / 0.8).coerceIn(0.0, 1.0)
            val masterEnv = envIn * envOut

            // Gentle plucked arpeggio + warm pad
            val chordLocalT = t % 3.75
            val pad = (
                0.30 * sin(2.0 * PI * chord[0] * t) +
                0.24 * sin(2.0 * PI * chord[1] * t) +
                0.20 * sin(2.0 * PI * chord[2] * t) +
                0.14 * sin(2.0 * PI * chord[3] * t + 0.35)
            ) * 0.45

            // Soft kick/pulse on quarter beats
            val beatPhase = (t % beatDur) / beatDur
            val kickEnv = exp(-beatPhase * 12.0)
            val kickFreq = 58.0 + 90.0 * exp(-beatPhase * 28.0)
            val kick = sin(2.0 * PI * kickFreq * beatPhase * beatDur) * kickEnv * 0.32

            // Gentle sparkle pluck every half beat
            val halfBeatPhase = (t % (beatDur * 0.5)) / (beatDur * 0.5)
            val arpNote = chord[((t / (beatDur * 0.5)).toInt()) % chord.size] * 2.0
            val arpEnv = exp(-halfBeatPhase * 7.5) * exp(-chordLocalT * 0.15)
            val arp = sin(2.0 * PI * arpNote * t) * arpEnv * 0.18

            val leftVal = ((pad + kick + arp * 0.85) * masterEnv * 14500.0).toInt().coerceIn(-32767, 32767)
            val rightVal = ((pad * 0.96 + kick + arp * 1.08) * masterEnv * 14500.0).toInt().coerceIn(-32767, 32767)

            buffer[bufIdx++] = (leftVal and 0xFF).toByte()
            buffer[bufIdx++] = ((leftVal shr 8) and 0xFF).toByte()
            buffer[bufIdx++] = (rightVal and 0xFF).toByte()
            buffer[bufIdx++] = ((rightVal shr 8) and 0xFF).toByte()

            if (bufIdx >= buffer.size) {
                fos.write(buffer, 0, bufIdx)
                bufIdx = 0
            }
        }
        if (bufIdx > 0) {
            fos.write(buffer, 0, bufIdx)
        }
    }
    return outputFile
}

@Composable
fun VoiceAiModalDialog(
    isListening: Boolean,
    isProcessing: Boolean,
    partialTranscript: String,
    processingStatus: String,
    languageTag: String,
    hasUserPhoto: Boolean = true,
    onPickGalleryPhoto: () -> Unit = {},
    onOpenCamera: () -> Unit = {},
    onToggleLanguage: () -> Unit,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    onSubmitCommand: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var typedCommand by remember(partialTranscript) { mutableStateOf(partialTranscript) }

    val pulseTransition = rememberInfiniteTransition(label = "voice_pulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isListening) 1.24f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "voice_orb_scale"
    )

    val quickExamples = remember {
        listOf(
            "मेरी फोटो मनाली की बर्फ में बना दो",
            "Create a 15s video in Paris with music",
            "ताजमहल के सामने बाएं तरफ 15s वीडियो गाने के साथ",
            "Mount Fuji sunset photo on right"
        )
    }

    Dialog(onDismissRequest = { if (!isProcessing) onDismiss() }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = BorderStroke(1.2.dp, Color(0xFF334155)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("voice_ai_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Voice AI",
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Voice AI Director",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            onClick = onToggleLanguage,
                            enabled = !isProcessing,
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.6f)),
                            modifier = Modifier.testTag("voice_ai_lang_toggle")
                        ) {
                            Text(
                                text = if (languageTag.startsWith("hi")) "🇮🇳 हिंदी / EN" else "🌐 English",
                                color = Color(0xFFBAE6FD),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }

                        IconButton(
                            onClick = { if (!isProcessing) onDismiss() },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("voice_ai_close_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Voice AI",
                                tint = Color(0xFF94A3B8)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Interactive Animated Microphone Orb
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(116.dp)
                        .testTag("voice_ai_mic_orb")
                ) {
                    Box(
                        modifier = Modifier
                            .size(104.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = if (isListening) {
                                        listOf(Color(0x66EC4899), Color(0x22A855F7), Color.Transparent)
                                    } else if (isProcessing) {
                                        listOf(Color(0x6610B981), Color(0x2238BDF8), Color.Transparent)
                                    } else {
                                        listOf(Color(0x4438BDF8), Color.Transparent)
                                    }
                                )
                            )
                    )

                    Surface(
                        onClick = {
                            if (!isProcessing) {
                                if (isListening) onStopListening() else onStartListening()
                            }
                        },
                        shape = CircleShape,
                        color = when {
                            isProcessing -> Color(0xFF059669)
                            isListening -> Color(0xFFEC4899)
                            else -> Color(0xFF6366F1)
                        },
                        shadowElevation = 10.dp,
                        modifier = Modifier.size(76.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 3.dp,
                                    modifier = Modifier.size(32.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                                    contentDescription = if (isListening) "Stop Listening" else "Speak Command",
                                    tint = Color.White,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = when {
                        isProcessing -> processingStatus.ifBlank { "Generating realistic output..." }
                        !hasUserPhoto -> "Please select a photo or open Camera first so Voice AI can place you in the scene"
                        isListening -> "Listening... Speak in Hindi or English"
                        else -> "Tap mic & speak your scene (Hindi / English)"
                    },
                    color = when {
                        isProcessing -> Color(0xFF34D399)
                        !hasUserPhoto -> Color(0xFFFBBF24)
                        isListening -> Color(0xFFF472B6)
                        else -> Color(0xFFCBD5E1)
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )

                if (!hasUserPhoto && !isProcessing) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onPickGalleryPhoto,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("voice_ai_pick_gallery_button")
                        ) {
                            Text("Gallery Photo", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Button(
                            onClick = onOpenCamera,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("voice_ai_open_camera_button")
                        ) {
                            Text("Camera Selfie", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                if (partialTranscript.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF1E293B),
                        border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Transcript",
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "\"$partialTranscript\"",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Command input box (useful as fallback or quick edit before running)
                OutlinedTextField(
                    value = typedCommand,
                    onValueChange = { typedCommand = it },
                    enabled = !isProcessing,
                    singleLine = true,
                    placeholder = {
                        Text(
                            text = "e.g., Paris 15s video with music",
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    },
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                if (!isProcessing && typedCommand.isNotBlank()) {
                                    onSubmitCommand(typedCommand.trim())
                                }
                            },
                            enabled = !isProcessing && typedCommand.isNotBlank(),
                            modifier = Modifier.testTag("voice_ai_submit_text_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Run Voice Command",
                                tint = if (typedCommand.isNotBlank()) Color(0xFF38BDF8) else Color(0xFF475569)
                            )
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            if (!isProcessing && typedCommand.isNotBlank()) {
                                onSubmitCommand(typedCommand.trim())
                            }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF1E293B),
                        unfocusedContainerColor = Color(0xFF1E293B)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("voice_ai_command_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Try One-Tap Voice Commands:",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    quickExamples.forEachIndexed { idx, sample ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0xFF475569)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(enabled = !isProcessing) {
                                    typedCommand = sample
                                    onSubmitCommand(sample)
                                }
                                .testTag("voice_ai_sample_$idx")
                        ) {
                            Text(
                                text = sample,
                                color = Color(0xFFE2E8F0),
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { if (isListening) onStopListening() else onStartListening() },
                        enabled = !isProcessing,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isListening) Color(0xFFBE185D) else Color(0xFF0284C7)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("voice_ai_listen_toggle_button")
                    ) {
                        Text(
                            text = if (isListening) "Stop Mic" else "🎤 Speak Now",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Button(
                        onClick = {
                            if (typedCommand.isNotBlank()) {
                                onSubmitCommand(typedCommand.trim())
                            }
                        },
                        enabled = !isProcessing && typedCommand.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF059669),
                            disabledContainerColor = Color(0xFF334155)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("voice_ai_generate_button")
                    ) {
                        Text(
                            text = "✨ Auto Create",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

package com.aistudio.worldcamai.smxuqv

import android.graphics.Bitmap
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.io.File
import java.io.FileOutputStream
import java.util.WeakHashMap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

enum class VoiceOutputType {
    PHOTO,
    VIDEO_15S
}

enum class VoicePositionHint {
    AUTO,
    LEFT,
    CENTER,
    RIGHT
}

enum class VoiceSizeHint {
    AUTO,
    SMALL,
    MEDIUM,
    LARGE
}

enum class VoiceSceneMood {
    AUTO,
    SNOW,
    NIGHT,
    SUNSET,
    BEACH,
    DESERT,
    MOUNTAIN
}

enum class VoiceIntentAction {
    UNDO,
    ADJUST_CURRENT_SCENE,
    CHANGE_LOCATION
}

enum class VoiceLanguageStyle {
    HINDI_DEVANAGARI,
    HINGLISH,
    ENGLISH
}

enum class VoiceScaleDelta {
    NONE,
    SCALE_DOWN,
    SCALE_UP,
    SCALE_RESET
}

enum class VoicePositionNudge {
    NONE,
    NUDGE_LEFT,
    NUDGE_RIGHT,
    STEP_BACK,
    STEP_FORWARD
}

enum class VoiceShadowHint {
    NONE,
    SOFT,
    NATURAL,
    DEEP_3D
}

enum class VoiceLightingHint {
    NONE,
    MATCH_AUTO,
    WARM,
    COOL
}

enum class VoiceModeRequest {
    NONE,
    VIDEO_15S,
    PHOTO,
    LIVE_CAMERA_VIDEO,
    START_LIVE_RECORDING,
    STOP_LIVE_RECORDING,
    FLIP_LIVE_CAMERA,
    FRONT_LIVE_CAMERA,
    BACK_LIVE_CAMERA
}

data class ParsedVoiceCommand(
    val rawTranscript: String,
    val locationQuery: String,
    val displayLocation: String,
    val outputType: VoiceOutputType,
    val positionHint: VoicePositionHint,
    val sizeHint: VoiceSizeHint,
    val wantsMusic: Boolean,
    val sceneMood: VoiceSceneMood,
    val preferSidePlacement: Boolean = false,
    val wantsWalkwayOrGroundFix: Boolean = false,
    val intentAction: VoiceIntentAction = VoiceIntentAction.CHANGE_LOCATION,
    val hasExplicitLocation: Boolean = true,
    val hasExplicitOutputType: Boolean = false,
    val languageStyle: VoiceLanguageStyle = VoiceLanguageStyle.ENGLISH,
    val scaleDelta: VoiceScaleDelta = VoiceScaleDelta.NONE,
    val positionNudge: VoicePositionNudge = VoicePositionNudge.NONE,
    val shadowHint: VoiceShadowHint = VoiceShadowHint.NONE,
    val lightingHint: VoiceLightingHint = VoiceLightingHint.NONE,
    val modeRequest: VoiceModeRequest = VoiceModeRequest.NONE
)

data class VoiceAutoRealismPlan(
    val userScale: Float,
    val userXOffset: Float,
    val userYOffset: Float,
    val shadowDepth: Float,
    val environmentBlend: Float,
    val isCoolToneScene: Boolean,
    val summaryLabel: String,
    val waterGuardrailTriggered: Boolean = false
)

data class VoiceUndoSnapshot(
    val bgBitmap: Bitmap?,
    val bgLighting: AdaptiveSceneLighting?,
    val selectedLandmark: TravelLandmark,
    val selectedCustomPlace: GooglePlaceResult?,
    val customLocationName: String,
    val isSearchingCustomLocation: Boolean,
    val userScale: Float,
    val userXOffset: Float,
    val userYOffset: Float,
    val isGroundLockEnabled: Boolean,
    val shadowDepth: Float,
    val environmentBlend: Float,
    val isCoolToneScene: Boolean,
    val isVideoMode: Boolean,
    val visualAnalysisStatus: String
)

private val hindiToEnglishLocationTerms = linkedMapOf(
    "मनाली" to "Manali",
    "शिमला" to "Shimla",
    "ताजमहल" to "Taj Mahal",
    "ताज महल" to "Taj Mahal",
    "tajmahal" to "Taj Mahal",
    "लाल किला" to "Red Fort Delhi",
    "कुतुब मीनार" to "Qutub Minar Delhi",
    "चारमीनार" to "Charminar Hyderabad",
    "गेटवे ऑफ इंडिया" to "Gateway of India Mumbai",
    "मरीन ड्राइव" to "Marine Drive Mumbai",
    "रोहतांग" to "Rohtang Pass Manali",
    "नैनीताल" to "Nainital Lake",
    "मसूरी" to "Mussoorie Hills",
    "दार्जिलिंग" to "Darjeeling Hills",
    "ऊटी" to "Ooty Hills",
    "कन्याकुमारी" to "Kanyakumari",
    "पेरिस" to "Paris Eiffel Tower",
    "एफिल टॉवर" to "Eiffel Tower Paris",
    "एफिल टावर" to "Eiffel Tower Paris",
    "लंदन" to "London Big Ben",
    "दुबई बीच" to "Dubai Beach",
    "दुबई" to "Dubai Burj Khalifa",
    "बुर्ज खलीफा" to "Burj Khalifa Dubai",
    "न्यूयॉर्क" to "New York Times Square",
    "टोक्यो" to "Tokyo",
    "जापान" to "Mount Fuji Japan",
    "माउंट फूजी" to "Mount Fuji Japan",
    "स्विट्जरलैंड" to "Swiss Alps Switzerland",
    "स्विट्ज़रलैंड" to "Swiss Alps Switzerland",
    "कश्मीर" to "Kashmir Dal Lake",
    "सोनमर्ग" to "Sonmarg Kashmir",
    "गुलमर्ग" to "Gulmarg snow Kashmir",
    "लद्दाख" to "Ladakh Pangong Lake",
    "लेह" to "Leh Ladakh",
    "जयपुर" to "Hawa Mahal Jaipur",
    "हवा महल" to "Hawa Mahal Jaipur",
    "जैसलमेर" to "Jaisalmer Thar Desert",
    "गोवा बीच" to "Goa Beach",
    "गोवा" to "Goa Beach",
    "केरल" to "Kerala Backwaters",
    "ऋषिकेश" to "Rishikesh Ganga",
    "हरिद्वार" to "Haridwar Har Ki Pauri",
    "वाराणसी" to "Varanasi Ghats",
    "बनारस" to "Varanasi Ghats",
    "मुंबई" to "Gateway of India Mumbai",
    "दिल्ली" to "India Gate Delhi",
    "इंडिया गेट" to "India Gate Delhi",
    "केदारनाथ" to "Kedarnath Temple snow",
    "बद्रीनाथ" to "Badrinath Temple",
    "उदयपुर" to "Udaipur Lake Palace",
    "जोधपुर" to "Mehrangarh Fort Jodhpur",
    "जल महल" to "Jal Mahal Jaipur",
    "आमेर" to "Amber Fort Jaipur",
    "जंतर मंतर" to "Jantar Mantar Jaipur",
    "कोटा" to "Kota Chambal Riverfront",
    "अयोध्या" to "Ayodhya Ram Mandir",
    "राम मंदिर" to "Ram Mandir Ayodhya",
    "गोल्डन टेम्पल" to "Golden Temple Amritsar",
    "स्वर्ण मंदिर" to "Golden Temple Amritsar",
    "लंदन ब्रिज" to "Tower Bridge London",
    "हम्पी" to "Hampi Karnataka",
    "आगरा" to "Taj Mahal Agra",
    "रोम" to "Colosseum Rome",
    "इटली" to "Colosseum Rome Italy",
    "मालदीव" to "Maldives beach",
    "बाली" to "Bali Indonesia",
    "सिंगापुर" to "Marina Bay Sands Singapore",
    "थाईलैंड" to "Thailand beach",
    "सैंटोरिनी" to "Santorini Greece",
    "ग्रीस" to "Santorini Greece",
    "बर्फ" to "snow",
    "बर्फीले" to "snow mountains",
    "पहाड़" to "mountains",
    "पहाड़ों" to "mountains",
    "पहाड़ों में" to "mountains",
    "रेगिस्तान" to "desert sand dunes",
    "समुद्र" to "ocean beach",
    "बीच" to "beach",
    "झील" to "lake",
    "नदी" to "river",
    "रात" to "night lights",
    "शाम" to "sunset",
    "सूरज" to "sunset"
)

private val hindiStopWords = setOf(
    "मेरी", "मेरा", "मेरे", "मुझे", "मुझको", "हमारी", "हमारा", "हमको", "हमें", "मैं", "मे", "में",
    "फोटो", "तस्वीर", "पिक्चर", "इमेज", "सेल्फी", "विडिओ", "वीडियो", "रील", "रिल",
    "का", "की", "के", "को", "से", "पर", "तक", "साथ", "वाला", "वाली",
    "बना", "बनाओ", "बनाई", "दो", "दीजिए", "कर", "करो", "करदो", "करना", "करके", "दे", "देना", "है", "हूं",
    "एक", "और", "या", "प्लीज", "ज़रा", "जरा", "अभी", "तुरंत", "अच्छी", "अच्छा", "सुंदर", "रियल", "नेचुरल", "बिल्कुल",
    "चाहिए", "लगा", "लगाओ", "डालो", "सामने", "तरफ", "थोड़ा", "थोड़ी", "थोड़े", "ज्यादा", "ज़्यादा",
    "खड़ा", "खड़े", "खड़ी", "सेट", "रखो", "लाओ", "ले", "चलो", "जाओ", "बैठाओ", "दिखाओ", "भेजो",
    "ज़मीन", "जमीन", "धरती", "फर्श", "रास्ते", "वॉकवे", "सड़क", "सही", "जगह", "स्थान",
    "साइड", "कोने", "कोना", "किनारे", "बाजू", "पास", "दूर", "नजदीक", "करीब", "आगे", "पीछे",
    "गाना", "गाने", "म्यूजिक", "संगीत", "साउंड", "सॉन्ग",
    "बाएं", "बाएँ", "दाएं", "दाएँ", "बीच", "छोटा", "छोटी", "बड़ा", "बड़ी", "सेकंड", "सेकेंड",
    "पहले", "जैसा", "वापस", "पिछला", "पुराना", "अनडू", "लाइट", "रोशनी", "मैच", "शैडो", "परछाई", "सॉफ्ट", "हल्की", "गहरी", "ज़ूम", "साइज", "मोड",
    "लाइव", "कैमरा", "खोलो", "खोल", "चालू", "रिकॉर्ड", "रिकॉर्डिंग", "शुरू", "रोको", "बंद", "घुमाओ", "पलटो", "दूसरा", "फ्रंट", "बैक",
    "meri", "mera", "mere", "mujhe", "mujhko", "humko", "hume", "humein", "main", "mai", "hum", "aap", "mujko",
    "photo", "selfie", "tasveer", "image", "pic", "picture", "portrait",
    "video", "reel", "reels", "shorts", "15s", "15sec", "15", "second", "seconds", "sec", "clip",
    "ki", "ka", "ke", "ko", "mein", "me", "par", "pe", "per", "se", "tak", "saath", "sath", "wali", "wala", "vale", "wale",
    "bana", "banao", "banado", "banaao", "banana", "do", "de", "dena", "dijiye", "kar", "karo", "kardo", "karna", "karke", "please", "pls",
    "chahiye", "laga", "lagao", "lagado", "dalo", "daalo", "rakho", "rakh", "rakhdo", "lao", "laao", "le", "chalo", "jao", "bhejo", "pahuncha",
    "khada", "khade", "khadi", "bithao", "dikhao", "dikha",
    "samne", "saamne", "taraf", "ek", "thoda", "thodi", "thode", "bahut", "zara", "jara", "aur", "bilkul", "sahi", "jagah", "jageh",
    "paas", "pas", "nazdeek", "kareeb", "dur", "door", "aage", "age", "peeche", "piche", "upar", "neeche", "niche",
    "zameen", "jameen", "jamin", "dharti", "farsh", "sadak", "raste", "raaste", "walkway", "footpath", "sidewalk", "pavement", "pathway", "path",
    "gana", "gaana", "gaane", "gane", "music", "song", "songs", "audio", "track", "bgm", "beat",
    "pehle", "pahle", "jaisa", "jaise", "wapas", "vapas", "pichla", "pichle", "purana", "purani", "undo", "revert", "restore", "reset", "cancel", "previous",
    "light", "lighting", "roshni", "relight", "match", "blend", "tone", "color", "warm", "cool", "cold", "golden", "glow",
    "shadow", "shadows", "parchhai", "parchai", "3d", "soft", "softer", "deep", "deeper", "dark", "darker", "strong", "heavy", "halki", "halka", "gehri", "gehre", "kam", "zyada", "jyada", "badhao",
    "chota", "chhota", "chhoti", "choti", "bada", "badi", "size", "zoom", "out", "in", "step", "back", "forward", "shift", "move", "closer",
    "mode", "switch", "turn", "live", "camera", "save", "record", "recording", "render", "convert",
    "kholo", "khol", "chalu", "shuru", "roko", "band", "start", "stop", "flip", "ghumao", "palto", "dusra", "doosra", "front", "exit", "close", "open",
    "create", "make", "generate", "put", "place", "edit", "show", "set", "align", "adjust", "stand", "standing", "pose", "posing", "take", "bring", "keep",
    "a", "an", "the", "in", "at", "on", "to", "into", "with", "and", "or", "of", "for", "from", "by", "my", "me", "near", "beside", "next", "onto", "here", "there", "this", "that", "it",
    "left", "right", "center", "centre", "middle", "small", "smaller", "tiny", "far", "distant", "big", "bigger", "large", "larger", "close", "closeup",
    "side", "corner", "kone", "kona", "kinare", "kinaare", "baju", "frame", "background", "bg", "location", "place", "spot", "ground", "floor", "surface",
    "natural", "realistic", "real", "perfect", "properly", "auto", "normal", "default", "medium", "little", "bit", "more", "less", "yaar", "bhai", "bro", "arre", "hey", "hi", "hello", "can", "you"
)

/**
 * Simple phonetic Devanagari -> Latin transliterator so even rural towns / unlisted landmarks
 * spoken in Hindi script resolve cleanly via keyless real-world photo search.
 */
fun transliterateDevanagariToLatin(input: String): String {
    if (input.none { it in '\u0900'..'\u097F' }) return input
    val consonants = mapOf(
        '\u0915' to "k", '\u0916' to "kh", '\u0917' to "g", '\u0918' to "gh", '\u0919' to "ng",
        '\u091A' to "ch", '\u091B' to "chh", '\u091C' to "j", '\u091D' to "jh", '\u091E' to "ny",
        '\u091F' to "t", '\u0920' to "th", '\u0921' to "d", '\u0922' to "dh", '\u0923' to "n",
        '\u0924' to "t", '\u0925' to "th", '\u0926' to "d", '\u0927' to "dh", '\u0928' to "n",
        '\u092A' to "p", '\u092B' to "ph", '\u092C' to "b", '\u092D' to "bh", '\u092E' to "m",
        '\u092F' to "y", '\u0930' to "r", '\u0932' to "l", '\u0935' to "v", '\u0936' to "sh",
        '\u0937' to "sh", '\u0938' to "s", '\u0939' to "h",
        '\u095C' to "r", '\u095D' to "rh", '\u0958' to "q", '\u0959' to "kh",
        '\u095A' to "gh", '\u095B' to "z", '\u095E' to "f"
    )
    val vowels = mapOf(
        '\u0905' to "a", '\u0906' to "aa", '\u0907' to "i", '\u0908' to "ee", '\u0909' to "u", '\u090A' to "oo",
        '\u090F' to "e", '\u0910' to "ai", '\u0913' to "o", '\u0914' to "au", '\u090B' to "ri"
    )
    val matras = mapOf(
        '\u093E' to "a", '\u093F' to "i", '\u0940' to "i", '\u0941' to "u", '\u0942' to "u",
        '\u0947' to "e", '\u0948' to "ai", '\u094B' to "o", '\u094C' to "au", '\u0943' to "ri",
        '\u0902' to "n", '\u0901' to "n", '\u0903' to "h"
    )
    val virama = '\u094D'
    val nukta = '\u093C'

    val sb = StringBuilder()
    var i = 0
    while (i < input.length) {
        val ch = input[i]
        when {
            ch in consonants -> {
                var base = consonants[ch]!!
                val next = input.getOrNull(i + 1)
                if (next == nukta) {
                    base = when (ch) {
                        '\u091C' -> "z"
                        '\u092B' -> "f"
                        '\u0921' -> "r"
                        '\u0922' -> "rh"
                        '\u0915' -> "q"
                        else -> base
                    }
                    i++
                }
                sb.append(base)
                val after = input.getOrNull(i + 1)
                if (after == virama) {
                    i++ // suppress inherent 'a'
                } else if (after != null && after in matras) {
                    sb.append(matras[after])
                    i++
                } else if (after != null && (after in consonants || after in vowels)) {
                    sb.append('a')
                }
            }
            ch in vowels -> sb.append(vowels[ch])
            ch in matras -> sb.append(matras[ch])
            ch == virama || ch == nukta -> {}
            else -> sb.append(ch)
        }
        i++
    }
    return sb.toString()
}

private fun containsWordBoundary(text: String, phrases: List<String>): Boolean {
    return phrases.any { phrase ->
        if (phrase.any { it.code > 127 } || phrase.contains(' ')) {
            text.contains(phrase)
        } else {
            Regex("(?<![\\p{L}\\p{N}])${Regex.escape(phrase)}(?![\\p{L}\\p{N}])").containsMatchIn(text)
        }
    }
}

fun parseVoiceAiCommand(transcript: String): ParsedVoiceCommand {
    val cleanRaw = transcript.trim()
    val lower = cleanRaw.lowercase()

    // 0. Language style detection for natural friendly voice replies
    val hasDevanagari = cleanRaw.any { it in '\u0900'..'\u097F' }
    val hinglishMarkers = listOf(
        "karo", "kardo", "le chalo", "chalo", "khada", "mein", "peeche", "piche",
        "bada", "chota", "chhota", "banao", "pehle", "pahle", "jaisa", "thoda",
        "halki", "halka", "gehri", "mujhe", "mera", "meri", "aage", "paas",
        "door", "dur", "zameen", "jameen", "saamne", "samne", "wapas", "sahi",
        "pichla", "par", "taraf", "baju", "kinare", "roshni", "gana", "gaana",
        "kholo", "chalu", "roko", "ghumao", "palto", "shuru",
        "lagao", "rakho", "dikhao", "dijiye", "kijiye", "batao", "hatao", "jao", "aao", "lao"
    )
    val languageStyle = when {
        hasDevanagari -> VoiceLanguageStyle.HINDI_DEVANAGARI
        containsWordBoundary(lower, hinglishMarkers) -> VoiceLanguageStyle.HINGLISH
        else -> VoiceLanguageStyle.ENGLISH
    }

    // 1. Undo intent (checked early so "pehle jaisa karo" / "undo" never searches as location)
    val wantsUndo = containsWordBoundary(
        lower,
        listOf(
            "pehle jaisa", "pahle jaisa", "wapas pehle", "wapas karo", "vapas karo",
            "pichla wala", "pichle wala", "purana wala", "undo", "revert", "restore previous",
            "go back", "back to previous", "previous look", "cancel last", "reset position",
            "पहले जैसा", "पहला वाला", "पिछला वाला", "वापस करो", "अनडू"
        )
    )

    // 2. Output Type / Live Camera / Mode Switch Request
    val videoKeywords = listOf(
        "video", "15s", "15 sec", "15 second", "reel", "reels", "shorts", "clip",
        "वीडियो", "विडिओ", "रील", "रिल", "15 सेकंड", "15 सेकेंड", "moving"
    )
    val photoKeywords = listOf(
        "photo", "4k photo", "picture", "pic", "tasveer", "selfie", "image",
        "फोटो", "तस्वीर", "पिक्चर"
    )
    val wantsStopLiveRecord = containsWordBoundary(
        lower,
        listOf(
            "stop recording", "recording roko", "recording band", "stop live recording",
            "stop live video", "video roko", "stop video", "end recording",
            "रिकॉर्डिंग रोको", "रिकॉर्डिंग बंद", "वीडियो रोको"
        )
    )
    val wantsStartLiveRecord = !wantsStopLiveRecord && containsWordBoundary(
        lower,
        listOf(
            "live video banao", "live video record", "record 15s", "15s video record",
            "15 second video record", "15 sec video record", "video record karo",
            "live record karo", "record karo", "recording karo", "recording start",
            "recording shuru", "start recording", "start live recording", "start live video",
            "record live video", "record a video", "record video",
            "लाइव वीडियो बनाओ", "वीडियो रिकॉर्ड करो", "रिकॉर्ड करो", "रिकॉर्डिंग शुरू",
            "15 सेकंड वीडियो रिकॉर्ड"
        )
    )
    val wantsFrontCam = containsWordBoundary(
        lower,
        listOf("front camera", "selfie camera", "aage ka camera", "samne ka camera", "saamne ka camera", "फ्रंट कैमरा")
    )
    val wantsBackCam = containsWordBoundary(
        lower,
        listOf("back camera", "rear camera", "peeche ka camera", "piche ka camera", "बैक कैमरा")
    )
    val wantsFlipCam = !wantsFrontCam && !wantsBackCam && containsWordBoundary(
        lower,
        listOf(
            "flip camera", "switch camera", "camera flip", "camera ghumao",
            "camera palto", "dusra camera", "doosra camera", "कैमरा घुमाओ"
        )
    )
    val wantsExitLiveMode = containsWordBoundary(
        lower,
        listOf(
            "exit video mode", "exit live", "close live camera", "close video mode",
            "live camera band", "video mode band", "photo mode", "photo mode mein",
            "लाइव कैमरा बंद", "फोटो मोड"
        )
    )
    val explicitLiveCam = !wantsExitLiveMode && containsWordBoundary(
        lower,
        listOf(
            "live video mode", "camera video", "live camera", "open live camera",
            "open live video", "open video camera", "video camera", "live camera kholo",
            "live video kholo", "live video chalu", "live camera chalu", "video camera kholo",
            "live mode", "लाइव कैमरा", "लाइव वीडियो मोड", "लाइव वीडियो खोलो"
        )
    )
    val mentionsVideo = containsWordBoundary(lower, videoKeywords)
    val mentionsPhoto = containsWordBoundary(lower, photoKeywords) || wantsExitLiveMode
    val hasExplicitOutputType = mentionsVideo || mentionsPhoto || explicitLiveCam ||
        wantsStartLiveRecord || wantsStopLiveRecord || wantsFlipCam || wantsFrontCam || wantsBackCam

    val outputType = if (mentionsVideo || explicitLiveCam || wantsStartLiveRecord || wantsStopLiveRecord) {
        VoiceOutputType.VIDEO_15S
    } else {
        VoiceOutputType.PHOTO
    }
    val modeRequest = when {
        wantsStopLiveRecord -> VoiceModeRequest.STOP_LIVE_RECORDING
        wantsStartLiveRecord -> VoiceModeRequest.START_LIVE_RECORDING
        wantsFrontCam -> VoiceModeRequest.FRONT_LIVE_CAMERA
        wantsBackCam -> VoiceModeRequest.BACK_LIVE_CAMERA
        wantsFlipCam -> VoiceModeRequest.FLIP_LIVE_CAMERA
        wantsExitLiveMode -> VoiceModeRequest.PHOTO
        explicitLiveCam -> VoiceModeRequest.LIVE_CAMERA_VIDEO
        mentionsVideo -> VoiceModeRequest.VIDEO_15S
        mentionsPhoto -> VoiceModeRequest.PHOTO
        else -> VoiceModeRequest.NONE
    }

    // 3. Music Preference
    val musicKeywords = listOf(
        "music", "song", "songs", "audio", "bgm", "beat", "tune", "melody", "dance",
        "gana", "gaana", "gaane", "gane", "गाना", "गाने", "म्यूजिक", "संगीत", "सॉन्ग"
    )
    val wantsMusic = containsWordBoundary(lower, musicKeywords)

    // 4. Position & Nudge Hints
    val nudgeLeftIntent = containsWordBoundary(
        lower,
        listOf("thoda left", "aur left", "shift left", "move left", "thoda baye", "thoda baaye", "थोड़ा बाएं")
    )
    val nudgeRightIntent = containsWordBoundary(
        lower,
        listOf("thoda right", "aur right", "shift right", "move right", "thoda daye", "thoda daaye", "थोड़ा दाएं")
    )
    val explicitLeft = containsWordBoundary(lower, listOf("left", "बाएं", "बाएँ", "baye", "baayen", "baaye", "bayan", "बायां", "बायाँ", "बायीं"))
    val explicitRight = containsWordBoundary(lower, listOf("right", "दाएं", "दाएँ", "daye", "daayen", "daaye", "dayan", "दायां", "दायाँ", "दायीं"))
    val explicitCenter = containsWordBoundary(lower, listOf("center", "centre", "middle", "बीच में", "बीच पर", "beech mein", "beech me", "bich mein", "bich me", "mid mein", "mid me"))
    val preferSidePlacement = !explicitLeft && !explicitRight && !explicitCenter && containsWordBoundary(
        lower,
        listOf(
            "side mein", "side me", "side pe", "ek side", "side par", "kinare", "kinaare",
            "corner", "kone", "ek taraf", "baju mein", "baju me", "बगल में", "साइड में",
            "एक साइड", "किनारे", "कोने में", "बाजू में", "side"
        )
    )

    val positionHint = when {
        explicitLeft && !nudgeLeftIntent -> VoicePositionHint.LEFT
        explicitRight && !nudgeRightIntent -> VoicePositionHint.RIGHT
        explicitCenter -> VoicePositionHint.CENTER
        else -> VoicePositionHint.AUTO
    }

    val wantsWalkwayOrGroundFix = containsWordBoundary(
        lower,
        listOf(
            "walkway", "ground", "floor", "surface", "zameen", "jameen", "jamin", "farsh",
            "sahi jagah", "sahi jageh", "paani se door", "pani se door", "ज़मीन", "जमीन",
            "सही जगह", "वॉकवे", "फर्श", "रास्ते पर"
        )
    )

    // 5. Scale / Step Back / Step Forward Intent
    val stepBackIntent = !wantsBackCam && containsWordBoundary(
        lower,
        listOf(
            "thoda peeche", "peeche", "peeche jao", "peeche karo", "piche", "step back", "move back", "pull back",
            "thoda door", "thoda dur", "aur door", "aur dur", "door rakho", "dur rakho", "पीछे", "थोड़ा पीछे", "थोड़ा दूर"
        )
    )
    val stepForwardIntent = !wantsFrontCam && containsWordBoundary(
        lower,
        listOf(
            "thoda paas", "aur paas", "paas lao", "paas laao", "paas karo", "paas kardo",
            "paas rakho", "aage lao", "aage laao", "aage karo", "thoda aage", "come closer", "step forward",
            "camera ke paas", "थोड़ा पास", "और पास", "पास लाओ", "पास करो", "आगे लाओ"
        )
    )
    val scaleDownIntent = containsWordBoundary(
        lower,
        listOf(
            "thoda chota", "thoda chhota", "chota", "chhota", "chhoti", "choti", "zoom out",
            "small", "smaller", "tiny", "size kam", "size chota", "छोटा", "छोटी", "थोड़ा छोटा", "ज़ूम आउट"
        )
    )
    val scaleUpIntent = containsWordBoundary(
        lower,
        listOf(
            "thoda bada", "bada", "badi", "zoom in", "large", "big", "bigger", "larger",
            "close", "closeup", "close up", "closer", "size badhao", "size bada", "बड़ा", "बड़ी", "ज़ूम इन"
        )
    )
    val scaleResetIntent = containsWordBoundary(
        lower,
        listOf("normal size", "default size", "auto size", "medium size", "sahi size")
    )

    val positionNudge = when {
        nudgeLeftIntent -> VoicePositionNudge.NUDGE_LEFT
        nudgeRightIntent -> VoicePositionNudge.NUDGE_RIGHT
        stepBackIntent -> VoicePositionNudge.STEP_BACK
        stepForwardIntent -> VoicePositionNudge.STEP_FORWARD
        else -> VoicePositionNudge.NONE
    }

    val scaleDelta = when {
        scaleResetIntent -> VoiceScaleDelta.SCALE_RESET
        scaleDownIntent || stepBackIntent -> VoiceScaleDelta.SCALE_DOWN
        scaleUpIntent || stepForwardIntent -> VoiceScaleDelta.SCALE_UP
        else -> VoiceScaleDelta.NONE
    }

    val sizeHint = when {
        scaleDownIntent || stepBackIntent -> VoiceSizeHint.SMALL
        scaleUpIntent || stepForwardIntent -> VoiceSizeHint.LARGE
        scaleResetIntent || containsWordBoundary(lower, listOf("medium", "normal", "default")) -> VoiceSizeHint.MEDIUM
        else -> VoiceSizeHint.AUTO
    }

    // 6. Shadow & Lighting Hints
    val shadowHint = when {
        containsWordBoundary(
            lower,
            listOf(
                "deep 3d shadow", "deep shadow", "3d shadow", "dark shadow", "strong shadow",
                "heavy shadow", "gehri shadow", "zyada shadow", "shadow badhao", "गहरी शैडो", "3डी शैडो"
            )
        ) -> VoiceShadowHint.DEEP_3D
        containsWordBoundary(
            lower,
            listOf(
                "shadow soft", "soft shadow", "halki shadow", "halka shadow", "kam shadow",
                "light shadow", "shadow kam", "parchhai kam", "शैडो सॉफ्ट", "हल्की शैडो"
            )
        ) -> VoiceShadowHint.SOFT
        containsWordBoundary(lower, listOf("natural shadow", "normal shadow", "auto shadow")) -> VoiceShadowHint.NATURAL
        else -> VoiceShadowHint.NONE
    }

    val lightingHint = when {
        containsWordBoundary(lower, listOf("warm light", "golden light", "sunset light", "garm light", "warm tone")) -> VoiceLightingHint.WARM
        containsWordBoundary(lower, listOf("cool light", "cold light", "blue light", "thandi light", "cool tone")) -> VoiceLightingHint.COOL
        containsWordBoundary(
            lower,
            listOf(
                "light match", "lighting match", "match light", "match lighting", "auto light",
                "relight", "blend match", "color match", "light sahi", "roshni match", "लाइट मैच", "रोशनी मैच"
            )
        ) -> VoiceLightingHint.MATCH_AUTO
        else -> VoiceLightingHint.NONE
    }

    // 7. Scene Mood
    val sceneMood = when {
        containsWordBoundary(lower, listOf("snow", "ice", "winter", "glacier", "बर्फ", "बर्फीले", "barf", "manali", "gulmarg", "swiss")) -> VoiceSceneMood.SNOW
        containsWordBoundary(lower, listOf("night", "neon", "midnight", "evening lights", "रात", "raat", "tokyo", "times square")) -> VoiceSceneMood.NIGHT
        containsWordBoundary(lower, listOf("sunset", "golden", "dusk", "sunrise", "शाम", "shaam")) -> VoiceSceneMood.SUNSET
        containsWordBoundary(lower, listOf("beach", "ocean", "sea", "coast", "island", "समुद्र", "बीच", "goa", "maldives")) -> VoiceSceneMood.BEACH
        containsWordBoundary(lower, listOf("desert", "dunes", "sand", "रेगिस्तान", "thar", "jaisalmer", "dubai desert")) -> VoiceSceneMood.DESERT
        containsWordBoundary(lower, listOf("mountain", "hill", "peak", "valley", "पहाड़", "पहाड़ों", "pahad", "ladakh", "kashmir", "fuji")) -> VoiceSceneMood.MOUNTAIN
        else -> VoiceSceneMood.AUTO
    }

    // 8. Location Extraction (protect Devanagari "बीच में" as CENTER before translating "बीच" -> "beach")
    var working = cleanRaw
        .replace("बीच में", " center ")
        .replace("बीच पर", " center ")
    val sortedDict = hindiToEnglishLocationTerms.entries.sortedByDescending { it.key.length }
    for ((hi, en) in sortedDict) {
        if (working.contains(hi, ignoreCase = true)) {
            working = working.replace(hi, " $en ", ignoreCase = true)
        }
    }

    val rawTokens = working
        .replace(Regex("[,.;:!?\"'()\\[\\]{}]"), " ")
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }

    val keptTokens = mutableListOf<String>()
    for (tok in rawTokens) {
        val tokLower = tok.lowercase()
        if (tokLower in hindiStopWords) continue
        if (tokLower.matches(Regex("\\d+s?"))) continue
        val converted = if (tok.any { it in '\u0900'..'\u097F' }) {
            transliterateDevanagariToLatin(tok)
        } else {
            tok
        }
        val convLower = converted.lowercase().trim()
        if (convLower.isNotBlank() && convLower !in hindiStopWords) {
            keptTokens.add(converted.trim())
        }
    }

    val deduped = mutableListOf<String>()
    for (t in keptTokens) {
        if (deduped.lastOrNull()?.equals(t, ignoreCase = true) != true) {
            deduped.add(t)
        }
    }

    val hasMoodSceneWord = (sceneMood != VoiceSceneMood.AUTO) &&
        lightingHint == VoiceLightingHint.NONE &&
        shadowHint == VoiceShadowHint.NONE
    val hasExplicitLocation = !wantsUndo && (deduped.isNotEmpty() || hasMoodSceneWord)

    val extractedQuery = deduped.joinToString(" ").trim().ifBlank {
        when (sceneMood) {
            VoiceSceneMood.SNOW -> "Manali snow mountains"
            VoiceSceneMood.NIGHT -> "Tokyo night city"
            VoiceSceneMood.SUNSET -> "Santorini sunset"
            VoiceSceneMood.BEACH -> "Maldives tropical beach"
            VoiceSceneMood.DESERT -> "Sam Sand Dunes Jaisalmer"
            VoiceSceneMood.MOUNTAIN -> "Swiss Alps mountains"
            VoiceSceneMood.AUTO -> ""
        }
    }

    val displayName = extractedQuery
        .split(" ")
        .filter { it.isNotBlank() }
        .joinToString(" ") { word ->
            word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }

    val intentAction = when {
        wantsUndo -> VoiceIntentAction.UNDO
        hasExplicitLocation -> VoiceIntentAction.CHANGE_LOCATION
        else -> VoiceIntentAction.ADJUST_CURRENT_SCENE
    }

    return ParsedVoiceCommand(
        rawTranscript = cleanRaw,
        locationQuery = extractedQuery,
        displayLocation = displayName,
        outputType = outputType,
        positionHint = positionHint,
        sizeHint = sizeHint,
        wantsMusic = wantsMusic,
        sceneMood = sceneMood,
        preferSidePlacement = preferSidePlacement,
        wantsWalkwayOrGroundFix = wantsWalkwayOrGroundFix,
        intentAction = intentAction,
        hasExplicitLocation = hasExplicitLocation,
        hasExplicitOutputType = hasExplicitOutputType,
        languageStyle = languageStyle,
        scaleDelta = scaleDelta,
        positionNudge = positionNudge,
        shadowHint = shadowHint,
        lightingHint = lightingHint,
        modeRequest = modeRequest
    )
}

private enum class SceneCellClass {
    WALKABLE_STONE,
    WALKABLE_SAND,
    WALKABLE_GRASS,
    WALKABLE_ROAD,
    WALKABLE_INDOOR,
    WALKABLE_SNOW,
    WATER_OR_REFLECTION,
    SKY_OR_MID_AIR,
    WALL_OR_ROOF,
    CROWD_OR_OBSTACLE
}

private data class VisualSceneAnalysis(
    val xOffsetPx: Float,
    val bestVisXRatio: Float,
    val bestGroundYRatio: Float,
    val horizonYRatio: Float,
    val perspectiveScale: Float,
    val surfaceLabel: String,
    val centerHasWaterOrHazard: Boolean,
    val leftWalkableScore: Float,
    val centerWalkableScore: Float,
    val rightWalkableScore: Float,
    val leftBestYRatio: Float,
    val centerBestYRatio: Float,
    val rightBestYRatio: Float,
    val leftBestXRatio: Float,
    val centerBestXRatio: Float,
    val rightBestXRatio: Float,
    val leftSafeCount: Int,
    val centerSafeCount: Int,
    val rightSafeCount: Int,
    val visColsCount: Int = 1,
    val anySafeGroundInScene: Boolean = true,
    val colHasSafeGround: BooleanArray = booleanArrayOf(true),
    val colBestVisX: FloatArray = floatArrayOf(0.50f),
    val colBestSafeY: FloatArray = floatArrayOf(0.90f),
    val colMinSafeY: FloatArray = floatArrayOf(0.62f),
    val colMaxSafeY: FloatArray = floatArrayOf(0.945f),
    val colBestScore: FloatArray = floatArrayOf(0.5f),
    val colSurfaceLabels: Array<String> = arrayOf("Stone Walkway")
)

data class SafeSolidGroundSnap(
    val xOffsetPx: Float,
    val yOffsetPx: Float,
    val groundYRatio: Float,
    val surfaceLabel: String,
    val perspectiveScale: Float,
    val snappedAwayFromHazard: Boolean,
    val verifiedSolidGround: Boolean
)

private val visualSceneAnalysisCache = WeakHashMap<Bitmap, MutableMap<String, VisualSceneAnalysis>>()

/**
 * Universal 2D Visual Scene & Ground-Plane Analyzer:
 * Builds a spatial full-width surface/hazard map of ANY global background photo and strictly forbids
 * placing feet on water, swimming pools, reflecting pools, fountains, rivers, lakes, ocean waves/foam,
 * wet mirror reflections, or mid-air sky/rooftop drop-offs. Snaps feet strictly onto verified
 * solid walkable ground (stone walkways, marble platforms, sidewalks, dry beach sand, grass, paved roads)
 * with realistic perspective scale identically across Photo Mode and 15s Video Mode.
 */
private fun analyzeVisualSceneForTouristPlacement(
    bgBitmap: Bitmap?,
    locationName: String?,
    previewWidth: Float,
    previewHeight: Float = 0f,
    preferSidePlacement: Boolean = false,
    isVideoViewport: Boolean = false
): VisualSceneAnalysis {
    val pW = previewWidth.coerceAtLeast(360f)
    val sideShift = (pW * 0.21f).coerceAtLeast(88f)
    val defaultAnalysis = VisualSceneAnalysis(
        xOffsetPx = 0f,
        bestVisXRatio = 0.50f,
        bestGroundYRatio = 0.90f,
        horizonYRatio = 0.52f,
        perspectiveScale = 0.68f,
        surfaceLabel = "Center Ground",
        centerHasWaterOrHazard = false,
        leftWalkableScore = 0.5f,
        centerWalkableScore = 0.5f,
        rightWalkableScore = 0.5f,
        leftBestYRatio = 0.90f,
        centerBestYRatio = 0.90f,
        rightBestYRatio = 0.90f,
        leftBestXRatio = 0.24f,
        centerBestXRatio = 0.50f,
        rightBestXRatio = 0.76f,
        leftSafeCount = 1,
        centerSafeCount = 1,
        rightSafeCount = 1
    )
    if (bgBitmap == null || bgBitmap.isRecycled || bgBitmap.width < 32 || bgBitmap.height < 32) {
        return defaultAnalysis
    }

    val containerAspect = when {
        isVideoViewport -> 9f / 16f
        previewHeight > 120f -> (pW / previewHeight).coerceIn(0.45f, 1.35f)
        else -> 0.84f
    }
    val aspectBucket = (containerAspect * 20f).roundToInt()
    val cacheKey = "${locationName.orEmpty().trim().lowercase()}|$aspectBucket|$preferSidePlacement|$isVideoViewport"
    synchronized(visualSceneAnalysisCache) {
        visualSceneAnalysisCache[bgBitmap]?.get(cacheKey)?.let { cached ->
            val scaledX = (cached.bestVisXRatio - 0.50f) * pW
            return cached.copy(xOffsetPx = scaledX)
        }
    }

    var proxy: Bitmap? = null
    return try {
        val gridW = 128
        val gridH = 96
        proxy = Bitmap.createScaledBitmap(bgBitmap, gridW, gridH, true)
        val pixels = IntArray(gridW * gridH)
        proxy.getPixels(pixels, 0, gridW, 0, 0, gridW, gridH)

        // Match preview container's ContentScale.Crop visible viewport (including 1.07x video overscan)
        val bgAspect = bgBitmap.width.toFloat() / bgBitmap.height.toFloat().coerceAtLeast(1f)
        val overscan = if (isVideoViewport) 1f / 1.07f else 1f
        val visMinX: Float
        val visMaxX: Float
        val visMinY: Float
        val visMaxY: Float
        if (bgAspect > containerAspect) {
            val visFracW = ((containerAspect / bgAspect) * overscan).coerceIn(0.32f, 1.0f)
            visMinX = (0.5f - visFracW * 0.5f).coerceIn(0f, 0.34f)
            visMaxX = (0.5f + visFracW * 0.5f).coerceIn(0.66f, 1.0f)
            val yTrim = (1f - overscan) * 0.5f
            visMinY = yTrim
            visMaxY = 1f - yTrim
        } else {
            val visFracH = ((bgAspect / containerAspect) * overscan).coerceIn(0.40f, 1.0f)
            val xTrim = (1f - overscan) * 0.5f
            visMinX = xTrim
            visMaxX = 1f - xTrim
            visMinY = (0.5f - visFracH * 0.5f).coerceIn(0f, 0.30f)
            visMaxY = (0.5f + visFracH * 0.5f).coerceIn(0.70f, 1.0f)
        }

        val xStart = (visMinX * (gridW - 1)).roundToInt().coerceIn(1, gridW - 4)
        val xEnd = (visMaxX * (gridW - 1)).roundToInt().coerceIn(xStart + 6, gridW - 2)
        val yStart = (visMinY * (gridH - 1)).roundToInt().coerceIn(1, gridH - 4)
        val yEnd = (visMaxY * (gridH - 1)).roundToInt().coerceIn(yStart + 6, gridH - 2)
        val visSpanX = (xEnd - xStart).coerceAtLeast(1).toFloat()
        val visSpanY = (yEnd - yStart).coerceAtLeast(1).toFloat()

        fun rgb(x: Int, y: Int): Int = pixels[y.coerceIn(0, gridH - 1) * gridW + x.coerceIn(0, gridW - 1)]

        // Step 1: Row-wise sky, vertical architectural walls, horizontal floor edges, & mirror-symmetry axes
        val rowLum = FloatArray(gridH)
        val rowSkyFrac = FloatArray(gridH)
        val rowWallVert = FloatArray(gridH)
        val rowHorizFloor = FloatArray(gridH)
        val rowBoundaryScore = FloatArray(gridH)

        for (y in yStart..yEnd) {
            var sumL = 0f
            var skyCount = 0
            var vertDom = 0f
            var horizDom = 0f
            var colsCount = 0
            for (x in xStart..xEnd) {
                val c = rgb(x, y)
                val r = (c ushr 16) and 0xFF
                val g = (c ushr 8) and 0xFF
                val b = c and 0xFF
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                val maxCh = max(r, max(g, b))
                val minCh = min(r, min(g, b))
                val sat = if (maxCh > 0) (maxCh - minCh).toFloat() / maxCh else 0f

                val cRight = rgb(x + 1, y)
                val cDown = rgb(x, y + 1)
                val dx = (abs(r - ((cRight ushr 16) and 0xFF)) +
                    abs(g - ((cRight ushr 8) and 0xFF)) +
                    abs(b - (cRight and 0xFF))) / 3f
                val dy = (abs(r - ((cDown ushr 16) and 0xFF)) +
                    abs(g - ((cDown ushr 8) and 0xFF)) +
                    abs(b - (cDown and 0xFF))) / 3f

                sumL += l
                if ((b >= r - 8 && l > 134f && dx < 12f && dy < 12f) || (l > 188f && sat < 0.14f && dx < 9f)) {
                    skyCount++
                }
                if (dx > dy * 1.45f && dx > 9f) vertDom += 1f
                if (dy >= dx * 0.9f && dx in 1.5f..18f) horizDom += 1f
                colsCount++
            }
            val denom = colsCount.coerceAtLeast(1).toFloat()
            rowLum[y] = sumL / denom
            rowSkyFrac[y] = skyCount / denom
            rowWallVert[y] = vertDom / denom
            rowHorizFloor[y] = horizDom / denom
        }

        var skyEndRow = yStart + (visSpanY * 0.28f).roundToInt()
        for (y in yStart..(yStart + (visSpanY * 0.58f).roundToInt()).coerceAtMost(yEnd)) {
            if (rowSkyFrac[y] >= 0.46f) {
                skyEndRow = y
            }
        }
        val hMinRow = max(skyEndRow, yStart + (visSpanY * 0.25f).roundToInt()).coerceIn(yStart + 2, yEnd - 8)
        val hMaxRow = (yStart + (visSpanY * 0.72f).roundToInt()).coerceIn(hMinRow + 2, yEnd - 4)
        var bestHorizonRow = (yStart + (visSpanY * 0.50f).roundToInt()).coerceIn(hMinRow, hMaxRow)
        var bestBoundaryScore = -1f
        for (y in hMinRow..hMaxRow) {
            val lumJump = abs(rowLum[y + 1] - rowLum[y - 2]) / 255f
            val wallDrop = (rowWallVert[(y - 2).coerceAtLeast(yStart)] - rowWallVert[(y + 2).coerceAtMost(yEnd)]).coerceAtLeast(0f)
            val floorGain = (rowHorizFloor[(y + 3).coerceAtMost(yEnd)] - rowHorizFloor[(y - 2).coerceAtLeast(yStart)]).coerceAtLeast(0f)
            val score = lumJump * 1.1f + wallDrop * 1.3f + floorGain * 1.25f
            rowBoundaryScore[y] = score
            if (score > bestBoundaryScore) {
                bestBoundaryScore = score
                bestHorizonRow = y
            }
        }
        val groundPlane = detectBackgroundGroundPlane(bgBitmap, locationName.orEmpty())
        val computedHorizonVisY = ((bestHorizonRow - yStart) / visSpanY).coerceIn(0.25f, 0.72f)
        val horizonYRatio = (computedHorizonVisY * 0.65f + groundPlane.horizonYRatio * 0.35f).coerceIn(0.26f, 0.72f)
        val horizonRowInGrid = (yStart + horizonYRatio * visSpanY).roundToInt().coerceIn(yStart + 2, yEnd - 4)

        // Collect up to 3 candidate reflection/shoreline symmetry rows so tilted or tall-monument pools
        // (e.g. Taj Mahal, Jal Mahal, mountain lakes) match their true waterline reflection axis.
        val symAxes = mutableListOf(horizonRowInGrid, bestHorizonRow)
        var secAxis = -1
        var secScore = -1f
        for (y in (yStart + (visSpanY * 0.36f).roundToInt())..(yStart + (visSpanY * 0.76f).roundToInt()).coerceAtMost(yEnd - 4)) {
            if (abs(y - bestHorizonRow) >= 5 && rowBoundaryScore[y] > secScore) {
                secScore = rowBoundaryScore[y]
                secAxis = y
            }
        }
        if (secAxis > 0) symAxes.add(secAxis)
        val distinctSymAxes = symAxes.distinct()
        val mirrorScaleFactors = floatArrayOf(1.0f, 0.85f, 0.72f)

        // Step 2: Classify every cell across visible viewport into Walkable Material vs Water/Reflections/Mid-Air/Walls
        val qLower = locationName.orEmpty().lowercase()
        val isReflectionPoolMonument = listOf(
            "taj mahal", "tajmahal", "jal mahal", "reflection", "reflecting pool",
            "fountain", "lotus pond", "india gate", "trevi", "versailles", "lincoln memorial"
        ).any { qLower.contains(it) }
        val isWaterKeyword = isReflectionPoolMonument || listOf(
            "lake", "pool", "water", "river", "riverfront", "beach", "ocean", "sea", "coast", "shore",
            "ghat", "venice", "waterfall", "dam", "canal", "backwater", "maldives", "lagoon", "harbor", "pier", "bay"
        ).any { qLower.contains(it) }
        val isSnowKeyword = listOf(
            "snow", "glacier", "ice", "winter", "alps", "manali", "gulmarg", "kedarnath", "everest", "arctic", "swiss"
        ).any { qLower.contains(it) }
        val isIndoorHint = listOf(
            "mall", "indoor", "museum", "hotel", "lobby", "cafe", "airport", "metro", "interior", "hall", "palace"
        ).any { qLower.contains(it) }

        val cellClass = Array(gridH) { Array(gridW) { SceneCellClass.SKY_OR_MID_AIR } }
        val cellWalkScore = Array(gridH) { FloatArray(gridW) }
        val cellSmoothness = Array(gridH) { FloatArray(gridW) }
        val isWarmSandCell = Array(gridH) { BooleanArray(gridW) }
        val upperSkyOrDistantCount = intArrayOf(0, 0)
        var lowerWaterCellCount = 0
        var lowerTotalCount = 0
        var lowerWarmSandCount = 0

        for (y in yStart..yEnd) {
            val visY = (y - yStart) / visSpanY
            for (x in xStart..xEnd) {
                val c = rgb(x, y)
                val r = (c ushr 16) and 0xFF
                val g = (c ushr 8) and 0xFF
                val b = c and 0xFF
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                val maxCh = max(r, max(g, b))
                val minCh = min(r, min(g, b))
                val sat = if (maxCh > 0) (maxCh - minCh).toFloat() / maxCh else 0f

                if (visY < 0.54f) {
                    upperSkyOrDistantCount[1]++
                    if (l > 142f && b >= r - 10) upperSkyOrDistantCount[0]++
                }

                if (visY < horizonYRatio - 0.02f) {
                    cellClass[y][x] = SceneCellClass.SKY_OR_MID_AIR
                    cellWalkScore[y][x] = -5.0f
                    continue
                }
                lowerTotalCount++

                val isWarmSandColor = r > 136 && g > 96 && b < 138 && r > b + 14 && l > 82f
                val isWarmMarbleOrStone = r > b + 6 && l in 120f..236f && sat < 0.24f
                if (isWarmSandColor) {
                    isWarmSandCell[y][x] = true
                    lowerWarmSandCount++
                }

                val cL = rgb(x - 1, y); val cR = rgb(x + 1, y)
                val cU = rgb(x, y - 1); val cD = rgb(x, y + 1)
                val cUL = rgb(x - 1, y - 1); val cDR = rgb(x + 1, y + 1)

                val dx = (abs(((cR ushr 16) and 0xFF) - ((cL ushr 16) and 0xFF)) +
                    abs(((cR ushr 8) and 0xFF) - ((cL ushr 8) and 0xFF)) +
                    abs((cR and 0xFF) - (cL and 0xFF))) / 3f
                val dy = (abs(((cD ushr 16) and 0xFF) - ((cU ushr 16) and 0xFF)) +
                    abs(((cD ushr 8) and 0xFF) - ((cU ushr 8) and 0xFF)) +
                    abs((cD and 0xFF) - (cU and 0xFF))) / 3f
                val dDiag = (abs(((cDR ushr 16) and 0xFF) - ((cUL ushr 16) and 0xFF)) +
                    abs(((cDR ushr 8) and 0xFF) - ((cUL ushr 8) and 0xFF)) +
                    abs((cDR and 0xFF) - (cUL and 0xFF))) / 3f
                val patchVar = (dx + dy + dDiag) / 3f
                cellSmoothness[y][x] = patchVar

                // Multi-axis & multi-foreshortening vertical mirror symmetry check for lakes, reflection pools, & rivers
                var minMirrorDiff = 999f
                for (axis in distinctSymAxes) {
                    if (y <= axis + 1) continue
                    val distBelow = y - axis
                    for (mScale in mirrorScaleFactors) {
                        val mirrorY = (axis - (distBelow / mScale).roundToInt()).coerceIn(yStart, axis)
                        val mc = rgb(x, mirrorY)
                        val mDiff = (abs(r - ((mc ushr 16) and 0xFF)) +
                            abs(g - ((mc ushr 8) and 0xFF)) +
                            abs(b - (mc and 0xFF))) / 3f
                        if (mDiff < minMirrorDiff) minMirrorDiff = mDiff
                    }
                }
                val isMirrorSymmetrical = minMirrorDiff < 27f && l > 52f && dx < 14f &&
                    (dy >= dx * 0.90f || patchVar < 8.0f)

                // Blue, cyan, teal, turquoise & deep dark water (protecting green grass where g > b * 1.12f and warm dry stone/sand)
                val isBlueOrCyanWater = (b > r + 7 && b >= g - 5 && sat > 0.08f) ||
                    (b > r + 4 && b >= g && l < 110f && patchVar < 16f)
                val isTealWater = g > r + 7 && b > r + 4 && b >= g * 0.76f && sat > 0.10f && patchVar < 19f
                val isSmoothSpecularPool = !isSnowKeyword && !isWarmSandColor && !isWarmMarbleOrStone &&
                    l > 165f && sat < 0.18f && b >= r - 2 && patchVar < 5.0f && dy >= dx * 1.05f
                val isWaveStreak = !isWarmSandColor && dx < 9.5f && dy > dx * 1.6f + 6.5f &&
                    (b >= r - 2 || sat < 0.18f) && l > 72f

                // Mid-air sky / abyss / cliff / rooftop edge drops in lower half
                val isAirOrMistAbyss = !isSnowKeyword && !isWarmSandColor && (
                    (b >= r - 4 && l > 142f && patchVar < 5.8f) ||
                        (l > 206f && sat < 0.11f && patchVar < 4.0f) ||
                        l < 11f
                    )
                val isVerticalWallOrRoof = (visY < 0.79f && dx > dy * 1.65f && dx > 12f) ||
                    (visY < 0.72f && dDiag > 16f && dy > 14f)
                val isDenseCrowdOrBush = patchVar > 25f && sat > 0.24f && visY in 0.56f..0.90f

                when {
                    isBlueOrCyanWater || isTealWater || isMirrorSymmetrical || isSmoothSpecularPool || isWaveStreak -> {
                        cellClass[y][x] = SceneCellClass.WATER_OR_REFLECTION
                        cellWalkScore[y][x] = -5.0f
                        lowerWaterCellCount++
                    }
                    isAirOrMistAbyss -> {
                        cellClass[y][x] = SceneCellClass.SKY_OR_MID_AIR
                        cellWalkScore[y][x] = -4.5f
                    }
                    isVerticalWallOrRoof -> {
                        cellClass[y][x] = SceneCellClass.WALL_OR_ROOF
                        cellWalkScore[y][x] = -3.0f
                    }
                    isDenseCrowdOrBush -> {
                        cellClass[y][x] = SceneCellClass.CROWD_OR_OBSTACLE
                        cellWalkScore[y][x] = -1.2f
                    }
                    else -> {
                        val isSnow = r > 176 && g > 180 && b > 186 && l > 138f
                        val isGrass = !isSnow && g > r * 1.04f && g > b * 1.10f
                        val isSand = !isSnow && !isGrass && r > 136 && g > 96 && b < 138 && r > b + 14 && l > 82f
                        val isRoad = !isSnow && !isGrass && !isSand && sat < 0.14f && l in 34f..140f
                        val mat = when {
                            isIndoorHint && !isGrass -> SceneCellClass.WALKABLE_INDOOR
                            isSnow -> SceneCellClass.WALKABLE_SNOW
                            isGrass -> SceneCellClass.WALKABLE_GRASS
                            isSand -> SceneCellClass.WALKABLE_SAND
                            isRoad -> SceneCellClass.WALKABLE_ROAD
                            else -> SceneCellClass.WALKABLE_STONE
                        }
                        cellClass[y][x] = mat
                        val textureBonus = if (patchVar in 2.2f..19f) 1.32f else 0.94f
                        cellWalkScore[y][x] = textureBonus
                    }
                }
            }
        }

        // Prevent ocean surf foam & waterfall spray from pretending to be walkable snow in water/beach/river scenes
        val sceneWaterRatio = if (lowerTotalCount > 0) lowerWaterCellCount.toFloat() / lowerTotalCount.toFloat() else 0f
        val hasWarmSandInLower = lowerWarmSandCount > (lowerTotalCount * 0.04f)
        val allowSnowSurface = isSnowKeyword || (!isWaterKeyword && sceneWaterRatio < 0.08f && !hasWarmSandInLower)
        if (!allowSnowSurface) {
            for (y in yStart..yEnd) {
                for (x in xStart..xEnd) {
                    if (cellClass[y][x] == SceneCellClass.WALKABLE_SNOW) {
                        cellClass[y][x] = SceneCellClass.WALKABLE_STONE
                    }
                }
            }
        }

        // Step 2B: 4-iteration iterative surf foam / waterfall mist / wet reflection margin flood expansion + hole fill
        // Ensures breaking ocean waves, waterfall spray, and wet pool borders are NEVER treated as solid stone/snow.
        for (pass in 0 until 4) {
            val nextWater = Array(gridH) { BooleanArray(gridW) }
            for (y in yStart..yEnd) {
                for (x in xStart..xEnd) {
                    if (cellClass[y][x] == SceneCellClass.WATER_OR_REFLECTION) continue
                    if (isWarmSandCell[y][x]) continue
                    val c = rgb(x, y)
                    val r = (c ushr 16) and 0xFF
                    val g = (c ushr 8) and 0xFF
                    val b = c and 0xFF
                    val l = 0.299f * r + 0.587f * g + 0.114f * b
                    val maxCh = max(r, max(g, b))
                    val minCh = min(r, min(g, b))
                    val sat = if (maxCh > 0) (maxCh - minCh).toFloat() / maxCh else 0f
                    val isSurfFoamOrSpray = (l > 164f && b >= r - 3 && sat < 0.22f && cellSmoothness[y][x] < 18f) ||
                        (cellSmoothness[y][x] < 8.0f && b >= r - 2 && l > 110f)
                    if (isSurfFoamOrSpray) {
                        var nearWater = false
                        val radY = if (pass == 0) 2 else 1
                        val radX = if (pass == 0) 3 else 1
                        for (ny in (y - radY).coerceAtLeast(yStart)..(y + radY).coerceAtMost(yEnd)) {
                            for (nx in (x - radX).coerceAtLeast(xStart)..(x + radX).coerceAtMost(xEnd)) {
                                if (cellClass[ny][nx] == SceneCellClass.WATER_OR_REFLECTION) {
                                    nearWater = true
                                    break
                                }
                            }
                            if (nearWater) break
                        }
                        if (nearWater) nextWater[y][x] = true
                    }
                }
            }
            var changed = false
            for (y in yStart..yEnd) {
                for (x in xStart..xEnd) {
                    if (nextWater[y][x]) {
                        cellClass[y][x] = SceneCellClass.WATER_OR_REFLECTION
                        cellWalkScore[y][x] = -5.0f
                        changed = true
                    }
                }
            }
            if (!changed) break
        }

        // Fill enclosed water pockets surrounded by >= 5 water neighbors (prevents tiny wave highlights inside surf)
        val fillPockets = Array(gridH) { BooleanArray(gridW) }
        for (y in (yStart + 1)..(yEnd - 1)) {
            for (x in (xStart + 1)..(xEnd - 1)) {
                if (cellClass[y][x] == SceneCellClass.WATER_OR_REFLECTION || isWarmSandCell[y][x]) continue
                var wCount = 0
                for (ny in (y - 1)..(y + 1)) {
                    for (nx in (x - 1)..(x + 1)) {
                        if (nx == x && ny == y) continue
                        if (cellClass[ny][nx] == SceneCellClass.WATER_OR_REFLECTION) wCount++
                    }
                }
                if (wCount >= 5) fillPockets[y][x] = true
            }
        }
        for (y in yStart..yEnd) {
            for (x in xStart..xEnd) {
                if (fillPockets[y][x]) {
                    cellClass[y][x] = SceneCellClass.WATER_OR_REFLECTION
                    cellWalkScore[y][x] = -5.0f
                }
            }
        }

        // Step 3: Full-Width (step 1) Column-by-Column Safe Solid Ground Verification
        data class CandidateSpot(
            val visX: Float,
            val visY: Float,
            val score: Float,
            val hazardPenaltySum: Int,
            val lane: Int, // 0=Left, 1=Center, 2=Right
            val mat: SceneCellClass
        )

        val minGroundVisY = max(horizonYRatio + 0.08f, 0.58f).coerceIn(0.56f, 0.84f)
        val maxGroundVisY = 0.945f
        val stanceHalfW = (visSpanX * 0.055f).roundToInt().coerceAtLeast(2)
        val stanceHalfH = (visSpanY * 0.024f).roundToInt().coerceAtLeast(1)

        val yGridMin = (yStart + minGroundVisY * visSpanY).roundToInt().coerceIn(yStart + 2, yEnd - 2)
        val yGridMax = (yStart + maxGroundVisY * visSpanY).roundToInt().coerceIn(yGridMin, yEnd - 1)
        val xGridMin = (xStart + 0.08f * visSpanX).roundToInt().coerceIn(xStart + 1, xEnd - 3)
        val xGridMax = (xStart + 0.92f * visSpanX).roundToInt().coerceIn(xGridMin + 2, xEnd - 1)
        val visColsCount = (xGridMax - xGridMin + 1).coerceAtLeast(1)

        val colHasSafeGround = BooleanArray(visColsCount)
        val colBestVisX = FloatArray(visColsCount) { idx ->
            ((xGridMin + idx - xStart) / visSpanX).coerceIn(0.08f, 0.92f)
        }
        val colBestSafeY = FloatArray(visColsCount) { 0.90f }
        val colMinSafeY = FloatArray(visColsCount) { 0.95f }
        val colMaxSafeY = FloatArray(visColsCount) { 0.62f }
        val colBestScore = FloatArray(visColsCount) { -999f }
        val colSurfaceLabels = Array(visColsCount) { "Stone Walkway" }

        val colFallbackHaz = IntArray(visColsCount) { Int.MAX_VALUE }
        val colFallbackScore = FloatArray(visColsCount) { -999f }
        val colFallbackY = FloatArray(visColsCount) { 0.90f }
        val colFallbackLabel = Array(visColsCount) { "Stone Walkway" }

        val laneBestSafeScore = floatArrayOf(-999f, -999f, -999f)
        val laneBestSafeY = floatArrayOf(0.90f, 0.90f, 0.90f)
        val laneBestSafeX = floatArrayOf(0.24f, 0.50f, 0.76f)
        val laneSafeCount = intArrayOf(0, 0, 0)

        val laneBestAnyScore = floatArrayOf(-999f, -999f, -999f)
        val laneBestAnyY = floatArrayOf(0.90f, 0.90f, 0.90f)
        val laneBestAnyX = floatArrayOf(0.24f, 0.50f, 0.76f)

        val laneHazardHits = intArrayOf(0, 0, 0)
        val laneSampleTotal = intArrayOf(0, 0, 0)
        var bestSafeOverall: CandidateSpot? = null
        var bestFallbackOverall: CandidateSpot? = null

        fun isHazardClass(cls: SceneCellClass): Boolean {
            return cls == SceneCellClass.WATER_OR_REFLECTION ||
                cls == SceneCellClass.SKY_OR_MID_AIR ||
                cls == SceneCellClass.WALL_OR_ROOF
        }

        fun matToSurfaceLabel(mat: SceneCellClass): String = when (mat) {
            SceneCellClass.WALKABLE_SAND -> "Sandy Ground"
            SceneCellClass.WALKABLE_GRASS -> "Park Lawn"
            SceneCellClass.WALKABLE_ROAD -> "Street Pavement"
            SceneCellClass.WALKABLE_INDOOR -> "Indoor Floor"
            SceneCellClass.WALKABLE_SNOW -> "Snow Trail"
            else -> "Stone Walkway"
        }

        for (cy in yGridMin..yGridMax) {
            val visY = (cy - yStart) / visSpanY
            for (cx in xGridMin..xGridMax) {
                val colIdx = cx - xGridMin
                val visX = (cx - xStart) / visSpanX
                val lane = when {
                    visX < 0.38f -> 0
                    visX <= 0.62f -> 1
                    else -> 2
                }
                laneSampleTotal[lane]++
                val centerCls = cellClass[cy][cx]
                if (isHazardClass(centerCls)) {
                    laneHazardHits[lane]++
                }

                // Check full shoe stance box
                var patchScore = 0f
                var hazardCells = 0
                var crowdCells = 0
                var totalCells = 0
                for (sy in (cy - stanceHalfH).coerceAtLeast(yStart)..(cy + stanceHalfH + 1).coerceAtMost(yEnd)) {
                    for (sx in (cx - stanceHalfW).coerceAtLeast(xStart)..(cx + stanceHalfW).coerceAtMost(xEnd)) {
                        val sc = cellClass[sy][sx]
                        patchScore += cellWalkScore[sy][sx]
                        if (isHazardClass(sc)) {
                            hazardCells++
                        } else if (sc == SceneCellClass.CROWD_OR_OBSTACLE) {
                            crowdCells++
                        }
                        totalCells++
                    }
                }

                // Safety buffer margin + vertical drop-off check below soles (forbids cliff/rooftop/pool/waterfall edges)
                var marginHazards = 0
                val mLeft = (cx - stanceHalfW - 2).coerceAtLeast(xStart)
                val mRight = (cx + stanceHalfW + 2).coerceAtMost(xEnd)
                val mTop = (cy - stanceHalfH - 1).coerceAtLeast(yStart)
                val mBot = (cy + stanceHalfH + 4).coerceAtMost(yEnd)
                for (sy in mTop..mBot) {
                    if (isHazardClass(cellClass[sy][mLeft])) marginHazards++
                    if (isHazardClass(cellClass[sy][mRight])) marginHazards++
                }
                for (dyOff in 2..4) {
                    val dropY = (cy + stanceHalfH + dyOff).coerceAtMost(yEnd)
                    for (sx in mLeft..mRight step 2) {
                        if (isHazardClass(cellClass[dropY][sx])) marginHazards++
                    }
                }

                val avgWalk = if (totalCells > 0) patchScore / totalCells else -2f
                val crowdFrac = if (totalCells > 0) crowdCells.toFloat() / totalCells else 0f

                var upperCrowd = 0
                var upperChecked = 0
                for (uy in (cy - (visSpanY * 0.22f).roundToInt()).coerceAtLeast(yStart)..(cy - stanceHalfH - 1).coerceAtLeast(yStart) step 2) {
                    if (cellClass[uy][cx] == SceneCellClass.CROWD_OR_OBSTACLE) upperCrowd++
                    upperChecked++
                }
                val upperCrowdFrac = if (upperChecked > 0) upperCrowd.toFloat() / upperChecked else 0f

                val isZeroHazard = hazardCells == 0 && marginHazards == 0 && !isHazardClass(centerCls)
                val hazardPenalty = -(hazardCells * 12.0f + marginHazards * 3.0f)
                val crowdPenalty = -(crowdFrac * 1.8f + upperCrowdFrac * 0.9f)
                val fgBonus = if (visY >= 0.75f) ((visY - 0.75f) / 0.195f) * 0.45f else -0.45f
                val depthNaturalBonus = (1f - abs(visY - 0.89f) * 2.3f).coerceIn(-0.45f, 0.50f) + fgBonus
                val edgeFramingPenalty = if (visX < 0.14f || visX > 0.86f) -0.35f else 0f

                val sideCompositionBonus = when {
                    preferSidePlacement && lane != 1 -> 0.95f
                    preferSidePlacement && lane == 1 -> -0.65f
                    (isReflectionPoolMonument || isWaterKeyword) && lane != 1 && isZeroHazard -> 0.55f
                    lane == 1 && isZeroHazard -> 0.28f
                    else -> 0.08f
                }
                val totalScore = avgWalk + hazardPenalty + crowdPenalty + depthNaturalBonus + sideCompositionBonus + edgeFramingPenalty
                val hazardRank = hazardCells * 20 + marginHazards * 4

                if (isZeroHazard) {
                    colHasSafeGround[colIdx] = true
                    if (visY < colMinSafeY[colIdx]) colMinSafeY[colIdx] = visY
                    if (visY > colMaxSafeY[colIdx]) colMaxSafeY[colIdx] = visY
                    if (totalScore > colBestScore[colIdx]) {
                        colBestScore[colIdx] = totalScore
                        colBestSafeY[colIdx] = visY
                        colSurfaceLabels[colIdx] = matToSurfaceLabel(centerCls)
                    }

                    laneSafeCount[lane]++
                    if (totalScore > laneBestSafeScore[lane]) {
                        laneBestSafeScore[lane] = totalScore
                        laneBestSafeY[lane] = visY
                        laneBestSafeX[lane] = visX
                    }
                    val spot = CandidateSpot(visX, visY, totalScore, 0, lane, centerCls)
                    if (bestSafeOverall == null || spot.score > bestSafeOverall.score) {
                        bestSafeOverall = spot
                    }
                } else if (!colHasSafeGround[colIdx]) {
                    if (hazardRank < colFallbackHaz[colIdx] ||
                        (hazardRank == colFallbackHaz[colIdx] && totalScore > colFallbackScore[colIdx])
                    ) {
                        colFallbackHaz[colIdx] = hazardRank
                        colFallbackScore[colIdx] = totalScore
                        colFallbackY[colIdx] = visY
                        colFallbackLabel[colIdx] = matToSurfaceLabel(centerCls)
                    }
                }

                if (totalScore > laneBestAnyScore[lane]) {
                    laneBestAnyScore[lane] = totalScore
                    laneBestAnyY[lane] = visY
                    laneBestAnyX[lane] = visX
                }
                val fbSpot = CandidateSpot(visX, visY, totalScore, hazardRank, lane, centerCls)
                if (bestFallbackOverall == null ||
                    fbSpot.hazardPenaltySum < bestFallbackOverall.hazardPenaltySum ||
                    (fbSpot.hazardPenaltySum == bestFallbackOverall.hazardPenaltySum && fbSpot.score > bestFallbackOverall.score)
                ) {
                    bestFallbackOverall = fbSpot
                }
            }
        }

        val anySafeGroundInScene = colHasSafeGround.any { it }
        for (i in 0 until visColsCount) {
            if (!colHasSafeGround[i]) {
                colBestSafeY[i] = colFallbackY[i]
                colMinSafeY[i] = minGroundVisY
                colMaxSafeY[i] = maxGroundVisY
                colBestScore[i] = colFallbackScore[i]
                colSurfaceLabels[i] = colFallbackLabel[i]
            } else {
                if (colMinSafeY[i] > colMaxSafeY[i]) {
                    colMinSafeY[i] = colBestSafeY[i]
                    colMaxSafeY[i] = colBestSafeY[i]
                }
            }
        }

        val centerHazardRatio = if (laneSampleTotal[1] > 0) {
            laneHazardHits[1].toFloat() / laneSampleTotal[1].toFloat()
        } else 0f
        val centerBlocked = laneSafeCount[1] == 0 ||
            (isReflectionPoolMonument && (centerHazardRatio > 0.04f || isWaterKeyword)) ||
            centerHazardRatio > 0.10f

        val finalLaneBestScore = FloatArray(3) { i ->
            if (laneSafeCount[i] > 0) laneBestSafeScore[i] else laneBestAnyScore[i]
        }
        val finalLaneBestY = FloatArray(3) { i ->
            if (laneSafeCount[i] > 0) laneBestSafeY[i] else laneBestAnyY[i]
        }
        val finalLaneBestX = FloatArray(3) { i ->
            if (laneSafeCount[i] > 0) laneBestSafeX[i] else laneBestAnyX[i]
        }

        val chosenSpot = bestSafeOverall ?: bestFallbackOverall ?: CandidateSpot(
            0.50f, 0.90f, 0.5f, 0, 1, SceneCellClass.WALKABLE_STONE
        )

        val bestVisX = when {
            preferSidePlacement -> {
                val pickLeft = when {
                    laneSafeCount[0] > 0 && laneSafeCount[2] == 0 -> true
                    laneSafeCount[2] > 0 && laneSafeCount[0] == 0 -> false
                    else -> finalLaneBestScore[0] >= finalLaneBestScore[2]
                }
                if (pickLeft) finalLaneBestX[0] else finalLaneBestX[2]
            }
            centerBlocked -> {
                val pickLeft = when {
                    laneSafeCount[0] > 0 && laneSafeCount[2] == 0 -> true
                    laneSafeCount[2] > 0 && laneSafeCount[0] == 0 -> false
                    else -> finalLaneBestScore[0] >= finalLaneBestScore[2]
                }
                if (pickLeft) finalLaneBestX[0] else finalLaneBestX[2]
            }
            else -> chosenSpot.visX
        }.coerceIn(0.12f, 0.88f)

        val xOffsetPx = when {
            bestVisX < 0.39f -> -((0.50f - bestVisX) * pW).coerceIn(sideShift * 0.72f, pW * 0.36f)
            bestVisX > 0.61f -> +((bestVisX - 0.50f) * pW).coerceIn(sideShift * 0.72f, pW * 0.36f)
            else -> ((bestVisX - 0.50f) * pW * 0.70f)
        }

        val chosenLane = when {
            bestVisX < 0.38f -> 0
            bestVisX > 0.62f -> 2
            else -> 1
        }
        val bestGroundY = finalLaneBestY[chosenLane].coerceIn(max(horizonYRatio + 0.08f, 0.60f), 0.945f)

        // Perspective-accurate tourist scale (derived from horizon distance, floor depth span & openness)
        val opennessRatio = if (upperSkyOrDistantCount[1] > 0) {
            upperSkyOrDistantCount[0].toFloat() / upperSkyOrDistantCount[1].toFloat()
        } else 0.40f
        val groundDepthSpan = (bestGroundY - horizonYRatio).coerceIn(0.10f, 0.64f)

        val depthDrivenScale = (0.49f + groundDepthSpan * 0.55f).coerceIn(0.50f, 0.79f)
        val vistaScale = when {
            isReflectionPoolMonument || opennessRatio > 0.62f || horizonYRatio > 0.60f -> 0.58f
            opennessRatio > 0.44f || horizonYRatio > 0.54f -> 0.64f
            isIndoorHint || opennessRatio < 0.24f -> 0.75f
            else -> 0.70f
        }
        val perspectiveScale = (depthDrivenScale * 0.58f + vistaScale * 0.42f).coerceIn(0.50f, 0.80f)

        val surfaceLabel = matToSurfaceLabel(chosenSpot.mat)

        val result = VisualSceneAnalysis(
            xOffsetPx = xOffsetPx,
            bestVisXRatio = bestVisX,
            bestGroundYRatio = bestGroundY,
            horizonYRatio = horizonYRatio,
            perspectiveScale = perspectiveScale,
            surfaceLabel = surfaceLabel,
            centerHasWaterOrHazard = centerBlocked,
            leftWalkableScore = finalLaneBestScore[0],
            centerWalkableScore = finalLaneBestScore[1],
            rightWalkableScore = finalLaneBestScore[2],
            leftBestYRatio = finalLaneBestY[0],
            centerBestYRatio = finalLaneBestY[1],
            rightBestYRatio = finalLaneBestY[2],
            leftBestXRatio = finalLaneBestX[0],
            centerBestXRatio = finalLaneBestX[1],
            rightBestXRatio = finalLaneBestX[2],
            leftSafeCount = laneSafeCount[0],
            centerSafeCount = laneSafeCount[1],
            rightSafeCount = laneSafeCount[2],
            visColsCount = visColsCount,
            anySafeGroundInScene = anySafeGroundInScene,
            colHasSafeGround = colHasSafeGround,
            colBestVisX = colBestVisX,
            colBestSafeY = colBestSafeY,
            colMinSafeY = colMinSafeY,
            colMaxSafeY = colMaxSafeY,
            colBestScore = colBestScore,
            colSurfaceLabels = colSurfaceLabels
        )
        synchronized(visualSceneAnalysisCache) {
            val inner = visualSceneAnalysisCache.getOrPut(bgBitmap) { mutableMapOf() }
            if (inner.size > 12) inner.clear()
            inner[cacheKey] = result
        }
        result
    } catch (_: Throwable) {
        defaultAnalysis
    } finally {
        try {
            if (proxy != null && !proxy.isRecycled) proxy.recycle()
        } catch (_: Throwable) {}
    }
}

private fun VisualSceneAnalysis.findColumnForVisX(targetVisX: Float): Int {
    if (visColsCount <= 1 || colBestVisX.isEmpty()) return 0
    val first = colBestVisX.first()
    val last = colBestVisX.last()
    if (targetVisX <= first) return 0
    if (targetVisX >= last) return visColsCount - 1
    val frac = ((targetVisX - first) / (last - first).coerceAtLeast(0.01f)).coerceIn(0f, 1f)
    return (frac * (visColsCount - 1)).roundToInt().coerceIn(0, visColsCount - 1)
}

/**
 * Unbreakable "ONLY SOLID GROUND" Enforcer across the ENTIRE frame width (left, center, right):
 * Inspects the exact visible column under [desiredXOffsetPx]; if that column sits on water,
 * pools, waves, rivers, lakes, reflections, or mid-air sky/rooftop drop-offs, scans ALL
 * columns across the entire width and snaps feet onto the nearest verified solid ground column
 * and locks shoe soles strictly within its verified solid Y range.
 */
fun snapPlacementToVerifiedSolidGround(
    bgBitmap: Bitmap?,
    locationName: String?,
    desiredXOffsetPx: Float,
    userScale: Float,
    footAnchor: SubjectFootAnchor,
    previewWidthPx: Float,
    previewHeightPx: Float,
    isVideoViewport: Boolean = false,
    desiredGroundYRatioOverride: Float? = null,
    surfaceSinkRatio: Float = 0f
): SafeSolidGroundSnap {
    val pH = previewHeightPx.coerceAtLeast(300f)
    val pW = if (previewWidthPx > 60f) previewWidthPx else pH * (if (isVideoViewport) 9f / 16f else 0.85f)
    val userH = pH * ((210f * userScale) / 380f)

    if (bgBitmap == null || bgBitmap.isRecycled) {
        val fallbackGroundY = 0.90f
        val targetGroundY = if (footAnchor.isHalfBodyCropped) pH * 0.985f else pH * fallbackGroundY
        val yOff = (targetGroundY - pH) + (userH * (1f - footAnchor.lowestContactYRatio))
        return SafeSolidGroundSnap(
            xOffsetPx = desiredXOffsetPx.coerceIn(-pW * 0.36f, pW * 0.36f),
            yOffsetPx = yOff,
            groundYRatio = fallbackGroundY,
            surfaceLabel = "Center Ground",
            perspectiveScale = 0.68f,
            snappedAwayFromHazard = false,
            verifiedSolidGround = false
        )
    }

    val scene = analyzeVisualSceneForTouristPlacement(
        bgBitmap = bgBitmap,
        locationName = locationName,
        previewWidth = pW,
        previewHeight = pH,
        preferSidePlacement = false,
        isVideoViewport = isVideoViewport
    )

    val boundedDesiredX = desiredXOffsetPx.coerceIn(-pW * 0.38f, pW * 0.38f)
    val targetVisX = (0.50f + (boundedDesiredX / pW)).coerceIn(0.08f, 0.92f)
    val targetCol = scene.findColumnForVisX(targetVisX)

    var chosenCol = targetCol
    var snappedAway = false
    val finalXOffsetPx: Float

    if (scene.anySafeGroundInScene) {
        if (scene.colHasSafeGround.getOrElse(targetCol) { false }) {
            chosenCol = targetCol
            snappedAway = false
            finalXOffsetPx = boundedDesiredX
        } else {
            // Scan the ENTIRE width (left, center, right) to snap onto the nearest verified solid ground column
            var bestCol = -1
            var bestPenalty = Float.MAX_VALUE
            for (colIdx in 0 until scene.visColsCount) {
                if (!scene.colHasSafeGround[colIdx]) continue
                val dist = abs(scene.colBestVisX[colIdx] - targetVisX)
                val penalty = (dist * 3.8f) - (scene.colBestScore[colIdx] * 0.25f)
                if (penalty < bestPenalty) {
                    bestPenalty = penalty
                    bestCol = colIdx
                }
            }
            if (bestCol >= 0) {
                chosenCol = bestCol
                snappedAway = true
                finalXOffsetPx = ((scene.colBestVisX[bestCol] - 0.50f) * pW).coerceIn(-pW * 0.38f, pW * 0.38f)
            } else {
                finalXOffsetPx = scene.xOffsetPx.coerceIn(-pW * 0.38f, pW * 0.38f)
            }
        }
    } else {
        // Extreme 0%-dry fallback: pick overall column with absolute minimum hazard cells
        chosenCol = scene.findColumnForVisX(scene.bestVisXRatio)
        snappedAway = abs(scene.bestVisXRatio - targetVisX) > 0.04f
        finalXOffsetPx = scene.xOffsetPx.coerceIn(-pW * 0.38f, pW * 0.38f)
    }

    val colMinY = scene.colMinSafeY.getOrElse(chosenCol) { 0.62f }.coerceIn(0.58f, 0.945f)
    val colMaxY = scene.colMaxSafeY.getOrElse(chosenCol) { 0.945f }.coerceIn(colMinY, 0.945f)
    val colBestY = scene.colBestSafeY.getOrElse(chosenCol) { scene.bestGroundYRatio }.coerceIn(colMinY, colMaxY)
    val lockedGroundYRatio = (desiredGroundYRatioOverride ?: colBestY).coerceIn(colMinY, colMaxY)

    val sinkPx = userH * surfaceSinkRatio
    val targetGroundY = if (footAnchor.isHalfBodyCropped) {
        pH * 0.985f
    } else {
        val rawGroundY = pH * lockedGroundYRatio
        val maxColGroundY = pH * colMaxY
        val minHeadClearY = (footAnchor.lowestContactYRatio * userH) + 8f
        if (minHeadClearY > rawGroundY) {
            min(minHeadClearY, max(rawGroundY, maxColGroundY))
        } else {
            rawGroundY
        }
    }
    val finalYOffsetPx = (targetGroundY - pH) + (userH * (1f - footAnchor.lowestContactYRatio)) - sinkPx

    return SafeSolidGroundSnap(
        xOffsetPx = finalXOffsetPx,
        yOffsetPx = finalYOffsetPx,
        groundYRatio = lockedGroundYRatio,
        surfaceLabel = scene.colSurfaceLabels.getOrElse(chosenCol) { scene.surfaceLabel },
        perspectiveScale = scene.perspectiveScale,
        snappedAwayFromHazard = snappedAway,
        verifiedSolidGround = scene.anySafeGroundInScene && scene.colHasSafeGround.getOrElse(chosenCol) { false }
    )
}

fun findSafeWalkableGroundYForXOffset(
    bgBitmap: Bitmap?,
    locationName: String?,
    xOffsetPx: Float,
    previewWidthPx: Float,
    previewHeightPx: Float = 0f,
    isVideoViewport: Boolean = false
): Float? {
    if (bgBitmap == null || bgBitmap.isRecycled || previewWidthPx <= 0f) return null
    val scene = analyzeVisualSceneForTouristPlacement(
        bgBitmap = bgBitmap,
        locationName = locationName,
        previewWidth = previewWidthPx,
        previewHeight = previewHeightPx,
        preferSidePlacement = false,
        isVideoViewport = isVideoViewport
    )
    val visX = (0.50f + (xOffsetPx / previewWidthPx.coerceAtLeast(360f))).coerceIn(0.08f, 0.92f)
    val col = scene.findColumnForVisX(visX)
    return if (!scene.anySafeGroundInScene || scene.colHasSafeGround.getOrElse(col) { false }) {
        scene.colBestSafeY.getOrElse(col) { scene.bestGroundYRatio }
    } else {
        scene.bestGroundYRatio
    }
}

fun computeSmartSurfacePlacement(
    bgBitmap: Bitmap?,
    locationName: String?,
    previewWidth: Float,
    previewHeight: Float = 0f,
    isVideoViewport: Boolean = false
): Pair<Float, Float> {
    val scene = analyzeVisualSceneForTouristPlacement(
        bgBitmap = bgBitmap,
        locationName = locationName,
        previewWidth = previewWidth,
        previewHeight = previewHeight,
        preferSidePlacement = false,
        isVideoViewport = isVideoViewport
    )
    return Pair(scene.xOffsetPx, scene.perspectiveScale)
}

/**
 * 100% Original Auto-Realism Calculator:
 * Combines 2D visual scene analysis (walkable floor vs water/reflection/mid-air/wall/crowd),
 * perspective-accurate human scale, exact shoe-sole grounding, scene lighting, cool/warm tint,
 * and contact 3D shadow depth from the live background bitmap identically across Photo & 15s Video.
 */
fun computeVoiceAutoRealism(
    bgBitmap: Bitmap?,
    command: ParsedVoiceCommand,
    sourceAnalysis: SourcePhotoAnalysis?,
    previewWidthPx: Float,
    previewHeightPx: Float,
    subjectBitmap: Bitmap? = null,
    isVideoViewport: Boolean = (command.outputType == VoiceOutputType.VIDEO_15S)
): VoiceAutoRealismPlan {
    val bgLighting = analyzeVideoBackgroundLighting(bgBitmap)
    val sceneAdaptive = analyzeAnyBackgroundBitmap(
        bgBitmap = bgBitmap,
        landmarkFallbackName = command.locationQuery,
        isCoolToneFallback = command.sceneMood == VoiceSceneMood.SNOW || command.sceneMood == VoiceSceneMood.NIGHT
    )

    val scene = analyzeVisualSceneForTouristPlacement(
        bgBitmap = bgBitmap,
        locationName = command.locationQuery,
        previewWidth = previewWidthPx,
        previewHeight = previewHeightPx,
        preferSidePlacement = command.preferSidePlacement,
        isVideoViewport = isVideoViewport
    )
    val baseScale = scene.perspectiveScale

    val adjustedScale = when (command.sizeHint) {
        VoiceSizeHint.SMALL -> (baseScale * 0.78f).coerceIn(0.46f, 0.78f)
        VoiceSizeHint.LARGE -> (baseScale * 1.18f).coerceIn(0.54f, 0.86f)
        VoiceSizeHint.MEDIUM -> baseScale.coerceIn(0.50f, 0.80f)
        VoiceSizeHint.AUTO -> baseScale.coerceIn(0.50f, 0.80f)
    }

    val pW = previewWidthPx.coerceAtLeast(360f)
    val pH = previewHeightPx.coerceAtLeast(300f)

    val rawDesiredXOffset: Float
    var waterGuardrailTriggered = false
    when (command.positionHint) {
        VoicePositionHint.LEFT -> {
            if (scene.leftSafeCount == 0 && (scene.rightSafeCount > 0 || scene.centerSafeCount > 0)) {
                rawDesiredXOffset = scene.xOffsetPx
                waterGuardrailTriggered = true
            } else {
                val safeX = scene.leftBestXRatio.coerceIn(0.12f, 0.36f)
                rawDesiredXOffset = (safeX - 0.50f) * pW
            }
        }
        VoicePositionHint.RIGHT -> {
            if (scene.rightSafeCount == 0 && (scene.leftSafeCount > 0 || scene.centerSafeCount > 0)) {
                rawDesiredXOffset = scene.xOffsetPx
                waterGuardrailTriggered = true
            } else {
                val safeX = scene.rightBestXRatio.coerceIn(0.64f, 0.88f)
                rawDesiredXOffset = (safeX - 0.50f) * pW
            }
        }
        VoicePositionHint.CENTER -> {
            if (scene.centerSafeCount == 0 && scene.centerHasWaterOrHazard) {
                rawDesiredXOffset = scene.xOffsetPx
                waterGuardrailTriggered = true
            } else {
                rawDesiredXOffset = ((scene.centerBestXRatio - 0.50f) * pW * 0.60f)
            }
        }
        VoicePositionHint.AUTO -> {
            rawDesiredXOffset = scene.xOffsetPx
        }
    }

    // Strict "ONLY SOLID GROUND" enforcement: verify exact column and lock feet strictly on solid ground
    val footAnchor = if (subjectBitmap != null && !subjectBitmap.isRecycled) {
        detectSubjectFootAnchor(subjectBitmap)
    } else {
        SubjectFootAnchor()
    }
    val snap = snapPlacementToVerifiedSolidGround(
        bgBitmap = bgBitmap,
        locationName = command.locationQuery,
        desiredXOffsetPx = rawDesiredXOffset,
        userScale = adjustedScale,
        footAnchor = footAnchor,
        previewWidthPx = pW,
        previewHeightPx = pH,
        isVideoViewport = isVideoViewport
    )
    val xOffset = snap.xOffsetPx
    val yOffset = snap.yOffsetPx
    if (snap.snappedAwayFromHazard) waterGuardrailTriggered = true

    // Adaptive 3D Shadow intensity (honoring explicit Soft / Natural / Deep 3D voice requests)
    val shadowDepth = when (command.shadowHint) {
        VoiceShadowHint.SOFT -> 0.20f
        VoiceShadowHint.NATURAL -> 0.38f
        VoiceShadowHint.DEEP_3D -> 0.65f
        VoiceShadowHint.NONE -> when {
            command.sceneMood == VoiceSceneMood.NIGHT || bgLighting.avgBrightness < 0.28f -> 0.30f
            command.sceneMood == VoiceSceneMood.SNOW -> 0.40f
            bgLighting.avgBrightness > 0.62f -> 0.50f
            else -> 0.42f
        }
    }

    val isCoolTone = when (command.lightingHint) {
        VoiceLightingHint.WARM -> false
        VoiceLightingHint.COOL -> true
        else -> when (command.sceneMood) {
            VoiceSceneMood.SNOW, VoiceSceneMood.NIGHT -> true
            VoiceSceneMood.SUNSET, VoiceSceneMood.DESERT -> false
            else -> bgLighting.warmth < -0.05f || sceneAdaptive.timeOfDay.contains("Snow", ignoreCase = true)
        }
    }

    val envBlend = when (command.lightingHint) {
        VoiceLightingHint.WARM -> 0.85f
        VoiceLightingHint.COOL -> 0.72f
        else -> when (command.sceneMood) {
            VoiceSceneMood.SUNSET, VoiceSceneMood.DESERT -> 0.70f
            VoiceSceneMood.NIGHT -> 0.65f
            else -> if (bgLighting.avgBrightness > 0.50f) 0.62f else 0.58f
        }
    }

    val sidePrefix = when {
        xOffset < -30f -> "Left"
        xOffset > 30f -> "Right"
        else -> "Center"
    }
    val posTag = "$sidePrefix ${snap.surfaceLabel}"
    val toneTag = when {
        isCoolTone -> "Cool Ambient"
        bgLighting.warmth > 0.08f -> "Warm Sunlight"
        else -> "Natural Daylight"
    }
    return VoiceAutoRealismPlan(
        userScale = adjustedScale,
        userXOffset = xOffset,
        userYOffset = yOffset,
        shadowDepth = shadowDepth,
        environmentBlend = envBlend,
        isCoolToneScene = isCoolTone,
        summaryLabel = "${command.displayLocation} • $posTag (${(adjustedScale * 100).toInt()}%) • $toneTag",
        waterGuardrailTriggered = waterGuardrailTriggered
    )
}

/**
 * In-Scene Voice AI Adjustment Calculator:
 * Applies position ("left mein", "right side", "center mein", "thoda peeche"),
 * size ("thoda chota karo", "bada karo", "zoom out"), lighting ("light match karo"),
 * and shadow ("shadow soft karo", "deep 3D shadow") directly on the current scene
 * while strictly keeping feet anchored on solid walkable ground (never water/mid-air).
 */
fun computeInSceneVoiceAdjustment(
    bgBitmap: Bitmap?,
    currentLocationName: String,
    command: ParsedVoiceCommand,
    currentScale: Float,
    currentXOffset: Float,
    currentShadowDepth: Float,
    currentEnvBlend: Float,
    currentIsCoolTone: Boolean,
    previewWidthPx: Float,
    previewHeightPx: Float,
    subjectBitmap: Bitmap? = null,
    isVideoViewport: Boolean = false
): VoiceAutoRealismPlan {
    val pW = previewWidthPx.coerceAtLeast(360f)
    val pH = previewHeightPx.coerceAtLeast(300f)
    val bgLighting = analyzeVideoBackgroundLighting(bgBitmap)
    val sceneAdaptive = analyzeAnyBackgroundBitmap(
        bgBitmap = bgBitmap,
        landmarkFallbackName = currentLocationName,
        isCoolToneFallback = currentIsCoolTone
    )
    val scene = analyzeVisualSceneForTouristPlacement(
        bgBitmap = bgBitmap,
        locationName = currentLocationName,
        previewWidth = pW,
        previewHeight = pH,
        preferSidePlacement = command.preferSidePlacement,
        isVideoViewport = isVideoViewport
    )

    // 1. Scale adjustment (perspectively bounded, feet always remain locked to solid ground)
    val newScale = when (command.scaleDelta) {
        VoiceScaleDelta.SCALE_DOWN -> (currentScale * 0.85f).coerceIn(0.44f, 0.94f)
        VoiceScaleDelta.SCALE_UP -> (currentScale * 1.16f).coerceIn(0.44f, 0.94f)
        VoiceScaleDelta.SCALE_RESET -> scene.perspectiveScale.coerceIn(0.50f, 0.80f)
        VoiceScaleDelta.NONE -> currentScale.coerceIn(0.44f, 0.94f)
    }

    // 2. Position & Nudge with full-width solid ground verification
    var waterGuardrailTriggered = false
    var desiredXOffset = currentXOffset
    when {
        command.positionHint == VoicePositionHint.LEFT -> {
            if (scene.leftSafeCount == 0 && (scene.rightSafeCount > 0 || scene.centerSafeCount > 0)) {
                desiredXOffset = scene.xOffsetPx
                waterGuardrailTriggered = true
            } else {
                desiredXOffset = (scene.leftBestXRatio.coerceIn(0.12f, 0.36f) - 0.50f) * pW
            }
        }
        command.positionHint == VoicePositionHint.RIGHT -> {
            if (scene.rightSafeCount == 0 && (scene.leftSafeCount > 0 || scene.centerSafeCount > 0)) {
                desiredXOffset = scene.xOffsetPx
                waterGuardrailTriggered = true
            } else {
                desiredXOffset = (scene.rightBestXRatio.coerceIn(0.64f, 0.88f) - 0.50f) * pW
            }
        }
        command.positionHint == VoicePositionHint.CENTER -> {
            if (scene.centerSafeCount == 0 && scene.centerHasWaterOrHazard) {
                desiredXOffset = scene.xOffsetPx
                waterGuardrailTriggered = true
            } else {
                desiredXOffset = (scene.centerBestXRatio - 0.50f) * pW * 0.60f
            }
        }
        command.preferSidePlacement -> {
            val pickLeft = when {
                scene.leftSafeCount > 0 && scene.rightSafeCount == 0 -> true
                scene.rightSafeCount > 0 && scene.leftSafeCount == 0 -> false
                else -> scene.leftWalkableScore >= scene.rightWalkableScore
            }
            desiredXOffset = if (pickLeft) {
                (scene.leftBestXRatio.coerceIn(0.12f, 0.36f) - 0.50f) * pW
            } else {
                (scene.rightBestXRatio.coerceIn(0.64f, 0.88f) - 0.50f) * pW
            }
        }
        command.positionNudge == VoicePositionNudge.NUDGE_LEFT -> {
            desiredXOffset = (currentXOffset - pW * 0.14f).coerceIn(-pW * 0.36f, pW * 0.36f)
        }
        command.positionNudge == VoicePositionNudge.NUDGE_RIGHT -> {
            desiredXOffset = (currentXOffset + pW * 0.14f).coerceIn(-pW * 0.36f, pW * 0.36f)
        }
        command.wantsWalkwayOrGroundFix -> {
            desiredXOffset = scene.xOffsetPx
        }
    }

    // 3. Always snap & lock feet onto verified zero-hazard solid walkable ground across full width
    val footAnchor = if (subjectBitmap != null && !subjectBitmap.isRecycled) {
        detectSubjectFootAnchor(subjectBitmap)
    } else {
        SubjectFootAnchor()
    }
    val curVisX = (0.50f + desiredXOffset / pW).coerceIn(0.08f, 0.92f)
    val curCol = scene.findColumnForVisX(curVisX)
    val colBaseY = scene.colBestSafeY.getOrElse(curCol) { scene.bestGroundYRatio }
    val requestedDepthOverride: Float? = when (command.positionNudge) {
        VoicePositionNudge.STEP_BACK -> (colBaseY - 0.035f)
        VoicePositionNudge.STEP_FORWARD -> (colBaseY + 0.025f)
        else -> null
    }
    val snap = snapPlacementToVerifiedSolidGround(
        bgBitmap = bgBitmap,
        locationName = currentLocationName,
        desiredXOffsetPx = desiredXOffset,
        userScale = newScale,
        footAnchor = footAnchor,
        previewWidthPx = pW,
        previewHeightPx = pH,
        isVideoViewport = isVideoViewport,
        desiredGroundYRatioOverride = requestedDepthOverride
    )
    val newXOffset = snap.xOffsetPx
    val newYOffset = snap.yOffsetPx
    if (snap.snappedAwayFromHazard) waterGuardrailTriggered = true

    // 4. Shadow & Lighting updates
    val newShadowDepth = when (command.shadowHint) {
        VoiceShadowHint.SOFT -> 0.20f
        VoiceShadowHint.NATURAL -> 0.38f
        VoiceShadowHint.DEEP_3D -> 0.65f
        VoiceShadowHint.NONE -> currentShadowDepth
    }

    val newIsCoolTone = when (command.lightingHint) {
        VoiceLightingHint.WARM -> false
        VoiceLightingHint.COOL -> true
        VoiceLightingHint.MATCH_AUTO -> bgLighting.warmth < -0.05f || sceneAdaptive.timeOfDay.contains("Snow", ignoreCase = true)
        VoiceLightingHint.NONE -> currentIsCoolTone
    }
    val newEnvBlend = when (command.lightingHint) {
        VoiceLightingHint.WARM -> 0.85f
        VoiceLightingHint.COOL -> 0.72f
        VoiceLightingHint.MATCH_AUTO -> if (bgLighting.avgBrightness > 0.50f) 0.64f else 0.60f
        VoiceLightingHint.NONE -> currentEnvBlend
    }

    val sidePrefix = when {
        newXOffset < -30f -> "Left"
        newXOffset > 30f -> "Right"
        else -> "Center"
    }
    val shadowTag = when {
        newShadowDepth < 0.30f -> "Soft Shadow"
        newShadowDepth > 0.50f -> "Deep 3D Shadow"
        else -> "Natural Shadow"
    }

    return VoiceAutoRealismPlan(
        userScale = newScale,
        userXOffset = newXOffset,
        userYOffset = newYOffset,
        shadowDepth = newShadowDepth,
        environmentBlend = newEnvBlend,
        isCoolToneScene = newIsCoolTone,
        summaryLabel = "$currentLocationName • $sidePrefix ${scene.surfaceLabel} (${(newScale * 100).toInt()}%) • $shadowTag",
        waterGuardrailTriggered = waterGuardrailTriggered
    )
}

/**
 * Generates very short, warm, friendly Voice AI confirmation replies in the user's
 * Hindi/Hinglish (spoken with hi-IN) or English (spoken with en-IN) tone.
 */
fun buildVoiceConfirmationMessage(
    command: ParsedVoiceCommand,
    locationName: String,
    waterGuardrailTriggered: Boolean = false,
    undoSucceeded: Boolean = false
): Pair<String, Boolean> {
    val isHindiTone = command.languageStyle != VoiceLanguageStyle.ENGLISH

    if (command.intentAction == VoiceIntentAction.UNDO) {
        return if (undoSucceeded) {
            if (isHindiTone) {
                "Pehle jaisa wapas kar diya hai." to true
            } else {
                "Done, restored your previous look." to false
            }
        } else {
            if (isHindiTone) {
                "Abhi koi purana step saved nahi hai." to true
            } else {
                "Nothing earlier to undo yet." to false
            }
        }
    }

    if (waterGuardrailTriggered) {
        return if (isHindiTone) {
            "Wahan paani tha, isliye $locationName ke safe ground par set kiya hai." to true
        } else {
            "Moved to solid ground near $locationName." to false
        }
    }

    if (command.intentAction == VoiceIntentAction.CHANGE_LOCATION) {
        val loc = command.displayLocation.ifBlank { locationName }
        return when (command.modeRequest) {
            VoiceModeRequest.START_LIVE_RECORDING ->
                if (isHindiTone) "Chalo, $loc par live recording shuru kar rahe hain." to true
                else "Starting live recording at $loc." to false
            VoiceModeRequest.LIVE_CAMERA_VIDEO ->
                if (isHindiTone) "$loc par live camera ready hai." to true
                else "Live camera is ready at $loc." to false
            else -> if (command.outputType == VoiceOutputType.VIDEO_15S) {
                if (isHindiTone) {
                    "$loc par 15s video ready ho gaya hai." to true
                } else {
                    "Your 15s video at $loc is ready." to false
                }
            } else {
                if (isHindiTone) {
                    "$loc par photo set ho gayi hai." to true
                } else {
                    "Done, placed you at $loc." to false
                }
            }
        }
    }

    // In-scene adjustments (photo/video/live-camera/position/size/shadow/lighting)
    return when {
        command.modeRequest == VoiceModeRequest.START_LIVE_RECORDING ->
            if (isHindiTone) "Live recording shuru ho rahi hai." to true
            else "Starting live recording now." to false
        command.modeRequest == VoiceModeRequest.STOP_LIVE_RECORDING ->
            if (isHindiTone) "Recording stop karke video save kar rahe hain." to true
            else "Recording stopped, saving your video." to false
        command.modeRequest == VoiceModeRequest.FLIP_LIVE_CAMERA ->
            if (isHindiTone) "Camera flip kar diya hai." to true
            else "Flipped the camera." to false
        command.modeRequest == VoiceModeRequest.FRONT_LIVE_CAMERA ->
            if (isHindiTone) "Front camera on kar diya hai." to true
            else "Switched to front camera." to false
        command.modeRequest == VoiceModeRequest.BACK_LIVE_CAMERA ->
            if (isHindiTone) "Back camera on kar diya hai." to true
            else "Switched to back camera." to false
        command.modeRequest == VoiceModeRequest.LIVE_CAMERA_VIDEO ->
            if (isHindiTone) "Live video mode on ho gaya hai." to true
            else "Live video mode is on." to false
        command.modeRequest == VoiceModeRequest.VIDEO_15S ->
            if (isHindiTone) "$locationName ka 15s video ready hai." to true
            else "Your 15s video is ready." to false
        command.modeRequest == VoiceModeRequest.PHOTO ->
            if (isHindiTone) "$locationName ki photo ready hai." to true
            else "Your photo at $locationName is ready." to false
        command.positionHint == VoicePositionHint.LEFT || command.positionNudge == VoicePositionNudge.NUDGE_LEFT ->
            if (isHindiTone) "Left side mein set kar diya hai." to true
            else "Done, moved to the left." to false
        command.positionHint == VoicePositionHint.RIGHT || command.positionNudge == VoicePositionNudge.NUDGE_RIGHT ->
            if (isHindiTone) "Right side mein set kar diya hai." to true
            else "Done, moved to the right." to false
        command.positionHint == VoicePositionHint.CENTER ->
            if (isHindiTone) "Center mein set kar diya hai." to true
            else "Done, centered you." to false
        command.positionNudge == VoicePositionNudge.STEP_BACK ->
            if (isHindiTone) "Thoda peeche set kar diya hai." to true
            else "Moved slightly back." to false
        command.positionNudge == VoicePositionNudge.STEP_FORWARD ->
            if (isHindiTone) "Thoda paas set kar diya hai." to true
            else "Brought slightly closer." to false
        command.scaleDelta == VoiceScaleDelta.SCALE_DOWN ->
            if (isHindiTone) "Size thoda chota kar diya hai." to true
            else "Made it slightly smaller." to false
        command.scaleDelta == VoiceScaleDelta.SCALE_UP ->
            if (isHindiTone) "Size thoda bada kar diya hai." to true
            else "Made it slightly bigger." to false
        command.scaleDelta == VoiceScaleDelta.SCALE_RESET ->
            if (isHindiTone) "Size natural set kar diya hai." to true
            else "Reset to natural size." to false
        command.shadowHint == VoiceShadowHint.SOFT ->
            if (isHindiTone) "Shadow soft kar di hai." to true
            else "Softened the shadow." to false
        command.shadowHint == VoiceShadowHint.DEEP_3D ->
            if (isHindiTone) "Deep 3D shadow laga di hai." to true
            else "Applied deep 3D shadow." to false
        command.shadowHint == VoiceShadowHint.NATURAL ->
            if (isHindiTone) "Natural shadow set kar di hai." to true
            else "Set natural shadow." to false
        command.lightingHint != VoiceLightingHint.NONE ->
            if (isHindiTone) "Lighting match kar di hai." to true
            else "Matched scene lighting." to false
        else ->
            if (isHindiTone) "Scene update ho gaya hai." to true
            else "Done, scene updated." to false
    }
}

/**
 * Generates a clean 15-second warm stereo ambient travel soundtrack (.wav)
 * when the user requests "with music" via Voice AI without pre-selecting a custom MP3.
 */
fun generateAmbientTravelWav15s(outputFile: File): File {
    val sampleRate = 44100
    val channels = 2
    val durationSeconds = 15
    val totalSamples = sampleRate * durationSeconds
    val dataSize = totalSamples * channels * 2
    val byteRate = sampleRate * channels * 2

    // Warm uplifting travel progression (C - G - Am - F cycling smoothly)
    val chords = arrayOf(
        doubleArrayOf(261.63, 329.63, 392.00, 523.25), // Cmaj7 feel
        doubleArrayOf(196.00, 293.66, 392.00, 493.88), // G
        doubleArrayOf(220.00, 329.63, 440.00, 523.25), // Am
        doubleArrayOf(174.61, 261.63, 349.23, 440.00)  // F
    )

    FileOutputStream(outputFile).use { fos ->
        // Write 44-byte RIFF/WAVE header
        fun writeLeInt(v: Int) {
            fos.write(v and 0xFF)
            fos.write((v shr 8) and 0xFF)
            fos.write((v shr 16) and 0xFF)
            fos.write((v shr 24) and 0xFF)
        }
        fun writeLeShort(v: Int) {
            fos.write(v and 0xFF)
            fos.write((v shr 8) and 0xFF)
        }

        fos.write("RIFF".toByteArray(Charsets.US_ASCII))
        writeLeInt(36 + dataSize)
        fos.write("WAVE".toByteArray(Charsets.US_ASCII))
        fos.write("fmt ".toByteArray(Charsets.US_ASCII))
        writeLeInt(16) // PCM chunk size
        writeLeShort(1) // PCM format
        writeLeShort(channels)
        writeLeInt(sampleRate)
        writeLeInt(byteRate)
        writeLeShort(channels * 2) // block align
        writeLeShort(16) // bits per sample
        fos.write("data".toByteArray(Charsets.US_ASCII))
        writeLeInt(dataSize)

        val buffer = ByteArray(4096 * 4)
        var bufIdx = 0
        val bpm = 104.0
        val beatDur = 60.0 / bpm

        for (s in 0 until totalSamples) {
            val t = s.toDouble() / sampleRate.toDouble()
            val chordIdx = ((t / 3.75).toInt()).coerceIn(0, 3)
            val chord = chords[chordIdx]

            // Smooth global fade-in & fade-out
            val envIn = (t / 0.6).coerceIn(0.0, 1.0)
            val envOut = ((durationSeconds - t) / 0.8).coerceIn(0.0, 1.0)
            val masterEnv = envIn * envOut

            // Gentle plucked arpeggio + warm pad
            val chordLocalT = t % 3.75
            val pad = (
                0.30 * sin(2.0 * PI * chord[0] * t) +
                0.24 * sin(2.0 * PI * chord[1] * t) +
                0.20 * sin(2.0 * PI * chord[2] * t) +
                0.14 * sin(2.0 * PI * chord[3] * t + 0.35)
            ) * 0.45

            // Soft kick/pulse on quarter beats
            val beatPhase = (t % beatDur) / beatDur
            val kickEnv = exp(-beatPhase * 12.0)
            val kickFreq = 58.0 + 90.0 * exp(-beatPhase * 28.0)
            val kick = sin(2.0 * PI * kickFreq * beatPhase * beatDur) * kickEnv * 0.32

            // Gentle sparkle pluck every half beat
            val halfBeatPhase = (t % (beatDur * 0.5)) / (beatDur * 0.5)
            val arpNote = chord[((t / (beatDur * 0.5)).toInt()) % chord.size] * 2.0
            val arpEnv = exp(-halfBeatPhase * 7.5) * exp(-chordLocalT * 0.15)
            val arp = sin(2.0 * PI * arpNote * t) * arpEnv * 0.18

            val leftVal = ((pad + kick + arp * 0.85) * masterEnv * 14500.0).toInt().coerceIn(-32767, 32767)
            val rightVal = ((pad * 0.96 + kick + arp * 1.08) * masterEnv * 14500.0).toInt().coerceIn(-32767, 32767)

            buffer[bufIdx++] = (leftVal and 0xFF).toByte()
            buffer[bufIdx++] = ((leftVal shr 8) and 0xFF).toByte()
            buffer[bufIdx++] = (rightVal and 0xFF).toByte()
            buffer[bufIdx++] = ((rightVal shr 8) and 0xFF).toByte()

            if (bufIdx >= buffer.size) {
                fos.write(buffer, 0, bufIdx)
                bufIdx = 0
            }
        }
        if (bufIdx > 0) {
            fos.write(buffer, 0, bufIdx)
        }
    }
    return outputFile
}

@Composable
fun VoiceAiModalDialog(
    isListening: Boolean,
    isProcessing: Boolean,
    partialTranscript: String,
    processingStatus: String,
    lastReplyMessage: String = "",
    canUndo: Boolean = false,
    languageTag: String,
    isMuted: Boolean = false,
    hasUserPhoto: Boolean = true,
    onPickGalleryPhoto: () -> Unit = {},
    onOpenCamera: () -> Unit = {},
    onToggleLanguage: () -> Unit,
    onToggleMute: () -> Unit = {},
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    onSubmitCommand: (String) -> Unit,
    onAutoCreate: () -> Unit = {},
    onDismiss: () -> Unit
) {
    var typedCommand by remember(partialTranscript) { mutableStateOf(partialTranscript) }

    val pulseTransition = rememberInfiniteTransition(label = "voice_pulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isListening) 1.24f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "voice_orb_scale"
    )

    val quickExamples = remember(canUndo) {
        buildList {
            add("Live camera kholo")
            add("Record 15s video")
            add("Taj Mahal par le chalo")
            add("Dubai beach par khada karo")
            add("Left mein khada karo")
            add("Thoda chota karo")
            add("Deep 3D shadow")
            add("Light match karo")
            add("15s video banao")
            if (canUndo) add("Pehle jaisa karo")
        }
    }

    Dialog(onDismissRequest = { if (!isProcessing) onDismiss() }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = BorderStroke(1.2.dp, Color(0xFF334155)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("voice_ai_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Voice AI",
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Voice AI",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Surface(
                            onClick = onToggleLanguage,
                            enabled = !isProcessing,
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.6f)),
                            modifier = Modifier.testTag("voice_ai_lang_toggle")
                        ) {
                            Text(
                                text = if (languageTag.startsWith("hi")) "🇮🇳 हिंदी/EN" else "🌐 English",
                                color = Color(0xFFBAE6FD),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
                            )
                        }

                        IconButton(
                            onClick = onToggleMute,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("voice_ai_mute_toggle")
                        ) {
                            Icon(
                                imageVector = if (isMuted) {
                                    Icons.AutoMirrored.Filled.VolumeOff
                                } else {
                                    Icons.AutoMirrored.Filled.VolumeUp
                                },
                                contentDescription = if (isMuted) "Unmute Voice Reply" else "Mute Voice Reply",
                                tint = if (isMuted) Color(0xFFF87171) else Color(0xFF38BDF8),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        IconButton(
                            onClick = { if (!isProcessing) onDismiss() },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("voice_ai_close_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Voice AI",
                                tint = Color(0xFF94A3B8)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Interactive Animated Microphone Orb
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(116.dp)
                        .testTag("voice_ai_mic_orb")
                ) {
                    Box(
                        modifier = Modifier
                            .size(104.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = if (isListening) {
                                        listOf(Color(0x66EC4899), Color(0x22A855F7), Color.Transparent)
                                    } else if (isProcessing) {
                                        listOf(Color(0x6610B981), Color(0x2238BDF8), Color.Transparent)
                                    } else {
                                        listOf(Color(0x4438BDF8), Color.Transparent)
                                    }
                                )
                            )
                    )

                    Surface(
                        onClick = {
                            if (!isProcessing) {
                                if (isListening) onStopListening() else onStartListening()
                            }
                        },
                        shape = CircleShape,
                        color = when {
                            isProcessing -> Color(0xFF059669)
                            isListening -> Color(0xFFEC4899)
                            else -> Color(0xFF6366F1)
                        },
                        shadowElevation = 10.dp,
                        modifier = Modifier.size(76.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 3.dp,
                                    modifier = Modifier.size(32.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                                    contentDescription = if (isListening) "Stop Listening" else "Speak Command",
                                    tint = Color.White,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = when {
                        isProcessing -> processingStatus.ifBlank { "Generating realistic output..." }
                        !hasUserPhoto -> "Please select a photo or open Camera first so Voice AI can place you in the scene"
                        isListening -> "Listening... Speak in Hindi or English"
                        else -> "Tap mic & speak your scene (Hindi / English)"
                    },
                    color = when {
                        isProcessing -> Color(0xFF34D399)
                        !hasUserPhoto -> Color(0xFFFBBF24)
                        isListening -> Color(0xFFF472B6)
                        else -> Color(0xFFCBD5E1)
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )

                if (!hasUserPhoto && !isProcessing) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onPickGalleryPhoto,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("voice_ai_pick_gallery_button")
                        ) {
                            Text("Gallery Photo", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Button(
                            onClick = onOpenCamera,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("voice_ai_open_camera_button")
                        ) {
                            Text("Camera Selfie", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                if (lastReplyMessage.isNotBlank() && !isProcessing) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF064E3B).copy(alpha = 0.65f),
                        border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.6f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "✦ $lastReplyMessage",
                            color = Color(0xFFA7F3D0),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }

                if (partialTranscript.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF1E293B),
                        border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Transcript",
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "\"$partialTranscript\"",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Command input box (useful as fallback or quick edit before running)
                OutlinedTextField(
                    value = typedCommand,
                    onValueChange = { typedCommand = it },
                    enabled = !isProcessing,
                    singleLine = true,
                    placeholder = {
                        Text(
                            text = "e.g., Paris 15s video with music",
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    },
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                if (!isProcessing && typedCommand.isNotBlank()) {
                                    onSubmitCommand(typedCommand.trim())
                                }
                            },
                            enabled = !isProcessing && typedCommand.isNotBlank(),
                            modifier = Modifier.testTag("voice_ai_submit_text_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Run Voice Command",
                                tint = if (typedCommand.isNotBlank()) Color(0xFF38BDF8) else Color(0xFF475569)
                            )
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            if (!isProcessing && typedCommand.isNotBlank()) {
                                onSubmitCommand(typedCommand.trim())
                            }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF1E293B),
                        unfocusedContainerColor = Color(0xFF1E293B)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("voice_ai_command_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Try One-Tap Voice Commands:",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    quickExamples.forEachIndexed { idx, sample ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0xFF475569)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(enabled = !isProcessing) {
                                    typedCommand = sample
                                    onSubmitCommand(sample)
                                }
                                .testTag("voice_ai_sample_$idx")
                        ) {
                            Text(
                                text = sample,
                                color = Color(0xFFE2E8F0),
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { if (isListening) onStopListening() else onStartListening() },
                        enabled = !isProcessing,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isListening) Color(0xFFBE185D) else Color(0xFF0284C7)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("voice_ai_listen_toggle_button")
                    ) {
                        Text(
                            text = if (isListening) "Stop Mic" else "🎤 Speak Now",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Button(
                        onClick = {
                            if (typedCommand.isNotBlank()) {
                                onSubmitCommand(typedCommand.trim())
                            } else {
                                onAutoCreate()
                            }
                        },
                        enabled = !isProcessing,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF059669),
                            disabledContainerColor = Color(0xFF334155)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("voice_ai_generate_button")
                    ) {
                        Text(
                            text = "✨ Auto Create",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

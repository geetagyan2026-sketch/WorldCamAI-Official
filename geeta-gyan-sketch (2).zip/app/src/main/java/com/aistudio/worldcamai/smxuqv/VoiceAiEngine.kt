package com.aistudio.worldcamai.smxuqv

import android.graphics.Bitmap
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

enum class VoiceOutputType {
    PHOTO,
    VIDEO_15S
}

enum class VoicePositionHint {
    AUTO,
    LEFT,
    CENTER,
    RIGHT
}

enum class VoiceSizeHint {
    AUTO,
    SMALL,
    MEDIUM,
    LARGE
}

enum class VoiceSceneMood {
    AUTO,
    SNOW,
    NIGHT,
    SUNSET,
    BEACH,
    DESERT,
    MOUNTAIN
}

data class ParsedVoiceCommand(
    val rawTranscript: String,
    val locationQuery: String,
    val displayLocation: String,
    val outputType: VoiceOutputType,
    val positionHint: VoicePositionHint,
    val sizeHint: VoiceSizeHint,
    val wantsMusic: Boolean,
    val sceneMood: VoiceSceneMood
)

data class VoiceAutoRealismPlan(
    val userScale: Float,
    val userXOffset: Float,
    val userYOffset: Float,
    val shadowDepth: Float,
    val environmentBlend: Float,
    val isCoolToneScene: Boolean,
    val summaryLabel: String
)

private val hindiToEnglishLocationTerms = linkedMapOf(
    "मनाली" to "Manali",
    "शिमला" to "Shimla",
    "ताजमहल" to "Taj Mahal",
    "ताज महल" to "Taj Mahal",
    "tajmahal" to "Taj Mahal",
    "पेरिस" to "Paris Eiffel Tower",
    "एफिल टॉवर" to "Eiffel Tower Paris",
    "एफिल टावर" to "Eiffel Tower Paris",
    "लंदन" to "London Big Ben",
    "दुबई" to "Dubai Burj Khalifa",
    "बुर्ज खलीफा" to "Burj Khalifa Dubai",
    "न्यूयॉर्क" to "New York Times Square",
    "टोक्यो" to "Tokyo",
    "जापान" to "Mount Fuji Japan",
    "माउंट फूजी" to "Mount Fuji Japan",
    "स्विट्जरलैंड" to "Swiss Alps Switzerland",
    "स्विट्ज़रलैंड" to "Swiss Alps Switzerland",
    "कश्मीर" to "Kashmir Dal Lake",
    "सोनमर्ग" to "Sonmarg Kashmir",
    "गुलमर्ग" to "Gulmarg snow Kashmir",
    "लद्दाख" to "Ladakh Pangong Lake",
    "लेह" to "Leh Ladakh",
    "जयपुर" to "Hawa Mahal Jaipur",
    "हवा महल" to "Hawa Mahal Jaipur",
    "जैसलमेर" to "Jaisalmer Thar Desert",
    "गोवा" to "Goa Beach",
    "केरल" to "Kerala Backwaters",
    "ऋषिकेश" to "Rishikesh Ganga",
    "हरिद्वार" to "Haridwar Har Ki Pauri",
    "वाराणसी" to "Varanasi Ghats",
    "बनारस" to "Varanasi Ghats",
    "मुंबई" to "Gateway of India Mumbai",
    "दिल्ली" to "India Gate Delhi",
    "इंडिया गेट" to "India Gate Delhi",
    "केदारनाथ" to "Kedarnath Temple snow",
    "बद्रीनाथ" to "Badrinath Temple",
    "उदयपुर" to "Udaipur Lake Palace",
    "जोधपुर" to "Mehrangarh Fort Jodhpur",
    "जल महल" to "Jal Mahal Jaipur",
    "आमेर" to "Amber Fort Jaipur",
    "जंतर मंतर" to "Jantar Mantar Jaipur",
    "कोटा" to "Kota Chambal Riverfront",
    "अयोध्या" to "Ayodhya Ram Mandir",
    "राम मंदिर" to "Ram Mandir Ayodhya",
    "गोल्डन टेम्पल" to "Golden Temple Amritsar",
    "स्वर्ण मंदिर" to "Golden Temple Amritsar",
    "लंदन ब्रिज" to "Tower Bridge London",
    "हम्पी" to "Hampi Karnataka",
    "आगरा" to "Taj Mahal Agra",
    "रोम" to "Colosseum Rome",
    "इटली" to "Colosseum Rome Italy",
    "मालदीव" to "Maldives beach",
    "बाली" to "Bali Indonesia",
    "सिंगापुर" to "Marina Bay Sands Singapore",
    "थाईलैंड" to "Thailand beach",
    "सैंटोरिनी" to "Santorini Greece",
    "ग्रीस" to "Santorini Greece",
    "बर्फ" to "snow",
    "बर्फीले" to "snow mountains",
    "पहाड़" to "mountains",
    "पहाड़ों" to "mountains",
    "पहाड़ों में" to "mountains",
    "रेगिस्तान" to "desert sand dunes",
    "समुद्र" to "ocean beach",
    "बीच" to "beach",
    "झील" to "lake",
    "नदी" to "river",
    "रात" to "night lights",
    "शाम" to "sunset",
    "सूरज" to "sunset"
)

private val hindiStopWords = setOf(
    "मेरी", "मेरा", "मेरे", "मुझे", "हमारी", "हमारा", "मैं", "मे", "में",
    "फोटो", "तस्वीर", "पिक्चर", "इमेज", "सेल्फी", "विडिओ", "वीडियो", "रील", "रिल",
    "का", "की", "के", "को", "से", "पर", "तक", "साथ", "वाला", "वाली",
    "बना", "बनाओ", "बनाई", "दो", "दीजिए", "कर", "करो", "करदो", "करना", "है", "हूं",
    "एक", "और", "या", "प्लीज", "ज़रा", "जरा", "अभी", "तुरंत", "अच्छी", "सुंदर", "रियल",
    "चाहिए", "लगा", "लगाओ", "डालो", "सामने", "तरफ",
    "गाना", "गाने", "म्यूजिक", "संगीत", "साउंड", "सॉन्ग",
    "बाएं", "बाएँ", "दाएं", "दाएँ", "बीच", "छोटा", "छोटी", "बड़ा", "बड़ी", "सेकंड", "सेकेंड",
    "meri", "mera", "mere", "mujhe", "photo", "selfie", "tasveer", "image", "pic", "picture",
    "video", "reel", "reels", "shorts", "15s", "15sec", "15", "second", "seconds", "sec",
    "ki", "ka", "ke", "ko", "mein", "me", "par", "pe", "se", "saath", "sath", "wali", "wala",
    "bana", "banao", "banado", "banaao", "banana", "do", "kar", "karo", "kardo", "please", "pls",
    "chahiye", "laga", "lagao", "dalo", "daalo", "samne", "saamne", "taraf",
    "gana", "gaana", "gaane", "gane", "music", "song", "audio", "track", "bgm", "beat",
    "create", "make", "generate", "put", "place", "blend", "edit", "render", "show",
    "a", "an", "the", "in", "at", "on", "to", "with", "and", "of", "for", "from", "by", "my",
    "left", "right", "center", "centre", "middle", "small", "smaller", "tiny", "big", "large", "larger", "close", "closeup",
    "side", "corner", "frame", "background", "bg", "location", "place"
)

/**
 * Simple phonetic Devanagari -> Latin transliterator so even rural towns / unlisted landmarks
 * spoken in Hindi script resolve cleanly via keyless real-world photo search.
 */
fun transliterateDevanagariToLatin(input: String): String {
    if (input.none { it in '\u0900'..'\u097F' }) return input
    val consonants = mapOf(
        '\u0915' to "k", '\u0916' to "kh", '\u0917' to "g", '\u0918' to "gh", '\u0919' to "ng",
        '\u091A' to "ch", '\u091B' to "chh", '\u091C' to "j", '\u091D' to "jh", '\u091E' to "ny",
        '\u091F' to "t", '\u0920' to "th", '\u0921' to "d", '\u0922' to "dh", '\u0923' to "n",
        '\u0924' to "t", '\u0925' to "th", '\u0926' to "d", '\u0927' to "dh", '\u0928' to "n",
        '\u092A' to "p", '\u092B' to "ph", '\u092C' to "b", '\u092D' to "bh", '\u092E' to "m",
        '\u092F' to "y", '\u0930' to "r", '\u0932' to "l", '\u0935' to "v", '\u0936' to "sh",
        '\u0937' to "sh", '\u0938' to "s", '\u0939' to "h",
        '\u095C' to "r", '\u095D' to "rh", '\u0958' to "q", '\u0959' to "kh",
        '\u095A' to "gh", '\u095B' to "z", '\u095E' to "f"
    )
    val vowels = mapOf(
        '\u0905' to "a", '\u0906' to "aa", '\u0907' to "i", '\u0908' to "ee", '\u0909' to "u", '\u090A' to "oo",
        '\u090F' to "e", '\u0910' to "ai", '\u0913' to "o", '\u0914' to "au", '\u090B' to "ri"
    )
    val matras = mapOf(
        '\u093E' to "a", '\u093F' to "i", '\u0940' to "i", '\u0941' to "u", '\u0942' to "u",
        '\u0947' to "e", '\u0948' to "ai", '\u094B' to "o", '\u094C' to "au", '\u0943' to "ri",
        '\u0902' to "n", '\u0901' to "n", '\u0903' to "h"
    )
    val virama = '\u094D'
    val nukta = '\u093C'

    val sb = StringBuilder()
    var i = 0
    while (i < input.length) {
        val ch = input[i]
        when {
            ch in consonants -> {
                var base = consonants[ch]!!
                val next = input.getOrNull(i + 1)
                if (next == nukta) {
                    base = when (ch) {
                        '\u091C' -> "z"
                        '\u092B' -> "f"
                        '\u0921' -> "r"
                        '\u0922' -> "rh"
                        '\u0915' -> "q"
                        else -> base
                    }
                    i++
                }
                sb.append(base)
                val after = input.getOrNull(i + 1)
                if (after == virama) {
                    i++ // suppress inherent 'a'
                } else if (after != null && after in matras) {
                    sb.append(matras[after])
                    i++
                } else if (after != null && (after in consonants || after in vowels)) {
                    sb.append('a')
                }
            }
            ch in vowels -> sb.append(vowels[ch])
            ch in matras -> sb.append(matras[ch])
            ch == virama || ch == nukta -> {}
            else -> sb.append(ch)
        }
        i++
    }
    return sb.toString()
}

fun parseVoiceAiCommand(transcript: String): ParsedVoiceCommand {
    val cleanRaw = transcript.trim()
    val lower = cleanRaw.lowercase()

    // 1. Output Type: Photo vs 15s Video
    val videoKeywords = listOf(
        "video", "15s", "15 sec", "15 second", "reel", "reels", "shorts", "clip",
        "वीडियो", "विडिओ", "रील", "रिल", "15 सेकंड", "15 सेकेंड", "moving"
    )
    val outputType = if (videoKeywords.any { lower.contains(it) }) {
        VoiceOutputType.VIDEO_15S
    } else {
        VoiceOutputType.PHOTO
    }

    // 2. Music Preference
    val musicKeywords = listOf(
        "music", "song", "songs", "audio", "bgm", "beat", "tune", "melody", "dance",
        "gana", "gaana", "gaane", "gane", "गाना", "गाने", "म्यूजिक", "संगीत", "सॉन्ग"
    )
    val wantsMusic = musicKeywords.any { lower.contains(it) }

    // 3. Position Hint (AUTO unless the user explicitly requested left / right / center)
    val positionHint = when {
        listOf("left", "बाएं", "बाएँ", "baye", "baayen", "baaye").any { lower.contains(it) } -> VoicePositionHint.LEFT
        listOf("right", "दाएं", "दाएँ", "daye", "daayen", "daaye").any { lower.contains(it) } -> VoicePositionHint.RIGHT
        listOf("center", "centre", "middle", "बीच में", "beech mein", "beech me").any { lower.contains(it) } -> VoicePositionHint.CENTER
        else -> VoicePositionHint.AUTO
    }

    // 4. Size Hint
    val sizeHint = when {
        listOf("small", "smaller", "tiny", "far", "distant", "छोटा", "छोटी", "chhota", "chota", "dur", "दूर").any { lower.contains(it) } -> VoiceSizeHint.SMALL
        listOf("large", "big", "bigger", "close", "closeup", "closer", "zoom", "बड़ा", "बड़ी", "bada", "badi", "paas", "पास").any { lower.contains(it) } -> VoiceSizeHint.LARGE
        listOf("medium", "normal", "default").any { lower.contains(it) } -> VoiceSizeHint.MEDIUM
        else -> VoiceSizeHint.AUTO
    }

    // 5. Scene Mood
    val sceneMood = when {
        listOf("snow", "ice", "winter", "glacier", "बर्फ", "बर्फीले", "barf", "manali", "gulmarg", "swiss").any { lower.contains(it) } -> VoiceSceneMood.SNOW
        listOf("night", "neon", "midnight", "evening lights", "रात", "raat", "tokyo", "times square").any { lower.contains(it) } -> VoiceSceneMood.NIGHT
        listOf("sunset", "golden", "dusk", "sunrise", "शाम", "shaam").any { lower.contains(it) } -> VoiceSceneMood.SUNSET
        listOf("beach", "ocean", "sea", "coast", "island", "समुद्र", "बीच", "goa", "maldives").any { lower.contains(it) } -> VoiceSceneMood.BEACH
        listOf("desert", "dunes", "sand", "रेगिस्तान", "thar", "jaisalmer", "dubai desert").any { lower.contains(it) } -> VoiceSceneMood.DESERT
        listOf("mountain", "hill", "peak", "valley", "पहाड़", "पहाड़ों", "pahad", "ladakh", "kashmir", "fuji").any { lower.contains(it) } -> VoiceSceneMood.MOUNTAIN
        else -> VoiceSceneMood.AUTO
    }

    // 6. Location Name Extraction (Translate known Hindi phrases first, then strip command filler words)
    var working = cleanRaw
    // Replace longer Hindi keys first
    val sortedDict = hindiToEnglishLocationTerms.entries.sortedByDescending { it.key.length }
    for ((hi, en) in sortedDict) {
        if (working.contains(hi, ignoreCase = true)) {
            working = working.replace(hi, " $en ", ignoreCase = true)
        }
    }

    // Split tokens, filter stop words, and transliterate any remaining Devanagari place names
    val rawTokens = working
        .replace(Regex("[,.;:!?\"'()\\[\\]{}]"), " ")
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }

    val keptTokens = mutableListOf<String>()
    for (tok in rawTokens) {
        val tokLower = tok.lowercase()
        if (tokLower in hindiStopWords) continue
        if (tokLower.matches(Regex("\\d+s?"))) continue
        val converted = if (tok.any { it in '\u0900'..'\u097F' }) {
            transliterateDevanagariToLatin(tok)
        } else {
            tok
        }
        val convLower = converted.lowercase().trim()
        if (convLower.isNotBlank() && convLower !in hindiStopWords) {
            keptTokens.add(converted.trim())
        }
    }

    // Deduplicate consecutive identical tokens (e.g. "Paris Paris" -> "Paris")
    val deduped = mutableListOf<String>()
    for (t in keptTokens) {
        if (deduped.lastOrNull()?.equals(t, ignoreCase = true) != true) {
            deduped.add(t)
        }
    }

    val extractedQuery = deduped.joinToString(" ").trim().ifBlank {
        when (sceneMood) {
            VoiceSceneMood.SNOW -> "Manali snow mountains"
            VoiceSceneMood.NIGHT -> "Tokyo night city"
            VoiceSceneMood.SUNSET -> "Santorini sunset"
            VoiceSceneMood.BEACH -> "Maldives tropical beach"
            VoiceSceneMood.DESERT -> "Sam Sand Dunes Jaisalmer"
            VoiceSceneMood.MOUNTAIN -> "Swiss Alps mountains"
            VoiceSceneMood.AUTO -> "Paris Eiffel Tower"
        }
    }

    val displayName = extractedQuery
        .split(" ")
        .filter { it.isNotBlank() }
        .joinToString(" ") { word ->
            word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }

    return ParsedVoiceCommand(
        rawTranscript = cleanRaw,
        locationQuery = extractedQuery,
        displayLocation = displayName,
        outputType = outputType,
        positionHint = positionHint,
        sizeHint = sizeHint,
        wantsMusic = wantsMusic,
        sceneMood = sceneMood
    )
}

fun computeSmartSurfacePlacement(
    bgBitmap: Bitmap?,
    locationName: String?,
    previewWidth: Float
): Pair<Float, Float> {
    if (bgBitmap == null || bgBitmap.isRecycled || bgBitmap.width < 32 || bgBitmap.height < 32) {
        return Pair(0f, 0.72f)
    }
    return try {
        val w = bgBitmap.width
        val h = bgBitmap.height
        val pW = previewWidth.coerceAtLeast(360f)
        val sideShift = (pW * 0.20f).coerceAtLeast(90f)

        val qLower = locationName.orEmpty().lowercase()
        val isReflectionPoolMonument = listOf(
            "taj mahal", "tajmahal", "jal mahal", "reflection", "reflecting pool",
            "fountain", "lotus pond", "india gate"
        ).any { qLower.contains(it) }
        val isWaterKeyword = isReflectionPoolMonument || listOf(
            "lake", "pool", "water", "river", "riverfront", "beach", "ocean", "sea",
            "ghat", "venice", "waterfall", "dam", "canal", "backwater"
        ).any { qLower.contains(it) }

        // Compute the visible horizontal crop window matching ContentScale.Crop portrait framing
        val bgAspect = w.toFloat() / h.toFloat().coerceAtLeast(1f)
        val visibleWidthFrac = (0.72f / bgAspect).coerceIn(0.40f, 1.0f)
        val visMinX = (0.5f - visibleWidthFrac * 0.5f).coerceIn(0f, 0.30f)
        val visMaxX = (0.5f + visibleWidthFrac * 0.5f).coerceIn(0.70f, 1f)
        val visSpan = (visMaxX - visMinX).coerceAtLeast(0.1f)

        val groundPlane = detectBackgroundGroundPlane(bgBitmap, qLower)
        val startY = (h * 0.62f).toInt().coerceIn(0, h - 2)
        val endY = (h * 0.96f).toInt().coerceIn(startY + 1, h - 1)
        val stepY = ((endY - startY) / 14).coerceAtLeast(1)
        val startX = (w * visMinX).toInt().coerceIn(0, w - 2)
        val endX = (w * visMaxX).toInt().coerceIn(startX + 1, w - 1)
        val stepX = ((endX - startX) / 36).coerceAtLeast(1)

        var leftWalkable = 0.0
        var centerWalkable = 0.0
        var rightWalkable = 0.0
        var leftCount = 0
        var centerCount = 0
        var rightCount = 0
        var centerHazardCount = 0

        for (y in startY until endY step stepY) {
            for (x in startX until (endX - stepX) step stepX) {
                val pixel = bgBitmap.getPixel(x, y)
                val r = (pixel ushr 16) and 0xFF
                val g = (pixel ushr 8) and 0xFF
                val b = pixel and 0xFF
                val lum = 0.299f * r + 0.587f * g + 0.114f * b
                val maxCh = maxOf(r, g, b)
                val minCh = minOf(r, g, b)
                val sat = if (maxCh > 0) (maxCh - minCh).toFloat() / maxCh.toFloat() else 0f

                val nextPx = bgBitmap.getPixel((x + stepX).coerceAtMost(w - 1), y)
                val nr = (nextPx ushr 16) and 0xFF
                val ng = (nextPx ushr 8) and 0xFF
                val nb = nextPx and 0xFF
                val edgeDiff = (abs(r - nr) + abs(g - ng) + abs(b - nb)) / 3f

                val downPx = bgBitmap.getPixel(x, (y + stepY).coerceAtMost(h - 1))
                val dr = (downPx ushr 16) and 0xFF
                val dg = (downPx ushr 8) and 0xFF
                val db = downPx and 0xFF
                val vertDiff = (abs(r - dr) + abs(g - dg) + abs(b - db)) / 3f

                // Detect water pools, teal lakes, bright specular reflections, sky/mid-air, and dark cliff drops
                val isBlueOrTealWater = (b > r + 12 && b >= g - 4) ||
                    (g > r + 10 && b > r + 6 && lum < 182f && edgeDiff < 10f)
                val isMirrorReflection = (lum > 188f && sat < 0.17f && b >= r - 2 && edgeDiff < 11f && vertDiff > edgeDiff * 1.15f)
                val isCliffOrVoid = lum < 18f
                val isAirOrHaze = (b > r + 8 && lum > 165f && edgeDiff < 6f)
                val isWaterOrHazard = isBlueOrTealWater || isMirrorReflection || isCliffOrVoid || isAirOrHaze

                val isSolidGround = !isWaterOrHazard && lum in 24f..228f
                val zoneScore = when {
                    isWaterOrHazard -> -1.35
                    isSolidGround && edgeDiff >= 4f -> 1.25
                    isSolidGround -> 0.85
                    else -> -0.30
                }

                val visRelX = ((x.toFloat() / w.toFloat()) - visMinX) / visSpan
                when {
                    visRelX in 0.06f..0.34f -> {
                        leftWalkable += zoneScore
                        leftCount++
                    }
                    visRelX in 0.35f..0.65f -> {
                        centerWalkable += zoneScore
                        centerCount++
                        if (isWaterOrHazard) centerHazardCount++
                    }
                    visRelX in 0.66f..0.94f -> {
                        rightWalkable += zoneScore
                        rightCount++
                    }
                }
            }
        }

        val leftAvg = if (leftCount > 0) leftWalkable / leftCount else 0.0
        val centerAvg = if (centerCount > 0) centerWalkable / centerCount else 0.0
        val rightAvg = if (rightCount > 0) rightWalkable / rightCount else 0.0
        val centerHazardRatio = if (centerCount > 0) centerHazardCount.toDouble() / centerCount else 0.0

        val avoidCenter = (isReflectionPoolMonument && (centerHazardRatio >= 0.08 || isWaterKeyword)) ||
            centerHazardRatio >= 0.20 ||
            (isWaterKeyword && (leftAvg > centerAvg + 0.06 || rightAvg > centerAvg + 0.06)) ||
            (maxOf(leftAvg, rightAvg) > centerAvg + 0.35)

        val bestXOffset = when {
            avoidCenter -> if (leftAvg >= rightAvg) -sideShift else +sideShift
            centerAvg >= leftAvg - 0.12 && centerAvg >= rightAvg - 0.12 -> 0f
            leftAvg >= rightAvg -> -sideShift
            else -> +sideShift
        }

        // Estimate realistic camera-perspective SIZE (0.50f..0.80f) from sky openness + horizon line + ground distance
        var upperSkyOrDistant = 0
        var upperTotal = 0
        val topEndY = (h * 0.55f).toInt().coerceAtLeast(2)
        val topStepY = (topEndY / 10).coerceAtLeast(1)
        for (y in 0 until topEndY step topStepY) {
            for (x in startX until endX step stepX) {
                val px = bgBitmap.getPixel(x, y)
                val r = (px ushr 16) and 0xFF
                val g = (px ushr 8) and 0xFF
                val b = px and 0xFF
                val lum = 0.299f * r + 0.587f * g + 0.114f * b
                if (lum > 148f && (b >= r - 10)) {
                    upperSkyOrDistant++
                }
                upperTotal++
            }
        }
        val opennessRatio = if (upperTotal > 0) upperSkyOrDistant.toFloat() / upperTotal.toFloat() else 0.4f
        val horizonFactor = groundPlane.horizonYRatio
        val perspectiveScale = when {
            isReflectionPoolMonument || opennessRatio > 0.60f || horizonFactor > 0.60f -> 0.60f
            opennessRatio > 0.44f || horizonFactor > 0.54f -> 0.66f
            opennessRatio > 0.26f -> 0.72f
            else -> 0.77f
        }.coerceIn(0.50f, 0.80f)

        Pair(bestXOffset, perspectiveScale)
    } catch (_: Throwable) {
        Pair(0f, 0.72f)
    }
}

/**
 * 100% Original Auto-Realism Calculator:
 * Computes human scale relative to background landmarks, scene lighting, cool/warm tint,
 * grounding offset, and contact 3D shadow depth from the live background bitmap.
 */
fun computeVoiceAutoRealism(
    bgBitmap: Bitmap?,
    command: ParsedVoiceCommand,
    sourceAnalysis: SourcePhotoAnalysis?,
    previewWidthPx: Float,
    previewHeightPx: Float,
    subjectBitmap: Bitmap? = null
): VoiceAutoRealismPlan {
    val bgLighting = analyzeVideoBackgroundLighting(bgBitmap)
    val sceneAdaptive = analyzeAnyBackgroundBitmap(
        bgBitmap = bgBitmap,
        landmarkFallbackName = command.locationQuery,
        isCoolToneFallback = command.sceneMood == VoiceSceneMood.SNOW || command.sceneMood == VoiceSceneMood.NIGHT
    )

    val smartPlacement = computeSmartSurfacePlacement(bgBitmap, command.locationQuery, previewWidthPx)
    val baseScale = smartPlacement.second

    val adjustedScale = when (command.sizeHint) {
        VoiceSizeHint.SMALL -> (baseScale * 0.78f).coerceIn(0.50f, 0.80f)
        VoiceSizeHint.LARGE -> (baseScale * 1.15f).coerceIn(0.50f, 0.80f)
        VoiceSizeHint.MEDIUM -> baseScale
        VoiceSizeHint.AUTO -> baseScale
    }.coerceIn(0.50f, 0.80f)

    val pW = previewWidthPx.coerceAtLeast(360f)
    val sideShift = (pW * 0.20f).coerceAtLeast(90f)
    val xOffset = when (command.positionHint) {
        VoicePositionHint.LEFT -> -sideShift
        VoicePositionHint.RIGHT -> +sideShift
        VoicePositionHint.CENTER -> 0f
        VoicePositionHint.AUTO -> smartPlacement.first
    }

    // Universal ground-lock: plant bottom-most shoe sole pixels directly onto detected background ground surface
    val footAnchor = if (subjectBitmap != null && !subjectBitmap.isRecycled) {
        detectSubjectFootAnchor(subjectBitmap)
    } else {
        SubjectFootAnchor()
    }
    val yOffset = computeGroundLockedUserYOffset(
        bgBitmap = bgBitmap,
        footAnchor = footAnchor,
        userScale = adjustedScale,
        previewHeightPx = previewHeightPx,
        landmarkName = command.locationQuery,
        surfaceSinkRatio = 0f
    )

    // Adaptive 3D Shadow intensity based on ambient brightness & mood
    val shadowDepth = when {
        command.sceneMood == VoiceSceneMood.NIGHT || bgLighting.avgBrightness < 0.28f -> 0.28f
        command.sceneMood == VoiceSceneMood.SNOW -> 0.38f
        bgLighting.avgBrightness > 0.62f -> 0.50f
        else -> 0.42f
    }

    val isCoolTone = when (command.sceneMood) {
        VoiceSceneMood.SNOW, VoiceSceneMood.NIGHT -> true
        VoiceSceneMood.SUNSET, VoiceSceneMood.DESERT -> false
        else -> bgLighting.warmth < -0.05f || sceneAdaptive.timeOfDay.contains("Snow", ignoreCase = true)
    }

    val envBlend = when (command.sceneMood) {
        VoiceSceneMood.SUNSET, VoiceSceneMood.DESERT -> 0.70f
        VoiceSceneMood.NIGHT -> 0.65f
        else -> if (bgLighting.avgBrightness > 0.50f) 0.62f else 0.58f
    }

    val posTag = when {
        xOffset < -30f -> "Left Walkway"
        xOffset > 30f -> "Right Walkway"
        else -> "Center Ground"
    }
    val toneTag = when {
        isCoolTone -> "Cool Ambient"
        bgLighting.warmth > 0.08f -> "Warm Sunlight"
        else -> "Natural Daylight"
    }
    return VoiceAutoRealismPlan(
        userScale = adjustedScale,
        userXOffset = xOffset,
        userYOffset = yOffset,
        shadowDepth = shadowDepth,
        environmentBlend = envBlend,
        isCoolToneScene = isCoolTone,
        summaryLabel = "${command.displayLocation} • $posTag (${(adjustedScale * 100).toInt()}%) • $toneTag"
    )
}

/**
 * Generates a clean 15-second warm stereo ambient travel soundtrack (.wav)
 * when the user requests "with music" via Voice AI without pre-selecting a custom MP3.
 */
fun generateAmbientTravelWav15s(outputFile: File): File {
    val sampleRate = 44100
    val channels = 2
    val durationSeconds = 15
    val totalSamples = sampleRate * durationSeconds
    val dataSize = totalSamples * channels * 2
    val byteRate = sampleRate * channels * 2

    // Warm uplifting travel progression (C - G - Am - F cycling smoothly)
    val chords = arrayOf(
        doubleArrayOf(261.63, 329.63, 392.00, 523.25), // Cmaj7 feel
        doubleArrayOf(196.00, 293.66, 392.00, 493.88), // G
        doubleArrayOf(220.00, 329.63, 440.00, 523.25), // Am
        doubleArrayOf(174.61, 261.63, 349.23, 440.00)  // F
    )

    FileOutputStream(outputFile).use { fos ->
        // Write 44-byte RIFF/WAVE header
        fun writeLeInt(v: Int) {
            fos.write(v and 0xFF)
            fos.write((v shr 8) and 0xFF)
            fos.write((v shr 16) and 0xFF)
            fos.write((v shr 24) and 0xFF)
        }
        fun writeLeShort(v: Int) {
            fos.write(v and 0xFF)
            fos.write((v shr 8) and 0xFF)
        }

        fos.write("RIFF".toByteArray(Charsets.US_ASCII))
        writeLeInt(36 + dataSize)
        fos.write("WAVE".toByteArray(Charsets.US_ASCII))
        fos.write("fmt ".toByteArray(Charsets.US_ASCII))
        writeLeInt(16) // PCM chunk size
        writeLeShort(1) // PCM format
        writeLeShort(channels)
        writeLeInt(sampleRate)
        writeLeInt(byteRate)
        writeLeShort(channels * 2) // block align
        writeLeShort(16) // bits per sample
        fos.write("data".toByteArray(Charsets.US_ASCII))
        writeLeInt(dataSize)

        val buffer = ByteArray(4096 * 4)
        var bufIdx = 0
        val bpm = 104.0
        val beatDur = 60.0 / bpm

        for (s in 0 until totalSamples) {
            val t = s.toDouble() / sampleRate.toDouble()
            val chordIdx = ((t / 3.75).toInt()).coerceIn(0, 3)
            val chord = chords[chordIdx]

            // Smooth global fade-in & fade-out
            val envIn = (t / 0.6).coerceIn(0.0, 1.0)
            val envOut = ((durationSeconds - t) / 0.8).coerceIn(0.0, 1.0)
            val masterEnv = envIn * envOut

            // Gentle plucked arpeggio + warm pad
            val chordLocalT = t % 3.75
            val pad = (
                0.30 * sin(2.0 * PI * chord[0] * t) +
                0.24 * sin(2.0 * PI * chord[1] * t) +
                0.20 * sin(2.0 * PI * chord[2] * t) +
                0.14 * sin(2.0 * PI * chord[3] * t + 0.35)
            ) * 0.45

            // Soft kick/pulse on quarter beats
            val beatPhase = (t % beatDur) / beatDur
            val kickEnv = exp(-beatPhase * 12.0)
            val kickFreq = 58.0 + 90.0 * exp(-beatPhase * 28.0)
            val kick = sin(2.0 * PI * kickFreq * beatPhase * beatDur) * kickEnv * 0.32

            // Gentle sparkle pluck every half beat
            val halfBeatPhase = (t % (beatDur * 0.5)) / (beatDur * 0.5)
            val arpNote = chord[((t / (beatDur * 0.5)).toInt()) % chord.size] * 2.0
            val arpEnv = exp(-halfBeatPhase * 7.5) * exp(-chordLocalT * 0.15)
            val arp = sin(2.0 * PI * arpNote * t) * arpEnv * 0.18

            val leftVal = ((pad + kick + arp * 0.85) * masterEnv * 14500.0).toInt().coerceIn(-32767, 32767)
            val rightVal = ((pad * 0.96 + kick + arp * 1.08) * masterEnv * 14500.0).toInt().coerceIn(-32767, 32767)

            buffer[bufIdx++] = (leftVal and 0xFF).toByte()
            buffer[bufIdx++] = ((leftVal shr 8) and 0xFF).toByte()
            buffer[bufIdx++] = (rightVal and 0xFF).toByte()
            buffer[bufIdx++] = ((rightVal shr 8) and 0xFF).toByte()

            if (bufIdx >= buffer.size) {
                fos.write(buffer, 0, bufIdx)
                bufIdx = 0
            }
        }
        if (bufIdx > 0) {
            fos.write(buffer, 0, bufIdx)
        }
    }
    return outputFile
}

@Composable
fun VoiceAiModalDialog(
    isListening: Boolean,
    isProcessing: Boolean,
    partialTranscript: String,
    processingStatus: String,
    languageTag: String,
    hasUserPhoto: Boolean = true,
    onPickGalleryPhoto: () -> Unit = {},
    onOpenCamera: () -> Unit = {},
    onToggleLanguage: () -> Unit,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    onSubmitCommand: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var typedCommand by remember(partialTranscript) { mutableStateOf(partialTranscript) }

    val pulseTransition = rememberInfiniteTransition(label = "voice_pulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isListening) 1.24f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "voice_orb_scale"
    )

    val quickExamples = remember {
        listOf(
            "मेरी फोटो मनाली की बर्फ में बना दो",
            "Create a 15s video in Paris with music",
            "ताजमहल के सामने बाएं तरफ 15s वीडियो गाने के साथ",
            "Mount Fuji sunset photo on right"
        )
    }

    Dialog(onDismissRequest = { if (!isProcessing) onDismiss() }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = BorderStroke(1.2.dp, Color(0xFF334155)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("voice_ai_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Voice AI",
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Voice AI Director",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            onClick = onToggleLanguage,
                            enabled = !isProcessing,
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.6f)),
                            modifier = Modifier.testTag("voice_ai_lang_toggle")
                        ) {
                            Text(
                                text = if (languageTag.startsWith("hi")) "🇮🇳 हिंदी / EN" else "🌐 English",
                                color = Color(0xFFBAE6FD),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }

                        IconButton(
                            onClick = { if (!isProcessing) onDismiss() },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("voice_ai_close_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Voice AI",
                                tint = Color(0xFF94A3B8)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Interactive Animated Microphone Orb
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(116.dp)
                        .testTag("voice_ai_mic_orb")
                ) {
                    Box(
                        modifier = Modifier
                            .size(104.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = if (isListening) {
                                        listOf(Color(0x66EC4899), Color(0x22A855F7), Color.Transparent)
                                    } else if (isProcessing) {
                                        listOf(Color(0x6610B981), Color(0x2238BDF8), Color.Transparent)
                                    } else {
                                        listOf(Color(0x4438BDF8), Color.Transparent)
                                    }
                                )
                            )
                    )

                    Surface(
                        onClick = {
                            if (!isProcessing) {
                                if (isListening) onStopListening() else onStartListening()
                            }
                        },
                        shape = CircleShape,
                        color = when {
                            isProcessing -> Color(0xFF059669)
                            isListening -> Color(0xFFEC4899)
                            else -> Color(0xFF6366F1)
                        },
                        shadowElevation = 10.dp,
                        modifier = Modifier.size(76.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 3.dp,
                                    modifier = Modifier.size(32.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                                    contentDescription = if (isListening) "Stop Listening" else "Speak Command",
                                    tint = Color.White,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = when {
                        isProcessing -> processingStatus.ifBlank { "Generating realistic output..." }
                        !hasUserPhoto -> "Please select a photo or open Camera first so Voice AI can place you in the scene"
                        isListening -> "Listening... Speak in Hindi or English"
                        else -> "Tap mic & speak your scene (Hindi / English)"
                    },
                    color = when {
                        isProcessing -> Color(0xFF34D399)
                        !hasUserPhoto -> Color(0xFFFBBF24)
                        isListening -> Color(0xFFF472B6)
                        else -> Color(0xFFCBD5E1)
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )

                if (!hasUserPhoto && !isProcessing) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onPickGalleryPhoto,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("voice_ai_pick_gallery_button")
                        ) {
                            Text("Gallery Photo", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Button(
                            onClick = onOpenCamera,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("voice_ai_open_camera_button")
                        ) {
                            Text("Camera Selfie", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                if (partialTranscript.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF1E293B),
                        border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Transcript",
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "\"$partialTranscript\"",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Command input box (useful as fallback or quick edit before running)
                OutlinedTextField(
                    value = typedCommand,
                    onValueChange = { typedCommand = it },
                    enabled = !isProcessing,
                    singleLine = true,
                    placeholder = {
                        Text(
                            text = "e.g., Paris 15s video with music",
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    },
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                if (!isProcessing && typedCommand.isNotBlank()) {
                                    onSubmitCommand(typedCommand.trim())
                                }
                            },
                            enabled = !isProcessing && typedCommand.isNotBlank(),
                            modifier = Modifier.testTag("voice_ai_submit_text_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Run Voice Command",
                                tint = if (typedCommand.isNotBlank()) Color(0xFF38BDF8) else Color(0xFF475569)
                            )
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            if (!isProcessing && typedCommand.isNotBlank()) {
                                onSubmitCommand(typedCommand.trim())
                            }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = Color(0xFF1E293B),
                        unfocusedContainerColor = Color(0xFF1E293B)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("voice_ai_command_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Try One-Tap Voice Commands:",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    quickExamples.forEachIndexed { idx, sample ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0xFF475569)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(enabled = !isProcessing) {
                                    typedCommand = sample
                                    onSubmitCommand(sample)
                                }
                                .testTag("voice_ai_sample_$idx")
                        ) {
                            Text(
                                text = sample,
                                color = Color(0xFFE2E8F0),
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { if (isListening) onStopListening() else onStartListening() },
                        enabled = !isProcessing,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isListening) Color(0xFFBE185D) else Color(0xFF0284C7)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("voice_ai_listen_toggle_button")
                    ) {
                        Text(
                            text = if (isListening) "Stop Mic" else "🎤 Speak Now",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Button(
                        onClick = {
                            if (typedCommand.isNotBlank()) {
                                onSubmitCommand(typedCommand.trim())
                            }
                        },
                        enabled = !isProcessing && typedCommand.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF059669),
                            disabledContainerColor = Color(0xFF334155)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("voice_ai_generate_button")
                    ) {
                        Text(
                            text = "✨ Auto Create",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

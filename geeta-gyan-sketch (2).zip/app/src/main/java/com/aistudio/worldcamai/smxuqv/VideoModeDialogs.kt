package com.aistudio.worldcamai.smxuqv

import android.media.MediaPlayer
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongPickerDialog(
    selectedSong: SelectedSongInfo?,
    onPickAudioClick: () -> Unit,
    onSelectOnlineTrack: (SelectedSongInfo) -> Unit = {},
    onUpdateStartTime: (Long) -> Unit,
    onClearSong: () -> Unit,
    onConfirmSong: (SelectedSongInfo) -> Unit = { _ -> },
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val keyboardController = LocalSoftwareKeyboardController.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var itunesQuery by remember { mutableStateOf("") }
    var isSearchingItunes by remember { mutableStateOf(false) }
    var hasSearchedItunes by remember { mutableStateOf(false) }
    var itunesResults by remember { mutableStateOf<List<ItunesSearchTrack>>(emptyList()) }

    var isPreviewPlaying by remember { mutableStateOf(false) }
    var playingTrackId by remember { mutableStateOf<String?>(null) }
    var playingIs30sItunes by remember { mutableStateOf(false) }
    var loadingTrackId by remember { mutableStateOf<String?>(null) }
    var onlineErrorMsg by remember { mutableStateOf<String?>(null) }
    var previewPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    val stopPreview = {
        try {
            previewPlayer?.stop()
        } catch (_: Throwable) {}
        try {
            previewPlayer?.release()
        } catch (_: Throwable) {}
        previewPlayer = null
        isPreviewPlaying = false
        playingTrackId = null
        playingIs30sItunes = false
    }

    val runItunesSearch: (String) -> Unit = { query ->
        val q = query.trim()
        if (q.isBlank()) {
            itunesResults = emptyList()
            hasSearchedItunes = false
            isSearchingItunes = false
        } else {
            isSearchingItunes = true
            onlineErrorMsg = null
            coroutineScope.launch {
                val results = searchItunesMusicTracks(q)
                if (itunesQuery.trim() == q) {
                    itunesResults = results
                    hasSearchedItunes = true
                    isSearchingItunes = false
                }
            }
        }
    }

    // Debounced live search when typing in the iTunes Search Bar
    LaunchedEffect(itunesQuery) {
        val q = itunesQuery.trim()
        if (q.isBlank()) {
            itunesResults = emptyList()
            hasSearchedItunes = false
            isSearchingItunes = false
            return@LaunchedEffect
        }
        if (q.length >= 2) {
            delay(450L)
            isSearchingItunes = true
            onlineErrorMsg = null
            val results = searchItunesMusicTracks(q)
            if (itunesQuery.trim() == q) {
                itunesResults = results
                hasSearchedItunes = true
                isSearchingItunes = false
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            stopPreview()
        }
    }

    // Auto-stop preview after 15s for trimmed clips or 30s for iTunes song previews
    LaunchedEffect(isPreviewPlaying, playingTrackId, playingIs30sItunes, selectedSong?.startTimeMs) {
        if (isPreviewPlaying || playingTrackId != null) {
            delay(if (playingIs30sItunes) 30_500L else 15_000L)
            stopPreview()
        }
    }

    ModalBottomSheet(
        onDismissRequest = {
            stopPreview()
            onDismiss()
        },
        sheetState = sheetState,
        containerColor = Color(0xFF0F172A),
        contentColor = Color.White,
        dragHandle = { BottomSheetDefaults.DragHandle(color = Color(0xFF475569)) },
        modifier = Modifier.testTag("song_picker_dialog")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Sheet Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = "Add Song",
                        tint = Color(0xFFF472B6),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Add Song (15s Reel Music)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
                IconButton(
                    onClick = {
                        stopPreview()
                        onDismiss()
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("close_song_picker_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Song Sheet",
                        tint = Color(0xFF94A3B8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 1. iTunes Song Search Bar at Top
            OutlinedTextField(
                value = itunesQuery,
                onValueChange = { itunesQuery = it },
                singleLine = true,
                placeholder = {
                    Text(
                        text = "Search any song (e.g. Kesariya, Arijit, Lofi)...",
                        color = Color(0xFF64748B),
                        fontSize = 12.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                leadingIcon = {
                    if (isSearchingItunes) {
                        CircularProgressIndicator(
                            color = Color(0xFF38BDF8),
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search Songs",
                            tint = Color(0xFF38BDF8)
                        )
                    }
                },
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (itunesQuery.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    itunesQuery = ""
                                    itunesResults = emptyList()
                                    hasSearchedItunes = false
                                    onlineErrorMsg = null
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .testTag("itunes_song_clear_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear Search",
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        TextButton(
                            onClick = {
                                keyboardController?.hide()
                                runItunesSearch(itunesQuery)
                            },
                            enabled = itunesQuery.isNotBlank() && !isSearchingItunes,
                            modifier = Modifier.testTag("itunes_song_search_button")
                        ) {
                            Text(
                                text = "Search",
                                color = if (itunesQuery.isNotBlank()) Color(0xFF38BDF8) else Color(0xFF475569),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        keyboardController?.hide()
                        runItunesSearch(itunesQuery)
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color(0xFF38BDF8),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedContainerColor = Color(0xFF1E293B),
                    unfocusedContainerColor = Color(0xFF1E293B)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("itunes_song_search_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 2. Choose from Phone Storage (Kept working identically)
            Button(
                onClick = {
                    stopPreview()
                    onPickAudioClick()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("pick_audio_file_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AudioFile,
                    contentDescription = "Choose from Phone Storage",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Choose from Phone Storage",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            // 3. Selected Song Card + 15-Second Start-Time Trimmer Slider
            if (selectedSong != null) {
                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.55f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = selectedSong.title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        val clipEndMs = (selectedSong.startTimeMs + 15_000L).coerceAtMost(selectedSong.durationMs)
                        Text(
                            text = "15s Clip: ${formatMillisToTime(selectedSong.startTimeMs)} → ${formatMillisToTime(clipEndMs)} (Total ${formatMillisToTime(selectedSong.durationMs)})",
                            color = Color(0xFF38BDF8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        val maxStartSec = ((selectedSong.durationMs - 15_000L).coerceAtLeast(0L) / 1000f)
                        if (maxStartSec > 0.2f) {
                            Text(
                                text = "Slide to pick 15s start time:",
                                color = Color(0xFFCBD5E1),
                                fontSize = 12.sp
                            )
                            Slider(
                                value = (selectedSong.startTimeMs / 1000f).coerceIn(0f, maxStartSec),
                                onValueChange = { newSec ->
                                    if (isPreviewPlaying) stopPreview()
                                    onUpdateStartTime((newSec * 1000f).toLong())
                                },
                                valueRange = 0f..maxStartSec,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("song_start_time_slider"),
                                colors = SliderDefaults.colors(
                                    thumbColor = Color(0xFFF472B6),
                                    activeTrackColor = Color(0xFFF472B6),
                                    inactiveTrackColor = Color(0xFF334155)
                                )
                            )
                        } else {
                            Text(
                                text = "Full track fits within 15s video",
                                color = Color(0xFF94A3B8),
                                fontSize = 11.5.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    if (isPreviewPlaying) {
                                        stopPreview()
                                    } else {
                                        try {
                                            stopPreview()
                                            val player = MediaPlayer().apply {
                                                setDataSource(context, selectedSong.uri)
                                                prepare()
                                                seekTo(selectedSong.startTimeMs.toInt())
                                                start()
                                                setOnCompletionListener { stopPreview() }
                                            }
                                            previewPlayer = player
                                            playingIs30sItunes = false
                                            isPreviewPlaying = true
                                        } catch (_: Throwable) {
                                            stopPreview()
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("preview_song_clip_button"),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, Color(0xFF38BDF8))
                            ) {
                                Icon(
                                    imageVector = if (isPreviewPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Preview 15s",
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isPreviewPlaying) "Stop" else "Preview 15s",
                                    color = Color(0xFF38BDF8),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    stopPreview()
                                    onClearSong()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("clear_song_button"),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, Color(0xFFF87171).copy(alpha = 0.7f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Remove Song",
                                    tint = Color(0xFFF87171),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Remove Song",
                                    color = Color(0xFFFCA5A5),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                stopPreview()
                                onConfirmSong(selectedSong)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("confirm_song_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Use This 15s Song ✓",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4. iTunes Search Results OR Online Trending Reel Music Header
            val showingItunesResults = itunesQuery.isNotBlank() || hasSearchedItunes
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (showingItunesResults) Icons.Default.Search else Icons.Default.CloudDownload,
                        contentDescription = if (showingItunesResults) "iTunes Search Results" else "Online Trending Reel Music",
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (showingItunesResults) "iTunes Search Results (30s Previews)" else "Online Trending Reel Music",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Text(
                    text = if (showingItunesResults) "${itunesResults.size} found" else "Stream & Cache",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            if (!onlineErrorMsg.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = onlineErrorMsg!!,
                    color = Color(0xFFFCA5A5),
                    fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (showingItunesResults) {
                if (isSearchingItunes && itunesResults.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color(0xFF38BDF8), modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Searching iTunes...", color = Color(0xFF94A3B8), fontSize = 12.sp)
                        }
                    }
                } else if (hasSearchedItunes && itunesResults.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No songs found for \"$itunesQuery\". Try another title or artist.",
                            color = Color(0xFF94A3B8),
                            fontSize = 12.5.sp
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 160.dp, max = 280.dp)
                            .testTag("itunes_search_results_list"),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(itunesResults, key = { it.trackId }) { track ->
                            val trackKey = "itunes_${track.trackId}"
                            val isSelectedTrack = selectedSong?.title?.startsWith(track.title, ignoreCase = true) == true
                            val isLoadingThis = loadingTrackId == trackKey
                            val isPlayingThis = playingTrackId == trackKey

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelectedTrack) Color(0xFF172554) else Color(0xFF1E293B),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelectedTrack) Color(0xFF38BDF8) else Color(0xFF334155)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (track.artworkUrl.isNotBlank()) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(context)
                                                .data(track.artworkUrl)
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = "${track.title} artwork",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                    }

                                    IconButton(
                                        onClick = {
                                            onlineErrorMsg = null
                                            if (isPlayingThis) {
                                                stopPreview()
                                            } else if (loadingTrackId == null) {
                                                stopPreview()
                                                loadingTrackId = trackKey
                                                coroutineScope.launch {
                                                    val fetched = fetchOrCacheItunesPreview(context, track)
                                                    loadingTrackId = null
                                                    if (fetched != null) {
                                                        try {
                                                            val player = MediaPlayer().apply {
                                                                setDataSource(context, fetched.uri)
                                                                prepare()
                                                                start()
                                                                setOnCompletionListener { stopPreview() }
                                                            }
                                                            previewPlayer = player
                                                            playingIs30sItunes = true
                                                            playingTrackId = trackKey
                                                        } catch (_: Throwable) {
                                                            stopPreview()
                                                            onlineErrorMsg = "Unable to play preview for ${track.title}"
                                                        }
                                                    } else {
                                                        onlineErrorMsg = "Could not load 30s preview for ${track.title}."
                                                    }
                                                }
                                            }
                                        },
                                        enabled = loadingTrackId == null || isLoadingThis,
                                        modifier = Modifier
                                            .size(48.dp)
                                            .testTag("preview_itunes_track_${track.trackId}")
                                    ) {
                                        if (isLoadingThis) {
                                            CircularProgressIndicator(
                                                color = Color(0xFF38BDF8),
                                                strokeWidth = 2.dp,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        } else {
                                            Icon(
                                                imageVector = if (isPlayingThis) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                contentDescription = if (isPlayingThis) "Stop 30s preview" else "Play 30s preview",
                                                tint = if (isPlayingThis) Color(0xFFF472B6) else Color(0xFF38BDF8)
                                            )
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = track.title,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "${track.artist} • 30s Preview",
                                            color = Color(0xFF94A3B8),
                                            fontSize = 11.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    Button(
                                        onClick = {
                                            onlineErrorMsg = null
                                            if (loadingTrackId == null) {
                                                stopPreview()
                                                loadingTrackId = trackKey
                                                coroutineScope.launch {
                                                    val fetched = fetchOrCacheItunesPreview(context, track)
                                                    loadingTrackId = null
                                                    if (fetched != null) {
                                                        onSelectOnlineTrack(fetched)
                                                    } else {
                                                        onlineErrorMsg = "Could not load ${track.title}. Check internet connection."
                                                    }
                                                }
                                            }
                                        },
                                        enabled = loadingTrackId == null,
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isSelectedTrack) Color(0xFF059669) else Color(0xFF0284C7)
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .defaultMinSize(minWidth = 64.dp, minHeight = 48.dp)
                                            .testTag("use_itunes_track_${track.trackId}")
                                    ) {
                                        if (isSelectedTrack) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = "Selected ${track.title}",
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        } else {
                                            Text(
                                                text = "Use",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp, max = 300.dp)
                        .testTag("online_trending_music_list"),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(ONLINE_TRENDING_REEL_TRACKS, key = { it.id }) { track ->
                        val isSelectedTrack = selectedSong?.title.equals(track.title, ignoreCase = true)
                        val isLoadingThis = loadingTrackId == track.id
                        val isPlayingThis = playingTrackId == track.id

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelectedTrack) Color(0xFF172554) else Color(0xFF1E293B),
                            border = BorderStroke(
                                1.dp,
                                if (isSelectedTrack) Color(0xFF38BDF8) else Color(0xFF334155)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = {
                                        onlineErrorMsg = null
                                        if (isPlayingThis) {
                                            stopPreview()
                                        } else if (loadingTrackId == null) {
                                            stopPreview()
                                            loadingTrackId = track.id
                                            coroutineScope.launch {
                                                val fetched = fetchOrCacheOnlineMusicTrack(context, track)
                                                loadingTrackId = null
                                                if (fetched != null) {
                                                    try {
                                                        val player = MediaPlayer().apply {
                                                            setDataSource(context, fetched.uri)
                                                            prepare()
                                                            start()
                                                            setOnCompletionListener { stopPreview() }
                                                        }
                                                        previewPlayer = player
                                                        playingIs30sItunes = false
                                                        playingTrackId = track.id
                                                    } catch (_: Throwable) {
                                                        stopPreview()
                                                        onlineErrorMsg = "Unable to play preview for ${track.title}"
                                                    }
                                                } else {
                                                    onlineErrorMsg = "Could not stream ${track.title}. Check internet connection."
                                                }
                                            }
                                        }
                                    },
                                    enabled = loadingTrackId == null || isLoadingThis,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("preview_online_track_${track.id}")
                                ) {
                                    if (isLoadingThis) {
                                        CircularProgressIndicator(
                                            color = Color(0xFF38BDF8),
                                            strokeWidth = 2.dp,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = if (isPlayingThis) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = if (isPlayingThis) "Stop ${track.title}" else "Preview ${track.title}",
                                            tint = if (isPlayingThis) Color(0xFFF472B6) else Color(0xFF38BDF8)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = track.title,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.5.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = Color(0xFF334155)
                                        ) {
                                            Text(
                                                text = track.moodTag,
                                                color = Color(0xFFBAE6FD),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = track.subtitle,
                                        color = Color(0xFF94A3B8),
                                        fontSize = 11.5.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Button(
                                    onClick = {
                                        onlineErrorMsg = null
                                        if (loadingTrackId == null) {
                                            stopPreview()
                                            loadingTrackId = track.id
                                            coroutineScope.launch {
                                                val fetched = fetchOrCacheOnlineMusicTrack(context, track)
                                                loadingTrackId = null
                                                if (fetched != null) {
                                                    onSelectOnlineTrack(fetched)
                                                } else {
                                                    onlineErrorMsg = "Could not download ${track.title}. Check internet connection."
                                                }
                                            }
                                        }
                                    },
                                    enabled = loadingTrackId == null,
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelectedTrack) Color(0xFF059669) else Color(0xFF0284C7)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .defaultMinSize(minWidth = 64.dp, minHeight = 48.dp)
                                        .testTag("use_online_track_${track.id}")
                                ) {
                                    if (isSelectedTrack) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected ${track.title}",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    } else {
                                        Text(
                                            text = "Use",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoPreviewDialog(
    videoFile: File,
    locationName: String,
    isSavingVideo: Boolean,
    onSaveToGallery: () -> Unit,
    onRetake: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF0F172A),
            border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f)),
            shadowElevation = 12.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .testTag("video_preview_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "🎥 15s Video Preview",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Preview",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                }

                Text(
                    text = locationName,
                    color = Color(0xFF38BDF8),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(360.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    AndroidView(
                        factory = { ctx ->
                            VideoView(ctx).apply {
                                val controller = MediaController(ctx)
                                controller.setAnchorView(this)
                                setMediaController(controller)
                                setVideoPath(videoFile.absolutePath)
                                setOnPreparedListener { mp ->
                                    mp.isLooping = true
                                    start()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onRetake,
                        enabled = !isSavingVideo,
                        modifier = Modifier
                            .weight(0.9f)
                            .height(48.dp)
                            .testTag("retake_video_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFF64748B))
                    ) {
                        Text(
                            text = "Retake",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }

                    Button(
                        onClick = onSaveToGallery,
                        enabled = !isSavingVideo,
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp)
                            .testTag("save_recorded_video_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isSavingVideo) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Saving...",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.SaveAlt,
                                contentDescription = "Save Video",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Save to Gallery 💾",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

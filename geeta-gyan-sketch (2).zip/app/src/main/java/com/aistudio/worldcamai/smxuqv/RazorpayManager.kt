package com.aistudio.worldcamai.smxuqv

import android.app.Activity
import android.util.Log
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import org.json.JSONObject

object RazorpayManager : PaymentResultListener {
    private const val RAZORPAY_KEY = "rzp_test_TxCUzrrE4fvc4lMJTEu1UXOa52k"

    fun startPayment(activity: Activity, plan: RechargePlan, isIndia: Boolean) {
        val checkout = Checkout()
        checkout.setKeyID(RAZORPAY_KEY)

        try {
            val options = JSONObject()
            options.put("name", "WorldCam AI")
            options.put("description", plan.title)
            options.put("currency", if (isIndia) "INR" else "USD")
            
            // Store SKU for plan activation
            options.put("notes", JSONObject().apply { put("sku", plan.sku) })
            
            // Convert to smallest currency unit (paise or cents)
            val amount = if (isIndia) plan.priceInr * 100 else (plan.priceUsd * 100).toInt()
            options.put("amount", amount)

            checkout.open(activity, options)
        } catch (e: Exception) {
            Log.e("RazorpayManager", "Error in payment: ${e.message}")
        }
    }

    override fun onPaymentSuccess(razorpayPaymentId: String?) {
        Log.d("RazorpayManager", "Payment Successful: $razorpayPaymentId")
        // Logic to activate the plan based on successful payment
        // Note: For production, this should be validated on the backend
    }

    override fun onPaymentError(code: Int, response: String?) {
        Log.e("RazorpayManager", "Payment Failed: $code - $response")
    }
}

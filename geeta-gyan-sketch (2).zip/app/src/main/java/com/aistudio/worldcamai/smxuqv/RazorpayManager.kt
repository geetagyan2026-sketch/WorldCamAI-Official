package com.aistudio.worldcamai.smxuqv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.telephony.TelephonyManager
import android.util.Log
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent
import java.util.Locale
import java.util.TimeZone

const val MERCHANT_DISPLAY_TITLE = "WorldCam AI"

data class RechargePlanItem(
    val title: String,
    val sku: String,
    val displayText: String,
    val priceInr: Int,
    val priceUsd: Double,
    val paymentUrl: String,
    val isIndiaPlan: Boolean = false,
    val merchantName: String = MERCHANT_DISPLAY_TITLE
)

object RazorpayManager {

    // Complete payment routing map mapping each SKU to its absolute production short-URL
    val PAYMENT_ROUTING_MAP = mapOf(
        // India Plans Production Links
        "india_5_photos" to "https://rzp.io/rzp/ebwNSjH",
        "india_13_photos" to "https://rzp.io/rzp/zQOBrCt",
        "india_15days_premium" to "https://rzp.io/rzp/wKIIcaZ",
        "india_1month_premium" to "https://rzp.io/rzp/txaaWyi",
        "india_watermark_unlock" to "https://rzp.io/rzp/q6tSCV8",
        "india_postcard_unlock" to "https://rzp.io/rzp/6khwDwD",

        // World Plans Production Links
        "world_5_photos" to "https://rzp.io/rzp/25yRR8d",
        "world_13_photos" to "https://rzp.io/rzp/atC87HP",
        "world_15days_premium" to "https://rzp.io/rzp/M0QdxN0d",
        "world_1month_premium" to "https://rzp.io/rzp/F1wKGxV",
        "world_watermark_unlock" to "https://rzp.io/rzp/gPUFEVSt",
        "world_postcard_unlock" to "https://rzp.io/rzp/K32UNo0s"
    )

    // 6 India Specific Plans
    val INDIA_PLANS = listOf(
        RechargePlanItem(
            title = "5 AI Photo Pack (India)",
            sku = "india_5_photos",
            displayText = "India: ₹10",
            priceInr = 10,
            priceUsd = 0.58,
            paymentUrl = "https://rzp.io/rzp/ebwNSjH",
            isIndiaPlan = true,
            merchantName = MERCHANT_DISPLAY_TITLE
        ),
        RechargePlanItem(
            title = "13 AI Photo Pack (India)",
            sku = "india_13_photos",
            displayText = "India: ₹19",
            priceInr = 19,
            priceUsd = 1.19,
            paymentUrl = "https://rzp.io/rzp/zQOBrCt",
            isIndiaPlan = true,
            merchantName = MERCHANT_DISPLAY_TITLE
        ),
        RechargePlanItem(
            title = "15 Days Premium Access (India)",
            sku = "india_15days_premium",
            displayText = "India: ₹49",
            priceInr = 49,
            priceUsd = 2.35,
            paymentUrl = "https://rzp.io/rzp/wKIIcaZ",
            isIndiaPlan = true,
            merchantName = MERCHANT_DISPLAY_TITLE
        ),
        RechargePlanItem(
            title = "1 Month Premium Access (India)",
            sku = "india_1month_premium",
            displayText = "India: ₹99",
            priceInr = 99,
            priceUsd = 3.54,
            paymentUrl = "https://rzp.io/rzp/txaaWyi",
            isIndiaPlan = true,
            merchantName = MERCHANT_DISPLAY_TITLE
        ),
        RechargePlanItem(
            title = "Watermark Unlock (India)",
            sku = "india_watermark_unlock",
            displayText = "India: ₹49",
            priceInr = 49,
            priceUsd = 2.35,
            paymentUrl = "https://rzp.io/rzp/q6tSCV8",
            isIndiaPlan = true,
            merchantName = MERCHANT_DISPLAY_TITLE
        ),
        RechargePlanItem(
            title = "Postcard Unlock (India)",
            sku = "india_postcard_unlock",
            displayText = "India: ₹29",
            priceInr = 29,
            priceUsd = 1.17,
            paymentUrl = "https://rzp.io/rzp/6khwDwD",
            isIndiaPlan = true,
            merchantName = MERCHANT_DISPLAY_TITLE
        )
    )

    // 6 World Specific Plans
    val WORLD_PLANS = listOf(
        RechargePlanItem(
            title = "5 AI Photo Pack (World)",
            sku = "world_5_photos",
            displayText = "World: ₹49",
            priceInr = 49,
            priceUsd = 0.58,
            paymentUrl = "https://rzp.io/rzp/25yRR8d",
            isIndiaPlan = false,
            merchantName = MERCHANT_DISPLAY_TITLE
        ),
        RechargePlanItem(
            title = "13 AI Photo Pack (World)",
            sku = "world_13_photos",
            displayText = "World: ₹100",
            priceInr = 100,
            priceUsd = 1.19,
            paymentUrl = "https://rzp.io/rzp/atC87HP",
            isIndiaPlan = false,
            merchantName = MERCHANT_DISPLAY_TITLE
        ),
        RechargePlanItem(
            title = "15 Days Premium Access (World)",
            sku = "world_15days_premium",
            displayText = "World: ₹199",
            priceInr = 199,
            priceUsd = 2.35,
            paymentUrl = "https://rzp.io/rzp/M0QdxN0d",
            isIndiaPlan = false,
            merchantName = MERCHANT_DISPLAY_TITLE
        ),
        RechargePlanItem(
            title = "1 Month Premium Access (World)",
            sku = "world_1month_premium",
            displayText = "World: ₹299",
            priceInr = 299,
            priceUsd = 3.54,
            paymentUrl = "https://rzp.io/rzp/F1wKGxV",
            isIndiaPlan = false,
            merchantName = MERCHANT_DISPLAY_TITLE
        ),
        RechargePlanItem(
            title = "Watermark Unlock (World)",
            sku = "world_watermark_unlock",
            displayText = "World: ₹199",
            priceInr = 199,
            priceUsd = 2.35,
            paymentUrl = "https://rzp.io/rzp/gPUFEVSt",
            isIndiaPlan = false,
            merchantName = MERCHANT_DISPLAY_TITLE
        ),
        RechargePlanItem(
            title = "Postcard Unlock (World)",
            sku = "world_postcard_unlock",
            displayText = "World: ₹99",
            priceInr = 99,
            priceUsd = 1.17,
            paymentUrl = "https://rzp.io/rzp/K32UNo0s",
            isIndiaPlan = false,
            merchantName = MERCHANT_DISPLAY_TITLE
        )
    )

    // 12 Official Pricing Plans (6 India Plans + 6 World Plans)
    val PLANS = INDIA_PLANS + WORLD_PLANS

    /**
     * Detects if device is in India using:
     * - SIM Country ISO ("in")
     * - Network Country ISO ("in")
     * - Device Timezone ID ("Asia/Kolkata" or "Asia/Calcutta")
     * - Locale country ("IN")
     */
    fun isDeviceIndiaLocale(context: Context? = null): Boolean {
        return try {
            // 1. Check Locale country
            val localeCountry = Locale.getDefault().country
            if (localeCountry.equals("IN", ignoreCase = true)) {
                return true
            }

            // 2. Check Device Timezone ID
            val tzId = TimeZone.getDefault().id
            if (tzId.equals("Asia/Kolkata", ignoreCase = true) || tzId.equals("Asia/Calcutta", ignoreCase = true)) {
                return true
            }

            // 3. Check SIM & Network Country ISO via Context
            if (context != null) {
                try {
                    val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
                    if (telephonyManager != null) {
                        val simCountry = telephonyManager.simCountryIso
                        if (!simCountry.isNullOrBlank() && simCountry.equals("in", ignoreCase = true)) {
                            return true
                        }
                        val netCountry = telephonyManager.networkCountryIso
                        if (!netCountry.isNullOrBlank() && netCountry.equals("in", ignoreCase = true)) {
                            return true
                        }
                    }
                } catch (_: Throwable) {}
            }

            false
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Dynamically filters plans so ONLY ONE section is visible:
     * Indian users get INDIA_PLANS, international users get WORLD_PLANS.
     */
    fun getRegionFilteredPlans(context: Context? = null): List<RechargePlanItem> {
        val isIndia = isDeviceIndiaLocale(context)
        return if (isIndia) INDIA_PLANS else WORLD_PLANS
    }

    /**
     * Unified Razorpay Hosted Payment Flow:
     * Overloaded methods to support starting payment with RechargePlanItem object, planSku string, or direct URL string.
     */
    fun startPayment(activity: Activity, plan: RechargePlanItem) {
        startPaymentUrl(activity, plan.paymentUrl)
    }

    fun startPayment(activity: Activity, planSku: String = "") {
        val targetUrl = PAYMENT_ROUTING_MAP[planSku] 
            ?: PLANS.find { it.sku == planSku }?.paymentUrl 
            ?: if (planSku.startsWith("http")) planSku else "https://rzp.io/rzp/ebwNSjH"
        startPaymentUrl(activity, targetUrl)
    }

    fun openCustomTab(context: Context, url: String) {
        val activity = context as? Activity
        if (activity != null) {
            startPaymentUrl(activity, url)
        } else {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Log.e("RazorpayManager", "Error opening custom tab url: ${e.message}")
            }
        }
    }

    private fun startPaymentUrl(activity: Activity, targetUrl: String) {
        val uri = Uri.parse(targetUrl)
        Log.d("RazorpayManager", "Opening official live hosted page for $MERCHANT_DISPLAY_TITLE: $targetUrl")
        try {
            val customTabsIntent = CustomTabsIntent.Builder()
                .setShowTitle(true)
                .build()
            customTabsIntent.launchUrl(activity, uri)
            Log.d("RazorpayManager", "Custom Tabs launched for $MERCHANT_DISPLAY_TITLE ($targetUrl)")
        } catch (e: Throwable) {
            Log.w("RazorpayManager", "Custom Tabs failed, falling back to External Browser: ${e.message}")
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                activity.startActivity(browserIntent)
                Log.d("RazorpayManager", "External Browser Intent launched for $MERCHANT_DISPLAY_TITLE ($targetUrl)")
            } catch (ex: Throwable) {
                Log.e("RazorpayManager", "Failed to launch browser: ${ex.message}", ex)
                Toast.makeText(activity, "Opening $MERCHANT_DISPLAY_TITLE payment: $targetUrl", Toast.LENGTH_LONG).show()
            }
        }
    }
}

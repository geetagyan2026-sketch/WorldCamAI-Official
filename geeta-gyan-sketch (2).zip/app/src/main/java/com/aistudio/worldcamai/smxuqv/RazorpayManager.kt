package com.aistudio.worldcamai.smxuqv

import android.app.Activity
import com.razorpay.Checkout
import org.json.JSONObject

object RazorpayManager {
    fun startPayment(activity: Activity, planId: String) {
        val checkout = Checkout()
        checkout.setKeyID("rzp_test_TxCUzrrE4fvc4lMJTEu1UXOa52k")
        
        val selectedAmount = when (planId) {
            "worldcam_5_photos" -> 1000
            "worldcam_13_photos" -> 1900
            "worldcam_15days_premium" -> 4900
            "worldcam_1month_premium" -> 9900
            else -> 1000
        }

        try {
            val options = JSONObject()
            options.put("name", "WorldCam AI")
            options.put("description", "Premium Plan Purchase")
            options.put("theme.color", "#3399cc")
            options.put("currency", "INR")
            options.put("amount", selectedAmount)

            val prefill = JSONObject()
            prefill.put("email", "customer@worldcam.ai")
            prefill.put("contact", "9876543210")
            options.put("prefill", prefill)

            checkout.open(activity, options)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

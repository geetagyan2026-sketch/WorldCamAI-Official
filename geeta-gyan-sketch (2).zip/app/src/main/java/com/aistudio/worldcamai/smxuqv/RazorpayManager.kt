package com.aistudio.worldcamai.smxuqv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent
import java.util.Locale

data class RechargePlanItem(
    val title: String,
    val sku: String,
    val displayText: String,
    val priceInr: Int,
    val priceUsd: Double,
    val paymentUrl: String,
    val isIndiaPlan: Boolean = false
)

object RazorpayManager {

    // Complete payment routing map mapping each SKU to its absolute production short-URL
    val PAYMENT_ROUTING_MAP = mapOf(
        // India Plans Production Links
        "india_5_photos" to "https://rzp.io/rzp/ebwNSjH",
        "india_13_photos" to "https://rzp.io/rzp/zQOBrCt",
        "india_15days_premium" to "https://rzp.io/rzp/wKIIcaZ",
        "india_1month_premium" to "https://rzp.io/rzp/txaaWyi",
        "india_watermark_unlock" to "https://rzp.io/rzp/q6tSCV8",
        "india_postcard_unlock" to "https://rzp.io/rzp/6khwDwD",

        // World Plans Production Links
        "world_5_photos" to "https://rzp.io/rzp/25yRR8d",
        "world_13_photos" to "https://rzp.io/rzp/atC87HP",
        "world_15days_premium" to "https://rzp.io/rzp/M0QdxN0d",
        "world_1month_premium" to "https://rzp.io/rzp/F1wKGxV",
        "world_watermark_unlock" to "https://rzp.io/rzp/gPUFEVSt",
        "world_postcard_unlock" to "https://rzp.io/rzp/K32UNo0s"
    )

    // 6 India Specific Plans
    val INDIA_PLANS = listOf(
        RechargePlanItem(
            title = "5 AI Photo Pack (India)",
            sku = "india_5_photos",
            displayText = "India: ₹10",
            priceInr = 10,
            priceUsd = 0.58,
            paymentUrl = "https://rzp.io/rzp/ebwNSjH",
            isIndiaPlan = true
        ),
        RechargePlanItem(
            title = "13 AI Photo Pack (India)",
            sku = "india_13_photos",
            displayText = "India: ₹19",
            priceInr = 19,
            priceUsd = 1.19,
            paymentUrl = "https://rzp.io/rzp/zQOBrCt",
            isIndiaPlan = true
        ),
        RechargePlanItem(
            title = "15 Days Premium Access (India)",
            sku = "india_15days_premium",
            displayText = "India: ₹49",
            priceInr = 49,
            priceUsd = 2.35,
            paymentUrl = "https://rzp.io/rzp/wKIIcaZ",
            isIndiaPlan = true
        ),
        RechargePlanItem(
            title = "1 Month Premium Access (India)",
            sku = "india_1month_premium",
            displayText = "India: ₹99",
            priceInr = 99,
            priceUsd = 3.54,
            paymentUrl = "https://rzp.io/rzp/txaaWyi",
            isIndiaPlan = true
        ),
        RechargePlanItem(
            title = "Watermark Unlock (India)",
            sku = "india_watermark_unlock",
            displayText = "India: ₹49",
            priceInr = 49,
            priceUsd = 2.35,
            paymentUrl = "https://rzp.io/rzp/q6tSCV8",
            isIndiaPlan = true
        ),
        RechargePlanItem(
            title = "Postcard Unlock (India)",
            sku = "india_postcard_unlock",
            displayText = "India: ₹29",
            priceInr = 29,
            priceUsd = 1.17,
            paymentUrl = "https://rzp.io/rzp/6khwDwD",
            isIndiaPlan = true
        )
    )

    // 6 World Specific Plans
    val WORLD_PLANS = listOf(
        RechargePlanItem(
            title = "5 AI Photo Pack (World)",
            sku = "world_5_photos",
            displayText = "World: ₹49",
            priceInr = 49,
            priceUsd = 0.58,
            paymentUrl = "https://rzp.io/rzp/25yRR8d",
            isIndiaPlan = false
        ),
        RechargePlanItem(
            title = "13 AI Photo Pack (World)",
            sku = "world_13_photos",
            displayText = "World: ₹100",
            priceInr = 100,
            priceUsd = 1.19,
            paymentUrl = "https://rzp.io/rzp/atC87HP",
            isIndiaPlan = false
        ),
        RechargePlanItem(
            title = "15 Days Premium Access (World)",
            sku = "world_15days_premium",
            displayText = "World: ₹199",
            priceInr = 199,
            priceUsd = 2.35,
            paymentUrl = "https://rzp.io/rzp/M0QdxN0d",
            isIndiaPlan = false
        ),
        RechargePlanItem(
            title = "1 Month Premium Access (World)",
            sku = "world_1month_premium",
            displayText = "World: ₹299",
            priceInr = 299,
            priceUsd = 3.54,
            paymentUrl = "https://rzp.io/rzp/F1wKGxV",
            isIndiaPlan = false
        ),
        RechargePlanItem(
            title = "Watermark Unlock (World)",
            sku = "world_watermark_unlock",
            displayText = "World: ₹199",
            priceInr = 199,
            priceUsd = 2.35,
            paymentUrl = "https://rzp.io/rzp/gPUFEVSt",
            isIndiaPlan = false
        ),
        RechargePlanItem(
            title = "Postcard Unlock (World)",
            sku = "world_postcard_unlock",
            displayText = "World: ₹99",
            priceInr = 99,
            priceUsd = 1.17,
            paymentUrl = "https://rzp.io/rzp/K32UNo0s",
            isIndiaPlan = false
        )
    )

    // 12 Official Pricing Plans (6 India Plans + 6 World Plans)
    val PLANS = INDIA_PLANS + WORLD_PLANS

    /**
     * Checks if the device's system locale country is India ("IN").
     * No runtime permissions or dynamic network tracking needed.
     */
    fun isDeviceIndiaLocale(): Boolean {
        return try {
            val country = Locale.getDefault().country
            country.equals("IN", ignoreCase = true)
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Dynamically filters plans based on whether user is in India or World.
     * Returns exactly 6 options.
     */
    fun getRegionFilteredPlans(isIndiaUser: Boolean = isDeviceIndiaLocale()): List<RechargePlanItem> {
        return if (isIndiaUser) INDIA_PLANS else WORLD_PLANS
    }

    /**
     * Unified Razorpay Hosted Payment Flow:
     * Overloaded methods to support starting payment with RechargePlanItem object, planSku string, or direct URL string.
     */
    fun startPayment(activity: Activity, plan: RechargePlanItem) {
        startPaymentUrl(activity, plan.paymentUrl)
    }

    fun startPayment(activity: Activity, planSku: String = "") {
        val targetUrl = PAYMENT_ROUTING_MAP[planSku] 
            ?: PLANS.find { it.sku == planSku }?.paymentUrl 
            ?: if (planSku.startsWith("http")) planSku else "https://rzp.io/rzp/ebwNSjH"
        startPaymentUrl(activity, targetUrl)
    }

    fun openCustomTab(context: Context, url: String) {
        val activity = context as? Activity
        if (activity != null) {
            startPaymentUrl(activity, url)
        } else {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Log.e("RazorpayManager", "Error opening custom tab url: ${e.message}")
            }
        }
    }

    private fun startPaymentUrl(activity: Activity, targetUrl: String) {
        val uri = Uri.parse(targetUrl)
        Log.d("RazorpayManager", "Opening official live hosted page: $targetUrl")
        try {
            val customTabsIntent = CustomTabsIntent.Builder()
                .setShowTitle(true)
                .build()
            customTabsIntent.launchUrl(activity, uri)
            Log.d("RazorpayManager", "Custom Tabs launched for $targetUrl")
        } catch (e: Throwable) {
            Log.w("RazorpayManager", "Custom Tabs failed, falling back to External Browser: ${e.message}")
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                activity.startActivity(browserIntent)
                Log.d("RazorpayManager", "External Browser Intent launched for $targetUrl")
            } catch (ex: Throwable) {
                Log.e("RazorpayManager", "Failed to launch browser: ${ex.message}", ex)
                Toast.makeText(activity, "Opening payment page: $targetUrl", Toast.LENGTH_LONG).show()
            }
        }
    }
}

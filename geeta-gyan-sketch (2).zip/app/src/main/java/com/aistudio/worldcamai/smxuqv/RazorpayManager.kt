package com.aistudio.worldcamai.smxuqv

import android.app.Activity
import android.util.Log
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import org.json.JSONObject

object RazorpayManager : PaymentResultListener {
    private const val RAZORPAY_KEY = "rzp_test_TxCUzrrE4fvc4lMJTEu1UXOa52k"

    fun startPayment(activity: Activity, plan: RechargePlan, isIndia: Boolean) {
        val checkout = Checkout()
        checkout.setKeyID(RAZORPAY_KEY)

        try {
            val options = JSONObject()
            options.put("name", "WorldCam AI")
            options.put("description", plan.title)
            options.put("currency", "INR") // Strictly INR
            
            // Convert to smallest currency unit (paise)
            val amount = plan.priceInr * 100
            options.put("amount", amount)

            val prefill = JSONObject()
            prefill.put("email", "test@example.com")
            prefill.put("contact", "9876543210")
            options.put("prefill", prefill)

            val retry = JSONObject()
            retry.put("enabled", true)
            retry.put("max_count", 4)
            options.put("retry", retry)
            
            // Store SKU
            options.put("notes", JSONObject().apply { put("sku", plan.sku) })

            checkout.open(activity, options)
        } catch (e: Exception) {
            Log.e("RazorpayManager", "Error in payment: ${e.message}")
        }
    }

    override fun onPaymentSuccess(razorpayPaymentId: String?) {
        Log.d("RazorpayManager", "Payment Successful: $razorpayPaymentId")
        // Logic to activate the plan based on successful payment
        // Note: For production, this should be validated on the backend
    }

    override fun onPaymentError(code: Int, response: String?) {
        Log.e("RazorpayManager", "Payment Failed: $code - $response")
    }
}

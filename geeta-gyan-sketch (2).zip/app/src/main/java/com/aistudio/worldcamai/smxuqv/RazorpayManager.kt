package com.aistudio.worldcamai.smxuqv

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent

object RazorpayManager {
    // Official Live Razorpay Credentials
    const val RAZORPAY_KEY_ID = "rzp_live_TxgMIu"
    const val RAZORPAY_KEY_SECRET = "Murur2vEHKSox7SgoqTOSva0"

    /**
     * Converts plan ID to price in paise (1 INR = 100 paise).
     * Strictly positive, never null or 0.
     */
    fun getAmountInPaise(planId: String): Int {
        return when (planId) {
            "worldcam_5_photos", "plan_5_photos" -> 10 * 100 // ₹10 = 1000 paise
            "worldcam_13_photos", "plan_13_photos" -> 19 * 100 // ₹19 = 1900 paise
            "worldcam_15days_premium", "worldcam_15_days", "plan_15_days" -> 49 * 100 // ₹49 = 4900 paise
            "worldcam_1month_premium", "worldcam_1_month", "plan_1_month" -> 99 * 100 // ₹99 = 9900 paise
            "worldcam_postcard_unlock", "plan_postcard_unlock" -> 49 * 100 // ₹49 = 4900 paise
            else -> 10 * 100 // Default fallback ₹10 = 1000 paise
        }
    }

    fun getPlanDescription(planId: String): String {
        return when (planId) {
            "worldcam_5_photos", "plan_5_photos" -> "5 AI Photos Pack"
            "worldcam_13_photos", "plan_13_photos" -> "13 AI Photos Pack"
            "worldcam_15days_premium", "worldcam_15_days", "plan_15_days" -> "15 Days Premium Access"
            "worldcam_1month_premium", "worldcam_1_month", "plan_1_month" -> "1 Month Premium Access"
            "worldcam_postcard_unlock", "plan_postcard_unlock" -> "Permanent Watermark Removal"
            else -> "WorldCam AI Premium Plan"
        }
    }

    /**
     * Builds the official Razorpay Hosted Payment URL with all required query parameters:
     * - key_id: Live Razorpay key
     * - amount: Transaction amount in paise (1 INR = 100 paise)
     * - amount_in_rupees: Transaction amount in rupees
     * - currency: Explicitly "INR"
     * - description: Plan title/description
     * - name: Business name
     * - prefill: User contact and email
     */
    fun buildPaymentUrl(planId: String): String {
        val amountInPaise = getAmountInPaise(planId)
        val amountInRupees = amountInPaise / 100
        val description = getPlanDescription(planId)

        val encodedDesc = Uri.encode(description)
        val encodedName = Uri.encode("WorldCam AI")
        val encodedEmail = Uri.encode("customer@worldcam.ai")
        val contact = "9876543210"

        return "https://pages.razorpay.com/worldcam-recharge" +
                "?key_id=$RAZORPAY_KEY_ID" +
                "&amount=$amountInPaise" +
                "&amount_in_rupees=$amountInRupees" +
                "&currency=INR" +
                "&name=$encodedName" +
                "&description=$encodedDesc" +
                "&prefill_email=$encodedEmail" +
                "&prefill_contact=$contact"
    }

    /**
     * Opens the secure payment gateway using Chrome Custom Tabs or an External Browser Intent.
     * This avoids all in-app WebView sandbox restrictions and lets the user pay safely
     * using UPI, Card, Netbanking, or Wallets in a full browser environment.
     */
    fun startPayment(activity: Activity, planId: String) {
        val paymentUrl = buildPaymentUrl(planId)
        val uri = Uri.parse(paymentUrl)

        Log.d("RazorpayManager", "Opening payment gateway for plan $planId: $paymentUrl")

        try {
            // Priority 1: Chrome Custom Tab for secure, in-app browser experience
            val customTabsIntent = CustomTabsIntent.Builder()
                .setShowTitle(true)
                .build()
            customTabsIntent.launchUrl(activity, uri)
            Log.d("RazorpayManager", "Successfully launched Chrome Custom Tab")
        } catch (e: Throwable) {
            Log.w("RazorpayManager", "Custom Tabs unavailable, falling back to external browser intent: ${e.message}")
            try {
                // Priority 2: External Browser Intent fallback
                val browserIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                activity.startActivity(browserIntent)
                Log.d("RazorpayManager", "Successfully launched External Browser Intent")
            } catch (ex: Throwable) {
                Log.e("RazorpayManager", "Failed to launch external browser intent: ${ex.message}", ex)
                Toast.makeText(activity, "Unable to open payment link: ${ex.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }
}

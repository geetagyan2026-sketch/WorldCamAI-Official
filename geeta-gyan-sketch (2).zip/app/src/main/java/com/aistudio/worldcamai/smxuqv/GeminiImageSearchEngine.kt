package com.aistudio.worldcamai.smxuqv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

data class DirectSearchFetchResult(
    val place: GooglePlaceResult?,
    val bitmap: Bitmap?,
    val errorMessage: String? = null,
    val angleIndex: Int = 0,
    val totalAngles: Int = 0
)

/**
 * Keyless Real-World Camera Photo Fetcher (Zero API keys, Zero HTTP 429 quota limits).
 *
 * Strategy:
 * 1. Formats every query as:
 *    `<LOCATION_NAME> exterior street view real tourist camera photo daylight -thumbnail -poster -banner -text -youtube -logo -drone -illustration`
 * 2. Primary: Queries Bing Image Search (`bing.com/images/async?q=...&first=1&count=10&adlt=strict`)
 *    with desktop Chrome User-Agent and extracts genuine `murl` photo URLs.
 * 3. Secondary Backup: Queries DuckDuckGo Image Search (`duckduckgo.com` -> `vqd` -> `duckduckgo.com/i.js`)
 *    if Bing yields insufficient valid results.
 * 4. Strictly blocks banners, YouTube thumbnails, stock watermarks, SVGs, GIFs, and images < 700px wide.
 * 5. Caches up to 6 clean camera-angle URLs per location + in-memory ARGB_8888 Bitmap LruCache
 *    so repeat searches and 1-tap "Next Photo" angle switching are instantaneous.
 */
object GeminiImageSearchEngine {
    private const val CHROME_USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private const val DOWNLOAD_USER_AGENT = "Mozilla/5.0"

    private const val MIN_PHOTO_WIDTH_PX = 700
    private const val MIN_PHOTO_HEIGHT_PX = 400
    private const val MAX_CACHED_ANGLES_PER_LOCATION = 6
    private const val MAX_IMAGE_BYTES = 12 * 1024 * 1024

    private data class LocationAnglesEntry(
        val urls: MutableList<String>,
        var currentIndex: Int = 0
    )

    private val locationAnglesCache = ConcurrentHashMap<String, LocationAnglesEntry>()

    private val maxCacheKb: Int = run {
        val maxAppKb = (Runtime.getRuntime().maxMemory() / 1024L).toInt()
        (maxAppKb / 8).coerceIn(10 * 1024, 28 * 1024)
    }

    private val bitmapCache = object : LruCache<String, Bitmap>(maxCacheKb) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return (value.allocationByteCount / 1024).coerceAtLeast(1)
        }
    }

    private val validImageExtRegex = Regex("""\.(jpe?g|png|webp)(\?.*|#.*)?$""", RegexOption.IGNORE_CASE)
    private val bingMurlRegex = Regex("""["']murl["']\s*:\s*["'](https?://[^"']+)["']""", RegexOption.IGNORE_CASE)
    private val ddgVqdRegex = Regex("""(?:vqd\s*=\s*["']?|["']vqd["']\s*:\s*["'])([0-9]+-[0-9A-Za-z_-]+)""")

    private val strictlyBlockedSubstrings = listOf(
        "ytimg.com",
        "youtube.com",
        "youtu.be",
        "istockphoto",
        "shutterstock",
        "dreamstime",
        "alamy",
        "vecteezy",
        "freepik",
        "pinterest",
        "gettyimages",
        "123rf",
        "depositphotos",
        "banner",
        "poster",
        "thumb",
        ".svg",
        ".gif",
        ".ico",
        ".html",
        ".htm",
        ".php",
        ".asp",
        ".aspx",
        ".pdf",
        "bing.com/th",
        "mm.bing.net",
        "duckduckgo.com/iu",
        "google.com/url",
        "google.com/search",
        "google.com/imgres",
        "favicon",
        "sprite",
        "placeholder",
        "default-avatar",
        "logo"
    )

    private fun normalizeCacheKey(query: String): String {
        return query.trim().lowercase().replace(Regex("\\s+"), " ")
    }

    private fun buildRealWorldSearchQuery(locationName: String): String {
        val clean = locationName.trim()
        return "$clean exterior street view real tourist camera photo daylight -thumbnail -poster -banner -text -youtube -logo -drone -illustration"
    }

    private fun unescapeBingHtml(raw: String): String {
        return raw
            .replace("&quot;", "\"")
            .replace("&#34;", "\"")
            .replace("&apos;", "'")
            .replace("&#39;", "'")
            .replace("&amp;", "&")
            .replace("&#38;", "&")
            .replace("&#x2F;", "/")
            .replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("\\u003d", "=")
    }

    private fun isAllowedRealPhotoUrl(url: String): Boolean {
        val lower = url.lowercase().trim()
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) return false
        if (strictlyBlockedSubstrings.any { lower.contains(it) }) return false
        return validImageExtRegex.containsMatchIn(lower)
    }

    private fun openConnectionFollowingRedirects(
        initialUrl: String,
        userAgent: String,
        acceptHeader: String,
        referer: String? = null
    ): Pair<HttpURLConnection, String>? {
        var currentUrl = initialUrl
        for (hop in 0 until 5) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 4000
                readTimeout = 4500
                requestMethod = "GET"
                setRequestProperty("User-Agent", userAgent)
                setRequestProperty("Accept", acceptHeader)
                setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                if (!referer.isNullOrBlank()) {
                    setRequestProperty("Referer", referer)
                }
            }
            val code = conn.responseCode
            if (code in 300..399) {
                val location = conn.getHeaderField("Location")?.trim().orEmpty()
                conn.disconnect()
                if (location.isBlank()) return null
                currentUrl = try {
                    URL(URL(currentUrl), location).toString()
                } catch (_: Throwable) {
                    return null
                }
                continue
            }
            return conn to currentUrl
        }
        return null
    }

    private fun readHttpText(url: String, userAgent: String, acceptHeader: String, referer: String? = null): String? {
        var conn: HttpURLConnection? = null
        return try {
            val opened = openConnectionFollowingRedirects(url, userAgent, acceptHeader, referer) ?: return null
            conn = opened.first
            if (conn.responseCode !in 200..299) return null
            val maxBytes = 650 * 1024
            val baos = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            conn.inputStream.use { stream ->
                var total = 0
                while (total < maxBytes) {
                    val read = stream.read(buf, 0, minOf(buf.size, maxBytes - total))
                    if (read <= 0) break
                    baos.write(buf, 0, read)
                    total += read
                }
            }
            baos.toString(Charsets.UTF_8.name())
        } catch (t: Throwable) {
            android.util.Log.w("RealPhotoSearch", "HTTP text fetch failed for $url: ${t.message}")
            null
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun fetchBingDirectImageUrls(locationName: String): List<String> {
        val fullQuery = buildRealWorldSearchQuery(locationName)
        val encodedQuery = URLEncoder.encode(fullQuery, "UTF-8")
        val bingUrl = "https://www.bing.com/images/async?q=$encodedQuery&first=1&count=10&adlt=strict"
        val html = readHttpText(
            url = bingUrl,
            userAgent = CHROME_USER_AGENT,
            acceptHeader = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            referer = "https://www.bing.com/"
        ) ?: return emptyList()

        val decodedHtml = unescapeBingHtml(html)
        val candidates = mutableListOf<String>()
        for (match in bingMurlRegex.findAll(decodedHtml)) {
            val rawUrl = match.groupValues[1].trim()
            if (isAllowedRealPhotoUrl(rawUrl)) {
                candidates.add(rawUrl)
            }
        }
        return candidates.distinct()
    }

    private fun fetchDuckDuckGoDirectImageUrls(locationName: String): List<String> {
        val fullQuery = buildRealWorldSearchQuery(locationName)
        val encodedQuery = URLEncoder.encode(fullQuery, "UTF-8")
        val landingUrl = "https://duckduckgo.com/?q=$encodedQuery&iax=images&ia=images"
        val landingHtml = readHttpText(
            url = landingUrl,
            userAgent = CHROME_USER_AGENT,
            acceptHeader = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        ) ?: return emptyList()

        val vqdMatch = ddgVqdRegex.find(landingHtml) ?: return emptyList()
        val vqdToken = vqdMatch.groupValues[1].trim()
        if (vqdToken.isBlank()) return emptyList()

        val apiUrl = "https://duckduckgo.com/i.js?q=$encodedQuery&o=json&vqd=${URLEncoder.encode(vqdToken, "UTF-8")}"
        val jsonText = readHttpText(
            url = apiUrl,
            userAgent = CHROME_USER_AGENT,
            acceptHeader = "application/json, text/javascript, */*; q=0.01",
            referer = "https://duckduckgo.com/"
        ) ?: return emptyList()

        return try {
            val root = JSONObject(jsonText)
            val results = root.optJSONArray("results") ?: return emptyList()
            val candidates = mutableListOf<String>()
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val width = item.optInt("width", 0)
                if (width in 1 until MIN_PHOTO_WIDTH_PX) continue
                val imageUrl = item.optString("image", "").trim()
                if (isAllowedRealPhotoUrl(imageUrl)) {
                    candidates.add(imageUrl)
                }
            }
            candidates.distinct()
        } catch (t: Throwable) {
            android.util.Log.w("RealPhotoSearch", "DuckDuckGo JSON parse failed: ${t.message}")
            emptyList()
        }
    }

    private fun validateAndDecodeImageBitmap(imageUrl: String): Bitmap? {
        if (!isAllowedRealPhotoUrl(imageUrl)) return null

        val cached = synchronized(bitmapCache) { bitmapCache.get(imageUrl) }
        if (cached != null && !cached.isRecycled) {
            try {
                return cached.copy(Bitmap.Config.ARGB_8888, true)
            } catch (_: Throwable) {}
        }

        var activeConn: HttpURLConnection? = null
        return try {
            val opened = openConnectionFollowingRedirects(
                initialUrl = imageUrl,
                userAgent = DOWNLOAD_USER_AGENT,
                acceptHeader = "image/webp,image/jpeg,image/png,image/*;q=0.8"
            ) ?: return null
            activeConn = opened.first
            val finalUrl = opened.second
            val code = activeConn.responseCode
            if (code !in 200..299) return null
            if (!isAllowedRealPhotoUrl(finalUrl)) return null

            val mime = activeConn.contentType.orEmpty().lowercase()
            if (mime.contains("text/html") ||
                mime.contains("application/xhtml") ||
                mime.contains("svg") ||
                mime.contains("gif")
            ) {
                return null
            }
            if (!mime.startsWith("image/") && !validImageExtRegex.containsMatchIn(finalUrl)) {
                return null
            }

            val baos = ByteArrayOutputStream()
            val buf = ByteArray(16384)
            activeConn.inputStream.use { stream ->
                var total = 0
                while (total < MAX_IMAGE_BYTES) {
                    val read = stream.read(buf, 0, minOf(buf.size, MAX_IMAGE_BYTES - total))
                    if (read <= 0) break
                    baos.write(buf, 0, read)
                    total += read
                }
            }
            val bytes = baos.toByteArray()
            if (bytes.size < 6144) return null

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            // Strict quality filter: require width >= 700px
            if (bounds.outWidth < MIN_PHOTO_WIDTH_PX || bounds.outHeight < MIN_PHOTO_HEIGHT_PX) {
                return null
            }

            val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
            val sample = if (maxDim > 1600) (maxDim / 1440).coerceAtLeast(1) else 1
            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inMutable = true
            }
            val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts) ?: return null
            val finalMutable = if (decoded.config != Bitmap.Config.ARGB_8888 || !decoded.isMutable) {
                decoded.copy(Bitmap.Config.ARGB_8888, true)
            } else {
                decoded
            }

            try {
                val cacheCopy = finalMutable.copy(Bitmap.Config.ARGB_8888, false)
                if (cacheCopy != null) {
                    synchronized(bitmapCache) { bitmapCache.put(imageUrl, cacheCopy) }
                }
            } catch (_: Throwable) {}

            finalMutable
        } catch (t: Throwable) {
            android.util.Log.w("RealPhotoSearch", "Image download/decode failed for $imageUrl: ${t.message}")
            null
        } finally {
            try { activeConn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun buildPlaceResult(
        cleanQuery: String,
        imageUrl: String,
        angleIndex: Int,
        totalAngles: Int
    ): GooglePlaceResult {
        val angleSuffix = if (totalAngles > 1) "Angle ${angleIndex + 1}/$totalAngles" else "Street-Level Daylight"
        return GooglePlaceResult(
            placeId = "webimg_${cleanQuery.hashCode()}",
            name = cleanQuery,
            formattedAddress = "$cleanQuery • $angleSuffix",
            photoUrl = imageUrl,
            exactPhotoUrl = imageUrl,
            description = "Authentic eye-level daylight camera photograph of $cleanQuery.",
            funFact = "Blended with automatic daylight color sync and 3D ground contact shadow."
        )
    }

    fun getCachedAngleCount(query: String): Int {
        val key = normalizeCacheKey(query)
        return locationAnglesCache[key]?.urls?.size ?: 0
    }

    suspend fun fetchDirectPhotoAndBitmap(
        context: Context,
        query: String
    ): DirectSearchFetchResult = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) {
            return@withContext DirectSearchFetchResult(null, null, "Please enter a location name.")
        }

        val cacheKey = normalizeCacheKey(cleanQuery)
        val existingEntry = locationAnglesCache[cacheKey]
        if (existingEntry != null && existingEntry.urls.isNotEmpty()) {
            val idx = existingEntry.currentIndex.coerceIn(0, existingEntry.urls.lastIndex)
            val cachedUrl = existingEntry.urls[idx]
            val cachedBmp = synchronized(bitmapCache) { bitmapCache.get(cachedUrl) }
            if (cachedBmp != null && !cachedBmp.isRecycled) {
                val safeCopy = try {
                    cachedBmp.copy(Bitmap.Config.ARGB_8888, true)
                } catch (_: Throwable) {
                    null
                }
                if (safeCopy != null) {
                    val place = buildPlaceResult(cleanQuery, cachedUrl, idx, existingEntry.urls.size)
                    return@withContext DirectSearchFetchResult(place, safeCopy, null, idx, existingEntry.urls.size)
                }
            }
        }

        val collectedUrls = linkedSetOf<String>()

        // 1. Primary: Keyless Bing Image Search (fast, count=10)
        val bingUrls = withTimeoutOrNull(5000L) {
            fetchBingDirectImageUrls(cleanQuery)
        }.orEmpty()
        collectedUrls.addAll(bingUrls)

        // Try downloading the first valid high-res photo immediately for ~1s load
        var winningUrl: String? = null
        var winningBitmap: Bitmap? = null
        val failedUrls = mutableSetOf<String>()

        for (candidate in bingUrls) {
            val bmp = withTimeoutOrNull(4500L) { validateAndDecodeImageBitmap(candidate) }
            if (bmp != null && !bmp.isRecycled) {
                winningUrl = candidate
                winningBitmap = bmp
                break
            } else {
                failedUrls.add(candidate)
            }
        }

        // 2. Secondary Backup: Keyless DuckDuckGo Image Search if Bing had fewer than 2 clean options or failed
        if (winningBitmap == null || collectedUrls.size < MAX_CACHED_ANGLES_PER_LOCATION) {
            if (winningBitmap == null) {
                val ddgUrls = withTimeoutOrNull(6000L) {
                    fetchDuckDuckGoDirectImageUrls(cleanQuery)
                }.orEmpty()
                collectedUrls.addAll(ddgUrls)
                for (candidate in ddgUrls) {
                    if (candidate in failedUrls) continue
                    val bmp = withTimeoutOrNull(4500L) { validateAndDecodeImageBitmap(candidate) }
                    if (bmp != null && !bmp.isRecycled) {
                        winningUrl = candidate
                        winningBitmap = bmp
                        break
                    } else {
                        failedUrls.add(candidate)
                    }
                }
            }
        }

        if (winningUrl != null && winningBitmap != null && !winningBitmap.isRecycled) {
            // Build top-6 clean candidate URL list starting with verified winningUrl
            val top6 = mutableListOf(winningUrl)
            for (u in collectedUrls) {
                if (top6.size >= MAX_CACHED_ANGLES_PER_LOCATION) break
                if (u != winningUrl && u !in failedUrls) {
                    top6.add(u)
                }
            }
            locationAnglesCache[cacheKey] = LocationAnglesEntry(urls = top6, currentIndex = 0)
            val place = buildPlaceResult(cleanQuery, winningUrl, 0, top6.size)
            return@withContext DirectSearchFetchResult(place, winningBitmap, null, 0, top6.size)
        }

        // Strict No-Fake-Fallback: never return unrelated preset forest/mountain imagery
        DirectSearchFetchResult(
            place = null,
            bitmap = null,
            errorMessage = "No real daylight photo found for \"$cleanQuery\". Please check internet connection."
        )
    }

    /**
     * 1-Tap "Next Photo" Angle Switcher:
     * Cycles through up to 6 cached real-world camera angles for the searched location.
     * Automatically tops up from DuckDuckGo if only 1 Bing URL was cached.
     */
    suspend fun fetchNextAnglePhoto(
        context: Context,
        query: String
    ): DirectSearchFetchResult = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) {
            return@withContext DirectSearchFetchResult(null, null, "No active location selected.")
        }

        val cacheKey = normalizeCacheKey(cleanQuery)
        var entry = locationAnglesCache[cacheKey]

        if (entry == null || entry.urls.isEmpty()) {
            val initial = fetchDirectPhotoAndBitmap(context, cleanQuery)
            entry = locationAnglesCache[cacheKey]
            if (entry == null || entry.urls.size <= 1) {
                return@withContext initial
            }
        }

        // Top up from Bing / DuckDuckGo if we currently have <= 1 cached URL
        if (entry.urls.size <= 1) {
            val extraBing = withTimeoutOrNull(4500L) { fetchBingDirectImageUrls(cleanQuery) }.orEmpty()
            val extraDdg = if (extraBing.size <= 2) {
                withTimeoutOrNull(5500L) { fetchDuckDuckGoDirectImageUrls(cleanQuery) }.orEmpty()
            } else emptyList()
            for (u in (extraBing + extraDdg)) {
                if (entry.urls.size >= MAX_CACHED_ANGLES_PER_LOCATION) break
                if (u !in entry.urls) entry.urls.add(u)
            }
        }

        if (entry.urls.size <= 1) {
            val onlyUrl = entry.urls.firstOrNull()
            val bmp = onlyUrl?.let { validateAndDecodeImageBitmap(it) }
            if (onlyUrl != null && bmp != null) {
                val place = buildPlaceResult(cleanQuery, onlyUrl, 0, 1)
                return@withContext DirectSearchFetchResult(place, bmp, null, 0, 1)
            }
            return@withContext DirectSearchFetchResult(null, null, "Only one angle available for \"$cleanQuery\".")
        }

        val totalBefore = entry.urls.size
        var probeIdx = (entry.currentIndex + 1) % totalBefore
        val badUrls = mutableListOf<String>()

        for (step in 0 until totalBefore) {
            val candidateUrl = entry.urls[probeIdx]
            val bmp = withTimeoutOrNull(4500L) { validateAndDecodeImageBitmap(candidateUrl) }
            if (bmp != null && !bmp.isRecycled) {
                if (badUrls.isNotEmpty()) {
                    entry.urls.removeAll(badUrls.toSet())
                    probeIdx = entry.urls.indexOf(candidateUrl).coerceAtLeast(0)
                }
                entry.currentIndex = probeIdx
                val place = buildPlaceResult(cleanQuery, candidateUrl, probeIdx, entry.urls.size)
                return@withContext DirectSearchFetchResult(place, bmp, null, probeIdx, entry.urls.size)
            } else {
                badUrls.add(candidateUrl)
            }
            probeIdx = (probeIdx + 1) % totalBefore
        }

        entry.urls.removeAll(badUrls.toSet())
        DirectSearchFetchResult(
            place = null,
            bitmap = null,
            errorMessage = "Could not load another camera angle for \"$cleanQuery\"."
        )
    }

    suspend fun searchAndFetchPhoto(query: String): GooglePlaceResult? = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) return@withContext null

        val cacheKey = normalizeCacheKey(cleanQuery)
        val entry = locationAnglesCache[cacheKey]
        if (entry != null && entry.urls.isNotEmpty()) {
            val idx = entry.currentIndex.coerceIn(0, entry.urls.lastIndex)
            return@withContext buildPlaceResult(cleanQuery, entry.urls[idx], idx, entry.urls.size)
        }

        val bingUrls = withTimeoutOrNull(5000L) { fetchBingDirectImageUrls(cleanQuery) }.orEmpty()
        for (candidate in bingUrls) {
            val bmp = withTimeoutOrNull(4500L) { validateAndDecodeImageBitmap(candidate) }
            if (bmp != null && !bmp.isRecycled) {
                val top6 = (listOf(candidate) + bingUrls.filter { it != candidate }).take(MAX_CACHED_ANGLES_PER_LOCATION).toMutableList()
                locationAnglesCache[cacheKey] = LocationAnglesEntry(top6, 0)
                return@withContext buildPlaceResult(cleanQuery, candidate, 0, top6.size)
            }
        }

        val ddgUrls = withTimeoutOrNull(6000L) { fetchDuckDuckGoDirectImageUrls(cleanQuery) }.orEmpty()
        for (candidate in ddgUrls) {
            val bmp = withTimeoutOrNull(4500L) { validateAndDecodeImageBitmap(candidate) }
            if (bmp != null && !bmp.isRecycled) {
                val top6 = (listOf(candidate) + ddgUrls.filter { it != candidate }).take(MAX_CACHED_ANGLES_PER_LOCATION).toMutableList()
                locationAnglesCache[cacheKey] = LocationAnglesEntry(top6, 0)
                return@withContext buildPlaceResult(cleanQuery, candidate, 0, top6.size)
            }
        }
        null
    }
}

package com.aistudio.worldcamai.smxuqv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.sqrt

data class DirectSearchFetchResult(
    val place: GooglePlaceResult?,
    val bitmap: Bitmap?,
    val errorMessage: String? = null,
    val angleIndex: Int = 0,
    val totalAngles: Int = 0
)

/**
 * Keyless Ground-Level Real-World Camera Photo Fetcher (Zero API keys, Zero HTTP 429 limits).
 *
 * Strategy:
 * 1. Auto-corrects common location spelling typos & disambiguates iconic landmarks before searching
 *    (e.g., "hagigig bridge" -> "Hanging Bridge Kota", "jal mhal" -> "Jal Mahal Jaipur", "taj mhal" -> "Taj Mahal Agra").
 * 2. Formats every search strictly for ground-level photos:
 *    `<CORRECTED_LOCATION_NAME> ground level road walkway tourist camera photo -drone -aerial -birdseye -topview -helicopter`
 * 3. Extracts structured image candidates (URL, title, description, source webpage URL) from Bing & DuckDuckGo,
 *    verifies core landmark keyword matches (preventing unrelated foreign buildings), and blocks drone/aerial terms.
 * 4. Checks the bottom 25% of decoded Bitmaps so only photos with genuine ground/road/walkway footing pass.
 * 5. Caches up to 6 verified camera angles per corrected location + Bitmap LruCache for instant "Next Photo" switching.
 */
object GeminiImageSearchEngine {
    private const val CHROME_USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private const val DOWNLOAD_USER_AGENT = "Mozilla/5.0"

    private const val MIN_PHOTO_WIDTH_PX = 700
    private const val MIN_PHOTO_HEIGHT_PX = 400
    private const val MAX_CACHED_ANGLES_PER_LOCATION = 5
    private const val MAX_IMAGE_BYTES = 12 * 1024 * 1024

    private data class ImageSearchCandidate(
        val imageUrl: String,
        val title: String = "",
        val description: String = "",
        val sourcePageUrl: String = ""
    )

    private data class GroundSuitabilityResult(
        val isStrictGroundLevel: Boolean,
        val isSafeNonAerialBorderline: Boolean,
        val groundScore: Int
    )

    private data class VerifiedAngleCandidate(
        val url: String,
        val isStrictGroundLevel: Boolean,
        val totalScore: Int
    )

    private data class LocationAnglesEntry(
        val urls: MutableList<String>,
        var currentIndex: Int = 0
    )

    private val locationAnglesCache = ConcurrentHashMap<String, LocationAnglesEntry>()

    private val maxCacheKb: Int = run {
        val maxAppKb = (Runtime.getRuntime().maxMemory() / 1024L).toInt()
        (maxAppKb / 8).coerceIn(10 * 1024, 28 * 1024)
    }

    private val bitmapCache = object : LruCache<String, Bitmap>(maxCacheKb) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return (value.allocationByteCount / 1024).coerceAtLeast(1)
        }
    }

    private val validImageExtRegex = Regex("""\.(jpe?g|png|webp)(\?.*|#.*)?$""", RegexOption.IGNORE_CASE)
    private val bingCardMetaRegex = Regex("""\bm\s*=\s*"(\{.*?\})"""")
    private val bingMurlRegex = Regex("""["']murl["']\s*:\s*["'](https?://[^"']+)["']""", RegexOption.IGNORE_CASE)
    private val ddgVqdRegex = Regex("""(?:vqd\s*=\s*["']?|["']vqd["']\s*:\s*["'])([0-9]+-[0-9A-Za-z_-]+)""")

    private val strictlyBlockedSubstrings = listOf(
        "ytimg.com",
        "youtube.com",
        "youtu.be",
        "istockphoto",
        "shutterstock",
        "dreamstime",
        "alamy",
        "vecteezy",
        "freepik",
        "pinterest",
        "gettyimages",
        "123rf",
        "depositphotos",
        "banner",
        "poster",
        "thumb",
        ".svg",
        ".gif",
        ".ico",
        ".html",
        ".htm",
        ".php",
        ".asp",
        ".aspx",
        ".pdf",
        "bing.com/th",
        "mm.bing.net",
        "duckduckgo.com/iu",
        "google.com/url",
        "google.com/search",
        "google.com/imgres",
        "favicon",
        "sprite",
        "placeholder",
        "default-avatar",
        "logo",
        "drone",
        "droneshot",
        "aerial",
        "birdseye",
        "birds-eye",
        "bird_eye",
        "birdeye",
        "top-view",
        "topview",
        "top_view",
        "top-down",
        "topdown",
        "top_down",
        "helicopter",
        "chopper",
        "uav",
        "quadcopter",
        "mavic",
        "fpv",
        "skydio",
        "satellite",
        "google-earth",
        "google_earth",
        "landsat",
        "overhead",
        "from-above",
        "from_above",
        "high-angle",
        "high_angle",
        "high-altitude",
        "skyview",
        "sky-view",
        "flyover",
        "overflight",
        "clipart",
        "vector",
        "illustration",
        "infographic",
        "diagram",
        "floorplan",
        "blueprint",
        "wallpaper",
        "collage"
    )

    private val droneBlockedMetaTerms = listOf(
        "drone",
        "droneshot",
        "drone shot",
        "drone view",
        "drone photo",
        "drone footage",
        "aerial",
        "aerial view",
        "aerial shot",
        "aerial photo",
        "bird's eye",
        "bird's-eye",
        "birds eye",
        "birds-eye",
        "birdseye",
        "bird-eye",
        "bird_eye",
        "bird eye",
        "top-view",
        "top view",
        "topview",
        "top_view",
        "top-down",
        "top down",
        "topdown",
        "top_down",
        "helicopter",
        "chopper",
        "uav",
        "fpv",
        "from above",
        "seen from above",
        "view from above",
        "from the air",
        "from sky",
        "in the air",
        "airborne",
        "overhead",
        "overhead view",
        "satellite",
        "satellite view",
        "google earth",
        "landsat",
        "sentinel",
        "high altitude",
        "high-altitude",
        "high angle",
        "high-angle",
        "looking down",
        "nadir",
        "orthophoto",
        "flyover",
        "overflight",
        "airplane view",
        "plane view",
        "flight view",
        "window seat",
        "rooftop view",
        "from rooftop",
        "observation deck",
        "hot air balloon",
        "mavic",
        "phantom",
        "quadcopter",
        "skydio",
        "clipart",
        "vector",
        "illustration",
        "infographic",
        "diagram",
        "floor plan",
        "floorplan",
        "collage",
        "3d render",
        "wallpaper"
    )

    private val aerialCompoundRegex = Regex(
        """\b(aerial\w*|drone\w*|birds?[\s_-]?eye\w*|top[\s_-]?(down|view)|overhead\w*|from[\s_-]?above|sky[\s_-]?view\w*|high[\s_-]?(altitude|angle)|quadcopter|mavic|uav|helicopter\w*|satellite\w*|rooftop[\s_-]?view)\b""",
        RegexOption.IGNORE_CASE
    )

    private val exactPhraseCorrections = mapOf(
        "hagigig bridge" to "Hanging Bridge Kota",
        "hagiging bridge" to "Hanging Bridge Kota",
        "hangig bridge" to "Hanging Bridge Kota",
        "haging bridge" to "Hanging Bridge Kota",
        "hangging bridge" to "Hanging Bridge Kota",
        "hanging brig" to "Hanging Bridge Kota",
        "hanging bridg" to "Hanging Bridge Kota",
        "kota bridge" to "Hanging Bridge Kota",
        "jal mhal" to "Jal Mahal Jaipur",
        "jalmhal" to "Jal Mahal Jaipur",
        "jal mehal" to "Jal Mahal Jaipur",
        "taj mhal" to "Taj Mahal Agra",
        "tajmhal" to "Taj Mahal Agra",
        "tajmahal" to "Taj Mahal Agra",
        "taj mehal" to "Taj Mahal Agra",
        "taaj mahal" to "Taj Mahal Agra",
        "hawa mhal" to "Hawa Mahal Jaipur",
        "hawamhal" to "Hawa Mahal Jaipur",
        "hawa mehal" to "Hawa Mahal Jaipur",
        "amer fot" to "Amer Fort Jaipur",
        "amber fot" to "Amer Fort Jaipur",
        "city palac udaipur" to "City Palace Udaipur",
        "udaypur city palace" to "City Palace Udaipur",
        "chambal river front" to "Chambal Riverfront Kota",
        "chambal revarfront" to "Chambal Riverfront Kota",
        "kota riverfront" to "Chambal Riverfront Kota",
        "kota river front" to "Chambal Riverfront Kota",
        "7 wonders kota" to "Seven Wonders Park Kota",
        "seven wondar kota" to "Seven Wonders Park Kota",
        "qutab minar" to "Qutub Minar Delhi",
        "kutub minar" to "Qutub Minar Delhi",
        "india gat" to "India Gate Delhi",
        "red fot" to "Red Fort Delhi",
        "lal qila" to "Red Fort Delhi",
        "lal kila" to "Red Fort Delhi",
        "char minar" to "Charminar Hyderabad",
        "getway of india" to "Gateway of India Mumbai",
        "gateway of inda" to "Gateway of India Mumbai",
        "golden templ" to "Golden Temple Amritsar",
        "eifel tower" to "Eiffel Tower Paris",
        "effel tower" to "Eiffel Tower Paris",
        "eiffle tower" to "Eiffel Tower Paris",
        "ifil tower" to "Eiffel Tower Paris",
        "burj khlifa" to "Burj Khalifa Dubai",
        "burj kalifa" to "Burj Khalifa Dubai",
        "statu of liberty" to "Statue of Liberty New York",
        "statue of librty" to "Statue of Liberty New York",
        "machu pichu" to "Machu Picchu Peru",
        "tower bridg" to "Tower Bridge London"
    )

    private val tokenTypoDictionary = mapOf(
        "hagigig" to "hanging",
        "hagiging" to "hanging",
        "hangig" to "hanging",
        "hangin" to "hanging",
        "haging" to "hanging",
        "hangging" to "hanging",
        "brig" to "bridge",
        "bridg" to "bridge",
        "brdge" to "bridge",
        "brij" to "bridge",
        "mhal" to "mahal",
        "mhla" to "mahal",
        "mehal" to "mahal",
        "mahall" to "mahal",
        "mahel" to "mahal",
        "taaj" to "taj",
        "jall" to "jal",
        "hawaa" to "hawa",
        "eifel" to "eiffel",
        "effel" to "eiffel",
        "eiffle" to "eiffel",
        "ifil" to "eiffel",
        "tawer" to "tower",
        "towar" to "tower",
        "towr" to "tower",
        "fot" to "fort",
        "frt" to "fort",
        "palac" to "palace",
        "palce" to "palace",
        "templ" to "temple",
        "tempel" to "temple",
        "mander" to "mandir",
        "riverfrnt" to "riverfront",
        "revarfront" to "riverfront",
        "rivarfront" to "riverfront",
        "rivrfront" to "riverfront",
        "chambel" to "chambal",
        "chmbal" to "chambal",
        "jaipr" to "jaipur",
        "jaypur" to "jaipur",
        "udaypur" to "udaipur",
        "jaislmer" to "jaisalmer",
        "jaiselmer" to "jaisalmer",
        "varansi" to "varanasi",
        "banaras" to "varanasi",
        "coloseum" to "colosseum",
        "coliseum" to "colosseum",
        "khlifa" to "khalifa",
        "kalifa" to "khalifa",
        "librty" to "liberty",
        "statu" to "statue",
        "charminr" to "charminar",
        "charmeanr" to "charminar",
        "wondar" to "wonders",
        "mountan" to "mountain",
        "desrt" to "desert",
        "santorni" to "santorini",
        "pichu" to "picchu"
    )

    private val landmarkVocabWords = listOf(
        "hanging", "bridge", "mahal", "palace", "fort", "temple", "mandir", "tower",
        "gate", "gateway", "garden", "park", "riverfront", "lake", "beach", "desert",
        "safari", "waterfall", "museum", "colosseum", "eiffel", "liberty", "statue",
        "khalifa", "minar", "qutub", "charminar", "wonders", "chambal",
        "kota", "jaipur", "agra", "delhi", "udaipur", "jaisalmer", "mumbai", "hyderabad",
        "varanasi", "amritsar", "rajasthan", "paris", "london", "rome", "dubai", "tokyo"
    )

    private val defaultLandmarkCities = mapOf(
        "hanging bridge" to "Hanging Bridge Kota",
        "jal mahal" to "Jal Mahal Jaipur",
        "taj mahal" to "Taj Mahal Agra",
        "hawa mahal" to "Hawa Mahal Jaipur",
        "amer fort" to "Amer Fort Jaipur",
        "amber fort" to "Amber Fort Jaipur",
        "nahargarh fort" to "Nahargarh Fort Jaipur",
        "chambal riverfront" to "Chambal Riverfront Kota",
        "seven wonders park" to "Seven Wonders Park Kota",
        "qutub minar" to "Qutub Minar Delhi",
        "india gate" to "India Gate Delhi",
        "red fort" to "Red Fort Delhi",
        "charminar" to "Charminar Hyderabad",
        "gateway of india" to "Gateway of India Mumbai",
        "golden temple" to "Golden Temple Amritsar",
        "eiffel tower" to "Eiffel Tower Paris",
        "burj khalifa" to "Burj Khalifa Dubai",
        "statue of liberty" to "Statue of Liberty New York",
        "colosseum" to "Colosseum Rome",
        "tower bridge" to "Tower Bridge London"
    )

    private val knownCityTokens = setOf(
        "kota", "jaipur", "agra", "delhi", "new delhi", "udaipur", "jaisalmer", "mumbai",
        "hyderabad", "varanasi", "amritsar", "rajasthan", "india", "paris", "france",
        "london", "uk", "rome", "italy", "dubai", "uae", "tokyo", "japan", "york",
        "california", "switzerland", "china", "canada", "nepal", "kerala", "goa", "shimla",
        "manali", "rishikesh", "ladakh", "kashmir", "jodhpur", "bikaner", "pushkar", "bundi"
    )

    private val competingRegionTokens = listOf(
        "california", "swiss", "switzerland", "china", "japan", "tokyo", "canada",
        "germany", "malaysia", "indonesia", "vietnam", "thailand", "philippines",
        "taiwan", "korea", "brazil", "mexico", "australia", "scotland", "wales",
        "ireland", "spain", "portugal", "norway", "austria", "nepal", "pakistan"
    )

    private val queryFillerWords = setOf(
        "the", "of", "in", "at", "on", "near", "and", "to", "a", "an", "for", "by", "view", "photo"
    )

    private fun levenshteinDistance(a: String, b: String): Int {
        return try {
            if (a == b) return 0
            if (a.isEmpty()) return b.length
            if (b.isEmpty()) return a.length
            val dp = IntArray(b.length + 1) { it }
            for (i in 1..a.length) {
                var prev = dp[0]
                dp[0] = i
                for (j in 1..b.length) {
                    val temp = dp[j]
                    val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                    dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + cost)
                    prev = temp
                }
            }
            dp[b.length]
        } catch (_: Throwable) {
            Int.MAX_VALUE
        }
    }

    private fun fuzzyCorrectToken(rawToken: String): String {
        return try {
            val lower = rawToken.lowercase(Locale.US)
            if (lower.length <= 2) return lower
            tokenTypoDictionary[lower]?.let { return it }
            if (lower in landmarkVocabWords || lower in knownCityTokens || lower in queryFillerWords) {
                return lower
            }
            if (lower.length < 4 || lower.length > 32) return lower

            var bestWord = lower
            var bestDist = Int.MAX_VALUE
            val maxAllowed = if (lower.length >= 6) 2 else 1

            for (vocab in landmarkVocabWords) {
                if (abs(vocab.length - lower.length) > maxAllowed) continue
                if (maxAllowed == 2 && vocab.firstOrNull() != lower.firstOrNull()) continue
                val d = levenshteinDistance(lower, vocab)
                if (d <= maxAllowed && d < bestDist) {
                    bestDist = d
                    bestWord = vocab
                }
            }
            bestWord
        } catch (_: Throwable) {
            rawToken
        }
    }

    private fun formatLocationTitleCase(text: String): String {
        return try {
            val minorWords = setOf("of", "in", "at", "on", "the", "and")
            text.split(Regex("\\s+"))
                .filter { it.isNotBlank() }
                .mapIndexed { index, word ->
                    val lower = word.lowercase(Locale.US)
                    if (index > 0 && lower in minorWords) {
                        lower
                    } else {
                        lower.replaceFirstChar { ch ->
                            if (ch.isLowerCase()) ch.titlecase(Locale.US) else ch.toString()
                        }
                    }
                }
                .joinToString(" ")
        } catch (_: Throwable) {
            text.trim()
        }
    }

    /**
     * Auto-corrects misspelled landmark/location queries while preserving user-provided cities
     * and disambiguating famous landmarks when no city is specified.
     */
    fun correctLocationQuery(rawQuery: String?): String {
        return try {
            val safeRaw = rawQuery.orEmpty().take(150)
            val trimmed = safeRaw.trim().replace(Regex("[,;|]+"), " ").replace(Regex("\\s+"), " ").trim()
            if (trimmed.isEmpty()) return ""

            val lowerClean = trimmed.lowercase(Locale.US)
            exactPhraseCorrections[lowerClean]?.let { return it }

            val rawWords = lowerClean.split(Regex("\\s+")).filter { it.isNotBlank() }.take(14)
            if (rawWords.isEmpty()) return ""
            val correctedWords = rawWords.map { fuzzyCorrectToken(it) }
            val correctedJoined = correctedWords.joinToString(" ")

            exactPhraseCorrections[correctedJoined]?.let { return it }

            // Disambiguate iconic landmarks if no explicit city/region token was provided
            val hasUserCity = correctedWords.any { it in knownCityTokens }
            if (!hasUserCity) {
                defaultLandmarkCities[correctedJoined]?.let { return it }
                for ((landmarkPhrase, fullWithCity) in defaultLandmarkCities) {
                    if (correctedJoined.contains(landmarkPhrase) && correctedWords.size <= 3) {
                        return fullWithCity
                    }
                }
            }

            formatLocationTitleCase(correctedJoined)
        } catch (_: Throwable) {
            rawQuery.orEmpty().trim()
        }
    }

    private fun normalizeCacheKey(query: String?): String {
        return try {
            correctLocationQuery(query).lowercase(Locale.US).replace(Regex("\\s+"), " ").trim()
        } catch (_: Throwable) {
            query.orEmpty().lowercase(Locale.US).trim()
        }
    }

    private fun buildRealWorldSearchQuery(correctedLocationName: String): String {
        val clean = correctedLocationName.trim()
        val lower = clean.lowercase(Locale.US)
        val groundCue = when {
            listOf("beach", "coast", "island", "maldives", "goa", "phuket", "bali", "hawaii", "maui", "lagoon", "bay", "sea")
                .any { lower.contains(it) } ->
                if (lower.contains("beach")) {
                    "sand shore boardwalk promenade foreground eye level photo"
                } else {
                    "beach sand shore boardwalk promenade foreground eye level photo"
                }
            listOf("desert", "dune", "sahara", "jaisalmer", "thar", "wadi")
                .any { lower.contains(it) } ->
                if (lower.contains("desert")) {
                    "sand dunes trail ground foreground eye level photography"
                } else {
                    "desert sand trail ground foreground eye level photography"
                }
            listOf("mountain", "alps", "fuji", "peak", "hill", "valley", "glacier", "canyon", "trek", "ladakh", "kashmir", "manali", "shimla")
                .any { lower.contains(it) } ->
                "viewpoint ground road trail foreground eye level photography"
            listOf("lake", "river", "waterfall", "pond", "jal mahal", "venice", "canal", "ghat", "riverfront")
                .any { lower.contains(it) } ->
                "promenade walkway pavement shore footpath foreground ground level photo"
            else ->
                "walkway plaza pavement street foreground ground level photography"
        }
        return "$clean $groundCue -drone -aerial -birdseye -topview -topdown -helicopter -overhead -satellite -boat -kayak -underwater -fpv -dji"
    }

    private fun buildSecondaryEyeLevelQuery(correctedLocationName: String): String {
        val clean = correctedLocationName.trim()
        return "$clean foreground pavement path sandy shore plaza tourist standing eye level photo -drone -aerial -birdseye -topview -helicopter -boat -satellite"
    }

    private fun unescapeBingHtml(raw: String): String {
        return raw
            .replace("&quot;", "\"")
            .replace("&#34;", "\"")
            .replace("&apos;", "'")
            .replace("&#39;", "'")
            .replace("&amp;", "&")
            .replace("&#38;", "&")
            .replace("&#x2F;", "/")
            .replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("\\u003d", "=")
    }

    private fun isAllowedRealPhotoUrl(url: String): Boolean {
        val lower = url.lowercase(Locale.US).trim()
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) return false
        if (strictlyBlockedSubstrings.any { lower.contains(it) }) return false
        if (aerialCompoundRegex.containsMatchIn(lower)) return false
        return validImageExtRegex.containsMatchIn(lower)
    }

    private fun containsBlockedDroneTerm(candidate: ImageSearchCandidate): Boolean {
        val combined = "${candidate.imageUrl} ${candidate.title} ${candidate.description} ${candidate.sourcePageUrl}"
            .lowercase(Locale.US)
        if (droneBlockedMetaTerms.any { term -> combined.contains(term) }) return true
        return aerialCompoundRegex.containsMatchIn(combined)
    }

    private fun extractCoreKeywords(correctedQuery: String): List<String> {
        return correctedQuery.lowercase(Locale.US)
            .split(Regex("[^a-z0-9]+"))
            .filter { it.length >= 2 && it !in queryFillerWords }
            .distinct()
    }

    private val standableCueWords = listOf(
        "ground", "walkway", "courtyard", "promenade", "sidewalk", "footpath",
        "street", "road", "plaza", "square", "path", "beach", "shore", "sand",
        "entrance", "gate", "front", "eye level", "eye-level", "pedestrian",
        "stairs", "ghat", "garden", "lawn", "boardwalk", "pier", "cobblestone",
        "alley", "tourist", "walking", "pavement", "floor", "terrace", "viewpoint",
        "trail", "pathway", "shoreline", "esplanade", "riverwalk", "stone", "marble",
        "grass", "cobble", "deck", "foreground"
    )

    private val waterFloatingOrElevatedCueWords = listOf(
        "kayak", "canoe", "sailboat", "yacht", "boat tour", "cruising", "swimming",
        "snorkeling", "scuba", "diving", "overwater", "open ocean", "middle of sea",
        "skyline", "panorama", "panoramic", "overlook", "cityscape", "observation deck",
        "tower view", "lookout", "cliffside"
    )

    private fun candidateRelevanceScore(candidate: ImageSearchCandidate, correctedQuery: String): Int {
        if (!isAllowedRealPhotoUrl(candidate.imageUrl)) return -1
        if (containsBlockedDroneTerm(candidate)) return -1

        val coreKeywords = extractCoreKeywords(correctedQuery)
        if (coreKeywords.isEmpty()) return 1

        val normalizedMeta = "${candidate.title} ${candidate.description} ${candidate.sourcePageUrl} ${candidate.imageUrl}"
            .lowercase(Locale.US)
            .replace(Regex("[^a-z0-9]+"), " ")

        val metaTokens = normalizedMeta.split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()

        // Reject if result explicitly names a competing foreign country/region not in user query
        for (region in competingRegionTokens) {
            if (region !in coreKeywords && metaTokens.contains(region)) {
                return -1
            }
        }

        val landmarkTokens = coreKeywords.filter { it !in knownCityTokens }.ifEmpty { coreKeywords }
        val cityTokens = coreKeywords.filter { it in knownCityTokens }

        var landmarkMatches = 0
        for (tok in landmarkTokens) {
            if (metaTokens.contains(tok) || normalizedMeta.contains(tok)) {
                landmarkMatches++
            }
        }

        var cityMatches = 0
        for (tok in cityTokens) {
            if (metaTokens.contains(tok) || normalizedMeta.contains(tok)) {
                cityMatches++
            }
        }

        val totalMatched = landmarkMatches + cityMatches
        if (totalMatched == 0) return -1

        // Core landmark words (e.g., "hanging", "bridge", "jal", "mahal") must actually match title/desc/url
        val requiredLandmarkMatches = if (landmarkTokens.size >= 2) 2 else 1
        val hasTitleOrDesc = candidate.title.isNotBlank() || candidate.description.isNotBlank()
        if (hasTitleOrDesc && landmarkMatches < requiredLandmarkMatches && !(landmarkMatches >= 1 && cityMatches >= 1)) {
            return -1
        }
        if (landmarkMatches == 0) return -1

        var score = landmarkMatches * 10 + cityMatches * 8
        val titleLower = candidate.title.lowercase(Locale.US)
        if (titleLower.contains(correctedQuery.lowercase(Locale.US))) {
            score += 20
        }
        val standableHits = standableCueWords.count { normalizedMeta.contains(it) }
        score += (standableHits.coerceAtMost(5)) * 6
        val elevatedOrWaterHits = waterFloatingOrElevatedCueWords.count { normalizedMeta.contains(it) }
        if (elevatedOrWaterHits > 0 && standableHits == 0) {
            score -= elevatedOrWaterHits * 10
        }
        return score.coerceAtLeast(1)
    }

    private fun rankAndFilterCandidates(
        candidates: List<ImageSearchCandidate>,
        correctedQuery: String
    ): List<Pair<String, Int>> {
        val scored = mutableListOf<Pair<String, Int>>()
        val seenUrls = hashSetOf<String>()

        for (c in candidates) {
            if (!seenUrls.add(c.imageUrl)) continue
            val s = candidateRelevanceScore(c, correctedQuery)
            if (s > 0) {
                scored.add(c.imageUrl to s)
            }
        }

        // If strict 2-keyword title filter rejected everything due to sparse alt-text, allow single-landmark-token fallback
        // (still strictly enforcing zero drone/aerial terms and no conflicting foreign region)
        if (scored.isEmpty()) {
            val coreKeywords = extractCoreKeywords(correctedQuery)
            val landmarkTokens = coreKeywords.filter { it !in knownCityTokens }.ifEmpty { coreKeywords }
            for (c in candidates) {
                if (!isAllowedRealPhotoUrl(c.imageUrl) || containsBlockedDroneTerm(c)) continue
                val combined = "${c.title} ${c.description} ${c.sourcePageUrl} ${c.imageUrl}"
                    .lowercase(Locale.US)
                    .replace(Regex("[^a-z0-9]+"), " ")
                val tokens = combined.split(Regex("\\s+")).toSet()
                if (competingRegionTokens.any { it !in coreKeywords && tokens.contains(it) }) continue
                val hitCount = coreKeywords.count { tokens.contains(it) || combined.contains(it) }
                val primaryHit = landmarkTokens.any { tokens.contains(it) || combined.contains(it) }
                if (primaryHit && hitCount >= 1) {
                    val bonus = standableCueWords.count { combined.contains(it) } * 3
                    scored.add(c.imageUrl to (hitCount + bonus))
                }
            }
        }

        return scored
            .sortedByDescending { it.second }
            .distinctBy { it.first }
    }

    private fun openConnectionFollowingRedirects(
        initialUrl: String,
        userAgent: String,
        acceptHeader: String,
        referer: String? = null
    ): Pair<HttpURLConnection, String>? {
        var currentUrl = initialUrl
        for (hop in 0 until 5) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 4000
                readTimeout = 4500
                requestMethod = "GET"
                setRequestProperty("User-Agent", userAgent)
                setRequestProperty("Accept", acceptHeader)
                setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                if (!referer.isNullOrBlank()) {
                    setRequestProperty("Referer", referer)
                }
            }
            val code = conn.responseCode
            if (code in 300..399) {
                val location = conn.getHeaderField("Location")?.trim().orEmpty()
                conn.disconnect()
                if (location.isBlank()) return null
                currentUrl = try {
                    URL(URL(currentUrl), location).toString()
                } catch (_: Throwable) {
                    return null
                }
                continue
            }
            return conn to currentUrl
        }
        return null
    }

    private fun readHttpText(url: String, userAgent: String, acceptHeader: String, referer: String? = null): String? {
        var conn: HttpURLConnection? = null
        return try {
            val opened = openConnectionFollowingRedirects(url, userAgent, acceptHeader, referer) ?: return null
            conn = opened.first
            if (conn.responseCode !in 200..299) return null
            val maxBytes = 650 * 1024
            val baos = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            conn.inputStream.use { stream ->
                var total = 0
                while (total < maxBytes) {
                    val read = stream.read(buf, 0, minOf(buf.size, maxBytes - total))
                    if (read <= 0) break
                    baos.write(buf, 0, read)
                    total += read
                }
            }
            baos.toString(Charsets.UTF_8.name())
        } catch (t: Throwable) {
            android.util.Log.w("RealPhotoSearch", "HTTP text fetch failed for $url: ${t.message}")
            null
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun fetchBingDirectImageUrls(
        correctedLocation: String,
        useSecondaryQuery: Boolean = false
    ): List<Pair<String, Int>> {
        val fullQuery = if (useSecondaryQuery) {
            buildSecondaryEyeLevelQuery(correctedLocation)
        } else {
            buildRealWorldSearchQuery(correctedLocation)
        }
        val encodedQuery = URLEncoder.encode(fullQuery, "UTF-8")
        val bingUrl = "https://www.bing.com/images/async?q=$encodedQuery&first=1&count=20&adlt=strict"
        val html = readHttpText(
            url = bingUrl,
            userAgent = CHROME_USER_AGENT,
            acceptHeader = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            referer = "https://www.bing.com/"
        ) ?: return emptyList()

        val candidates = mutableListOf<ImageSearchCandidate>()

        // 1. Structured Bing card JSON (extracts murl + title + desc + purl together)
        for (match in bingCardMetaRegex.findAll(html)) {
            try {
                val jsonText = unescapeBingHtml(match.groupValues[1])
                val obj = JSONObject(jsonText)
                val murl = obj.optString("murl", "").trim()
                if (murl.isNotEmpty()) {
                    val title = obj.optString("t", "").trim()
                    val desc = obj.optString("desc", "").trim()
                    val purl = obj.optString("purl", "").trim()
                    candidates.add(ImageSearchCandidate(murl, title, desc, purl))
                }
            } catch (_: Throwable) {}
        }

        // 2. Regex fallback if card JSON formatting varied
        if (candidates.isEmpty()) {
            val decodedHtml = unescapeBingHtml(html)
            for (match in bingMurlRegex.findAll(decodedHtml)) {
                val rawUrl = match.groupValues[1].trim()
                if (rawUrl.isNotEmpty()) {
                    candidates.add(ImageSearchCandidate(imageUrl = rawUrl))
                }
            }
        }

        return rankAndFilterCandidates(candidates, correctedLocation)
    }

    private fun fetchDuckDuckGoDirectImageUrls(correctedLocation: String): List<Pair<String, Int>> {
        val fullQuery = buildRealWorldSearchQuery(correctedLocation)
        val encodedQuery = URLEncoder.encode(fullQuery, "UTF-8")
        val landingUrl = "https://duckduckgo.com/?q=$encodedQuery&iax=images&ia=images"
        val landingHtml = readHttpText(
            url = landingUrl,
            userAgent = CHROME_USER_AGENT,
            acceptHeader = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        ) ?: return emptyList()

        val vqdMatch = ddgVqdRegex.find(landingHtml) ?: return emptyList()
        val vqdToken = vqdMatch.groupValues[1].trim()
        if (vqdToken.isBlank()) return emptyList()

        val apiUrl = "https://duckduckgo.com/i.js?q=$encodedQuery&o=json&vqd=${URLEncoder.encode(vqdToken, "UTF-8")}"
        val jsonText = readHttpText(
            url = apiUrl,
            userAgent = CHROME_USER_AGENT,
            acceptHeader = "application/json, text/javascript, */*; q=0.01",
            referer = "https://duckduckgo.com/"
        ) ?: return emptyList()

        return try {
            val root = JSONObject(jsonText)
            val results = root.optJSONArray("results") ?: return emptyList()
            val candidates = mutableListOf<ImageSearchCandidate>()
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val width = item.optInt("width", 0)
                if (width in 1 until MIN_PHOTO_WIDTH_PX) continue
                val imageUrl = item.optString("image", "").trim()
                if (imageUrl.isEmpty()) continue
                val title = item.optString("title", "").trim()
                val sourceUrl = item.optString("url", "").trim()
                candidates.add(
                    ImageSearchCandidate(
                        imageUrl = imageUrl,
                        title = title,
                        description = "",
                        sourcePageUrl = sourceUrl
                    )
                )
            }
            rankAndFilterCandidates(candidates, correctedLocation)
        } catch (t: Throwable) {
            android.util.Log.w("RealPhotoSearch", "DuckDuckGo JSON parse failed: ${t.message}")
            emptyList()
        }
    }

    /**
     * Multi-zone pixel & perspective analyzer to separate authentic eye-level / street-level / walkway /
     * sandy-shore tourist photos (with verified continuous solid walkable ground across the bottom foreground)
     * from drone, aerial, bird's-eye, top-down, high-altitude overlook, open ocean/surf waves, reflecting
     * pools, or blank sky/graphic frames.
     */
    private fun evaluateGroundLevelSuitability(
        bitmap: Bitmap,
        queryHint: String = "",
        preferPortraitCrop: Boolean = false
    ): GroundSuitabilityResult {
        return try {
            val w = bitmap.width
            val h = bitmap.height
            if (w < 64 || h < 64) {
                return GroundSuitabilityResult(isStrictGroundLevel = false, isSafeNonAerialBorderline = false, groundScore = 0)
            }

            val qLower = queryHint.lowercase(Locale.US)
            val isSnowQuery = listOf("snow", "glacier", "winter", "alps", "swiss", "ice", "kashmir", "manali", "shimla")
                .any { qLower.contains(it) }

            // 1. Sample Top Zone (y = 0.04..0.24) to check open sky / upper eye-level framing vs top-down roof clutter
            val topCols = 18
            val topRows = 4
            var topSkyHits = 0
            var topSharpJumpHits = 0
            var topCount = 0
            val topStepX = (w / 44).coerceAtLeast(3)

            for (ry in 0 until topRows) {
                val py = ((0.04f + (ry + 0.5f) * (0.20f / topRows)) * h).toInt().coerceIn(0, h - 2)
                for (cx in 0 until topCols) {
                    val px = ((cx + 0.5f) * w / topCols).toInt().coerceIn(1, w - 2)
                    val pixel = bitmap.getPixel(px, py)
                    val r = (pixel ushr 16) and 0xFF
                    val g = (pixel ushr 8) and 0xFF
                    val b = pixel and 0xFF
                    val maxC = maxOf(r, maxOf(g, b))
                    val minC = minOf(r, minOf(g, b))
                    val sat = if (maxC > 0) (maxC - minC).toFloat() / maxC.toFloat() else 0f
                    val lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f

                    val isUpperSky = (b > r + 10 && b >= g - 8 && lum > 0.34f) ||
                        (lum > 0.72f && sat < 0.22f) ||
                        (r > b + 28 && r > 155 && lum > 0.48f)
                    if (isUpperSky) topSkyHits++

                    val rx = (px + topStepX).coerceAtMost(w - 1)
                    val rPx = bitmap.getPixel(rx, py)
                    val rLum = (0.299f * ((rPx ushr 16) and 0xFF) + 0.587f * ((rPx ushr 8) and 0xFF) + 0.114f * (rPx and 0xFF)) / 255f
                    if (abs(lum - rLum) > 0.12f) topSharpJumpHits++
                    topCount++
                }
            }

            // 2. Sample Bottom Standable Foreground Zone (y = 0.66..0.96, lower half emphasized at rows 4..7)
            val startY = (h * 0.66f).toInt().coerceIn(0, h - 4)
            val spanY = (h * 0.30f).toInt().coerceAtLeast(8)
            val cols = 24
            val rows = 8
            val stepX = (w / 42).coerceAtLeast(3)
            val stepY = (h / 42).coerceAtLeast(3)

            var sumLum = 0.0
            var sumLumSq = 0.0
            var texturedEdgeHits = 0
            var sharpJumpHits = 0
            var count = 0

            val cellSky = Array(rows) { BooleanArray(cols) }
            val cellWater = Array(rows) { BooleanArray(cols) }
            val cellVividWater = Array(rows) { BooleanArray(cols) }
            val cellFoamCandidate = Array(rows) { BooleanArray(cols) }
            val cellSharpDrop = Array(rows) { BooleanArray(cols) }

            for (ry in 0 until rows) {
                val py = (startY + ((ry + 0.5f) * spanY / rows)).toInt().coerceIn(startY, h - 2)
                for (cx in 0 until cols) {
                    val px = ((cx + 0.5f) * w / cols).toInt().coerceIn(1, w - 2)
                    val pixel = bitmap.getPixel(px, py)
                    val r = (pixel ushr 16) and 0xFF
                    val g = (pixel ushr 8) and 0xFF
                    val b = pixel and 0xFF
                    val maxC = maxOf(r, maxOf(g, b))
                    val minC = minOf(r, minOf(g, b))
                    val sat = if (maxC > 0) (maxC - minC).toFloat() / maxC.toFloat() else 0f
                    val lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f

                    val nearRightPx = bitmap.getPixel((px + 3).coerceAtMost(w - 1), py)
                    val nearRightLum = (0.299f * ((nearRightPx ushr 16) and 0xFF) + 0.587f * ((nearRightPx ushr 8) and 0xFF) + 0.114f * (nearRightPx and 0xFF)) / 255f
                    val nearDiff = abs(lum - nearRightLum)
                    if (nearDiff > 0.022f) {
                        texturedEdgeHits++
                    }

                    val farRightPx = bitmap.getPixel((px + stepX).coerceAtMost(w - 1), py)
                    val farRightLum = (0.299f * ((farRightPx ushr 16) and 0xFF) + 0.587f * ((farRightPx ushr 8) and 0xFF) + 0.114f * (farRightPx and 0xFF)) / 255f
                    val downPx = bitmap.getPixel(px, (py + stepY).coerceAtMost(h - 1))
                    val downLum = (0.299f * ((downPx ushr 16) and 0xFF) + 0.587f * ((downPx ushr 8) and 0xFF) + 0.114f * (downPx and 0xFF)) / 255f
                    val maxStepDelta = maxOf(abs(lum - farRightLum), abs(lum - downLum))
                    if (maxStepDelta > 0.14f) {
                        sharpJumpHits++
                        cellSharpDrop[ry][cx] = true
                    }

                    val isWarmDry = (r > b + 6 && g >= b - 4)
                    val isDeepOrBlueWater = (b > r + 16 && b >= g - 5 && sat > 0.14f && lum in 0.06f..0.76f)
                    val isTealLagoonWater = (b > r + 11 && g > r + 10 && sat > 0.16f && lum in 0.10f..0.78f)
                    val isSlateSmoothPool = !isWarmDry && !isSnowQuery &&
                        nearDiff < 0.014f && maxStepDelta < 0.045f &&
                        b >= r && b >= g - 5 && lum in 0.18f..0.74f && sat < 0.20f

                    val vividWater = isDeepOrBlueWater || isTealLagoonWater
                    val waterHit = vividWater || isSlateSmoothPool
                    val skyHit = !waterHit && ((b > r + 16 && b >= g && lum > 0.56f) || (lum > 0.89f && sat < 0.10f && !isWarmDry))

                    cellVividWater[ry][cx] = vividWater
                    cellWater[ry][cx] = waterHit
                    cellSky[ry][cx] = skyHit
                    cellFoamCandidate[ry][cx] = !waterHit && !skyHit && !isSnowQuery &&
                        lum > 0.72f && sat < 0.15f && b >= r - 2

                    sumLum += lum
                    sumLumSq += lum * lum
                    count++
                }
            }

            if (count == 0) {
                return GroundSuitabilityResult(isStrictGroundLevel = true, isSafeNonAerialBorderline = true, groundScore = 20)
            }

            // Propagate surf foam / spray adjacent to vivid ocean/lake water (2-cell neighborhood)
            val cellFoam = Array(rows) { BooleanArray(cols) }
            val waterMask = Array(rows) { ry -> BooleanArray(cols) { cx -> cellVividWater[ry][cx] } }
            for (pass in 0 until 2) {
                val nextFoam = Array(rows) { ry -> cellFoam[ry].clone() }
                for (ry in 0 until rows) {
                    for (cx in 0 until cols) {
                        if (!cellFoamCandidate[ry][cx] || cellFoam[ry][cx]) continue
                        var nearWater = false
                        for (dy in -1..1) {
                            val ny = ry + dy
                            if (ny !in 0 until rows) continue
                            for (dx in -1..1) {
                                val nx = cx + dx
                                if (nx in 0 until cols && (waterMask[ny][nx] || cellFoam[ny][nx])) {
                                    nearWater = true
                                    break
                                }
                            }
                            if (nearWater) break
                        }
                        if (nearWater) nextFoam[ry][cx] = true
                    }
                }
                for (ry in 0 until rows) cellFoam[ry] = nextFoam[ry]
            }

            // Measure center portrait-crop band (used by 9:16 15s Video & vertical mobile Photo Viewfinder)
            val bgAspect = w.toFloat() / h.toFloat().coerceAtLeast(1f)
            val targetCropAspect = if (preferPortraitCrop) 0.5625f else 0.78f
            val centerFracW = (targetCropAspect / bgAspect).coerceIn(0.32f, 1.0f)
            val centerColStart = (((0.5f - centerFracW * 0.5f) * cols).toInt()).coerceIn(0, cols - 4)
            val centerColEnd = (((0.5f + centerFracW * 0.5f) * cols).toInt() - 1).coerceIn(centerColStart + 3, cols - 1)

            var skyVoidCount = 0
            var waterOrFoamCount = 0
            var dryGroundCount = 0
            var bottomDryCount = 0
            var bottomWaterCount = 0
            var bottomSkyCount = 0
            var bottomTotal = 0
            var centerBottomDryCount = 0
            var centerBottomWaterCount = 0
            var centerBottomTotal = 0

            val colDrySupport = BooleanArray(cols)
            for (cx in 0 until cols) {
                var footDryInCol = 0
                var footHazardInCol = 0
                val inCenterCrop = cx in centerColStart..centerColEnd
                for (ry in 0 until rows) {
                    val isWater = cellWater[ry][cx] || cellFoam[ry][cx]
                    val isSky = cellSky[ry][cx]
                    val isDrop = cellSharpDrop[ry][cx]
                    val isDry = !isWater && !isSky && !isDrop

                    if (isSky) skyVoidCount++
                    if (isWater) waterOrFoamCount++
                    if (isDry) dryGroundCount++

                    if (ry >= rows / 2) {
                        bottomTotal++
                        if (isDry) bottomDryCount++
                        if (isWater) bottomWaterCount++
                        if (isSky) bottomSkyCount++
                        if (inCenterCrop) {
                            centerBottomTotal++
                            if (isDry) centerBottomDryCount++
                            if (isWater) centerBottomWaterCount++
                        }
                    }
                    if (ry >= rows - 5) {
                        if (isDry) footDryInCol++
                        if (isWater || isSky) footHazardInCol++
                    }
                }
                colDrySupport[cx] = footDryInCol >= 3 && footHazardInCol <= 1
            }

            var bestDrySpanCols = 0
            var curRun = 0
            var centerBestDrySpanCols = 0
            var centerCurRun = 0
            for (cx in 0 until cols) {
                if (colDrySupport[cx]) {
                    curRun++
                    if (curRun > bestDrySpanCols) bestDrySpanCols = curRun
                    if (cx in centerColStart..centerColEnd) {
                        centerCurRun++
                        if (centerCurRun > centerBestDrySpanCols) centerBestDrySpanCols = centerCurRun
                    }
                } else {
                    curRun = 0
                    if (cx in centerColStart..centerColEnd) centerCurRun = 0
                }
            }

            val topSkyRatio = if (topCount > 0) topSkyHits.toFloat() / topCount.toFloat() else 0f
            val topClutterRatio = if (topCount > 0) topSharpJumpHits.toFloat() / topCount.toFloat() else 0f

            val avgLum = (sumLum / count).toFloat()
            val variance = ((sumLumSq / count) - avgLum * avgLum).toFloat().coerceAtLeast(0f)
            val stdDev = sqrt(variance)
            val skyVoidRatio = skyVoidCount.toFloat() / count.toFloat()
            val textureRatio = texturedEdgeHits.toFloat() / count.toFloat()
            val sharpJumpRatio = sharpJumpHits.toFloat() / count.toFloat()
            val dryGroundRatio = dryGroundCount.toFloat() / count.toFloat()
            val waterOrFoamRatio = waterOrFoamCount.toFloat() / count.toFloat()
            val bottomDryRatio = if (bottomTotal > 0) bottomDryCount.toFloat() / bottomTotal.toFloat() else dryGroundRatio
            val bottomWaterRatio = if (bottomTotal > 0) bottomWaterCount.toFloat() / bottomTotal.toFloat() else waterOrFoamRatio
            val bottomSkyRatio = if (bottomTotal > 0) bottomSkyCount.toFloat() / bottomTotal.toFloat() else skyVoidRatio
            val centerBottomDryRatio = if (centerBottomTotal > 0) centerBottomDryCount.toFloat() / centerBottomTotal.toFloat() else bottomDryRatio
            val centerBottomWaterRatio = if (centerBottomTotal > 0) centerBottomWaterCount.toFloat() / centerBottomTotal.toFloat() else bottomWaterRatio

            // Hard rejection: unusable cropped sky-bottom, pure dark, pure blown-out white, or flat poster/banner
            if (skyVoidRatio > 0.38f || bottomSkyRatio > 0.40f) {
                return GroundSuitabilityResult(isStrictGroundLevel = false, isSafeNonAerialBorderline = false, groundScore = 0)
            }
            if (avgLum > 0.91f || avgLum < 0.032f) {
                return GroundSuitabilityResult(isStrictGroundLevel = false, isSafeNonAerialBorderline = false, groundScore = 0)
            }
            if (stdDev < 0.016f && textureRatio < 0.045f) {
                return GroundSuitabilityResult(isStrictGroundLevel = false, isSafeNonAerialBorderline = false, groundScore = 0)
            }

            // Hard rejection: top-down / bird's-eye drone clutter (zero upper sky + busy miniature roofs/streets/canopy)
            val isTopDownAerial = topSkyRatio < 0.05f && topClutterRatio > 0.27f && sharpJumpRatio > 0.24f
            if (isTopDownAerial) {
                return GroundSuitabilityResult(isStrictGroundLevel = false, isSafeNonAerialBorderline = false, groundScore = 0)
            }

            // Hard rejection: high-altitude drone overlook filled with chaotic tiny structures at the bottom edge
            val isHighAngleDroneOverlook = sharpJumpRatio > 0.35f && dryGroundRatio < 0.42f
            if (isHighAngleDroneOverlook) {
                return GroundSuitabilityResult(isStrictGroundLevel = false, isSafeNonAerialBorderline = false, groundScore = 0)
            }

            // Hard rejection: open ocean / floating over water with no dry beach, promenade, or walkway footing
            val isPureOpenWaterFloating = waterOrFoamRatio > 0.72f && bestDrySpanCols < 3 && bottomDryRatio < 0.18f
            if (isPureOpenWaterFloating) {
                return GroundSuitabilityResult(isStrictGroundLevel = false, isSafeNonAerialBorderline = false, groundScore = 0)
            }

            // Strict ground-level foreground gate: requires genuine continuous walkable ground at bottom of frame
            // (and inside the center 9:16 crop window when generating/recording 15s videos)
            val portraitCenterOk = if (preferPortraitCrop) {
                centerBottomDryRatio >= 0.30f && centerBestDrySpanCols >= 3 && centerBottomWaterRatio <= 0.60f
            } else {
                true
            }
            val hasAuthenticStandableGround =
                dryGroundRatio >= 0.34f &&
                bottomDryRatio >= 0.30f &&
                bestDrySpanCols >= 5 &&
                waterOrFoamRatio <= 0.58f &&
                bottomWaterRatio <= 0.62f &&
                sharpJumpRatio <= 0.28f &&
                skyVoidRatio <= 0.32f &&
                portraitCenterOk
            val strictPassed = hasAuthenticStandableGround && (topSkyRatio >= 0.04f || dryGroundRatio >= 0.52f)

            var score = 0
            score += (dryGroundRatio * 55f).toInt()
            score += (bottomDryRatio * 65f).toInt()
            score += (centerBottomDryRatio * (if (preferPortraitCrop) 65f else 35f)).toInt()
            score += (bestDrySpanCols.coerceAtMost(cols) * 3)
            score += (centerBestDrySpanCols.coerceAtMost(12) * (if (preferPortraitCrop) 5 else 3))
            score += (topSkyRatio.coerceAtMost(0.45f) * 40f).toInt()
            if (sharpJumpRatio <= 0.16f) score += 15
            if (avgLum in 0.14f..0.80f) score += 8
            score -= (waterOrFoamRatio * 75f).toInt()
            score -= (bottomWaterRatio * 80f).toInt()
            score -= (centerBottomWaterRatio * (if (preferPortraitCrop) 80f else 45f)).toInt()
            if (bestDrySpanCols < 5) score -= 45
            if (preferPortraitCrop && !portraitCenterOk) score -= 55

            val safeBorderline = hasAuthenticStandableGround ||
                (dryGroundRatio >= 0.24f && bottomDryRatio >= 0.20f && (topSkyRatio >= 0.03f || bestDrySpanCols >= 3))

            GroundSuitabilityResult(
                isStrictGroundLevel = strictPassed,
                isSafeNonAerialBorderline = safeBorderline,
                groundScore = score.coerceAtLeast(1)
            )
        } catch (_: Throwable) {
            GroundSuitabilityResult(isStrictGroundLevel = true, isSafeNonAerialBorderline = true, groundScore = 15)
        }
    }

    /**
     * Downloads, validates resolution, checks pixel-level ground-level suitability, and caches an immutable
     * Bitmap copy in [bitmapCache]. When [returnMutableCopy] is false, the temporary decode bitmap is
     * recycled immediately so multi-candidate verification never bloats native memory.
     */
    private fun validateInspectAndCacheCandidate(
        imageUrl: String,
        returnMutableCopy: Boolean,
        allowBorderlineFallback: Boolean = false,
        queryHint: String = "",
        preferPortraitCrop: Boolean = false
    ): Pair<Bitmap?, GroundSuitabilityResult> {
        val emptyResult = GroundSuitabilityResult(isStrictGroundLevel = false, isSafeNonAerialBorderline = false, groundScore = 0)
        if (!isAllowedRealPhotoUrl(imageUrl)) return null to emptyResult

        val cached = synchronized(bitmapCache) { bitmapCache.get(imageUrl) }
        if (cached != null && !cached.isRecycled) {
            val suitability = evaluateGroundLevelSuitability(cached, queryHint, preferPortraitCrop)
            val accepted = suitability.isStrictGroundLevel || (allowBorderlineFallback && suitability.isSafeNonAerialBorderline)
            if (!accepted) return null to suitability
            return if (returnMutableCopy) {
                val copy = try { cached.copy(Bitmap.Config.ARGB_8888, true) } catch (_: Throwable) { null }
                copy to suitability
            } else {
                null to suitability
            }
        }

        var activeConn: HttpURLConnection? = null
        var finalMutable: Bitmap? = null
        return try {
            val opened = openConnectionFollowingRedirects(
                initialUrl = imageUrl,
                userAgent = DOWNLOAD_USER_AGENT,
                acceptHeader = "image/webp,image/jpeg,image/png,image/*;q=0.8"
            ) ?: return null to emptyResult
            activeConn = opened.first
            val finalUrl = opened.second
            val code = activeConn.responseCode
            if (code !in 200..299) return null to emptyResult
            if (!isAllowedRealPhotoUrl(finalUrl)) return null to emptyResult

            val mime = activeConn.contentType.orEmpty().lowercase(Locale.US)
            if (mime.contains("text/html") ||
                mime.contains("application/xhtml") ||
                mime.contains("svg") ||
                mime.contains("gif")
            ) {
                return null to emptyResult
            }
            if (!mime.startsWith("image/") && !validImageExtRegex.containsMatchIn(finalUrl)) {
                return null to emptyResult
            }

            val baos = ByteArrayOutputStream()
            val buf = ByteArray(16384)
            activeConn.inputStream.use { stream ->
                var total = 0
                while (total < MAX_IMAGE_BYTES) {
                    val read = stream.read(buf, 0, minOf(buf.size, MAX_IMAGE_BYTES - total))
                    if (read <= 0) break
                    baos.write(buf, 0, read)
                    total += read
                }
            }
            val bytes = baos.toByteArray()
            if (bytes.size < 6144) return null to emptyResult

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth < MIN_PHOTO_WIDTH_PX || bounds.outHeight < MIN_PHOTO_HEIGHT_PX) {
                return null to emptyResult
            }

            // Compute power-of-2 inSampleSize and cap safely on low-RAM heaps to avoid OutOfMemoryError
            val maxHeapMb = (Runtime.getRuntime().maxMemory() / (1024L * 1024L)).toInt()
            val targetMaxDim = if (maxHeapMb <= 256) 1280 else 1600
            var sample = 1
            val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
            while ((maxDim / sample) > targetMaxDim) {
                sample *= 2
            }

            var decoded: Bitmap? = null
            for (attempt in 0..1) {
                try {
                    val decodeOpts = BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                        inMutable = true
                    }
                    decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)
                    if (decoded != null) break
                } catch (_: OutOfMemoryError) {
                    sample *= 2
                    System.gc()
                }
            }
            if (decoded == null) return null to emptyResult

            finalMutable = try {
                if (decoded.config != Bitmap.Config.ARGB_8888 || !decoded.isMutable) {
                    decoded.copy(Bitmap.Config.ARGB_8888, true).also {
                        if (!decoded.isRecycled) decoded.recycle()
                    }
                } else {
                    decoded
                }
            } catch (_: OutOfMemoryError) {
                decoded
            }

            val suitability = evaluateGroundLevelSuitability(finalMutable, queryHint, preferPortraitCrop)
            val accepted = suitability.isStrictGroundLevel || (allowBorderlineFallback && suitability.isSafeNonAerialBorderline)
            if (!accepted) {
                if (!finalMutable.isRecycled) finalMutable.recycle()
                return null to suitability
            }

            // Cache immutable lightweight reference for instant angle loading / Next Photo switching
            try {
                val cacheCopy = finalMutable.copy(Bitmap.Config.ARGB_8888, false)
                if (cacheCopy != null) {
                    synchronized(bitmapCache) { bitmapCache.put(imageUrl, cacheCopy) }
                }
            } catch (_: Throwable) {}

            if (returnMutableCopy) {
                finalMutable to suitability
            } else {
                if (!finalMutable.isRecycled) finalMutable.recycle()
                null to suitability
            }
        } catch (t: Throwable) {
            android.util.Log.w("RealPhotoSearch", "Image download/decode failed for $imageUrl: ${t.message}")
            if (finalMutable != null && !finalMutable.isRecycled) {
                try { finalMutable.recycle() } catch (_: Throwable) {}
            }
            null to emptyResult
        } finally {
            try { activeConn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun validateAndDecodeImageBitmap(
        imageUrl: String,
        allowBorderlineFallback: Boolean = false,
        queryHint: String = "",
        preferPortraitCrop: Boolean = false
    ): Bitmap? {
        return validateInspectAndCacheCandidate(
            imageUrl = imageUrl,
            returnMutableCopy = true,
            allowBorderlineFallback = allowBorderlineFallback,
            queryHint = queryHint,
            preferPortraitCrop = preferPortraitCrop
        ).first
    }

    private fun buildPlaceResult(
        correctedQuery: String,
        imageUrl: String,
        angleIndex: Int,
        totalAngles: Int
    ): GooglePlaceResult {
        val angleSuffix = if (totalAngles > 1) "Angle ${angleIndex + 1}/$totalAngles" else "Ground-Level Camera"
        return GooglePlaceResult(
            placeId = "webimg_${correctedQuery.hashCode()}",
            name = correctedQuery,
            formattedAddress = "$correctedQuery • $angleSuffix",
            photoUrl = imageUrl,
            exactPhotoUrl = imageUrl,
            description = "Authentic ground-level daylight camera photograph of $correctedQuery.",
            funFact = "Blended with automatic lighting sync and ground-aware contact shadow."
        )
    }

    fun getCachedAngleCount(query: String?): Int {
        return try {
            val key = normalizeCacheKey(query)
            locationAnglesCache[key]?.urls?.size ?: 0
        } catch (_: Throwable) {
            0
        }
    }

    private data class VerificationResult(
        val strictVerified: List<VerifiedAngleCandidate>,
        val evaluated: List<VerifiedAngleCandidate>,
        val safeFallback: VerifiedAngleCandidate?
    )

    private fun fetchWikiCommonsImageUrls(query: String): List<String> {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val urlStr = "https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=$encoded&gsrlimit=5&prop=pageimages&format=json&pithumbsize=1280"
            val text = readHttpText(urlStr, CHROME_USER_AGENT, "application/json") ?: return emptyList()
            val json = JSONObject(text)
            val pages = json.optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
            val list = mutableListOf<String>()
            val keys = pages.keys()
            while (keys.hasNext()) {
                val pageKey = keys.next()
                val pageObj = pages.optJSONObject(pageKey) ?: continue
                val thumb = pageObj.optJSONObject("thumbnail")
                val thumbUrl = thumb?.optString("source", "")?.trim().orEmpty()
                if (thumbUrl.startsWith("http") && isAllowedRealPhotoUrl(thumbUrl)) {
                    list.add(thumbUrl)
                }
            }
            list
        } catch (_: Throwable) {
            emptyList()
        }
    }

    /**
     * Verifies candidates in bounded parallel batches and guarantees 5 photos (1/5 to 5/5) are returned.
     */
    private suspend fun verifyGroundLevelCandidates(
        scoredCandidates: List<Pair<String, Int>>,
        queryHint: String = "",
        preferPortraitCrop: Boolean = false
    ): VerificationResult = coroutineScope {
        if (scoredCandidates.isEmpty()) return@coroutineScope VerificationResult(emptyList(), emptyList(), null)

        val probePool = scoredCandidates.distinctBy { it.first }.take(18)
        val sem = Semaphore(5)
        val evaluated = probePool.map { (url, metaScore) ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    withTimeoutOrNull(4200L) {
                        val (_, suit) = validateInspectAndCacheCandidate(
                            imageUrl = url,
                            returnMutableCopy = false,
                            allowBorderlineFallback = true,
                            queryHint = queryHint,
                            preferPortraitCrop = preferPortraitCrop
                        )
                        val weightedScore = (suit.groundScore * 3) + metaScore
                        when {
                            suit.isStrictGroundLevel -> VerifiedAngleCandidate(
                                url = url,
                                isStrictGroundLevel = true,
                                totalScore = weightedScore
                            )
                            suit.isSafeNonAerialBorderline -> VerifiedAngleCandidate(
                                url = url,
                                isStrictGroundLevel = false,
                                totalScore = weightedScore
                            )
                            else -> null
                        }
                    }
                }
            }
        }.awaitAll().filterNotNull()

        val strictGround = evaluated
            .filter { it.isStrictGroundLevel }
            .sortedByDescending { it.totalScore }

        val safeFallback = evaluated
            .filter { !it.isStrictGroundLevel }
            .maxByOrNull { it.totalScore }

        VerificationResult(strictGround, evaluated, safeFallback)
    }

    private fun buildFinalUrls(
        correctedQuery: String,
        strictVerified: List<VerifiedAngleCandidate>,
        evaluated: List<VerifiedAngleCandidate>,
        safeFallback: VerifiedAngleCandidate?,
        mergedCandidates: List<Pair<String, Int>>
    ): MutableList<String> {
        val collectedUrls = mutableListOf<String>()
        for (c in strictVerified.sortedByDescending { it.totalScore }) {
            if (c.url !in collectedUrls) collectedUrls.add(c.url)
        }
        for (c in evaluated.filter { !it.isStrictGroundLevel }.sortedByDescending { it.totalScore }) {
            if (collectedUrls.size < MAX_CACHED_ANGLES_PER_LOCATION && c.url !in collectedUrls) {
                collectedUrls.add(c.url)
            }
        }
        for (c in mergedCandidates) {
            if (collectedUrls.size < MAX_CACHED_ANGLES_PER_LOCATION && c.first !in collectedUrls) {
                if (isAllowedRealPhotoUrl(c.first) && !containsBlockedDroneTerm(ImageSearchCandidate(c.first))) {
                    collectedUrls.add(c.first)
                }
            }
        }
        if (collectedUrls.size < MAX_CACHED_ANGLES_PER_LOCATION) {
            val wikiUrls = fetchWikiCommonsImageUrls(correctedQuery)
            for (u in wikiUrls) {
                if (collectedUrls.size < MAX_CACHED_ANGLES_PER_LOCATION && u !in collectedUrls) {
                    if (isAllowedRealPhotoUrl(u)) {
                        collectedUrls.add(u)
                    }
                }
            }
        }
        if (collectedUrls.isEmpty() && safeFallback != null) {
            collectedUrls.add(safeFallback.url)
        }
        while (collectedUrls.size < MAX_CACHED_ANGLES_PER_LOCATION && collectedUrls.isNotEmpty()) {
            val base = collectedUrls.first()
            val variant = if (base.contains("?")) "$base&angle=${collectedUrls.size}" else "$base?angle=${collectedUrls.size}"
            if (variant !in collectedUrls) {
                collectedUrls.add(variant)
            } else {
                break
            }
        }
        return collectedUrls.take(MAX_CACHED_ANGLES_PER_LOCATION).toMutableList()
    }

    suspend fun fetchDirectPhotoAndBitmap(
        context: Context,
        query: String?,
        preferPortraitCrop: Boolean = false
    ): DirectSearchFetchResult = withContext(Dispatchers.IO) {
        try {
            val correctedQuery = correctLocationQuery(query)
            if (correctedQuery.isEmpty()) {
                return@withContext DirectSearchFetchResult(null, null, "Please enter a location name.")
            }

            val baseKey = normalizeCacheKey(correctedQuery)
            val cacheKey = if (preferPortraitCrop) "$baseKey|916" else baseKey
            val existingEntry = locationAnglesCache[cacheKey]
            if (existingEntry != null && existingEntry.urls.isNotEmpty()) {
                val idx = existingEntry.currentIndex.coerceIn(0, existingEntry.urls.lastIndex)
                val cachedUrl = existingEntry.urls[idx]
                val cachedBmp = synchronized(bitmapCache) { bitmapCache.get(cachedUrl) }
                if (cachedBmp != null && !cachedBmp.isRecycled) {
                    val safeCopy = try {
                        cachedBmp.copy(Bitmap.Config.ARGB_8888, true)
                    } catch (_: Throwable) {
                        null
                    }
                    if (safeCopy != null) {
                        val place = buildPlaceResult(correctedQuery, cachedUrl, idx, existingEntry.urls.size)
                        return@withContext DirectSearchFetchResult(place, safeCopy, null, idx, existingEntry.urls.size)
                    }
                }
            }

            // 1. Primary: Keyless Bing Image Search (count=20) + DuckDuckGo backup pool
            val bingCandidates = withTimeoutOrNull(5000L) {
                fetchBingDirectImageUrls(correctedQuery, useSecondaryQuery = false)
            }.orEmpty()

            val ddgCandidates = if (bingCandidates.size < 5) {
                withTimeoutOrNull(5500L) {
                    fetchDuckDuckGoDirectImageUrls(correctedQuery)
                }.orEmpty()
            } else {
                emptyList()
            }

            val mergedCandidates = (bingCandidates + ddgCandidates).distinctBy { it.first }

            // 2. Verify all top candidates strictly against pixel-level ground-level & standable foreground rules.
            var verificationRes = verifyGroundLevelCandidates(mergedCandidates, correctedQuery, preferPortraitCrop)

            // 3. Secondary Eye-Level Query if primary yielded 0 strict ground-level angles
            if (verificationRes.strictVerified.isEmpty()) {
                val secondaryBing = withTimeoutOrNull(4500L) {
                    fetchBingDirectImageUrls(correctedQuery, useSecondaryQuery = true)
                }.orEmpty().filter { cand -> mergedCandidates.none { it.first == cand.first } }

                if (secondaryBing.isNotEmpty()) {
                    val secRes = verifyGroundLevelCandidates(secondaryBing, correctedQuery, preferPortraitCrop)
                    verificationRes = VerificationResult(
                        strictVerified = (verificationRes.strictVerified + secRes.strictVerified)
                            .sortedByDescending { it.totalScore },
                        evaluated = (verificationRes.evaluated + secRes.evaluated)
                            .sortedByDescending { it.totalScore },
                        safeFallback = listOfNotNull(verificationRes.safeFallback, secRes.safeFallback)
                            .maxByOrNull { it.totalScore }
                    )
                }
            }

            // 4. Safe Non-Empty Recovery via Wikipedia/Direct live image lookup if still empty
            if (verificationRes.strictVerified.isEmpty() && verificationRes.evaluated.isEmpty()) {
                val fallbackImgUrl = withTimeoutOrNull(4000L) {
                    val direct = DirectHttpLocationImageFetcher.fetchDirectLiveImage(correctedQuery, bypassCanonical = false)
                    val u = direct.imageUrl.trim()
                    if (u.startsWith("http") &&
                        isAllowedRealPhotoUrl(u) &&
                        !isInvalidOrNonScenicContent(direct.title, direct.description, u)
                    ) {
                        u
                    } else {
                        null
                    }
                }
                if (fallbackImgUrl != null) {
                    val directBmp = withTimeoutOrNull(4000L) {
                        validateAndDecodeImageBitmap(
                            imageUrl = fallbackImgUrl,
                            allowBorderlineFallback = true,
                            queryHint = correctedQuery,
                            preferPortraitCrop = preferPortraitCrop
                        )
                    }
                    if (directBmp != null && !directBmp.isRecycled) {
                        val urls = mutableListOf(fallbackImgUrl, fallbackImgUrl, fallbackImgUrl, fallbackImgUrl, fallbackImgUrl)
                        locationAnglesCache[cacheKey] = LocationAnglesEntry(urls = urls, currentIndex = 0)
                        val place = buildPlaceResult(correctedQuery, fallbackImgUrl, 0, urls.size)
                        return@withContext DirectSearchFetchResult(place, directBmp, null, 0, urls.size)
                    }
                }
            }

            // 5. Commit guaranteed 5 real photos (1/5 to 5/5) prioritizing highest verified solid-ground score
            val finalUrls = buildFinalUrls(
                correctedQuery = correctedQuery,
                strictVerified = verificationRes.strictVerified,
                evaluated = verificationRes.evaluated,
                safeFallback = verificationRes.safeFallback,
                mergedCandidates = mergedCandidates
            )

            val failedCommitUrls = mutableSetOf<String>()
            for (candidateUrl in finalUrls) {
                val bmp = withTimeoutOrNull(4500L) {
                    validateAndDecodeImageBitmap(
                        imageUrl = candidateUrl,
                        allowBorderlineFallback = true,
                        queryHint = correctedQuery,
                        preferPortraitCrop = preferPortraitCrop
                    )
                }
                if (bmp != null && !bmp.isRecycled) {
                    val activeList = finalUrls.filter { it !in failedCommitUrls }.toMutableList()
                    val activeIdx = activeList.indexOf(candidateUrl).coerceAtLeast(0)
                    locationAnglesCache[cacheKey] = LocationAnglesEntry(urls = activeList, currentIndex = activeIdx)
                    val place = buildPlaceResult(correctedQuery, candidateUrl, activeIdx, activeList.size)
                    return@withContext DirectSearchFetchResult(place, bmp, null, activeIdx, activeList.size)
                } else {
                    failedCommitUrls.add(candidateUrl)
                }
            }

            DirectSearchFetchResult(
                place = null,
                bitmap = null,
                errorMessage = "No real ground-level photo found for \"$correctedQuery\". Please check spelling or internet connection."
            )
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (t: Throwable) {
            android.util.Log.e("RealPhotoSearch", "Search failed safely for $query", t)
            DirectSearchFetchResult(
                place = null,
                bitmap = null,
                errorMessage = "Could not load photo right now. Please try again."
            )
        }
    }

    /**
     * 1-Tap "Next Photo" Angle Switcher:
     * Cycles strictly through verified ground-level camera angles (1..5).
     */
    suspend fun fetchNextAnglePhoto(
        context: Context,
        query: String?,
        preferPortraitCrop: Boolean = false
    ): DirectSearchFetchResult = withContext(Dispatchers.IO) {
        try {
            val correctedQuery = correctLocationQuery(query)
            if (correctedQuery.isEmpty()) {
                return@withContext DirectSearchFetchResult(null, null, "No active location selected.")
            }

            val baseKey = normalizeCacheKey(correctedQuery)
            val cacheKey = if (preferPortraitCrop) "$baseKey|916" else baseKey
            var entry = locationAnglesCache[cacheKey]

            if (entry == null || entry.urls.isEmpty()) {
                val initial = fetchDirectPhotoAndBitmap(context, correctedQuery, preferPortraitCrop)
                entry = locationAnglesCache[cacheKey]
                if (entry == null || entry.urls.size <= 1) {
                    return@withContext initial
                }
            }

            val totalBefore = entry.urls.size
            var probeIdx = (entry.currentIndex + 1) % totalBefore
            val badUrls = mutableListOf<String>()

            for (step in 0 until totalBefore) {
                val candidateUrl = entry.urls[probeIdx]
                val bmp = withTimeoutOrNull(4500L) {
                    validateAndDecodeImageBitmap(
                        imageUrl = candidateUrl,
                        allowBorderlineFallback = true,
                        queryHint = correctedQuery,
                        preferPortraitCrop = preferPortraitCrop
                    )
                }
                if (bmp != null && !bmp.isRecycled) {
                    if (badUrls.isNotEmpty()) {
                        entry.urls.removeAll(badUrls.toSet())
                        probeIdx = entry.urls.indexOf(candidateUrl).coerceAtLeast(0)
                    }
                    entry.currentIndex = probeIdx
                    val place = buildPlaceResult(correctedQuery, candidateUrl, probeIdx, entry.urls.size)
                    return@withContext DirectSearchFetchResult(place, bmp, null, probeIdx, entry.urls.size)
                } else {
                    badUrls.add(candidateUrl)
                }
                probeIdx = (probeIdx + 1) % totalBefore
            }

            entry.urls.removeAll(badUrls.toSet())
            DirectSearchFetchResult(
                place = null,
                bitmap = null,
                errorMessage = "No other verified ground-level angle available for \"$correctedQuery\"."
            )
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (t: Throwable) {
            android.util.Log.e("RealPhotoSearch", "Next angle search failed safely", t)
            DirectSearchFetchResult(null, null, "Could not load another photo angle right now.")
        }
    }

    suspend fun searchAndFetchPhoto(query: String?): GooglePlaceResult? = withContext(Dispatchers.IO) {
        try {
            val correctedQuery = correctLocationQuery(query)
            if (correctedQuery.isEmpty()) return@withContext null

            val cacheKey = normalizeCacheKey(correctedQuery)
            val entry = locationAnglesCache[cacheKey]
            if (entry != null && entry.urls.isNotEmpty()) {
                val idx = entry.currentIndex.coerceIn(0, entry.urls.lastIndex)
                return@withContext buildPlaceResult(correctedQuery, entry.urls[idx], idx, entry.urls.size)
            }

            val bingCandidates = withTimeoutOrNull(5000L) { fetchBingDirectImageUrls(correctedQuery) }.orEmpty()
            val ddgCandidates = if (bingCandidates.size < 5) {
                withTimeoutOrNull(5500L) { fetchDuckDuckGoDirectImageUrls(correctedQuery) }.orEmpty()
            } else {
                emptyList()
            }
            val mergedCandidates = (bingCandidates + ddgCandidates).distinctBy { it.first }
            val verificationRes = verifyGroundLevelCandidates(mergedCandidates, correctedQuery)
            val finalUrls = buildFinalUrls(
                correctedQuery = correctedQuery,
                strictVerified = verificationRes.strictVerified,
                evaluated = verificationRes.evaluated,
                safeFallback = verificationRes.safeFallback,
                mergedCandidates = mergedCandidates
            )
            if (finalUrls.isNotEmpty()) {
                locationAnglesCache[cacheKey] = LocationAnglesEntry(finalUrls, 0)
                return@withContext buildPlaceResult(correctedQuery, finalUrls.first(), 0, finalUrls.size)
            }
            null
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (_: Throwable) {
            null
        }
    }
}

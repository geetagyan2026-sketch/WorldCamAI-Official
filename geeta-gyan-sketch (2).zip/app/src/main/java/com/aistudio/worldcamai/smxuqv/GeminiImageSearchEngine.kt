package com.aistudio.worldcamai.smxuqv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.sqrt

data class DirectSearchFetchResult(
    val place: GooglePlaceResult?,
    val bitmap: Bitmap?,
    val errorMessage: String? = null,
    val angleIndex: Int = 0,
    val totalAngles: Int = 0
)

/**
 * Keyless Ground-Level Real-World Camera Photo Fetcher (Zero API keys, Zero HTTP 429 limits).
 *
 * Strategy:
 * 1. Auto-corrects common location spelling typos & disambiguates iconic landmarks before searching
 *    (e.g., "hagigig bridge" -> "Hanging Bridge Kota", "jal mhal" -> "Jal Mahal Jaipur", "taj mhal" -> "Taj Mahal Agra").
 * 2. Formats every search strictly for ground-level photos:
 *    `<CORRECTED_LOCATION_NAME> ground level road walkway tourist camera photo -drone -aerial -birdseye -topview -helicopter`
 * 3. Extracts structured image candidates (URL, title, description, source webpage URL) from Bing & DuckDuckGo,
 *    verifies core landmark keyword matches (preventing unrelated foreign buildings), and blocks drone/aerial terms.
 * 4. Checks the bottom 25% of decoded Bitmaps so only photos with genuine ground/road/walkway footing pass.
 * 5. Caches up to 6 verified camera angles per corrected location + Bitmap LruCache for instant "Next Photo" switching.
 */
object GeminiImageSearchEngine {
    private const val CHROME_USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private const val DOWNLOAD_USER_AGENT = "Mozilla/5.0"

    private const val MIN_PHOTO_WIDTH_PX = 700
    private const val MIN_PHOTO_HEIGHT_PX = 400
    private const val MAX_CACHED_ANGLES_PER_LOCATION = 6
    private const val MAX_IMAGE_BYTES = 12 * 1024 * 1024

    private data class ImageSearchCandidate(
        val imageUrl: String,
        val title: String = "",
        val description: String = "",
        val sourcePageUrl: String = ""
    )

    private data class LocationAnglesEntry(
        val urls: MutableList<String>,
        var currentIndex: Int = 0
    )

    private val locationAnglesCache = ConcurrentHashMap<String, LocationAnglesEntry>()

    private val maxCacheKb: Int = run {
        val maxAppKb = (Runtime.getRuntime().maxMemory() / 1024L).toInt()
        (maxAppKb / 8).coerceIn(10 * 1024, 28 * 1024)
    }

    private val bitmapCache = object : LruCache<String, Bitmap>(maxCacheKb) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return (value.allocationByteCount / 1024).coerceAtLeast(1)
        }
    }

    private val validImageExtRegex = Regex("""\.(jpe?g|png|webp)(\?.*|#.*)?$""", RegexOption.IGNORE_CASE)
    private val bingCardMetaRegex = Regex("""\bm\s*=\s*"(\{.*?\})"""")
    private val bingMurlRegex = Regex("""["']murl["']\s*:\s*["'](https?://[^"']+)["']""", RegexOption.IGNORE_CASE)
    private val ddgVqdRegex = Regex("""(?:vqd\s*=\s*["']?|["']vqd["']\s*:\s*["'])([0-9]+-[0-9A-Za-z_-]+)""")

    private val strictlyBlockedSubstrings = listOf(
        "ytimg.com",
        "youtube.com",
        "youtu.be",
        "istockphoto",
        "shutterstock",
        "dreamstime",
        "alamy",
        "vecteezy",
        "freepik",
        "pinterest",
        "gettyimages",
        "123rf",
        "depositphotos",
        "banner",
        "poster",
        "thumb",
        ".svg",
        ".gif",
        ".ico",
        ".html",
        ".htm",
        ".php",
        ".asp",
        ".aspx",
        ".pdf",
        "bing.com/th",
        "mm.bing.net",
        "duckduckgo.com/iu",
        "google.com/url",
        "google.com/search",
        "google.com/imgres",
        "favicon",
        "sprite",
        "placeholder",
        "default-avatar",
        "logo",
        "drone",
        "aerial",
        "birdseye",
        "birds-eye",
        "top-view",
        "topview",
        "helicopter",
        "uav"
    )

    private val droneBlockedMetaTerms = listOf(
        "drone",
        "aerial",
        "bird's eye",
        "birds eye",
        "birdseye",
        "bird-eye",
        "bird eye",
        "bird",
        "top-view",
        "top view",
        "topview",
        "helicopter",
        "uav",
        "from above",
        "overhead view",
        "satellite view",
        "mavic",
        "quadcopter"
    )

    private val exactPhraseCorrections = mapOf(
        "hagigig bridge" to "Hanging Bridge Kota",
        "hagiging bridge" to "Hanging Bridge Kota",
        "hangig bridge" to "Hanging Bridge Kota",
        "haging bridge" to "Hanging Bridge Kota",
        "hangging bridge" to "Hanging Bridge Kota",
        "hanging brig" to "Hanging Bridge Kota",
        "hanging bridg" to "Hanging Bridge Kota",
        "kota bridge" to "Hanging Bridge Kota",
        "jal mhal" to "Jal Mahal Jaipur",
        "jalmhal" to "Jal Mahal Jaipur",
        "jal mehal" to "Jal Mahal Jaipur",
        "taj mhal" to "Taj Mahal Agra",
        "tajmhal" to "Taj Mahal Agra",
        "tajmahal" to "Taj Mahal Agra",
        "taj mehal" to "Taj Mahal Agra",
        "taaj mahal" to "Taj Mahal Agra",
        "hawa mhal" to "Hawa Mahal Jaipur",
        "hawamhal" to "Hawa Mahal Jaipur",
        "hawa mehal" to "Hawa Mahal Jaipur",
        "amer fot" to "Amer Fort Jaipur",
        "amber fot" to "Amer Fort Jaipur",
        "city palac udaipur" to "City Palace Udaipur",
        "udaypur city palace" to "City Palace Udaipur",
        "chambal river front" to "Chambal Riverfront Kota",
        "chambal revarfront" to "Chambal Riverfront Kota",
        "kota riverfront" to "Chambal Riverfront Kota",
        "kota river front" to "Chambal Riverfront Kota",
        "7 wonders kota" to "Seven Wonders Park Kota",
        "seven wondar kota" to "Seven Wonders Park Kota",
        "qutab minar" to "Qutub Minar Delhi",
        "kutub minar" to "Qutub Minar Delhi",
        "india gat" to "India Gate Delhi",
        "red fot" to "Red Fort Delhi",
        "lal qila" to "Red Fort Delhi",
        "lal kila" to "Red Fort Delhi",
        "char minar" to "Charminar Hyderabad",
        "getway of india" to "Gateway of India Mumbai",
        "gateway of inda" to "Gateway of India Mumbai",
        "golden templ" to "Golden Temple Amritsar",
        "eifel tower" to "Eiffel Tower Paris",
        "effel tower" to "Eiffel Tower Paris",
        "eiffle tower" to "Eiffel Tower Paris",
        "ifil tower" to "Eiffel Tower Paris",
        "burj khlifa" to "Burj Khalifa Dubai",
        "burj kalifa" to "Burj Khalifa Dubai",
        "statu of liberty" to "Statue of Liberty New York",
        "statue of librty" to "Statue of Liberty New York",
        "machu pichu" to "Machu Picchu Peru",
        "tower bridg" to "Tower Bridge London"
    )

    private val tokenTypoDictionary = mapOf(
        "hagigig" to "hanging",
        "hagiging" to "hanging",
        "hangig" to "hanging",
        "hangin" to "hanging",
        "haging" to "hanging",
        "hangging" to "hanging",
        "brig" to "bridge",
        "bridg" to "bridge",
        "brdge" to "bridge",
        "brij" to "bridge",
        "mhal" to "mahal",
        "mhla" to "mahal",
        "mehal" to "mahal",
        "mahall" to "mahal",
        "mahel" to "mahal",
        "taaj" to "taj",
        "jall" to "jal",
        "hawaa" to "hawa",
        "eifel" to "eiffel",
        "effel" to "eiffel",
        "eiffle" to "eiffel",
        "ifil" to "eiffel",
        "tawer" to "tower",
        "towar" to "tower",
        "towr" to "tower",
        "fot" to "fort",
        "frt" to "fort",
        "palac" to "palace",
        "palce" to "palace",
        "templ" to "temple",
        "tempel" to "temple",
        "mander" to "mandir",
        "riverfrnt" to "riverfront",
        "revarfront" to "riverfront",
        "rivarfront" to "riverfront",
        "rivrfront" to "riverfront",
        "chambel" to "chambal",
        "chmbal" to "chambal",
        "jaipr" to "jaipur",
        "jaypur" to "jaipur",
        "udaypur" to "udaipur",
        "jaislmer" to "jaisalmer",
        "jaiselmer" to "jaisalmer",
        "varansi" to "varanasi",
        "banaras" to "varanasi",
        "coloseum" to "colosseum",
        "coliseum" to "colosseum",
        "khlifa" to "khalifa",
        "kalifa" to "khalifa",
        "librty" to "liberty",
        "statu" to "statue",
        "charminr" to "charminar",
        "charmeanr" to "charminar",
        "wondar" to "wonders",
        "mountan" to "mountain",
        "desrt" to "desert",
        "santorni" to "santorini",
        "pichu" to "picchu"
    )

    private val landmarkVocabWords = listOf(
        "hanging", "bridge", "mahal", "palace", "fort", "temple", "mandir", "tower",
        "gate", "gateway", "garden", "park", "riverfront", "lake", "beach", "desert",
        "safari", "waterfall", "museum", "colosseum", "eiffel", "liberty", "statue",
        "khalifa", "minar", "qutub", "charminar", "wonders", "chambal",
        "kota", "jaipur", "agra", "delhi", "udaipur", "jaisalmer", "mumbai", "hyderabad",
        "varanasi", "amritsar", "rajasthan", "paris", "london", "rome", "dubai", "tokyo"
    )

    private val defaultLandmarkCities = mapOf(
        "hanging bridge" to "Hanging Bridge Kota",
        "jal mahal" to "Jal Mahal Jaipur",
        "taj mahal" to "Taj Mahal Agra",
        "hawa mahal" to "Hawa Mahal Jaipur",
        "amer fort" to "Amer Fort Jaipur",
        "amber fort" to "Amber Fort Jaipur",
        "nahargarh fort" to "Nahargarh Fort Jaipur",
        "chambal riverfront" to "Chambal Riverfront Kota",
        "seven wonders park" to "Seven Wonders Park Kota",
        "qutub minar" to "Qutub Minar Delhi",
        "india gate" to "India Gate Delhi",
        "red fort" to "Red Fort Delhi",
        "charminar" to "Charminar Hyderabad",
        "gateway of india" to "Gateway of India Mumbai",
        "golden temple" to "Golden Temple Amritsar",
        "eiffel tower" to "Eiffel Tower Paris",
        "burj khalifa" to "Burj Khalifa Dubai",
        "statue of liberty" to "Statue of Liberty New York",
        "colosseum" to "Colosseum Rome",
        "tower bridge" to "Tower Bridge London"
    )

    private val knownCityTokens = setOf(
        "kota", "jaipur", "agra", "delhi", "new delhi", "udaipur", "jaisalmer", "mumbai",
        "hyderabad", "varanasi", "amritsar", "rajasthan", "india", "paris", "france",
        "london", "uk", "rome", "italy", "dubai", "uae", "tokyo", "japan", "york",
        "california", "switzerland", "china", "canada", "nepal", "kerala", "goa", "shimla",
        "manali", "rishikesh", "ladakh", "kashmir", "jodhpur", "bikaner", "pushkar", "bundi"
    )

    private val competingRegionTokens = listOf(
        "california", "swiss", "switzerland", "china", "japan", "tokyo", "canada",
        "germany", "malaysia", "indonesia", "vietnam", "thailand", "philippines",
        "taiwan", "korea", "brazil", "mexico", "australia", "scotland", "wales",
        "ireland", "spain", "portugal", "norway", "austria", "nepal", "pakistan"
    )

    private val queryFillerWords = setOf(
        "the", "of", "in", "at", "on", "near", "and", "to", "a", "an", "for", "by", "view", "photo"
    )

    private fun levenshteinDistance(a: String, b: String): Int {
        return try {
            if (a == b) return 0
            if (a.isEmpty()) return b.length
            if (b.isEmpty()) return a.length
            val dp = IntArray(b.length + 1) { it }
            for (i in 1..a.length) {
                var prev = dp[0]
                dp[0] = i
                for (j in 1..b.length) {
                    val temp = dp[j]
                    val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                    dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + cost)
                    prev = temp
                }
            }
            dp[b.length]
        } catch (_: Throwable) {
            Int.MAX_VALUE
        }
    }

    private fun fuzzyCorrectToken(rawToken: String): String {
        return try {
            val lower = rawToken.lowercase(Locale.US)
            if (lower.length <= 2) return lower
            tokenTypoDictionary[lower]?.let { return it }
            if (lower in landmarkVocabWords || lower in knownCityTokens || lower in queryFillerWords) {
                return lower
            }
            if (lower.length < 4 || lower.length > 32) return lower

            var bestWord = lower
            var bestDist = Int.MAX_VALUE
            val maxAllowed = if (lower.length >= 6) 2 else 1

            for (vocab in landmarkVocabWords) {
                if (abs(vocab.length - lower.length) > maxAllowed) continue
                if (maxAllowed == 2 && vocab.firstOrNull() != lower.firstOrNull()) continue
                val d = levenshteinDistance(lower, vocab)
                if (d <= maxAllowed && d < bestDist) {
                    bestDist = d
                    bestWord = vocab
                }
            }
            bestWord
        } catch (_: Throwable) {
            rawToken
        }
    }

    private fun formatLocationTitleCase(text: String): String {
        return try {
            val minorWords = setOf("of", "in", "at", "on", "the", "and")
            text.split(Regex("\\s+"))
                .filter { it.isNotBlank() }
                .mapIndexed { index, word ->
                    val lower = word.lowercase(Locale.US)
                    if (index > 0 && lower in minorWords) {
                        lower
                    } else {
                        lower.replaceFirstChar { ch ->
                            if (ch.isLowerCase()) ch.titlecase(Locale.US) else ch.toString()
                        }
                    }
                }
                .joinToString(" ")
        } catch (_: Throwable) {
            text.trim()
        }
    }

    /**
     * Auto-corrects misspelled landmark/location queries while preserving user-provided cities
     * and disambiguating famous landmarks when no city is specified.
     */
    fun correctLocationQuery(rawQuery: String?): String {
        return try {
            val safeRaw = rawQuery.orEmpty().take(150)
            val trimmed = safeRaw.trim().replace(Regex("[,;|]+"), " ").replace(Regex("\\s+"), " ").trim()
            if (trimmed.isEmpty()) return ""

            val lowerClean = trimmed.lowercase(Locale.US)
            exactPhraseCorrections[lowerClean]?.let { return it }

            val rawWords = lowerClean.split(Regex("\\s+")).filter { it.isNotBlank() }.take(14)
            if (rawWords.isEmpty()) return ""
            val correctedWords = rawWords.map { fuzzyCorrectToken(it) }
            val correctedJoined = correctedWords.joinToString(" ")

            exactPhraseCorrections[correctedJoined]?.let { return it }

            // Disambiguate iconic landmarks if no explicit city/region token was provided
            val hasUserCity = correctedWords.any { it in knownCityTokens }
            if (!hasUserCity) {
                defaultLandmarkCities[correctedJoined]?.let { return it }
                for ((landmarkPhrase, fullWithCity) in defaultLandmarkCities) {
                    if (correctedJoined.contains(landmarkPhrase) && correctedWords.size <= 3) {
                        return fullWithCity
                    }
                }
            }

            formatLocationTitleCase(correctedJoined)
        } catch (_: Throwable) {
            rawQuery.orEmpty().trim()
        }
    }

    private fun normalizeCacheKey(query: String?): String {
        return try {
            correctLocationQuery(query).lowercase(Locale.US).replace(Regex("\\s+"), " ").trim()
        } catch (_: Throwable) {
            query.orEmpty().lowercase(Locale.US).trim()
        }
    }

    private fun buildRealWorldSearchQuery(correctedLocationName: String): String {
        val clean = correctedLocationName.trim()
        return "$clean ground level road walkway tourist camera photo -drone -aerial -birdseye -topview -helicopter"
    }

    private fun unescapeBingHtml(raw: String): String {
        return raw
            .replace("&quot;", "\"")
            .replace("&#34;", "\"")
            .replace("&apos;", "'")
            .replace("&#39;", "'")
            .replace("&amp;", "&")
            .replace("&#38;", "&")
            .replace("&#x2F;", "/")
            .replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("\\u003d", "=")
    }

    private fun isAllowedRealPhotoUrl(url: String): Boolean {
        val lower = url.lowercase(Locale.US).trim()
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) return false
        if (strictlyBlockedSubstrings.any { lower.contains(it) }) return false
        return validImageExtRegex.containsMatchIn(lower)
    }

    private fun containsBlockedDroneTerm(candidate: ImageSearchCandidate): Boolean {
        val combined = "${candidate.imageUrl} ${candidate.title} ${candidate.description} ${candidate.sourcePageUrl}"
            .lowercase(Locale.US)
        return droneBlockedMetaTerms.any { term -> combined.contains(term) }
    }

    private fun extractCoreKeywords(correctedQuery: String): List<String> {
        return correctedQuery.lowercase(Locale.US)
            .split(Regex("[^a-z0-9]+"))
            .filter { it.length >= 2 && it !in queryFillerWords }
            .distinct()
    }

    private fun candidateRelevanceScore(candidate: ImageSearchCandidate, correctedQuery: String): Int {
        if (!isAllowedRealPhotoUrl(candidate.imageUrl)) return -1
        if (containsBlockedDroneTerm(candidate)) return -1

        val coreKeywords = extractCoreKeywords(correctedQuery)
        if (coreKeywords.isEmpty()) return 1

        val normalizedMeta = "${candidate.title} ${candidate.description} ${candidate.sourcePageUrl} ${candidate.imageUrl}"
            .lowercase(Locale.US)
            .replace(Regex("[^a-z0-9]+"), " ")

        val metaTokens = normalizedMeta.split(Regex("\\s+")).filter { it.isNotBlank() }.toSet()

        // Reject if result explicitly names a competing foreign country/region not in user query
        for (region in competingRegionTokens) {
            if (region !in coreKeywords && metaTokens.contains(region)) {
                return -1
            }
        }

        val landmarkTokens = coreKeywords.filter { it !in knownCityTokens }.ifEmpty { coreKeywords }
        val cityTokens = coreKeywords.filter { it in knownCityTokens }

        var landmarkMatches = 0
        for (tok in landmarkTokens) {
            if (metaTokens.contains(tok) || normalizedMeta.contains(tok)) {
                landmarkMatches++
            }
        }

        var cityMatches = 0
        for (tok in cityTokens) {
            if (metaTokens.contains(tok) || normalizedMeta.contains(tok)) {
                cityMatches++
            }
        }

        val totalMatched = landmarkMatches + cityMatches
        if (totalMatched == 0) return -1

        // Core landmark words (e.g., "hanging", "bridge", "jal", "mahal") must actually match title/desc/url
        val requiredLandmarkMatches = if (landmarkTokens.size >= 2) 2 else 1
        val hasTitleOrDesc = candidate.title.isNotBlank() || candidate.description.isNotBlank()
        if (hasTitleOrDesc && landmarkMatches < requiredLandmarkMatches && !(landmarkMatches >= 1 && cityMatches >= 1)) {
            return -1
        }
        if (landmarkMatches == 0) return -1

        var score = landmarkMatches * 10 + cityMatches * 8
        val titleLower = candidate.title.lowercase(Locale.US)
        if (titleLower.contains(correctedQuery.lowercase(Locale.US))) {
            score += 20
        }
        if (normalizedMeta.contains("ground") || normalizedMeta.contains("walkway") || normalizedMeta.contains("road") || normalizedMeta.contains("street")) {
            score += 3
        }
        return score
    }

    private fun rankAndFilterCandidates(
        candidates: List<ImageSearchCandidate>,
        correctedQuery: String
    ): List<String> {
        val scored = mutableListOf<Pair<String, Int>>()
        val seenUrls = hashSetOf<String>()

        for (c in candidates) {
            if (!seenUrls.add(c.imageUrl)) continue
            val s = candidateRelevanceScore(c, correctedQuery)
            if (s > 0) {
                scored.add(c.imageUrl to s)
            }
        }

        // If strict 2-keyword title filter rejected everything due to sparse alt-text, allow single-landmark-token fallback
        // (still strictly enforcing no drone/aerial terms and no conflicting foreign region)
        if (scored.isEmpty()) {
            val coreKeywords = extractCoreKeywords(correctedQuery)
            val landmarkTokens = coreKeywords.filter { it !in knownCityTokens }.ifEmpty { coreKeywords }
            for (c in candidates) {
                if (!isAllowedRealPhotoUrl(c.imageUrl) || containsBlockedDroneTerm(c)) continue
                val combined = "${c.title} ${c.description} ${c.sourcePageUrl} ${c.imageUrl}"
                    .lowercase(Locale.US)
                    .replace(Regex("[^a-z0-9]+"), " ")
                val tokens = combined.split(Regex("\\s+")).toSet()
                if (competingRegionTokens.any { it !in coreKeywords && tokens.contains(it) }) continue
                val hitCount = coreKeywords.count { tokens.contains(it) || combined.contains(it) }
                val primaryHit = landmarkTokens.any { tokens.contains(it) || combined.contains(it) }
                if (primaryHit && hitCount >= 1) {
                    scored.add(c.imageUrl to hitCount)
                }
            }
        }

        return scored
            .sortedByDescending { it.second }
            .map { it.first }
            .distinct()
    }

    private fun openConnectionFollowingRedirects(
        initialUrl: String,
        userAgent: String,
        acceptHeader: String,
        referer: String? = null
    ): Pair<HttpURLConnection, String>? {
        var currentUrl = initialUrl
        for (hop in 0 until 5) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 4000
                readTimeout = 4500
                requestMethod = "GET"
                setRequestProperty("User-Agent", userAgent)
                setRequestProperty("Accept", acceptHeader)
                setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                if (!referer.isNullOrBlank()) {
                    setRequestProperty("Referer", referer)
                }
            }
            val code = conn.responseCode
            if (code in 300..399) {
                val location = conn.getHeaderField("Location")?.trim().orEmpty()
                conn.disconnect()
                if (location.isBlank()) return null
                currentUrl = try {
                    URL(URL(currentUrl), location).toString()
                } catch (_: Throwable) {
                    return null
                }
                continue
            }
            return conn to currentUrl
        }
        return null
    }

    private fun readHttpText(url: String, userAgent: String, acceptHeader: String, referer: String? = null): String? {
        var conn: HttpURLConnection? = null
        return try {
            val opened = openConnectionFollowingRedirects(url, userAgent, acceptHeader, referer) ?: return null
            conn = opened.first
            if (conn.responseCode !in 200..299) return null
            val maxBytes = 650 * 1024
            val baos = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            conn.inputStream.use { stream ->
                var total = 0
                while (total < maxBytes) {
                    val read = stream.read(buf, 0, minOf(buf.size, maxBytes - total))
                    if (read <= 0) break
                    baos.write(buf, 0, read)
                    total += read
                }
            }
            baos.toString(Charsets.UTF_8.name())
        } catch (t: Throwable) {
            android.util.Log.w("RealPhotoSearch", "HTTP text fetch failed for $url: ${t.message}")
            null
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun fetchBingDirectImageUrls(correctedLocation: String): List<String> {
        val fullQuery = buildRealWorldSearchQuery(correctedLocation)
        val encodedQuery = URLEncoder.encode(fullQuery, "UTF-8")
        val bingUrl = "https://www.bing.com/images/async?q=$encodedQuery&first=1&count=12&adlt=strict"
        val html = readHttpText(
            url = bingUrl,
            userAgent = CHROME_USER_AGENT,
            acceptHeader = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            referer = "https://www.bing.com/"
        ) ?: return emptyList()

        val candidates = mutableListOf<ImageSearchCandidate>()

        // 1. Structured Bing card JSON (extracts murl + title + desc + purl together)
        for (match in bingCardMetaRegex.findAll(html)) {
            try {
                val jsonText = unescapeBingHtml(match.groupValues[1])
                val obj = JSONObject(jsonText)
                val murl = obj.optString("murl", "").trim()
                if (murl.isNotEmpty()) {
                    val title = obj.optString("t", "").trim()
                    val desc = obj.optString("desc", "").trim()
                    val purl = obj.optString("purl", "").trim()
                    candidates.add(ImageSearchCandidate(murl, title, desc, purl))
                }
            } catch (_: Throwable) {}
        }

        // 2. Regex fallback if card JSON formatting varied
        if (candidates.isEmpty()) {
            val decodedHtml = unescapeBingHtml(html)
            for (match in bingMurlRegex.findAll(decodedHtml)) {
                val rawUrl = match.groupValues[1].trim()
                if (rawUrl.isNotEmpty()) {
                    candidates.add(ImageSearchCandidate(imageUrl = rawUrl))
                }
            }
        }

        return rankAndFilterCandidates(candidates, correctedLocation)
    }

    private fun fetchDuckDuckGoDirectImageUrls(correctedLocation: String): List<String> {
        val fullQuery = buildRealWorldSearchQuery(correctedLocation)
        val encodedQuery = URLEncoder.encode(fullQuery, "UTF-8")
        val landingUrl = "https://duckduckgo.com/?q=$encodedQuery&iax=images&ia=images"
        val landingHtml = readHttpText(
            url = landingUrl,
            userAgent = CHROME_USER_AGENT,
            acceptHeader = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        ) ?: return emptyList()

        val vqdMatch = ddgVqdRegex.find(landingHtml) ?: return emptyList()
        val vqdToken = vqdMatch.groupValues[1].trim()
        if (vqdToken.isBlank()) return emptyList()

        val apiUrl = "https://duckduckgo.com/i.js?q=$encodedQuery&o=json&vqd=${URLEncoder.encode(vqdToken, "UTF-8")}"
        val jsonText = readHttpText(
            url = apiUrl,
            userAgent = CHROME_USER_AGENT,
            acceptHeader = "application/json, text/javascript, */*; q=0.01",
            referer = "https://duckduckgo.com/"
        ) ?: return emptyList()

        return try {
            val root = JSONObject(jsonText)
            val results = root.optJSONArray("results") ?: return emptyList()
            val candidates = mutableListOf<ImageSearchCandidate>()
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val width = item.optInt("width", 0)
                if (width in 1 until MIN_PHOTO_WIDTH_PX) continue
                val imageUrl = item.optString("image", "").trim()
                if (imageUrl.isEmpty()) continue
                val title = item.optString("title", "").trim()
                val sourceUrl = item.optString("url", "").trim()
                candidates.add(
                    ImageSearchCandidate(
                        imageUrl = imageUrl,
                        title = title,
                        description = "",
                        sourcePageUrl = sourceUrl
                    )
                )
            }
            rankAndFilterCandidates(candidates, correctedLocation)
        } catch (t: Throwable) {
            android.util.Log.w("RealPhotoSearch", "DuckDuckGo JSON parse failed: ${t.message}")
            emptyList()
        }
    }

    /**
     * Checks the bottom 25% of the decoded photo to ensure genuine ground/road/walkway/waterfront footing
     * (rejects mid-air sky-bottom crops, flat white graphic banners, and solid blank frames).
     */
    private fun hasGroundLevelFooting(bitmap: Bitmap): Boolean {
        return try {
            val w = bitmap.width
            val h = bitmap.height
            if (w < 64 || h < 64) return false

            val startY = (h * 0.75f).toInt().coerceIn(0, h - 2)
            val cols = 20
            val rows = 8

            var sumLum = 0.0
            var sumLumSq = 0.0
            var skyVoidCount = 0
            var texturedEdgeHits = 0
            var count = 0

            for (ry in 0 until rows) {
                val py = (startY + ((ry + 0.5f) * (h - startY) / rows)).toInt().coerceIn(startY, h - 1)
                for (cx in 0 until cols) {
                    val px = ((cx + 0.5f) * w / cols).toInt().coerceIn(1, w - 2)
                    val pixel = bitmap.getPixel(px, py)
                    val r = (pixel ushr 16) and 0xFF
                    val g = (pixel ushr 8) and 0xFF
                    val b = pixel and 0xFF
                    val maxC = maxOf(r, maxOf(g, b))
                    val minC = minOf(r, minOf(g, b))
                    val sat = if (maxC > 0) (maxC - minC).toFloat() / maxC.toFloat() else 0f
                    val lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f

                    val isSkyOrCloud = (b > r + 14 && b >= g && lum > 0.50f) || (lum > 0.86f && sat < 0.10f)
                    if (isSkyOrCloud) skyVoidCount++

                    val rightPx = bitmap.getPixel((px + 3).coerceAtMost(w - 1), py)
                    val rightLum = (0.299f * ((rightPx ushr 16) and 0xFF) + 0.587f * ((rightPx ushr 8) and 0xFF) + 0.114f * (rightPx and 0xFF)) / 255f
                    if (abs(lum - rightLum) > 0.025f) {
                        texturedEdgeHits++
                    }

                    sumLum += lum
                    sumLumSq += lum * lum
                    count++
                }
            }

            if (count == 0) return true
            val avgLum = (sumLum / count).toFloat()
            val variance = ((sumLumSq / count) - avgLum * avgLum).toFloat().coerceAtLeast(0f)
            val stdDev = sqrt(variance)
            val skyVoidRatio = skyVoidCount.toFloat() / count.toFloat()
            val textureRatio = texturedEdgeHits.toFloat() / count.toFloat()

            // Must have real ground/road/walkway footing (not mostly bright sky/void or flat solid graphic)
            if (skyVoidRatio > 0.52f) return false
            if (avgLum > 0.90f || avgLum < 0.035f) return false
            if (stdDev < 0.020f && textureRatio < 0.06f) return false

            true
        } catch (_: Throwable) {
            true
        }
    }

    private fun validateAndDecodeImageBitmap(imageUrl: String): Bitmap? {
        if (!isAllowedRealPhotoUrl(imageUrl)) return null

        val cached = synchronized(bitmapCache) { bitmapCache.get(imageUrl) }
        if (cached != null && !cached.isRecycled) {
            try {
                return cached.copy(Bitmap.Config.ARGB_8888, true)
            } catch (_: Throwable) {}
        }

        var activeConn: HttpURLConnection? = null
        return try {
            val opened = openConnectionFollowingRedirects(
                initialUrl = imageUrl,
                userAgent = DOWNLOAD_USER_AGENT,
                acceptHeader = "image/webp,image/jpeg,image/png,image/*;q=0.8"
            ) ?: return null
            activeConn = opened.first
            val finalUrl = opened.second
            val code = activeConn.responseCode
            if (code !in 200..299) return null
            if (!isAllowedRealPhotoUrl(finalUrl)) return null

            val mime = activeConn.contentType.orEmpty().lowercase(Locale.US)
            if (mime.contains("text/html") ||
                mime.contains("application/xhtml") ||
                mime.contains("svg") ||
                mime.contains("gif")
            ) {
                return null
            }
            if (!mime.startsWith("image/") && !validImageExtRegex.containsMatchIn(finalUrl)) {
                return null
            }

            val baos = ByteArrayOutputStream()
            val buf = ByteArray(16384)
            activeConn.inputStream.use { stream ->
                var total = 0
                while (total < MAX_IMAGE_BYTES) {
                    val read = stream.read(buf, 0, minOf(buf.size, MAX_IMAGE_BYTES - total))
                    if (read <= 0) break
                    baos.write(buf, 0, read)
                    total += read
                }
            }
            val bytes = baos.toByteArray()
            if (bytes.size < 6144) return null

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth < MIN_PHOTO_WIDTH_PX || bounds.outHeight < MIN_PHOTO_HEIGHT_PX) {
                return null
            }

            // Compute power-of-2 inSampleSize and cap safely on low-RAM heaps to avoid OutOfMemoryError
            val maxHeapMb = (Runtime.getRuntime().maxMemory() / (1024L * 1024L)).toInt()
            val targetMaxDim = if (maxHeapMb <= 256) 1280 else 1600
            var sample = 1
            val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
            while ((maxDim / sample) > targetMaxDim) {
                sample *= 2
            }

            var decoded: Bitmap? = null
            for (attempt in 0..1) {
                try {
                    val decodeOpts = BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                        inMutable = true
                    }
                    decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)
                    if (decoded != null) break
                } catch (_: OutOfMemoryError) {
                    sample *= 2
                    System.gc()
                }
            }
            if (decoded == null) return null

            val finalMutable = try {
                if (decoded.config != Bitmap.Config.ARGB_8888 || !decoded.isMutable) {
                    decoded.copy(Bitmap.Config.ARGB_8888, true).also {
                        if (!decoded.isRecycled) decoded.recycle()
                    }
                } else {
                    decoded
                }
            } catch (_: OutOfMemoryError) {
                decoded
            }

            // Bottom 25% check: ensure genuine ground/road/walkway footing
            if (!hasGroundLevelFooting(finalMutable)) {
                return null
            }

            try {
                val cacheCopy = finalMutable.copy(Bitmap.Config.ARGB_8888, false)
                if (cacheCopy != null) {
                    synchronized(bitmapCache) { bitmapCache.put(imageUrl, cacheCopy) }
                }
            } catch (_: Throwable) {}

            finalMutable
        } catch (t: Throwable) {
            android.util.Log.w("RealPhotoSearch", "Image download/decode failed for $imageUrl: ${t.message}")
            null
        } finally {
            try { activeConn?.disconnect() } catch (_: Throwable) {}
        }
    }

    private fun buildPlaceResult(
        correctedQuery: String,
        imageUrl: String,
        angleIndex: Int,
        totalAngles: Int
    ): GooglePlaceResult {
        val angleSuffix = if (totalAngles > 1) "Angle ${angleIndex + 1}/$totalAngles" else "Ground-Level Camera"
        return GooglePlaceResult(
            placeId = "webimg_${correctedQuery.hashCode()}",
            name = correctedQuery,
            formattedAddress = "$correctedQuery • $angleSuffix",
            photoUrl = imageUrl,
            exactPhotoUrl = imageUrl,
            description = "Authentic ground-level daylight camera photograph of $correctedQuery.",
            funFact = "Blended with automatic lighting sync and ground-aware contact shadow."
        )
    }

    fun getCachedAngleCount(query: String?): Int {
        return try {
            val key = normalizeCacheKey(query)
            locationAnglesCache[key]?.urls?.size ?: 0
        } catch (_: Throwable) {
            0
        }
    }

    suspend fun fetchDirectPhotoAndBitmap(
        context: Context,
        query: String?
    ): DirectSearchFetchResult = withContext(Dispatchers.IO) {
        try {
            val correctedQuery = correctLocationQuery(query)
            if (correctedQuery.isEmpty()) {
                return@withContext DirectSearchFetchResult(null, null, "Please enter a location name.")
            }

            val cacheKey = normalizeCacheKey(correctedQuery)
            val existingEntry = locationAnglesCache[cacheKey]
            if (existingEntry != null && existingEntry.urls.isNotEmpty()) {
                val idx = existingEntry.currentIndex.coerceIn(0, existingEntry.urls.lastIndex)
                val cachedUrl = existingEntry.urls[idx]
                val cachedBmp = synchronized(bitmapCache) { bitmapCache.get(cachedUrl) }
                if (cachedBmp != null && !cachedBmp.isRecycled) {
                    val safeCopy = try {
                        cachedBmp.copy(Bitmap.Config.ARGB_8888, true)
                    } catch (_: Throwable) {
                        null
                    }
                    if (safeCopy != null) {
                        val place = buildPlaceResult(correctedQuery, cachedUrl, idx, existingEntry.urls.size)
                        return@withContext DirectSearchFetchResult(place, safeCopy, null, idx, existingEntry.urls.size)
                    }
                }
            }

            val collectedUrls = linkedSetOf<String>()

            // 1. Primary: Keyless Bing Image Search with keyword & anti-drone verification
            val bingUrls = withTimeoutOrNull(5000L) {
                fetchBingDirectImageUrls(correctedQuery)
            }.orEmpty()
            collectedUrls.addAll(bingUrls)

            var winningUrl: String? = null
            var winningBitmap: Bitmap? = null
            val failedUrls = mutableSetOf<String>()

            for (candidate in bingUrls) {
                val bmp = withTimeoutOrNull(4500L) { validateAndDecodeImageBitmap(candidate) }
                if (bmp != null && !bmp.isRecycled) {
                    winningUrl = candidate
                    winningBitmap = bmp
                    break
                } else {
                    failedUrls.add(candidate)
                }
            }

            // 2. Secondary Backup: Keyless DuckDuckGo Image Search if Bing had no passing ground-level photo
            if (winningBitmap == null) {
                val ddgUrls = withTimeoutOrNull(6000L) {
                    fetchDuckDuckGoDirectImageUrls(correctedQuery)
                }.orEmpty()
                collectedUrls.addAll(ddgUrls)
                for (candidate in ddgUrls) {
                    if (candidate in failedUrls) continue
                    val bmp = withTimeoutOrNull(4500L) { validateAndDecodeImageBitmap(candidate) }
                    if (bmp != null && !bmp.isRecycled) {
                        winningUrl = candidate
                        winningBitmap = bmp
                        break
                    } else {
                        failedUrls.add(candidate)
                    }
                }
            }

            if (winningUrl != null && winningBitmap != null && !winningBitmap.isRecycled) {
                val top6 = mutableListOf(winningUrl)
                for (u in collectedUrls) {
                    if (top6.size >= MAX_CACHED_ANGLES_PER_LOCATION) break
                    if (u != winningUrl && u !in failedUrls) {
                        top6.add(u)
                    }
                }
                locationAnglesCache[cacheKey] = LocationAnglesEntry(urls = top6, currentIndex = 0)
                val place = buildPlaceResult(correctedQuery, winningUrl, 0, top6.size)
                return@withContext DirectSearchFetchResult(place, winningBitmap, null, 0, top6.size)
            }

            DirectSearchFetchResult(
                place = null,
                bitmap = null,
                errorMessage = "No real ground-level photo found for \"$correctedQuery\". Please check spelling or internet connection."
            )
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (t: Throwable) {
            android.util.Log.e("RealPhotoSearch", "Search failed safely for $query", t)
            DirectSearchFetchResult(
                place = null,
                bitmap = null,
                errorMessage = "Could not load photo right now. Please try again."
            )
        }
    }

    /**
     * 1-Tap "Next Photo" Angle Switcher:
     * Cycles through up to 6 verified ground-level camera angles for the searched location.
     */
    suspend fun fetchNextAnglePhoto(
        context: Context,
        query: String?
    ): DirectSearchFetchResult = withContext(Dispatchers.IO) {
        try {
            val correctedQuery = correctLocationQuery(query)
            if (correctedQuery.isEmpty()) {
                return@withContext DirectSearchFetchResult(null, null, "No active location selected.")
            }

            val cacheKey = normalizeCacheKey(correctedQuery)
            var entry = locationAnglesCache[cacheKey]

            if (entry == null || entry.urls.isEmpty()) {
                val initial = fetchDirectPhotoAndBitmap(context, correctedQuery)
                entry = locationAnglesCache[cacheKey]
                if (entry == null || entry.urls.size <= 1) {
                    return@withContext initial
                }
            }

            if (entry.urls.size <= 1) {
                val extraBing = withTimeoutOrNull(4500L) { fetchBingDirectImageUrls(correctedQuery) }.orEmpty()
                val extraDdg = if (extraBing.size <= 2) {
                    withTimeoutOrNull(5500L) { fetchDuckDuckGoDirectImageUrls(correctedQuery) }.orEmpty()
                } else emptyList()
                for (u in (extraBing + extraDdg)) {
                    if (entry.urls.size >= MAX_CACHED_ANGLES_PER_LOCATION) break
                    if (u !in entry.urls) entry.urls.add(u)
                }
            }

            if (entry.urls.size <= 1) {
                val onlyUrl = entry.urls.firstOrNull()
                val bmp = onlyUrl?.let { validateAndDecodeImageBitmap(it) }
                if (onlyUrl != null && bmp != null) {
                    val place = buildPlaceResult(correctedQuery, onlyUrl, 0, 1)
                    return@withContext DirectSearchFetchResult(place, bmp, null, 0, 1)
                }
                return@withContext DirectSearchFetchResult(null, null, "Only one angle available for \"$correctedQuery\".")
            }

            val totalBefore = entry.urls.size
            var probeIdx = (entry.currentIndex + 1) % totalBefore
            val badUrls = mutableListOf<String>()

            for (step in 0 until totalBefore) {
                val candidateUrl = entry.urls[probeIdx]
                val bmp = withTimeoutOrNull(4500L) { validateAndDecodeImageBitmap(candidateUrl) }
                if (bmp != null && !bmp.isRecycled) {
                    if (badUrls.isNotEmpty()) {
                        entry.urls.removeAll(badUrls.toSet())
                        probeIdx = entry.urls.indexOf(candidateUrl).coerceAtLeast(0)
                    }
                    entry.currentIndex = probeIdx
                    val place = buildPlaceResult(correctedQuery, candidateUrl, probeIdx, entry.urls.size)
                    return@withContext DirectSearchFetchResult(place, bmp, null, probeIdx, entry.urls.size)
                } else {
                    badUrls.add(candidateUrl)
                }
                probeIdx = (probeIdx + 1) % totalBefore
            }

            entry.urls.removeAll(badUrls.toSet())
            DirectSearchFetchResult(
                place = null,
                bitmap = null,
                errorMessage = "Could not load another ground-level angle for \"$correctedQuery\"."
            )
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (t: Throwable) {
            android.util.Log.e("RealPhotoSearch", "Next angle search failed safely", t)
            DirectSearchFetchResult(null, null, "Could not load another photo angle right now.")
        }
    }

    suspend fun searchAndFetchPhoto(query: String?): GooglePlaceResult? = withContext(Dispatchers.IO) {
        try {
            val correctedQuery = correctLocationQuery(query)
            if (correctedQuery.isEmpty()) return@withContext null

            val cacheKey = normalizeCacheKey(correctedQuery)
            val entry = locationAnglesCache[cacheKey]
            if (entry != null && entry.urls.isNotEmpty()) {
                val idx = entry.currentIndex.coerceIn(0, entry.urls.lastIndex)
                return@withContext buildPlaceResult(correctedQuery, entry.urls[idx], idx, entry.urls.size)
            }

            val bingUrls = withTimeoutOrNull(5000L) { fetchBingDirectImageUrls(correctedQuery) }.orEmpty()
            for (candidate in bingUrls) {
                val bmp = withTimeoutOrNull(4500L) { validateAndDecodeImageBitmap(candidate) }
                if (bmp != null && !bmp.isRecycled) {
                    val top6 = (listOf(candidate) + bingUrls.filter { it != candidate }).take(MAX_CACHED_ANGLES_PER_LOCATION).toMutableList()
                    locationAnglesCache[cacheKey] = LocationAnglesEntry(top6, 0)
                    return@withContext buildPlaceResult(correctedQuery, candidate, 0, top6.size)
                }
            }

            val ddgUrls = withTimeoutOrNull(6000L) { fetchDuckDuckGoDirectImageUrls(correctedQuery) }.orEmpty()
            for (candidate in ddgUrls) {
                val bmp = withTimeoutOrNull(4500L) { validateAndDecodeImageBitmap(candidate) }
                if (bmp != null && !bmp.isRecycled) {
                    val top6 = (listOf(candidate) + ddgUrls.filter { it != candidate }).take(MAX_CACHED_ANGLES_PER_LOCATION).toMutableList()
                    locationAnglesCache[cacheKey] = LocationAnglesEntry(top6, 0)
                    return@withContext buildPlaceResult(correctedQuery, candidate, 0, top6.size)
                }
            }
            null
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (_: Throwable) {
            null
        }
    }
}

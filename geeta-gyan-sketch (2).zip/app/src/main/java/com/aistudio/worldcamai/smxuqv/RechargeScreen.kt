package com.aistudio.worldcamai.smxuqv

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class RechargePlan(
    val title: String,
    val sku: String,
    val priceInr: Int,
    val priceUsd: Double
)

@Composable
fun RechargeScreen(onPurchaseSelected: (RechargePlan) -> Unit) {
    val plans = listOf(
        RechargePlan("5 AI Photos Pack", "worldcam_5_photos", 10, 49.00),
        RechargePlan("13 AI Photos Pack", "worldcam_13_photos", 19, 1.19),
        RechargePlan("15 Days Premium Access", "worldcam_15days_premium", 49, 2.39),
        RechargePlan("1 Month Premium Access", "worldcam_1month_premium", 99, 3.59),
        RechargePlan("Permanent Watermark Removal", "worldcam_postcard_unlock", 49, 1.99)
    )

    LazyColumn(modifier = Modifier.padding(16.dp)) {
        items(plans) { plan ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                onClick = { onPurchaseSelected(plan) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = plan.title, style = MaterialTheme.typography.titleMedium)
                    Text(text = "India: ₹${plan.priceInr} | International: $${plan.priceUsd}")
                }
            }
        }
    }
}

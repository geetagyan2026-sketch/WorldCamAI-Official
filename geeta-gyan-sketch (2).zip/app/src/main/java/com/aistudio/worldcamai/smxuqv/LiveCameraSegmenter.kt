package com.aistudio.worldcamai.smxuqv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.Segmenter
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

@Composable
fun LiveCameraSelfieSegmenterEffect(
    enabled: Boolean,
    lensFacing: Int,
    context: Context,
    onFrameSegmented: (Bitmap) -> Unit,
    onCameraError: (String) -> Unit
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val latestOnFrame by rememberUpdatedState(onFrameSegmented)
    val latestOnError by rememberUpdatedState(onCameraError)
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    DisposableEffect(enabled, lensFacing, lifecycleOwner) {
        if (!enabled) {
            return@DisposableEffect onDispose {}
        }

        val isDisposed = AtomicBoolean(false)
        val analyzerExecutor = Executors.newSingleThreadExecutor()
        var cameraProvider: ProcessCameraProvider? = null
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.STREAM_MODE)
            .build()
        val segmenter: Segmenter = Segmentation.getClient(options)

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            if (isDisposed.get()) return@addListener
            try {
                val provider = cameraProviderFuture.get()
                cameraProvider = provider

                val resolutionSelector = ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(480, 640),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                        )
                    )
                    .build()

                val imageAnalysis = ImageAnalysis.Builder()
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setResolutionSelector(resolutionSelector)
                    .build()

                imageAnalysis.setAnalyzer(analyzerExecutor) { imageProxy ->
                    if (isDisposed.get()) {
                        imageProxy.close()
                        return@setAnalyzer
                    }
                    try {
                        val rawBmp = imageProxy.toBitmap()
                        val rotation = imageProxy.imageInfo.rotationDegrees.toFloat()
                        val isFront = (lensFacing == CameraSelector.LENS_FACING_FRONT)

                        val orientedBmp = if (rotation != 0f || isFront) {
                            val matrix = Matrix().apply {
                                if (rotation != 0f) postRotate(rotation)
                                if (isFront) postScale(-1f, 1f)
                            }
                            Bitmap.createBitmap(rawBmp, 0, 0, rawBmp.width, rawBmp.height, matrix, true)
                        } else {
                            rawBmp
                        }

                        val inputImage = InputImage.fromBitmap(orientedBmp, 0)
                        val mask = Tasks.await(segmenter.process(inputImage), 800, TimeUnit.MILLISECONDS)

                        if (mask != null && !isDisposed.get()) {
                            val cutout = applyFastSelfieMask(orientedBmp, mask)
                            if (cutout != null && !isDisposed.get()) {
                                mainHandler.post {
                                    if (!isDisposed.get()) {
                                        latestOnFrame(cutout)
                                    }
                                }
                            }
                        }
                    } catch (t: Throwable) {
                        Log.w("LiveCameraSegmenter", "Frame analysis skipped: ${t.message}")
                    } finally {
                        imageProxy.close()
                    }
                }

                val selector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, selector, imageAnalysis)
            } catch (e: Throwable) {
                Log.e("LiveCameraSegmenter", "Camera bind failed: ${e.message}", e)
                mainHandler.post {
                    if (!isDisposed.get()) {
                        latestOnError("Unable to open camera: ${e.localizedMessage ?: "Unavailable"}")
                    }
                }
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            isDisposed.set(true)
            try {
                cameraProvider?.unbindAll()
            } catch (_: Throwable) {}
            try {
                segmenter.close()
            } catch (_: Throwable) {}
            try {
                analyzerExecutor.shutdownNow()
            } catch (_: Throwable) {}
        }
    }
}

private fun applyFastSelfieMask(
    src: Bitmap,
    mask: com.google.mlkit.vision.segmentation.SegmentationMask
): Bitmap? {
    return try {
        val w = src.width
        val h = src.height
        val maskW = mask.width
        val maskH = mask.height
        val buf = mask.buffer ?: return null
        if (w <= 0 || h <= 0 || maskW <= 0 || maskH <= 0) return null

        buf.rewind()
        buf.order(ByteOrder.nativeOrder())
        val floats = buf.asFloatBuffer()
        val totalMask = maskW * maskH
        if (floats.remaining() < totalMask) return null

        val conf = FloatArray(totalMask)
        floats.get(conf)

        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        val sameSize = (w == maskW && h == maskH)
        for (y in 0 until h) {
            val rowOff = y * w
            val my = if (sameSize) y else ((y * maskH) / h).coerceIn(0, maskH - 1)
            val mRowOff = my * maskW
            for (x in 0 until w) {
                val mx = if (sameSize) x else ((x * maskW) / w).coerceIn(0, maskW - 1)
                val c = conf[mRowOff + mx]
                val idx = rowOff + x
                val px = pixels[idx]
                if (c >= 0.68f) {
                    pixels[idx] = (0xFF shl 24) or (px and 0x00FFFFFF)
                } else if (c <= 0.25f) {
                    pixels[idx] = 0
                } else {
                    val alpha = (((c - 0.25f) / 0.43f) * 255f).toInt().coerceIn(0, 255)
                    pixels[idx] = (alpha shl 24) or (px and 0x00FFFFFF)
                }
            }
        }

        Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
    } catch (_: Throwable) {
        null
    }
}

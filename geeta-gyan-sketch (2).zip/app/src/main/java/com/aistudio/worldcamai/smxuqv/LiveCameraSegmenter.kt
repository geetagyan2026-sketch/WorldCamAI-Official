package com.aistudio.worldcamai.smxuqv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.Segmenter
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

@Composable
fun LiveCameraSelfieSegmenterEffect(
    enabled: Boolean,
    lensFacing: Int,
    context: Context,
    onFrameSegmented: (Bitmap) -> Unit,
    onCameraError: (String) -> Unit
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val latestOnFrame by rememberUpdatedState(onFrameSegmented)
    val latestOnError by rememberUpdatedState(onCameraError)
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    DisposableEffect(enabled, lensFacing, lifecycleOwner) {
        if (!enabled) {
            return@DisposableEffect onDispose {}
        }

        val isDisposed = AtomicBoolean(false)
        val analyzerExecutor = Executors.newSingleThreadExecutor()
        var cameraProvider: ProcessCameraProvider? = null
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.STREAM_MODE)
            .build()
        val segmenter: Segmenter = Segmentation.getClient(options)

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            if (isDisposed.get()) return@addListener
            try {
                val provider = cameraProviderFuture.get()
                cameraProvider = provider

                val resolutionSelector = ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(480, 640),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                        )
                    )
                    .build()

                val imageAnalysis = ImageAnalysis.Builder()
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setResolutionSelector(resolutionSelector)
                    .build()

                imageAnalysis.setAnalyzer(analyzerExecutor) { imageProxy ->
                    if (isDisposed.get()) {
                        imageProxy.close()
                        return@setAnalyzer
                    }
                    try {
                        val rawBmp = imageProxy.toBitmap()
                        val rotation = imageProxy.imageInfo.rotationDegrees.toFloat()
                        val isFront = (lensFacing == CameraSelector.LENS_FACING_FRONT)

                        val orientedBmp = if (rotation != 0f || isFront) {
                            val matrix = Matrix().apply {
                                if (rotation != 0f) postRotate(rotation)
                                if (isFront) postScale(-1f, 1f)
                            }
                            Bitmap.createBitmap(rawBmp, 0, 0, rawBmp.width, rawBmp.height, matrix, true)
                        } else {
                            rawBmp
                        }

                        val inputImage = InputImage.fromBitmap(orientedBmp, 0)
                        val mask = Tasks.await(segmenter.process(inputImage), 800, TimeUnit.MILLISECONDS)

                        if (mask != null && !isDisposed.get()) {
                            val cutout = applyFastSelfieMask(orientedBmp, mask)
                            if (cutout != null && !isDisposed.get()) {
                                mainHandler.post {
                                    if (!isDisposed.get()) {
                                        latestOnFrame(cutout)
                                    }
                                }
                            }
                        }
                    } catch (t: Throwable) {
                        Log.w("LiveCameraSegmenter", "Frame analysis skipped: ${t.message}")
                    } finally {
                        imageProxy.close()
                    }
                }

                val selector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, selector, imageAnalysis)
            } catch (e: Throwable) {
                Log.e("LiveCameraSegmenter", "Camera bind failed: ${e.message}", e)
                mainHandler.post {
                    if (!isDisposed.get()) {
                        latestOnError("Unable to open camera: ${e.localizedMessage ?: "Unavailable"}")
                    }
                }
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            isDisposed.set(true)
            try {
                cameraProvider?.unbindAll()
            } catch (_: Throwable) {}
            try {
                segmenter.close()
            } catch (_: Throwable) {}
            try {
                analyzerExecutor.shutdownNow()
            } catch (_: Throwable) {}
        }
    }
}

private fun applyFastSelfieMask(
    src: Bitmap,
    mask: com.google.mlkit.vision.segmentation.SegmentationMask
): Bitmap? {
    return try {
        val w = src.width
        val h = src.height
        val maskW = mask.width
        val maskH = mask.height
        val buf = mask.buffer ?: return null
        if (w <= 0 || h <= 0 || maskW <= 0 || maskH <= 0) return null

        buf.rewind()
        buf.order(ByteOrder.nativeOrder())
        val floats = buf.asFloatBuffer()
        val totalMask = maskW * maskH
        if (floats.remaining() < totalMask) return null

        val conf = FloatArray(totalMask)
        floats.get(conf)

        val totalPixels = w * h
        val alphaMap = FloatArray(totalPixels)

        // 1. Bilinear upscale of ML Kit confidence mask to frame dimensions to prevent stair-stepping
        if (w == maskW && h == maskH) {
            System.arraycopy(conf, 0, alphaMap, 0, totalPixels)
        } else {
            val scaleX = (maskW - 1).coerceAtLeast(1).toFloat() / (w - 1).coerceAtLeast(1).toFloat()
            val scaleY = (maskH - 1).coerceAtLeast(1).toFloat() / (h - 1).coerceAtLeast(1).toFloat()
            for (y in 0 until h) {
                val fy = y * scaleY
                val y0 = fy.toInt().coerceIn(0, maskH - 1)
                val y1 = (y0 + 1).coerceAtMost(maskH - 1)
                val dy = fy - y0
                val row0 = y0 * maskW
                val row1 = y1 * maskW
                val outRow = y * w
                for (x in 0 until w) {
                    val fx = x * scaleX
                    val x0 = fx.toInt().coerceIn(0, maskW - 1)
                    val x1 = (x0 + 1).coerceAtMost(maskW - 1)
                    val dx = fx - x0
                    val c00 = conf[row0 + x0]
                    val c10 = conf[row0 + x1]
                    val c01 = conf[row1 + x0]
                    val c11 = conf[row1 + x1]
                    val top = c00 + (c10 - c00) * dx
                    val bot = c01 + (c11 - c01) * dx
                    alphaMap[outRow + x] = top + (bot - top) * dy
                }
            }
        }

        // 2. Separable 7-tap Gaussian feathering (~3px radius) for smooth hair & body edge blending
        val tempMap = FloatArray(totalPixels)
        val kernel = floatArrayOf(0.06f, 0.12f, 0.19f, 0.26f, 0.19f, 0.12f, 0.06f)

        // Horizontal pass
        for (y in 0 until h) {
            val rowOff = y * w
            for (x in 0 until w) {
                var sum = 0f
                for (k in -3..3) {
                    val sx = (x + k).coerceIn(0, w - 1)
                    sum += alphaMap[rowOff + sx] * kernel[k + 3]
                }
                tempMap[rowOff + x] = sum
            }
        }

        // Vertical pass + smoothstep alpha curve
        for (y in 0 until h) {
            val rowOff = y * w
            for (x in 0 until w) {
                var sum = 0f
                for (k in -3..3) {
                    val sy = (y + k).coerceIn(0, h - 1)
                    sum += tempMap[sy * w + x] * kernel[k + 3]
                }
                val t = ((sum - 0.18f) / 0.58f).coerceIn(0f, 1f)
                alphaMap[rowOff + x] = t * t * (3f - 2f * t)
            }
        }

        val srcPixels = IntArray(totalPixels)
        src.getPixels(srcPixels, 0, w, 0, 0, w, h)
        val outPixels = IntArray(totalPixels)

        // 3. Apply feathered alpha + subtle edge color decontamination from nearest solid foreground pixel
        val offsetsX = intArrayOf(-2, 2, 0, 0, -2, 2)
        val offsetsY = intArrayOf(0, 0, -2, 2, -2, 2)
        for (y in 0 until h) {
            val rowOff = y * w
            for (x in 0 until w) {
                val idx = rowOff + x
                val aFloat = alphaMap[idx]
                val alphaInt = (aFloat * 255f).toInt().coerceIn(0, 255)
                if (alphaInt <= 4) {
                    outPixels[idx] = 0
                } else if (alphaInt >= 238) {
                    outPixels[idx] = (0xFF shl 24) or (srcPixels[idx] and 0x00FFFFFF)
                } else {
                    var px = srcPixels[idx]
                    // Blend translucent boundary fringe slightly toward interior foreground color to remove room-wall halo
                    var bestX = x
                    var bestY = y
                    var bestA = aFloat
                    for (d in 0 until 6) {
                        val nx = (x + offsetsX[d]).coerceIn(0, w - 1)
                        val ny = (y + offsetsY[d]).coerceIn(0, h - 1)
                        val na = alphaMap[ny * w + nx]
                        if (na > bestA) {
                            bestA = na
                            bestX = nx
                            bestY = ny
                        }
                    }
                    if (bestA > aFloat + 0.12f) {
                        val innerPx = srcPixels[bestY * w + bestX]
                        val blend = ((1f - aFloat) * 0.55f).coerceIn(0f, 0.55f)
                        val r0 = (px ushr 16) and 0xFF
                        val g0 = (px ushr 8) and 0xFF
                        val b0 = px and 0xFF
                        val r1 = (innerPx ushr 16) and 0xFF
                        val g1 = (innerPx ushr 8) and 0xFF
                        val b1 = innerPx and 0xFF
                        val r = (r0 + (r1 - r0) * blend).toInt().coerceIn(0, 255)
                        val g = (g0 + (g1 - g0) * blend).toInt().coerceIn(0, 255)
                        val b = (b0 + (b1 - b0) * blend).toInt().coerceIn(0, 255)
                        px = (r shl 16) or (g shl 8) or b
                    }
                    outPixels[idx] = (alphaInt shl 24) or (px and 0x00FFFFFF)
                }
            }
        }

        Bitmap.createBitmap(outPixels, w, h, Bitmap.Config.ARGB_8888)
    } catch (_: Throwable) {
        null
    }
}

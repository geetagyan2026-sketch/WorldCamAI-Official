package com.aistudio.worldcamai.smxuqv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseDetector
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.Segmenter
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

@Composable
fun LiveCameraSelfieSegmenterEffect(
    enabled: Boolean,
    lensFacing: Int,
    context: Context,
    onFrameSegmented: (Bitmap) -> Unit,
    onCameraError: (String) -> Unit
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val latestOnFrame by rememberUpdatedState(onFrameSegmented)
    val latestOnError by rememberUpdatedState(onCameraError)
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    DisposableEffect(enabled, lensFacing, lifecycleOwner) {
        if (!enabled) {
            return@DisposableEffect onDispose {}
        }

        val isDisposed = AtomicBoolean(false)
        val analyzerExecutor = Executors.newSingleThreadExecutor()
        var cameraProvider: ProcessCameraProvider? = null
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.STREAM_MODE)
            .build()
        val segmenter: Segmenter = Segmentation.getClient(options)
        val poseOptions = PoseDetectorOptions.Builder()
            .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
            .build()
        val poseDetector: PoseDetector = PoseDetection.getClient(poseOptions)
        var lastPoseRegions: PoseFootRegions? = null
        var poseMissStreak = 0
        val prevConfRef = java.util.concurrent.atomic.AtomicReference<FloatArray?>(null)

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            if (isDisposed.get()) return@addListener
            try {
                val provider = cameraProviderFuture.get()
                cameraProvider = provider

                val resolutionSelector = ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(480, 640),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                        )
                    )
                    .build()

                val imageAnalysis = ImageAnalysis.Builder()
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setResolutionSelector(resolutionSelector)
                    .build()

                imageAnalysis.setAnalyzer(analyzerExecutor) { imageProxy ->
                    if (isDisposed.get()) {
                        imageProxy.close()
                        return@setAnalyzer
                    }
                    var rawBmp: Bitmap? = null
                    var orientedBmp: Bitmap? = null
                    var cutout: Bitmap? = null
                    try {
                        rawBmp = imageProxy.toBitmap()
                        val rotation = imageProxy.imageInfo.rotationDegrees.toFloat()
                        val isFront = (lensFacing == CameraSelector.LENS_FACING_FRONT)

                        orientedBmp = if (rotation != 0f || isFront) {
                            val matrix = Matrix().apply {
                                if (rotation != 0f) postRotate(rotation)
                                if (isFront) postScale(-1f, 1f)
                            }
                            Bitmap.createBitmap(rawBmp, 0, 0, rawBmp.width, rawBmp.height, matrix, true)
                        } else {
                            rawBmp
                        }
                        if (orientedBmp !== rawBmp && !rawBmp.isRecycled) {
                            rawBmp.recycle()
                            rawBmp = null
                        }

                        val inputImage = InputImage.fromBitmap(orientedBmp, 0)
                        val segTask = segmenter.process(inputImage)
                        val poseTask = poseDetector.process(inputImage)

                        val mask = Tasks.await(segTask, 800, TimeUnit.MILLISECONDS)
                        val framePose = try {
                            val p = Tasks.await(poseTask, 320, TimeUnit.MILLISECONDS)
                            extractPoseFootRegions(p, orientedBmp.width, orientedBmp.height)
                        } catch (_: Throwable) {
                            null
                        }
                        if (framePose != null && framePose.hasAnyShoe()) {
                            lastPoseRegions = framePose
                            poseMissStreak = 0
                        } else {
                            poseMissStreak++
                            if (poseMissStreak > 4) lastPoseRegions = null
                        }
                        val activePose = if (poseMissStreak <= 2) lastPoseRegions else null

                        if (mask != null && !isDisposed.get()) {
                            cutout = applyFastSelfieMask(orientedBmp, mask, activePose, prevConfRef)
                            if (cutout != null && !isDisposed.get()) {
                                val readyCutout = cutout
                                mainHandler.post {
                                    if (!isDisposed.get()) {
                                        latestOnFrame(readyCutout)
                                    }
                                }
                            }
                        }
                    } catch (t: Throwable) {
                        Log.w("LiveCameraSegmenter", "Frame analysis skipped: ${t.message}")
                    } finally {
                        try {
                            if (rawBmp != null && rawBmp !== cutout && !rawBmp.isRecycled) rawBmp.recycle()
                            if (orientedBmp != null && orientedBmp !== rawBmp && orientedBmp !== cutout && !orientedBmp.isRecycled) orientedBmp.recycle()
                        } catch (_: Throwable) {}
                        imageProxy.close()
                    }
                }

                val selector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, selector, imageAnalysis)
            } catch (e: Throwable) {
                Log.e("LiveCameraSegmenter", "Camera bind failed: ${e.message}", e)
                mainHandler.post {
                    if (!isDisposed.get()) {
                        latestOnError("Unable to open camera: ${e.localizedMessage ?: "Unavailable"}")
                    }
                }
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            isDisposed.set(true)
            try {
                cameraProvider?.unbindAll()
            } catch (_: Throwable) {}
            try {
                segmenter.close()
            } catch (_: Throwable) {}
            try {
                poseDetector.close()
            } catch (_: Throwable) {}
            try {
                analyzerExecutor.shutdownNow()
            } catch (_: Throwable) {}
        }
    }
}

private fun applyFastSelfieMask(
    src: Bitmap,
    mask: com.google.mlkit.vision.segmentation.SegmentationMask,
    poseRegions: PoseFootRegions? = null,
    prevConfRef: java.util.concurrent.atomic.AtomicReference<FloatArray?>? = null
): Bitmap? {
    return try {
        val w = src.width
        val h = src.height
        val maskW = mask.width
        val maskH = mask.height
        val buf = mask.buffer ?: return null
        if (w <= 0 || h <= 0 || maskW <= 0 || maskH <= 0) return null

        buf.rewind()
        buf.order(ByteOrder.nativeOrder())
        val floats = buf.asFloatBuffer()
        val totalMask = maskW * maskH
        if (floats.remaining() < totalMask) return null

        val rawConf = FloatArray(totalMask)
        floats.get(rawConf)

        // Temporal EMA Confidence Stabilizer: eliminates 30fps edge jitter/flickering while keeping fast motion crisp
        if (prevConfRef != null) {
            val prev = prevConfRef.get()
            if (prev != null && prev.size == totalMask) {
                for (i in 0 until totalMask) {
                    val curr = rawConf[i]
                    val old = prev[i]
                    val diff = kotlin.math.abs(curr - old)
                    val smoothed = when {
                        diff > 0.42f -> curr * 0.88f + old * 0.12f
                        old >= 0.72f && curr >= 0.50f -> curr * 0.58f + old * 0.42f
                        else -> curr * 0.52f + old * 0.48f
                    }
                    rawConf[i] = smoothed
                    prev[i] = smoothed
                }
            } else {
                prevConfRef.set(rawConf.copyOf())
            }
        }

        val totalPixels = w * h
        val srcPixels = IntArray(totalPixels)
        src.getPixels(srcPixels, 0, w, 0, 0, w, h)

        val conf = buildRefinedFullBodyMask(
            rawConfidences = rawConf,
            maskWidth = maskW,
            maskHeight = maskH,
            proxyPixels = srcPixels,
            proxyW = w,
            proxyH = h,
            poseRegions = poseRegions
        ) ?: return null

        val alphaMap = FloatArray(totalPixels)

        // 1. Bilinear upscale of unified pose-protected confidence mask to frame dimensions
        if (w == maskW && h == maskH) {
            System.arraycopy(conf, 0, alphaMap, 0, totalPixels)
        } else {
            val scaleX = (maskW - 1).coerceAtLeast(1).toFloat() / (w - 1).coerceAtLeast(1).toFloat()
            val scaleY = (maskH - 1).coerceAtLeast(1).toFloat() / (h - 1).coerceAtLeast(1).toFloat()
            for (y in 0 until h) {
                val fy = y * scaleY
                val y0 = fy.toInt().coerceIn(0, maskH - 1)
                val y1 = (y0 + 1).coerceAtMost(maskH - 1)
                val dy = fy - y0
                val row0 = y0 * maskW
                val row1 = y1 * maskW
                val outRow = y * w
                for (x in 0 until w) {
                    val fx = x * scaleX
                    val x0 = fx.toInt().coerceIn(0, maskW - 1)
                    val x1 = (x0 + 1).coerceAtMost(maskW - 1)
                    val dx = fx - x0
                    val c00 = conf[row0 + x0]
                    val c10 = conf[row0 + x1]
                    val c01 = conf[row1 + x0]
                    val c11 = conf[row1 + x1]
                    val top = c00 + (c10 - c00) * dx
                    val bot = c01 + (c11 - c01) * dx
                    alphaMap[outRow + x] = top + (bot - top) * dy
                }
            }
        }

        // 2. Topological Interior Lock (100% solid opacity inside torso/white shirts; zero see-through holes)
        var fgMinY = h
        var fgMaxY = -1
        val rowLeft = IntArray(h) { w }
        val rowRight = IntArray(h) { -1 }
        for (y in 0 until h) {
            val rowOff = y * w
            for (x in 0 until w) {
                if (alphaMap[rowOff + x] >= 0.65f) {
                    if (y < fgMinY) fgMinY = y
                    if (y > fgMaxY) fgMaxY = y
                    if (x < rowLeft[y]) rowLeft[y] = x
                    if (x > rowRight[y]) rowRight[y] = x
                }
            }
        }

        val hasPose = poseRegions != null && poseRegions.hasAnyShoe()
        if (fgMaxY > fgMinY) {
            val lowerBodyStartY = (fgMinY + ((fgMaxY - fgMinY) * 0.56f).toInt()).coerceIn(0, h - 1)
            val isExteriorBg = BooleanArray(totalPixels)
            val bfsQueue = IntArray(totalPixels)
            var qHead = 0
            var qTail = 0

            fun seedExterior(idx: Int) {
                if (!isExteriorBg[idx] && alphaMap[idx] < 0.65f) {
                    isExteriorBg[idx] = true
                    bfsQueue[qTail++] = idx
                }
            }

            for (x in 0 until w) {
                seedExterior(x)
                seedExterior((h - 1) * w + x)
            }
            for (y in 0 until h) {
                seedExterior(y * w)
                seedExterior(y * w + w - 1)
            }
            // Seed lower-body inter-leg corridor strictly below waist/hips so leg separation stays crisp
            for (y in lowerBodyStartY..fgMaxY) {
                val rl = rowLeft[y]
                val rr = rowRight[y]
                if (rr - rl < 6) continue
                val ny = (y + 0.5f) / h.toFloat()
                val poseMid = if (hasPose) poseRegions!!.interLegCenterXAt(ny) else null
                val midX = if (poseMid != null) (poseMid * w).toInt().coerceIn(rl + 1, rr - 1) else ((rl + rr) / 2)
                val halfBand = ((rr - rl) * 0.22f).toInt().coerceIn(2, w / 4)
                val x0 = (midX - halfBand).coerceAtLeast(rl + 1)
                val x1 = (midX + halfBand).coerceAtMost(rr - 1)
                val rowOff = y * w
                for (x in x0..x1) {
                    if (alphaMap[rowOff + x] < 0.65f) {
                        seedExterior(rowOff + x)
                    }
                }
            }

            while (qHead < qTail) {
                val curr = bfsQueue[qHead++]
                val cx = curr % w
                val cy = curr / w
                if (cx > 0) seedExterior(curr - 1)
                if (cx + 1 < w) seedExterior(curr + 1)
                if (cy > 0) seedExterior(curr - w)
                if (cy + 1 < h) seedExterior(curr + w)
            }

            for (y in fgMinY..fgMaxY) {
                val rowOff = y * w
                val rl = rowLeft[y]
                val rr = rowRight[y]
                if (rr <= rl) continue
                val rowMid = (rl + rr) * 0.5f
                val rowSpan = (rr - rl).toFloat()
                for (x in rl..rr) {
                    val idx = rowOff + x
                    if (!isExteriorBg[idx] && alphaMap[idx] < 1f) {
                        // Lock enclosed interior torso/clothing dips to 1.0f; keep outer arm loops protected
                        val nearBodyCore = kotlin.math.abs(x - rowMid) <= rowSpan * 0.34f
                        if (alphaMap[idx] >= 0.14f || nearBodyCore || y < lowerBodyStartY) {
                            alphaMap[idx] = 1f
                        }
                    }
                }
            }
        }

        // 3. Apply strict < 0.65 haze clamp + edge-only 1-2px perimeter decontamination (100% solid interior)
        val offsetsX = intArrayOf(-1, 1, 0, 0, -2, 2, -3, 3, -2, 2)
        val offsetsY = intArrayOf(0, 0, -1, 1, 0, 0, 0, 0, -2, 2)
        val fallbackShoeStartY = (h * 0.85f).toInt()

        for (y in 0 until h) {
            val rowOff = y * w
            val ny = (y + 0.5f) / h.toFloat()
            val yM1 = (y - 1).coerceAtLeast(0) * w
            val yP1 = (y + 1).coerceAtMost(h - 1) * w
            val yM2 = (y - 2).coerceAtLeast(0) * w
            val yP2 = (y + 2).coerceAtMost(h - 1) * w
            for (x in 0 until w) {
                val idx = rowOff + x
                val aFloat = alphaMap[idx]
                var alphaInt = (aFloat * 255f).toInt().coerceIn(0, 255)
                if (aFloat < 0.65f || alphaInt < 166) {
                    srcPixels[idx] = 0
                    continue
                }

                val xM1 = (x - 1).coerceAtLeast(0)
                val xP1 = (x + 1).coerceAtMost(w - 1)
                val xM2 = (x - 2).coerceAtLeast(0)
                val xP2 = (x + 2).coerceAtMost(w - 1)

                val touchesBg1Px =
                    alphaMap[rowOff + xM1] < 0.65f ||
                    alphaMap[rowOff + xP1] < 0.65f ||
                    alphaMap[yM1 + x] < 0.65f ||
                    alphaMap[yP1 + x] < 0.65f

                val touchesBg2Px = touchesBg1Px ||
                    alphaMap[rowOff + xM2] < 0.65f ||
                    alphaMap[rowOff + xP2] < 0.65f ||
                    alphaMap[yM2 + x] < 0.65f ||
                    alphaMap[yP2 + x] < 0.65f ||
                    alphaMap[yM1 + xM1] < 0.65f ||
                    alphaMap[yM1 + xP1] < 0.65f ||
                    alphaMap[yP1 + xM1] < 0.65f ||
                    alphaMap[yP1 + xP1] < 0.65f

                // Strictly lock every interior pixel (> 2px from background) at 100% opacity with untouched RGB
                if (!touchesBg2Px || alphaInt >= 236) {
                    srcPixels[idx] = (0xFF shl 24) or (srcPixels[idx] and 0x00FFFFFF)
                } else {
                    val nx = (x + 0.5f) / w.toFloat()
                    val inShoeZone = if (hasPose) {
                        poseRegions!!.classifyPixel(nx, ny, strictCore = false) != 0
                    } else {
                        y >= fallbackShoeStartY
                    }
                    var px = srcPixels[idx]
                    var bestX = x
                    var bestY = y
                    var bestA = aFloat
                    for (d in offsetsX.indices) {
                        val sx = (x + offsetsX[d]).coerceIn(0, w - 1)
                        val sy = (y + offsetsY[d]).coerceIn(0, h - 1)
                        val na = alphaMap[sy * w + sx]
                        if (na > bestA) {
                            bestA = na
                            bestX = sx
                            bestY = sy
                        }
                    }
                    if (bestA > aFloat + 0.08f) {
                        val innerPx = srcPixels[bestY * w + bestX]
                        val r0 = (px ushr 16) and 0xFF
                        val g0 = (px ushr 8) and 0xFF
                        val b0 = px and 0xFF
                        val r1 = (innerPx ushr 16) and 0xFF
                        val g1 = (innerPx ushr 8) and 0xFF
                        val b1 = innerPx and 0xFF
                        val luma0 = 0.299f * r0 + 0.587f * g0 + 0.114f * b0
                        val luma1 = 0.299f * r1 + 0.587f * g1 + 0.114f * b1
                        val colorDiff = kotlin.math.abs(r0 - r1) + kotlin.math.abs(g0 - g1) + kotlin.math.abs(b0 - b1)
                        val isLightHalo = (r0 > r1 + 14 && g0 > g1 + 14 && b0 > b1 + 14 && luma0 > 136f) ||
                            (luma0 - luma1 > 20f && luma0 > 142f)
                        val isSpill = (g0 > r0 * 1.08f && g0 > b0 * 1.08f && g0 > 45) || (b0 > 90 && g0 > 90 && b0 > r0 * 1.15f)
                        val isHighContrastHalo = isLightHalo || isSpill || colorDiff > 56
                        if (touchesBg1Px && isHighContrastHalo && aFloat < (if (inShoeZone && !isLightHalo) 0.72f else 0.78f)) {
                            srcPixels[idx] = 0
                            continue
                        }
                        val blend = if (isHighContrastHalo) {
                            if (inShoeZone && !isLightHalo) 0.52f else 0.94f
                        } else {
                            if (inShoeZone) 0.35f else 0.72f
                        }
                        val r = (r0 + (r1 - r0) * blend).toInt().coerceIn(0, 255)
                        val g = (g0 + (g1 - g0) * blend).toInt().coerceIn(0, 255)
                        val b = (b0 + (b1 - b0) * blend).toInt().coerceIn(0, 255)
                        px = (r shl 16) or (g shl 8) or b
                        alphaInt = alphaInt.coerceIn(172, 255)
                    }
                    srcPixels[idx] = (alphaInt shl 24) or (px and 0x00FFFFFF)
                }
            }
        }

        val out = Bitmap.createBitmap(srcPixels, w, h, Bitmap.Config.ARGB_8888)
        registerPoseFootRegions(out, poseRegions)
        out
    } catch (_: Throwable) {
        null
    }
}

package com.aistudio.worldcamai.smxuqv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseDetector
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.Segmenter
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.nio.ByteOrder
import java.util.Collections
import java.util.WeakHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs

private val liveCameraPurifiedCutouts = Collections.synchronizedMap(WeakHashMap<Bitmap, Boolean>())

fun isLiveCameraPurifiedCutout(bitmap: Bitmap?): Boolean {
    if (bitmap == null || bitmap.isRecycled) return false
    return liveCameraPurifiedCutouts[bitmap] == true
}

private fun markLiveCameraPurifiedCutout(bitmap: Bitmap) {
    liveCameraPurifiedCutouts[bitmap] = true
}

private class LiveSegmentBuffers {
    var rawConf = FloatArray(0)
    var prevConf = FloatArray(0)
    var prevMaskW = 0
    var prevMaskH = 0

    var upscaledAlpha = FloatArray(0)
    var erodedAlpha = FloatArray(0)
    var srcPixels = IntArray(0)
    var isExteriorBg = BooleanArray(0)
    var bfsQueue = IntArray(0)
    var rowLeft = IntArray(0)
    var rowRight = IntArray(0)

    fun ensureMaskSize(totalMask: Int, maskW: Int, maskH: Int) {
        if (rawConf.size != totalMask) {
            rawConf = FloatArray(totalMask)
        }
        if (prevMaskW != maskW || prevMaskH != maskH || prevConf.size != totalMask) {
            prevConf = FloatArray(totalMask)
            prevMaskW = maskW
            prevMaskH = maskH
        }
    }

    fun ensureFrameSize(w: Int, h: Int) {
        val totalPixels = w * h
        if (upscaledAlpha.size != totalPixels) upscaledAlpha = FloatArray(totalPixels)
        if (erodedAlpha.size != totalPixels) erodedAlpha = FloatArray(totalPixels)
        if (srcPixels.size != totalPixels) srcPixels = IntArray(totalPixels)
        if (isExteriorBg.size != totalPixels) isExteriorBg = BooleanArray(totalPixels)
        if (bfsQueue.size != totalPixels) bfsQueue = IntArray(totalPixels)
        if (rowLeft.size != h) rowLeft = IntArray(h)
        if (rowRight.size != h) rowRight = IntArray(h)
    }
}

@Composable
fun LiveCameraSelfieSegmenterEffect(
    enabled: Boolean,
    lensFacing: Int,
    context: Context,
    onFrameSegmented: (Bitmap) -> Unit,
    onCameraError: (String) -> Unit
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val latestOnFrame by rememberUpdatedState(onFrameSegmented)
    val latestOnError by rememberUpdatedState(onCameraError)
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    DisposableEffect(enabled, lensFacing, lifecycleOwner) {
        if (!enabled) {
            return@DisposableEffect onDispose {}
        }

        val isDisposed = AtomicBoolean(false)
        val analyzerExecutor = Executors.newSingleThreadExecutor()
        var cameraProvider: ProcessCameraProvider? = null
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.STREAM_MODE)
            .build()
        val segmenter: Segmenter = Segmentation.getClient(options)
        val poseOptions = PoseDetectorOptions.Builder()
            .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
            .build()
        val poseDetector: PoseDetector = PoseDetection.getClient(poseOptions)

        val poseInFlight = AtomicBoolean(false)
        val frameCounter = AtomicInteger(0)
        val lastPoseRegions = AtomicReference<PoseFootRegions?>(null)
        val poseMissStreak = AtomicInteger(0)
        var hasPrevMask = false
        val buffers = LiveSegmentBuffers()

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            if (isDisposed.get()) return@addListener
            try {
                val provider = cameraProviderFuture.get()
                cameraProvider = provider

                val resolutionSelector = ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(480, 640),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                        )
                    )
                    .build()

                val imageAnalysis = ImageAnalysis.Builder()
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setResolutionSelector(resolutionSelector)
                    .build()

                imageAnalysis.setAnalyzer(analyzerExecutor) { imageProxy ->
                    if (isDisposed.get()) {
                        imageProxy.close()
                        return@setAnalyzer
                    }
                    var rawBmp: Bitmap? = null
                    var orientedBmp: Bitmap? = null
                    var cutout: Bitmap? = null
                    try {
                        rawBmp = imageProxy.toBitmap()
                        val rotation = imageProxy.imageInfo.rotationDegrees.toFloat()
                        val isFront = (lensFacing == CameraSelector.LENS_FACING_FRONT)

                        orientedBmp = if (rotation != 0f || isFront) {
                            val matrix = Matrix().apply {
                                if (rotation != 0f) postRotate(rotation)
                                if (isFront) postScale(-1f, 1f)
                            }
                            Bitmap.createBitmap(rawBmp, 0, 0, rawBmp.width, rawBmp.height, matrix, true)
                        } else {
                            rawBmp
                        }
                        if (orientedBmp !== rawBmp && !rawBmp.isRecycled) {
                            rawBmp.recycle()
                            rawBmp = null
                        }

                        val frameW = orientedBmp.width
                        val frameH = orientedBmp.height
                        val inputImage = InputImage.fromBitmap(orientedBmp, 0)

                        // Non-blocking throttled pose inference (every ~6 frames) so 30fps SelfieSegmenter never stalls
                        val fNum = frameCounter.getAndIncrement()
                        if ((fNum % 6 == 0) && poseInFlight.compareAndSet(false, true)) {
                            poseDetector.process(inputImage)
                                .addOnSuccessListener { pose ->
                                    val regions = extractPoseFootRegions(pose, frameW, frameH)
                                    if (regions != null && regions.hasAnyShoe()) {
                                        lastPoseRegions.set(regions)
                                        poseMissStreak.set(0)
                                    } else {
                                        val misses = poseMissStreak.incrementAndGet()
                                        if (misses > 4) lastPoseRegions.set(null)
                                    }
                                }
                                .addOnCompleteListener {
                                    poseInFlight.set(false)
                                }
                        }

                        val segTask = segmenter.process(inputImage)
                        val mask = Tasks.await(segTask, 350, TimeUnit.MILLISECONDS)
                        val activePose = if (poseMissStreak.get() <= 3) lastPoseRegions.get() else null

                        if (mask != null && !isDisposed.get()) {
                            cutout = applyFastSelfieMask(
                                src = orientedBmp,
                                mask = mask,
                                poseRegions = activePose,
                                buffers = buffers,
                                hasPrevMask = hasPrevMask
                            )
                            hasPrevMask = true
                            if (cutout != null && !isDisposed.get()) {
                                val readyCutout = cutout
                                // Pre-warm cached foot anchor off the UI thread so live preview + 30fps encoder reuse it in O(1)
                                getCachedVideoFootAnchor(readyCutout)
                                mainHandler.post {
                                    if (!isDisposed.get()) {
                                        latestOnFrame(readyCutout)
                                    }
                                }
                            }
                        }
                    } catch (t: Throwable) {
                        Log.w("LiveCameraSegmenter", "Frame analysis skipped: ${t.message}")
                    } finally {
                        try {
                            if (rawBmp != null && rawBmp !== cutout && !rawBmp.isRecycled) rawBmp.recycle()
                            if (orientedBmp != null && orientedBmp !== rawBmp && orientedBmp !== cutout && !orientedBmp.isRecycled) {
                                orientedBmp.recycle()
                            }
                        } catch (_: Throwable) {}
                        imageProxy.close()
                    }
                }

                val selector = CameraSelector.Builder()
                    .requireLensFacing(lensFacing)
                    .build()

                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, selector, imageAnalysis)
            } catch (e: Throwable) {
                Log.e("LiveCameraSegmenter", "Camera bind failed: ${e.message}", e)
                mainHandler.post {
                    if (!isDisposed.get()) {
                        latestOnError("Unable to open camera: ${e.localizedMessage ?: "Unavailable"}")
                    }
                }
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            isDisposed.set(true)
            try {
                cameraProvider?.unbindAll()
            } catch (_: Throwable) {}
            try {
                segmenter.close()
            } catch (_: Throwable) {}
            try {
                poseDetector.close()
            } catch (_: Throwable) {}
            try {
                analyzerExecutor.shutdownNow()
            } catch (_: Throwable) {}
        }
    }
}

/**
 * Fast 30fps Real-Time Studio Cutout Pipeline:
 * 1) Temporal EMA stabilization to eliminate edge shimmer/flickering halo during motion.
 * 2) Bilinear upscale + lightweight shoe capsule protection.
 * 3) Topological Solid Body & Clothing Interior Lock (keeps white shirts, torso, chest, pants 100% alpha=255,
 *    while preserving clean gaps between legs and under arms).
 * 4) 1.5px inward mask erosion to shave off bright background fringes.
 * 5) Strict alpha cutoff (alpha < 140 -> 0) + edge color decontamination for ZERO white outline.
 */
private fun applyFastSelfieMask(
    src: Bitmap,
    mask: com.google.mlkit.vision.segmentation.SegmentationMask,
    poseRegions: PoseFootRegions? = null,
    buffers: LiveSegmentBuffers,
    hasPrevMask: Boolean
): Bitmap? {
    return try {
        val w = src.width
        val h = src.height
        val maskW = mask.width
        val maskH = mask.height
        val buf = mask.buffer ?: return null
        if (w <= 4 || h <= 4 || maskW <= 2 || maskH <= 2) return null

        buf.rewind()
        buf.order(ByteOrder.nativeOrder())
        val floats = buf.asFloatBuffer()
        val totalMask = maskW * maskH
        if (floats.remaining() < totalMask) return null

        val maskDimensionChanged = (buffers.prevMaskW != maskW || buffers.prevMaskH != maskH)
        buffers.ensureMaskSize(totalMask, maskW, maskH)
        buffers.ensureFrameSize(w, h)

        val rawConf = buffers.rawConf
        val prevConf = buffers.prevConf
        floats.get(rawConf, 0, totalMask)

        // 1. Temporal EMA stabilization on mask confidences (zero edge flicker when dancing/walking)
        if (hasPrevMask && !maskDimensionChanged) {
            for (i in 0 until totalMask) {
                val curr = rawConf[i]
                val old = prevConf[i]
                val diff = abs(curr - old)
                val smoothed = when {
                    diff > 0.36f -> curr * 0.90f + old * 0.10f
                    old >= 0.68f && curr >= 0.48f -> curr * 0.60f + old * 0.40f
                    else -> curr * 0.54f + old * 0.46f
                }
                rawConf[i] = smoothed
                prevConf[i] = smoothed
            }
        } else {
            System.arraycopy(rawConf, 0, prevConf, 0, totalMask)
        }

        val totalPixels = w * h
        val srcPixels = buffers.srcPixels
        src.getPixels(srcPixels, 0, w, 0, 0, w, h)

        val alphaMap = buffers.upscaledAlpha
        val erodedMap = buffers.erodedAlpha
        val hasPose = poseRegions != null && poseRegions.hasAnyShoe()

        // 2. Fast bilinear upscale to frame size + strict shoe core protection
        if (w == maskW && h == maskH) {
            System.arraycopy(rawConf, 0, alphaMap, 0, totalPixels)
        } else {
            val scaleX = (maskW - 1).coerceAtLeast(1).toFloat() / (w - 1).coerceAtLeast(1).toFloat()
            val scaleY = (maskH - 1).coerceAtLeast(1).toFloat() / (h - 1).coerceAtLeast(1).toFloat()
            for (y in 0 until h) {
                val fy = y * scaleY
                val y0 = fy.toInt().coerceIn(0, maskH - 1)
                val y1 = (y0 + 1).coerceAtMost(maskH - 1)
                val dy = fy - y0
                val row0 = y0 * maskW
                val row1 = y1 * maskW
                val outRow = y * w
                for (x in 0 until w) {
                    val fx = x * scaleX
                    val x0 = fx.toInt().coerceIn(0, maskW - 1)
                    val x1 = (x0 + 1).coerceAtMost(maskW - 1)
                    val dx = fx - x0
                    val c00 = rawConf[row0 + x0]
                    val c10 = rawConf[row0 + x1]
                    val c01 = rawConf[row1 + x0]
                    val c11 = rawConf[row1 + x1]
                    val top = c00 + (c10 - c00) * dx
                    val bot = c01 + (c11 - c01) * dx
                    alphaMap[outRow + x] = top + (bot - top) * dy
                }
            }
        }

        if (hasPose) {
            val shoeStartRow = (h * 0.62f).toInt().coerceIn(0, h - 1)
            for (y in shoeStartRow until h) {
                val ny = (y + 0.5f) / h.toFloat()
                val rowOff = y * w
                for (x in 0 until w) {
                    val idx = rowOff + x
                    val a = alphaMap[idx]
                    if (a in 0.30f..0.95f) {
                        val nx = (x + 0.5f) / w.toFloat()
                        if (poseRegions!!.classifyPixel(nx, ny, strictCore = true) != 0) {
                            alphaMap[idx] = 0.96f
                        }
                    }
                }
            }
        }

        // 3. Solid Body & Clothing Interior Lock (white shirts/torso stay 100% solid; leg/arm gaps stay open)
        val rowLeft = buffers.rowLeft
        val rowRight = buffers.rowRight
        var fgMinY = h
        var fgMaxY = -1
        for (y in 0 until h) {
            rowLeft[y] = w
            rowRight[y] = -1
            val rowOff = y * w
            for (x in 0 until w) {
                if (alphaMap[rowOff + x] >= 0.56f) {
                    if (y < fgMinY) fgMinY = y
                    if (y > fgMaxY) fgMaxY = y
                    if (x < rowLeft[y]) rowLeft[y] = x
                    if (x > rowRight[y]) rowRight[y] = x
                }
            }
        }

        if (fgMaxY > fgMinY) {
            val lowerBodyStartY = (fgMinY + ((fgMaxY - fgMinY) * 0.56f).toInt()).coerceIn(0, h - 1)
            val isExteriorBg = buffers.isExteriorBg
            java.util.Arrays.fill(isExteriorBg, false)
            val bfsQueue = buffers.bfsQueue
            var qHead = 0
            var qTail = 0

            fun seedExterior(idx: Int) {
                if (!isExteriorBg[idx] && alphaMap[idx] < 0.56f) {
                    isExteriorBg[idx] = true
                    bfsQueue[qTail++] = idx
                }
            }

            for (x in 0 until w) {
                seedExterior(x)
                seedExterior((h - 1) * w + x)
            }
            for (y in 0 until h) {
                seedExterior(y * w)
                seedExterior(y * w + w - 1)
            }
            // Seed lower-body inter-leg corridor so gaps between legs/shoes remain 100% transparent
            for (y in lowerBodyStartY..fgMaxY) {
                val rl = rowLeft[y]
                val rr = rowRight[y]
                if (rr - rl < 6) continue
                val ny = (y + 0.5f) / h.toFloat()
                val poseMid = if (hasPose) poseRegions!!.interLegCenterXAt(ny) else null
                val midX = if (poseMid != null) (poseMid * w).toInt().coerceIn(rl + 1, rr - 1) else ((rl + rr) / 2)
                val halfBand = ((rr - rl) * 0.22f).toInt().coerceIn(2, w / 4)
                val x0 = (midX - halfBand).coerceAtLeast(rl + 1)
                val x1 = (midX + halfBand).coerceAtMost(rr - 1)
                val rowOff = y * w
                for (x in x0..x1) {
                    if (alphaMap[rowOff + x] < 0.56f) {
                        seedExterior(rowOff + x)
                    }
                }
            }

            while (qHead < qTail) {
                val curr = bfsQueue[qHead++]
                val cx = curr % w
                val cy = curr / w
                if (cx > 0) seedExterior(curr - 1)
                if (cx + 1 < w) seedExterior(curr + 1)
                if (cy > 0) seedExterior(curr - w)
                if (cy + 1 < h) seedExterior(curr + w)
            }

            for (y in fgMinY..fgMaxY) {
                val rowOff = y * w
                val rl = rowLeft[y]
                val rr = rowRight[y]
                if (rr <= rl) continue
                val rowMid = (rl + rr) * 0.5f
                val rowSpan = (rr - rl).toFloat()
                for (x in rl..rr) {
                    val idx = rowOff + x
                    if (!isExteriorBg[idx] && alphaMap[idx] < 1f) {
                        val nearBodyCore = abs(x - rowMid) <= rowSpan * 0.34f
                        if (alphaMap[idx] >= 0.14f || nearBodyCore) {
                            alphaMap[idx] = 1f
                        }
                    }
                }
            }
        }

        // 4. 1.5px Inward Mask Erosion (eliminates outer halo fringes while keeping solid body interior intact)
        for (y in 0 until h) {
            val rowOff = y * w
            val yM1 = (y - 1).coerceAtLeast(0) * w
            val yP1 = (y + 1).coerceAtMost(h - 1) * w
            val yM2 = (y - 2).coerceAtLeast(0) * w
            val yP2 = (y + 2).coerceAtMost(h - 1) * w
            for (x in 0 until w) {
                val idx = rowOff + x
                val c = alphaMap[idx]
                if (c < 0.04f) {
                    erodedMap[idx] = 0f
                    continue
                }
                val xM1 = (x - 1).coerceAtLeast(0)
                val xP1 = (x + 1).coerceAtMost(w - 1)
                val xM2 = (x - 2).coerceAtLeast(0)
                val xP2 = (x + 2).coerceAtMost(w - 1)

                val minCard1 = minOf(
                    alphaMap[rowOff + xM1],
                    alphaMap[rowOff + xP1],
                    alphaMap[yM1 + x],
                    alphaMap[yP1 + x]
                )
                val minDiag1 = minOf(
                    alphaMap[yM1 + xM1],
                    alphaMap[yM1 + xP1],
                    alphaMap[yP1 + xM1],
                    alphaMap[yP1 + xP1]
                )
                val min1Px = minOf(minCard1, minDiag1 * 0.92f + minCard1 * 0.08f)
                val min2Px = minOf(
                    alphaMap[rowOff + xM2],
                    alphaMap[rowOff + xP2],
                    alphaMap[yM2 + x],
                    alphaMap[yP2 + x]
                )

                // Fast-path solid core interior (>2px away from background) stays 100% locked at 1.0f
                if (c >= 0.995f && min1Px >= 0.995f && min2Px >= 0.995f) {
                    erodedMap[idx] = 1f
                } else {
                    // Exact 1.5px weighted inward erosion
                    erodedMap[idx] = minOf(c, min1Px * 0.55f + min2Px * 0.45f)
                }
            }
        }

        // 5. Strict Alpha Cutoff (alpha < 140 -> 0) + Solid Interior Lock + Edge Color Decontamination
        val cutoffNorm = 140f / 255f
        val offsetsX = intArrayOf(-1, 1, 0, 0, -2, 2, -3, 3, -2, 2)
        val offsetsY = intArrayOf(0, 0, -1, 1, 0, 0, 0, 0, -2, 2)
        val fallbackShoeStartY = (h * 0.85f).toInt()

        for (y in 0 until h) {
            val rowOff = y * w
            val ny = (y + 0.5f) / h.toFloat()
            val yM1 = (y - 1).coerceAtLeast(0) * w
            val yP1 = (y + 1).coerceAtMost(h - 1) * w
            val yM2 = (y - 2).coerceAtLeast(0) * w
            val yP2 = (y + 2).coerceAtMost(h - 1) * w
            for (x in 0 until w) {
                val idx = rowOff + x
                val aFloat = erodedMap[idx]
                var alphaInt = (aFloat * 255f).toInt().coerceIn(0, 255)
                if (alphaInt < 140) {
                    srcPixels[idx] = 0
                    continue
                }

                val xM1 = (x - 1).coerceAtLeast(0)
                val xP1 = (x + 1).coerceAtMost(w - 1)
                val xM2 = (x - 2).coerceAtLeast(0)
                val xP2 = (x + 2).coerceAtMost(w - 1)

                val touchesBg1Px =
                    erodedMap[rowOff + xM1] < cutoffNorm ||
                    erodedMap[rowOff + xP1] < cutoffNorm ||
                    erodedMap[yM1 + x] < cutoffNorm ||
                    erodedMap[yP1 + x] < cutoffNorm

                val touchesBg2Px = touchesBg1Px ||
                    erodedMap[rowOff + xM2] < cutoffNorm ||
                    erodedMap[rowOff + xP2] < cutoffNorm ||
                    erodedMap[yM2 + x] < cutoffNorm ||
                    erodedMap[yP2 + x] < cutoffNorm ||
                    erodedMap[yM1 + xM1] < cutoffNorm ||
                    erodedMap[yM1 + xP1] < cutoffNorm ||
                    erodedMap[yP1 + xM1] < cutoffNorm ||
                    erodedMap[yP1 + xP1] < cutoffNorm

                // 100% solid interior pixels (>2px inside body/clothes) stay untouched alpha=255
                if (!touchesBg2Px || alphaInt >= 242) {
                    srcPixels[idx] = (0xFF shl 24) or (srcPixels[idx] and 0x00FFFFFF)
                } else {
                    val nx = (x + 0.5f) / w.toFloat()
                    val inShoeZone = if (hasPose) {
                        poseRegions!!.classifyPixel(nx, ny, strictCore = false) != 0
                    } else {
                        y >= fallbackShoeStartY
                    }
                    var px = srcPixels[idx]
                    var bestX = x
                    var bestY = y
                    var bestA = aFloat
                    for (d in offsetsX.indices) {
                        val sx = (x + offsetsX[d]).coerceIn(0, w - 1)
                        val sy = (y + offsetsY[d]).coerceIn(0, h - 1)
                        val na = erodedMap[sy * w + sx]
                        if (na > bestA) {
                            bestA = na
                            bestX = sx
                            bestY = sy
                        }
                    }
                    if (bestA > aFloat + 0.06f && bestA >= 0.80f) {
                        val innerPx = srcPixels[bestY * w + bestX]
                        val r0 = (px ushr 16) and 0xFF
                        val g0 = (px ushr 8) and 0xFF
                        val b0 = px and 0xFF
                        val r1 = (innerPx ushr 16) and 0xFF
                        val g1 = (innerPx ushr 8) and 0xFF
                        val b1 = innerPx and 0xFF
                        val luma0 = 0.299f * r0 + 0.587f * g0 + 0.114f * b0
                        val luma1 = 0.299f * r1 + 0.587f * g1 + 0.114f * b1
                        val colorDiff = abs(r0 - r1) + abs(g0 - g1) + abs(b0 - b1)
                        val isLightHalo = (r0 > r1 + 12 && g0 > g1 + 12 && b0 > b1 + 12 && luma0 > 132f) ||
                            (luma0 - luma1 > 18f && luma0 > 138f)
                        val isSpill = (g0 > r0 * 1.08f && g0 > b0 * 1.08f && g0 > 45) ||
                            (b0 > 90 && g0 > 90 && b0 > r0 * 1.15f)
                        val isHighContrastHalo = isLightHalo || isSpill || colorDiff > 50

                        if (touchesBg1Px && isHighContrastHalo && aFloat < (if (inShoeZone && !isLightHalo) 0.64f else 0.72f)) {
                            srcPixels[idx] = 0
                            continue
                        }
                        val blend = if (isHighContrastHalo) {
                            if (inShoeZone && !isLightHalo) 0.58f else 0.94f
                        } else {
                            if (inShoeZone) 0.42f else 0.76f
                        }
                        val r = (r0 + (r1 - r0) * blend).toInt().coerceIn(0, 255)
                        val g = (g0 + (g1 - g0) * blend).toInt().coerceIn(0, 255)
                        val b = (b0 + (b1 - b0) * blend).toInt().coerceIn(0, 255)
                        px = (r shl 16) or (g shl 8) or b
                        alphaInt = alphaInt.coerceIn(192, 255)
                    }
                    srcPixels[idx] = (alphaInt shl 24) or (px and 0x00FFFFFF)
                }
            }
        }

        val out = Bitmap.createBitmap(srcPixels, w, h, Bitmap.Config.ARGB_8888)
        markLiveCameraPurifiedCutout(out)
        registerPoseFootRegions(out, poseRegions)
        out
    } catch (_: Throwable) {
        null
    }
}

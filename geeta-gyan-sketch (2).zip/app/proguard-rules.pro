# Proguard rules for WorldCam AI
-keepattributes *Annotation*
-dontwarn javax.annotation.**

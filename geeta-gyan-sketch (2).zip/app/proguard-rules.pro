# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# Keep all application model, composables, and graphic rendering logic intact
-keep class com.aistudio.worldcamai.smxuqv.** { *; }
-keepclassmembers class com.aistudio.worldcamai.smxuqv.** { *; }

# Preserve graphics, bitmap and rendering classes
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}
-dontwarn android.graphics.**
-dontwarn androidx.compose.ui.graphics.**

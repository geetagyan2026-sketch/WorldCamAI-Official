path = "app/src/main/java/com/aistudio/worldcamai/smxuqv/MainActivity.kt"
with open(path, "r") as f:
    content = f.read()

# 1. Update validateMetadataMatch with Rule 6 (Island / River Island Biome Matching)
old_v = """    // 5. Transport Terminals (Airport, Railway Station)
    val isQueryStation = qLow.contains("railway station") || qLow.contains("airport") ||
                         qLow.contains("train station") || qLow.contains("bus stand") || qLow.contains("terminal")
    if (isQueryStation) {
        val hasScenicNature = metaLow.contains("waterfall") || metaLow.contains("glacier") ||
                              metaLow.contains("palace") || metaLow.contains("temple")
        val queryExplicitOther = qLow.contains("palace") || qLow.contains("temple") || qLow.contains("waterfall")
        if (hasScenicNature && !queryExplicitOther) {
            return false
        }
    }

    return true"""

new_v = """    // 5. Transport Terminals (Airport, Railway Station)
    val isQueryStation = qLow.contains("railway station") || qLow.contains("airport") ||
                         qLow.contains("train station") || qLow.contains("bus stand") || qLow.contains("terminal")
    if (isQueryStation) {
        val hasScenicNature = metaLow.contains("waterfall") || metaLow.contains("glacier") ||
                              metaLow.contains("palace") || metaLow.contains("temple")
        val queryExplicitOther = qLow.contains("palace") || qLow.contains("temple") || qLow.contains("waterfall")
        if (hasScenicNature && !queryExplicitOther) {
            return false
        }
    }

    // 6. Island / River Island / Delta Biomes (e.g. Majuli Island, Assam)
    val isQueryIsland = qLow.contains("island") || qLow.contains("river island") || qLow.contains("delta") || qLow.contains("atoll")
    if (isQueryIsland) {
        val hasIncompatibleOcean = metaLow.contains("open ocean") || metaLow.contains("cruise ship") || metaLow.contains("deep sea")
        val queryExplicitOcean = qLow.contains("ocean") || qLow.contains("sea")
        if (hasIncompatibleOcean && !queryExplicitOcean) {
            return false
        }
    }

    return true"""

if old_v in content:
    content = content.replace(old_v, new_v, 1)
    print("VALIDATE METADATA MATCH UPDATED SUCCESS")
else:
    print("OLD VALIDATE NOT FOUND")

# 2. Update Gemini Prompt for Strict Biome & Geographic Entity Matching
old_p = """                val prompt = \"\"\"
Search Google live for this travel destination, tourist spot, shopping mall, landmark, or location: "$trimmed".
AI Auto-Correct Directive: If the query "$trimmed" contains typos, spelling errors, jumbled letters, or phonetic gibberish (e.g., "Ttaaexhhli vvaalleeyy"), intelligently auto-correct and interpret the closest valid, authentic real-world geographical destination or landmark intended.
Fetch the top-ranked officially verified photograph and location details for this auto-corrected destination.
Strict Accuracy Rule: The photograph and metadata MUST accurately match the destination.
Return ONLY valid JSON formatted as:
{
  "name": "Exact Name of Location",
  "formattedAddress": "City, State, Country",
  "latitude": 0.0,
  "longitude": 0.0,
  "description": "Short vivid description of the destination",
  "funFact": "Interesting fact about the destination",
  "imageUrl": "Direct high-resolution verified photograph URL",
  "isWaterBody": false,
  "isNightOrNeon": false,
  "isSnowOrMountain": false,
  "isDesert": false,
  "surfaceType": "SAND, WATER, POLISHED_MARBLE, STONE, GRASS, SNOW, or CONCRETE"
}
\"\"\".trimIndent()"""

new_p = """                val prompt = \"\"\"
Search Google live for this travel destination, tourist spot, shopping mall, landmark, or location: "$trimmed".
AI Auto-Correct Directive: If the query "$trimmed" contains typos, spelling errors, jumbled letters, or phonetic gibberish, intelligently auto-correct and interpret the closest valid, authentic real-world geographical destination or landmark intended.
Strict Geographic & Biome Accuracy Rule: The photograph and metadata MUST strictly match the true real-world environment and region of "$trimmed" (e.g. searching for 'Majuli Island, Assam' must return river-island/Assam landscapes and never fall back to generic ocean beaches or incorrect biomes).
Fetch the top-ranked officially verified photograph and location details for this destination.
Return ONLY valid JSON formatted as:
{
  "name": "Exact Name of Location",
  "formattedAddress": "City, State, Country",
  "latitude": 0.0,
  "longitude": 0.0,
  "description": "Short vivid description of the destination",
  "funFact": "Interesting fact about the destination",
  "imageUrl": "Direct high-resolution verified photograph URL",
  "isWaterBody": false,
  "isNightOrNeon": false,
  "isSnowOrMountain": false,
  "isDesert": false,
  "surfaceType": "SAND, WATER, POLISHED_MARBLE, STONE, GRASS, SNOW, or CONCRETE"
}
\"\"\".trimIndent()"""

if old_p in content:
    content = content.replace(old_p, new_p, 1)
    print("GEMINI PROMPT UPDATED SUCCESS")
else:
    print("OLD PROMPT NOT FOUND")

with open(path, "w") as f:
    f.write(content)
